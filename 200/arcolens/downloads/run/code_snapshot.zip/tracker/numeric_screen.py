"""Numeric-token screening for the editorial adapter; semantic review remains separate."""

from __future__ import annotations

from datetime import date
from decimal import Decimal, ROUND_HALF_UP
import re
from typing import Any

# Import this from .llm_adapter when integrating into tracker/editorial.py.
from .llm_adapter import FORBIDDEN_PATTERNS

_MONTHS = {
    name.lower(): number
    for number, name in enumerate(
        (
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December",
        ),
        1,
    )
}
_MONTHS.update({name[:3]: number for name, number in list(_MONTHS.items())})
_MONTH_PATTERN = "|".join(sorted(_MONTHS, key=len, reverse=True))
_NUMERIC = re.compile(
    r"(?<![\w.])(?P<number>[+\-−]?(?:(?:\d{1,3}(?:,\d{3})+|\d+)"
    r"(?:\.\d+)?|\.\d+)(?:[eE][+\-]?\d+)?)(?!\w|\.\d)"
)
_SUFFIX = re.compile(
    r"^\s*(?P<points>pp\b|percentage[\s-]+points?\b)" r"|^\s*(?P<percent>%|percent\b)",
    re.IGNORECASE,
)


def _mask_calendar_dates(text: str, maximum_year: int) -> str:
    """Remove syntactically valid full calendar dates, never isolated day numbers."""

    def replace(match: re.Match[str]) -> str:
        groups = match.groupdict()
        year = int(groups["year"])
        month_text = groups["month"].lower().rstrip(".")
        month = int(month_text) if month_text.isdigit() else _MONTHS[month_text]
        day = int(groups["day"])
        try:
            date(year, month, day)
        except ValueError:
            return match.group(0)
        return (
            " " * len(match.group(0)) if 1 <= year <= maximum_year else match.group(0)
        )

    patterns = (
        r"(?<!\d)(?P<year>\d{4})-(?P<month>\d{2})-(?P<day>\d{2})(?!\d)",
        rf"\b(?P<month>{_MONTH_PATTERN})\.?\s+(?P<day>\d{{1,2}})(?:st|nd|rd|th)?[,]?\s+(?P<year>\d{{4}})\b",
        rf"\b(?P<day>\d{{1,2}})(?:st|nd|rd|th)?\s+(?P<month>{_MONTH_PATTERN})\.?[,]?\s+(?P<year>\d{{4}})\b",
    )
    for pattern in patterns:
        text = re.sub(pattern, replace, text, flags=re.IGNORECASE)
    return text


def _taxonomy_numbers(definition: Any) -> set[Decimal]:
    """Permit decimal taxonomy codes only when they occur in a cited selection."""
    result: set[Decimal] = set()
    if isinstance(definition, dict):
        for key, value in definition.items():
            if key in {"subdomains", "domains"} and isinstance(value, list):
                for label in value:
                    if isinstance(label, str):
                        match = re.match(r"^(\d+(?:\.\d+)?)(?:\b|$)", label)
                        if match:
                            result.add(Decimal(match.group(1)))
            else:
                result.update(_taxonomy_numbers(value))
    elif isinstance(definition, list):
        for value in definition:
            result.update(_taxonomy_numbers(value))
    return result


def _mask_source_references(text: str, ids: list[str], evidence: dict[str, Any]) -> str:
    """Recognize labeled source references without admitting those IDs as counts."""
    snapshot = date.fromisoformat(evidence["analysis_date"])
    months = "|".join(
        name for name, number in _MONTHS.items() if number == snapshot.month
    )
    # A shortened date is allowed only for this snapshot and with an explicit
    # export/snapshot label. An isolated day number remains an unsupported count.
    text = re.sub(
        rf"\b(?:{months})\.?\s+{snapshot.day}(?=\s+(?:export|snapshot)\b)",
        lambda match: " " * len(match.group()),
        text,
        flags=re.IGNORECASE,
    )
    for candidate in evidence.get("candidates", []):
        if not set(ids).intersection(candidate.get("evidence_ids", [])):
            continue
        incident = (
            candidate.get("chart_configuration", {})
            .get("filters", {})
            .get("incident_id")
        )
        if incident is None or not re.fullmatch(r"\d+", str(incident)):
            continue
        text = re.sub(
            rf"\bincident(?:\s+(?:ID|number))?\s+{re.escape(str(incident))}\b",
            lambda match: " " * len(match.group()),
            text,
            flags=re.IGNORECASE,
        )
    return text


def screen_text(text: str, ids: list[str], evidence: dict[str, Any]) -> dict[str, Any]:
    """Check numeric tokens against cited measures, not the truth of the sentence."""
    calculations = evidence["calculations"]
    missing = sorted(set(ids) - set(calculations))
    cited = [calculations[key] for key in ids if key in calculations]
    maximum_year = int(evidence["analysis_date"][:4])
    counts = {
        int(measure[key])
        for measure in cited
        for key in ("numerator", "denominator", "denominator_incident_count")
        if measure.get(key) is not None
    }
    numerators = {int(measure["numerator"]) for measure in cited}
    # Derived changes use only observed numerators. Years and denominators never
    # enter this arithmetic, avoiding the old closure over unrelated integers.
    count_changes = {b - a for a in numerators for b in numerators}
    allowed_numbers = {
        Decimal(value)
        for value in counts
        | count_changes
        | set(range(14))
        | set(range(1980, maximum_year + 1))
    }
    for measure in cited:
        allowed_numbers.update(_taxonomy_numbers(measure.get("definition", {})))
    shares = [
        measure["percent"] for measure in cited if measure.get("percent") is not None
    ]
    percentages = {
        Decimal(f"{share:.{digits}f}") for share in shares for digits in (0, 1, 2)
    }
    # Exact supplied percentages may legitimately have more than two decimals.
    # This does not allow nearby, uncited values at that precision.
    percentages.update(Decimal(str(share)) for share in shares)
    # Both conventional half-up rounding and Python's half-even formatting are
    # legitimate at a declared display precision; neither changes the raw value.
    percentages.update(
        Decimal(str(share)).quantize(Decimal(1).scaleb(-digits), rounding=ROUND_HALF_UP)
        for share in shares
        for digits in (0, 1, 2)
    )
    for before in numerators:
        if before:
            for after in numerators:
                change = Decimal(100) * Decimal(after - before) / Decimal(before)
                for digits in (0, 1, 2):
                    percentages.add(Decimal(f"{change:.{digits}f}"))
                    percentages.add(Decimal(f"{abs(change):.{digits}f}"))
    points = {
        Decimal(f"{abs(a-b):.{digits}f}")
        for a in shares
        for b in shares
        for digits in (0, 1, 2)
    }
    masked = _mask_source_references(
        _mask_calendar_dates(text, maximum_year), ids, evidence
    )
    bad_counts: set[int] = set()
    bad_numbers: set[str] = set()
    bad_percentages: set[str] = set()
    bad_points: set[str] = set()
    for match in _NUMERIC.finditer(masked):
        token = match.group("number")
        if len(token) > 64 or "e" in token.lower():
            bad_numbers.add(token)
            continue
        value = Decimal(token.replace(",", "").replace("−", "-"))
        suffix = _SUFFIX.match(masked[match.end() :])
        if suffix and suffix.group("points"):
            if abs(value) not in points:
                bad_points.add(token)
        elif suffix and suffix.group("percent"):
            if value not in percentages:
                bad_percentages.add(token)
        elif value not in allowed_numbers:
            if value == value.to_integral_value():
                bad_counts.add(int(value))
            else:
                bad_numbers.add(token)
    flags = [
        {"pattern": name, "match": match.group(0)}
        for name, pattern in FORBIDDEN_PATTERNS.items()
        for match in re.finditer(pattern, text, re.IGNORECASE)
    ]
    return {
        "evidence_ids_missing": missing,
        "unexplained_integers": sorted(bad_counts),
        "unexplained_numbers": sorted(bad_numbers),
        "unexplained_percentages": sorted(bad_percentages),
        "unexplained_percentage_points": sorted(bad_points),
        "editorial_flags": flags,
        "grounded": not (
            missing or bad_counts or bad_numbers or bad_percentages or bad_points
        ),
    }
