"""Markdown reports rendered from verified calculations and session-assisted wording."""

from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from typing import Any

from .audit import SUPPORTED, fraction_text, percent_text
from .calc import Engine
from .candidates import REPORT_TEXT
from .models import AuditRecord, Candidate

PRIMARY_ORDER = ["C01", "C02", "C03", "C04", "C05", "C06", "C07"]


def version_text(version: str | None) -> dict[str, str]:
    versions = REPORT_TEXT["versions"]
    return versions.get(version or "", versions[sorted(versions)[-1]])


def table(headers: list[str], rows: list[list[Any]]) -> list[str]:
    def cell(value: Any) -> str:
        return str(value).replace("|", "\\|").replace("\n", " ")

    return [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
    ] + ["| " + " | ".join(cell(value) for value in row) + " |" for row in rows]


def trend_summary(value: dict[str, Any], unit: str = "proportions") -> str:
    details = []
    if unit == "counts":
        details.append(f"endpoint {value['endpoint_count_change']:+,} records")
        if value.get("relative_count_change_pct") is not None:
            details.append(
                f"{value['relative_count_change_pct']:+.1f}% relative change"
            )
        for key, label in (
            ("strictly_increasing_count", "strict annual count rise"),
            ("strictly_decreasing_count", "strict annual count decline"),
        ):
            if value.get(key):
                details.append(label)
        steps = ", ".join(
            f"{s['from_year']}→{s['to_year']} {s['count_direction']}"
            for s in value.get("steps", [])
        )
        return "; ".join(details) + (f"; count steps: {steps}" if steps else "")
    if value.get("endpoint_delta_pp") is not None:
        details.append(f"endpoint {value['endpoint_delta_pp']:+.2f} pp")
    for key, label in (
        ("strictly_decreasing_share", "strict annual share decline"),
        ("strictly_increasing_share", "strict annual share rise"),
        ("strictly_increasing_count", "strict annual count rise"),
        ("strictly_decreasing_count", "strict annual count decline"),
    ):
        if value.get(key):
            details.append(label)
    reversals = [
        f"{s['from_year']}→{s['to_year']} {s['share_direction']}"
        for s in value.get("steps", [])
    ]
    return "; ".join(details) + (
        f"; steps: {', '.join(reversals)}" if reversals else ""
    )


def robustness_summary(variant: dict[str, Any]) -> str:
    prefix = ""
    if variant.get("identical_to_base"):
        prefix = "no effect (0 records removed): "
    elif variant.get("records_removed"):
        prefix = f"{variant['records_removed']} records removed: "
    return prefix + robustness_body(variant)


def robustness_body(variant: dict[str, Any]) -> str:
    if "top_categories_growth" in variant:
        return f"total growth {variant['total_growth']:+,} records; " + "; ".join(
            f"{row['subdomain']}: {row['start_count']}→{row['end_count']} ({row['growth']:+d}, {row['share_of_total_growth_pct']}% of growth)"
            for row in variant["top_categories_growth"]
        )
    if "top_categories" in variant:
        text = "; ".join(
            f"{point['category']}: {fraction_text(point)}"
            for point in variant["top_categories"]
        )
        if variant.get("lead_pp") is not None:
            text += f"; lead {variant['lead_pp']:.2f} pp; same ranking-margin screen passes: {variant['same_ranking_margin_rule_passed']}"
        return text
    if "points" in variant:
        points = variant["points"]
        unit = variant.get("display_unit", "proportions")
        brief = " → ".join(
            f"{point.get('label', point.get('year', 'comparison'))}: "
            + (
                f"{point['numerator']:,} records"
                if unit == "counts"
                else fraction_text(point)
            )
            for point in points
        )
        standalone_delta = variant.get("endpoint_delta_pp", variant.get("delta_pp"))
        if standalone_delta is not None:
            brief += f"; change {standalone_delta:+.2f} pp"
        if "eligibility" in variant:
            brief += f"; numerical candidate screen passes: {variant['eligibility']['passed']}"
        return brief + (
            "; " + trend_summary(variant["trend"], unit) if "trend" in variant else ""
        )
    if "numerator" in variant:
        return fraction_text(variant)
    return json.dumps(variant, ensure_ascii=False)


def candidate_block(candidate: Candidate) -> list[str]:
    lines = [
        f"### {candidate.candidate_id} — {candidate.title}",
        "",
        f"**Finding.** {candidate.finding}",
        "",
        f"**Review status:** `{candidate.review_state}`. **Selection stage:** `{candidate.selection_stage}`. **Eligibility:** `{json.dumps(candidate.eligibility, ensure_ascii=False)}`.",
        "",
        "**Proposed website wording**",
        "",
        "> " + candidate.proposed_website_text,
        "",
        "**Chart configuration**"
        + (
            " (no faithful current chart; supporting table)"
            if not candidate.chart_ids
            else ""
        ),
        "",
    ]
    for key, value in candidate.chart_configuration.items():
        if isinstance(value, (dict, list)):
            value = json.dumps(value, ensure_ascii=False)
        lines.append(f"- **{key.replace('_', ' ').capitalize()}:** {value}")
    lines += [
        "",
        f"**Confidence in calculation:** {candidate.calculation_confidence}",
        "",
        f"**Confidence in interpretation:** {candidate.interpretation_confidence}",
        "",
        "**Caveats**",
        "",
        *["- " + item for item in candidate.caveats],
        "",
        "**Robustness checks**",
        "",
        *table(
            ["Alternative", "Calculated result"],
            [
                [variant["alternative"], robustness_summary(variant)]
                for variant in candidate.robustness
            ],
        ),
        "",
        f"**Executable evidence:** ID `{candidate.candidate_id}`. All {len(candidate.evidence_ids)} associated calculation IDs and their set references are in `candidates.json`; use `python3 -m tracker evidence --run <this-run> --candidate {candidate.candidate_id}`.",
        "",
    ]
    return lines


def grouped_by_chart(candidates: list[Candidate]) -> list[str]:
    lines: list[str] = []
    emitted: set[str] = set()
    for chart_id in PRIMARY_ORDER:
        selected = [
            c
            for c in candidates
            if c.chart_ids
            and c.chart_ids[0] == chart_id
            and c.candidate_id not in emitted
        ]
        if not selected:
            continue
        lines += [f"## {chart_id}", ""]
        for candidate in selected:
            emitted.add(candidate.candidate_id)
            lines += candidate_block(candidate)
    table_only = [c for c in candidates if c.candidate_id not in emitted]
    if table_only:
        lines += ["## Supporting table only (no faithful current chart)", ""]
        for candidate in table_only:
            lines += candidate_block(candidate)
    return lines


def discovery_summary(ledger: dict[str, Any]) -> list[str]:
    entries = ledger["entries"]
    counts = ledger["counts"]
    lines = [
        "## Discovery ledger summary (data-driven stage, v2)",
        "",
        f"Discovery version `{ledger['discovery_version']}`; weights `{json.dumps(ledger['weights'])}`. Stages: "
        + "; ".join(ledger["stages"])
        + ".",
        "",
        *table(
            ["Decision", "Cells"],
            [[k, v] for k, v in sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))],
        ),
        "",
        "Every eligible cell has a decision and a reason in `discovery_ledger.json`. Selected and highest-scoring non-selected cells:",
        "",
    ]
    shown = [e for e in entries if e["decision"] == "selected"] + sorted(
        [e for e in entries if e["decision"] != "selected" and e["score"] is not None],
        key=lambda e: -e["score"],
    )[:12]
    lines += table(
        ["Rank/decision", "Family", "Cell", "Score", "Components", "Reason"],
        [
            [
                f"{e.get('rank', '')} {e['decision']}".strip(),
                e["family"],
                e["name"],
                "" if e["score"] is None else f"{e['score']:.3f}",
                (
                    ""
                    if not e["components"]
                    else ", ".join(f"{k} {v:.2f}" for k, v in e["components"].items())
                ),
                (e["reason"] or "")[:160],
            ]
            for e in shown
        ],
    )
    routed = [
        e
        for e in entries
        if e["decision"]
        in {
            "route_to_claim_audit",
            "route_to_archived_replay",
            "complement_of_audited_claim",
        }
    ]
    if routed:
        lines += [
            "",
            "Cells routed to the published-claim audit or to archived replays instead of being proposed as new:",
            "",
        ]
        lines += table(
            ["Cell", "Decision", "Claims"],
            [
                [
                    e["name"],
                    e["decision"],
                    ", ".join(e["published_claim_ids"]) or "(complement)",
                ]
                for e in routed
            ],
        )
    lines += ["", *[f"- {note}" for note in ledger.get("notes", [])], ""]
    return lines


def write_candidate_report(
    output: Path,
    engine: Engine,
    candidates: list[Candidate],
    outcomes: list[dict[str, Any]],
    search_ledger: list[dict[str, Any]],
    discovery_ledger: dict[str, Any] | None = None,
    version: str | None = None,
) -> None:
    text = version_text(version)
    templates = [c for c in candidates if c.selection_stage == "session_template"]
    discovered = [c for c in candidates if c.selection_stage == "data_driven_discovery"]
    emergence = sum(1 for item in search_ledger if item.get("emergence_candidate"))
    lines = [
        "# Candidate insights — human review edition",
        "",
        f"**Analysis date:** {engine.analysis_date}. **Snapshot:** {len(engine.rows):,} distinct incident records. **Status:** {text['candidate_status']}",
        "",
        "Calculations are deterministic. Candidate selection, caveats and wording are preserved in code, configuration and prompts. All numerical evidence is in `calculations.json`, with numerator and denominator incident IDs in content-addressed `evidence/id_sets/` files.",
        "",
        f"The logged exploratory search screened {len(search_ledger)} comparisons; {sum(item['eligible'] for item in search_ledger)} passed its numerical screen and {emergence} more are admitted to the discovery stage under the emergence rule. The five session templates are the audited baseline; the data-driven discovery stage proposes additional candidates with a full selection ledger. Neither is a significance ranking. See `selection_decisions.json`, `discovery_ledger.json`, `tables/search_ledger.csv`, and `inputs/methodology.md`.",
        "",
        "## Read before using the charts",
        "",
        "- Use the recorded incident date, not the classification timestamp or assumed report-submission date.",
        "- Keep all primary categories visible for an all-incident percentage. Hiding legend categories changes the live percentage denominator.",
        "- All Subdomains and Harm category proportions are assignment shares. An incident may contribute to several categories.",
        "- The live mirror differs from this export. Chart configurations describe a compatible view, not an assertion that today's public chart already reproduces these numbers.",
        f"- {engine.analysis_date.year} is excluded from complete-year comparisons. All-record cross-sectional results retain the current-year and any undated records; missing dates are reported in quality.json.",
        "",
        "## Current chart coverage",
        "",
        *table(
            ["Chart/surface", "Candidates", "Outcome"],
            [
                [
                    item["chart_id"] + ": " + item["name"],
                    ", ".join(item["candidate_ids"]) or "None",
                    item["decision"],
                ]
                for item in outcomes
                if item["publication_status"] == "current_tracker"
            ],
        ),
        "",
    ]
    lines += ["# Part 1 — retained session templates (audited baseline)", ""]
    lines += grouped_by_chart(templates)
    if discovered:
        lines += [
            "# Part 2 — data-driven discovery candidates (v2)",
            "",
            "Selected by the declared discovery stage from the exploratory ledger; all texts are templated from calculations and require human review.",
            "",
        ]
        lines += grouped_by_chart(discovered)
    if discovery_ledger:
        lines += discovery_summary(discovery_ledger)
    lines += [
        "## No-candidate and historical surfaces",
        "",
        "C06's potential-cause diagram does not establish causal effects. C07's individual NatSec radar cannot portray an aggregate trend; its sample-size check is reported in the coverage table. The two framework pages define scales; they are not empirical charts. Historical surfaces and dated-study figures are itemized in `chart_outcomes.json` and `inputs/chart_inventory.json`; no current chart is inferred from an archived Airtable shell.",
        "",
        f"## {text['limit_heading']}",
        "",
        "No export-to-export changes, historical submission volumes, delay corrections, historical classification versions, population prevalence, or causation can be identified from this single export. Late entry can only be bounded from record order under a stated assumption. Human reviewers should inspect contributing cases and the chart/version discrepancies before publication.",
        "",
    ]
    (output / "candidate_insights.md").write_text("\n".join(lines), encoding="utf-8")


def audit_blocks(records: list[AuditRecord]) -> list[str]:
    lines = []
    for record in records:
        lines += [
            f"## {record.claim_id} — {record.status}",
            "",
            f"[Source]({record.source_url}) · retrieved **{record.retrieved_at_utc}** · `{record.publication_status}`",
            "",
            "**Exact published wording**",
            "",
            *["> " + line for line in record.exact_wording.splitlines()],
            "",
            f"**Original window:** {record.original_time_window}",
            "",
            f"**Interpretation:** {record.interpretation}",
            "",
            f"**Evidence and reason:** {record.reason}",
            "",
        ]
        if record.component_checks:
            lines += [
                "**Component checks:** `claim_audit.json` preserves every component, alternative denominator and annual step; a composite claim is not passed merely because one part matches.",
                "",
            ]
            for component in record.component_checks:
                if "component" in component and "status" in component:
                    lines.append(
                        f"- {component['component']}: **{component['status']}**"
                        + (
                            " — " + component["interpretation"]
                            if component.get("interpretation")
                            else ""
                        )
                    )
            lines.append("")
        if record.discrepancy_explanation:
            lines += [
                f"**Discrepancy explanation:** {record.discrepancy_explanation}",
                "",
            ]
        if record.proposed_revision:
            heading = (
                "**Current-export replay (not a correction of the archived text; original snapshot unavailable)**"
                if record.publication_status == "archived_tracker"
                else "**Suggested revision**"
            )
            lines += [heading, "", "> " + record.proposed_revision, ""]
        if record.editorial_flags:
            lines += ["**Editorial flags:** " + "; ".join(record.editorial_flags), ""]
        lines += [
            f"**Calculation definition:** `{json.dumps(record.calculation_definition,ensure_ascii=False)}`",
            "",
            f"**Incident-level evidence:** {len(record.evidence_ids)} calculation references in `claim_audit.json`. Run `python3 -m tracker evidence --run <this-run> --claim {record.claim_id}`. Source/quote hashes and raw source paths are retained in the same registry.",
            "",
        ]
    return lines


def write_audit_reports(output: Path, audit: list[AuditRecord]) -> None:
    current = [
        r for r in audit if r.publication_status == "current_tracker" and r.empirical
    ]
    counts = Counter(r.status for r in current)
    lines = [
        "# Existing published insights — current-page audit",
        "",
        "These statuses assess the supplied export under explicit interpretations, not the original publication snapshot. Fixed historical windows are recalculated without extending them to the current partial year. Exact wording is preserved after HTML entity/whitespace extraction, including publication typos.",
        "",
        f"**Scope:** {len(current)} current empirical quotation blocks, including repeated validation prose. Composite statements have component checks. The {sum(1 for r in current if r.calculation_definition.get('handler') == 'validation_unavailable')} copies of the reliability paragraph are separate source occurrences, not independent findings.",
        "",
        *table(
            ["Status", "Quotation blocks"],
            [[status, count] for status, count in sorted(counts.items())],
        ),
        "",
        *table(
            ["Claim", "Status", "Qualification", "Source"],
            [
                [
                    r.claim_id,
                    r.status,
                    (
                        "Rounded numerical component; ‘Almost all’ remains editorial"
                        if r.calculation_definition.get("handler") == "timing_rounded"
                        else "See component checks and interpretation"
                    ),
                    f"[page]({r.source_url})",
                ]
                for r in current
            ],
        ),
        "",
        "Ambiguous ‘about half’, ‘dramatically’, ‘vast majority’ and ‘few’ expressions receive exact numerical context and an editorial flag; no tolerance is silently invented. ‘Supported’ is scoped to the stated calculation and does not validate the LLM labels or population representativeness.",
        "",
        *audit_blocks(current),
    ]
    (output / "existing_insight_audit.md").write_text(
        "\n".join(lines), encoding="utf-8"
    )
    archived = [
        r for r in audit if r.publication_status == "archived_tracker" and r.empirical
    ]
    (output / "archived_insight_replays.md").write_text(
        "\n".join(
            [
                "# Archived insights — explicitly bounded retrospective replays",
                "",
                "These are archived `/old-ai-incident-tracker/` claims, not current dashboard text. Missing original snapshots/relative endpoints make many historical claims unverifiable. Replays expose what the current CSV says under named definitions; they do not establish what an earlier export contained.",
                "",
                *audit_blocks(archived),
            ]
        ),
        encoding="utf-8",
    )
    remaining = [r for r in audit if r not in current and r not in archived]
    (output / "scope_and_study_dispositions.md").write_text(
        "\n".join(
            [
                "# Scope, reference and dated-study dispositions",
                "",
                "All extracted quotation records have a structured disposition. ‘Not verifiable’ here often means the CSV is the wrong evidence for a framework definition, interface description, historical coverage claim or small validation study; it does not mean that source is false.",
                "",
                *audit_blocks(remaining),
            ]
        ),
        encoding="utf-8",
    )


def write_summary(
    output: Path,
    metadata: dict[str, Any],
    candidates: list[Candidate],
    audit: list[AuditRecord],
    quality: dict[str, Any],
) -> None:
    text = version_text(metadata.get("code", {}).get("version"))
    current = [
        r for r in audit if r.publication_status == "current_tracker" and r.empirical
    ]
    attention = [r for r in current if r.status != SUPPORTED]
    order = {
        "Unsupported under the stated interpretation": 0,
        "Needs a numerical or wording update": 1,
        "Not verifiable with the available data or an ambiguous definition": 2,
    }
    attention.sort(key=lambda r: (order.get(r.status, 9), r.claim_id))
    templates = [
        c
        for c in candidates
        if c.selection_stage == "session_template"
        and c.review_state == "human_review_required"
    ]
    discovered = [
        c
        for c in candidates
        if c.selection_stage == "data_driven_discovery"
        and c.review_state == "human_review_required"
    ]
    lines = [
        "# Start here — AI Incident Tracker evidence prototype",
        "",
        f"**Run:** `{metadata['run_id']}` · **Code version:** `{metadata.get('code', {}).get('version', '?')}` · **Analysis date:** {metadata['analysis_date']} · **Input SHA-256:** `{metadata['input']['sha256']}`",
        "",
        f"{text['review_lineage']}",
        "",
        "## Results — retained session templates",
        "",
        *[f"- **{c.candidate_id}:** {c.finding}" for c in templates],
        "",
        "## Results — data-driven discovery candidates",
        "",
        *(
            [f"- **{c.candidate_id}:** {c.finding}" for c in discovered]
            or ["- none selected in this run"]
        ),
        "",
        f"## Current published claims needing attention ({len(attention)} of {len(current)}; every status except Supported, grouped by status)",
        "",
        *[f"- **{r.claim_id} — {r.status}:** {r.reason}" for r in attention],
        "",
        "## Supported current claims",
        "",
        *[
            f"- **{r.claim_id}:** {r.proposed_revision or r.reason}"
            for r in current
            if r.status == SUPPORTED
        ],
        "",
        "## Review files",
        "",
        "- [Candidate insights by chart](candidate_insights.md)",
        "- [Current published-insight audit](existing_insight_audit.md)",
        "- [Archived insight replays](archived_insight_replays.md)",
        "- [Scope and dated-study dispositions](scope_and_study_dispositions.md)",
        "- [Machine-readable candidates](candidates.json), [claim registry/audit](claim_audit.json), [calculation definitions and results](calculations.json)",
        "- [Run metadata](run_metadata.json), [validation](validation.json), [data quality](quality.json)",
        "- Source inventory, raw claim registry and configuration snapshots are under `inputs/`. Supporting CSV tables are under `tables/`; complete numerator/denominator sets are under `evidence/id_sets/`.",
        "",
        "## What is working",
        "",
        "The offline pipeline snapshots a CSV, validates the schema and IDs, calculates exploratory tables and sensitivity checks, audits preserved claims, emits reports and machine-readable evidence, and records code/config/prompt hashes. The default cadence is monthly; fortnightly uses the same calculations. A CLI evidence command exposes the exact incident records behind a finding.",
        "",
        "## Limits",
        "",
        "This is a single-export analysis, not a reconstructed history of monthly exports; a comparison tool exists but no earlier real export does. "
        + REPORT_TEXT["chart_caveat"]
        + " Full report-level corroboration, the meaning of zero-coded severity cells, and independent validation of classification accuracy remain open. LLM generation/review was session-assisted; the provider adapter exists but has not been executed against a live API. Publication decisions remain with humans.",
        "",
    ]
    (output / "START_HERE.md").write_text("\n".join(lines), encoding="utf-8")
