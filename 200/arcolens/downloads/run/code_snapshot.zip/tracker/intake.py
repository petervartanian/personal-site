"""Read-only discovery of dated local analysis exports; no network access."""

from __future__ import annotations

import argparse
import csv
from datetime import date
import hashlib
import json
from pathlib import Path
import re
import stat
import sys
from typing import Any, Callable

EXPORT_NAME = re.compile(r"incident_tracker_export_(\d{4}-\d{2}-\d{2})\.csv\Z")
DIGEST = re.compile(r"[0-9a-f]{64}\Z")


def file_hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def previous_input(project: Path) -> dict[str, Any] | None:
    """Read pointer and run metadata; full artifact verification is separate."""
    pointer_path = project / "LATEST_RUN.json"
    if not pointer_path.exists():
        return None
    pointer = json.loads(pointer_path.read_text())
    run = (project / pointer["path"]).resolve()
    if not run.is_relative_to(project.resolve()):
        raise ValueError("Latest-run pointer escapes the project directory")
    metadata = json.loads((run / "run_metadata.json").read_text())
    digest = metadata["input"]["sha256"]
    if not isinstance(digest, str) or not DIGEST.fullmatch(digest):
        raise ValueError("Latest-run metadata has an invalid input SHA256")
    if pointer.get("input_sha256") != digest:
        raise ValueError("Latest-run pointer and metadata input hashes disagree")
    filename = Path(metadata["input"].get("original_path", "")).name
    matched = EXPORT_NAME.fullmatch(filename)
    export_day = date.fromisoformat(matched[1]) if matched else None
    return {
        "run_id": pointer.get("run_id", run.name),
        "input_sha256": digest,
        "export_date": export_day.isoformat() if export_day else None,
        "analysis_date": metadata["analysis_date"],
        "verification_scope": "Pointer/metadata agreement only; verify the complete run before analysis.",
    }


def inspect_exports(
    project: Path,
    directories: list[Path],
    today: date,
    loader: Callable[[Path, date], list[Any]],
) -> dict[str, Any]:
    """Return JSON-compatible intake facts without altering any input or run."""
    baseline = previous_input(project)
    observations: list[dict[str, Any]] = []
    directories_checked: list[dict[str, Any]] = []
    seen_paths: set[str] = set()
    discovery_errors: list[str] = []
    for directory in directories:
        directory = directory.expanduser().absolute()
        if not directory.exists():
            directories_checked.append({"path": str(directory), "status": "missing"})
            continue
        try:
            children = sorted(directory.iterdir())
        except OSError as error:
            discovery_errors.append(f"Cannot read {directory}: {error}")
            continue
        directories_checked.append({"path": str(directory), "status": "read"})
        for path in children:
            matched = EXPORT_NAME.fullmatch(path.name)
            if not matched or str(path) in seen_paths:
                continue
            seen_paths.add(str(path))
            item: dict[str, Any] = {"path": str(path), "filename_date": matched[1]}
            try:
                export_day = date.fromisoformat(matched[1])
                if export_day > today:
                    raise ValueError("Filename date is later than the intake date")
                before = path.lstat()
                if not stat.S_ISREG(before.st_mode):
                    raise ValueError(
                        "Only regular local files are accepted; links are not followed"
                    )
                digest_before = file_hash(path)
                rows = loader(path, export_day)
                after = path.lstat()
                digest_after = file_hash(path)
                if (
                    (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
                    != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
                    or digest_before != digest_after
                    or not stat.S_ISREG(after.st_mode)
                ):
                    raise ValueError(
                        "File changed during validation; retry after delivery completes"
                    )
                item.update(
                    validation="valid",
                    sha256=digest_after,
                    bytes=after.st_size,
                    records=len(rows),
                    days_since_filename_date=(today - export_day).days,
                )
            except (OSError, ValueError, csv.Error) as error:
                item.update(validation="invalid", error=str(error))
            observations.append(item)

    valid = [item for item in observations if item["validation"] == "valid"]
    invalid = [item for item in observations if item["validation"] == "invalid"]
    report: dict[str, Any] = {
        "schema_version": 1,
        "checked_date": today.isoformat(),
        "status": "no_export_found",
        "ready_for_analysis": False,
        "selected": None,
        "baseline": baseline,
        "directories": directories_checked,
        "observations": observations,
        "discovery_errors": discovery_errors,
        "warnings": [],
        "provenance_limit": "A filename and valid schema do not independently authenticate its publisher or prove its collection date. No website/API data are substituted.",
    }
    if discovery_errors:
        report["status"] = "discovery_error"
        return report
    if not valid:
        if invalid:
            report["status"] = "invalid_export"
        return report
    newest_date = max(item["filename_date"] for item in valid)
    # Do not silently skip a newer delivery that is invalid or unfinished.
    if any(item["filename_date"] >= newest_date for item in invalid):
        report["status"] = "invalid_newest_export"
        return report
    newest = [item for item in valid if item["filename_date"] == newest_date]
    if len({item["sha256"] for item in newest}) != 1:
        report["status"] = "conflicting_exports_for_same_date"
        return report
    selected = sorted(newest, key=lambda item: item["path"])[0]
    report["selected"] = selected
    if baseline is None:
        report.update(status="first_input", ready_for_analysis=True)
        return report
    unchanged = selected["sha256"] == baseline["input_sha256"]
    report["same_content_as_latest_run"] = unchanged
    if unchanged:
        report["status"] = "unchanged_export"
        report["warnings"].append(
            "No new data observation: this file has the same bytes as the latest run's input."
        )
    elif baseline["export_date"] and newest_date < baseline["export_date"]:
        report["status"] = "older_than_latest_export"
    else:
        report.update(status="different_export", ready_for_analysis=True)
        if baseline["export_date"] == newest_date:
            report["warnings"].append(
                "Changed content has the same declared export date; retain both versions and do not imply a later collection date."
            )
    if invalid:
        report["warnings"].append("Older invalid files were recorded and not selected.")
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--project", type=Path, default=Path(__file__).resolve().parents[1]
    )
    parser.add_argument("--downloads", type=Path, default=Path.home() / "Downloads")
    parser.add_argument("--inbox", type=Path, action="append", default=[])
    parser.add_argument("--today", type=date.fromisoformat, default=date.today())
    args = parser.parse_args()
    # Keep intake read-only even when importing the existing tracker package.
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(args.project.resolve()))
    try:
        from tracker.data import load_incidents

        result = inspect_exports(
            args.project, [args.downloads, *args.inbox], args.today, load_incidents
        )
    except Exception as error:
        result = {
            "schema_version": 1,
            "status": "intake_error",
            "ready_for_analysis": False,
            "selected": None,
            "error": str(error),
        }
    print(json.dumps(result, indent=2))
    failures = {
        "intake_error",
        "discovery_error",
        "invalid_export",
        "invalid_newest_export",
        "conflicting_exports_for_same_date",
        "older_than_latest_export",
    }
    return 2 if result["status"] in failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
