"""Executable claim checking with explicit interpretations and partial components."""

from __future__ import annotations

from collections import Counter
from typing import Any

from .calc import Engine, trend
from .data import HARM10, HARM13
from .models import AuditRecord, Selection, SeveritySpec
from .provenance import ASSUMPTION, prefix_scan, prefix_with_count, prefixes_matching

SUPPORTED = "Supported"
UPDATE = "Needs a numerical or wording update"
UNSUPPORTED = "Unsupported under the stated interpretation"
UNVERIFIABLE = "Not verifiable with the available data or an ambiguous definition"


def percent_text(value: float | None, decimals: int = 1) -> str:
    return f"{value:.{decimals}f}%" if value is not None else "undefined"


def signed_text(value: float | None, decimals: int = 2) -> str:
    return f"{value:+.{decimals}f}" if value is not None else "undefined"


def fraction_text(measure: Any) -> str:
    if hasattr(measure, "numerator"):
        n, d, p = measure.numerator, measure.denominator, measure.percent
    else:
        n, d, p = measure["numerator"], measure["denominator"], measure["percent"]
    return f"{n:,}/{d:,} ({percent_text(p)})"


def points_text(series: dict[str, Any]) -> str:
    return "; ".join(f"{p['year']}: {fraction_text(p)}" for p in series["points"])


def series_ids(series: dict[str, Any]) -> list[str]:
    return [point["calculation_id"] for point in series["points"]]


def of_text(point: Any) -> str:
    """'n of d (p%)' for website-facing sentences."""
    if hasattr(point, "numerator"):
        n, d, p = point.numerator, point.denominator, point.percent
    else:
        n, d, p = point["numerator"], point["denominator"], point["percent"]
    return f"{n:,} of {d:,} ({percent_text(p)})"


def join_clauses(items: list[str]) -> str:
    return items[0] if len(items) == 1 else ", ".join(items[:-1]) + " and " + items[-1]


def subdomain_label(engine: Engine, code_value: str) -> str:
    for row in engine.rows:
        if row.primary == code_value and row.raw["subdomain_code"].strip():
            return row.raw["subdomain_code"].strip()
    return code_value


def domain_label(engine: Engine, code_value: str) -> str:
    for row in engine.rows:
        if row.domain == code_value and row.raw["domain_code"].strip():
            return row.raw["domain_code"].strip()
    return code_value


def fraction_word(percent: float | None) -> str | None:
    """Plain-language fraction for revision sentences; a rendering aid, never a status rule."""
    if percent is None:
        return None
    for low, high, word in (
        (45, 55, "about half"),
        (60, 70, "about two-thirds"),
        (70, 80, "about three-quarters"),
        (90, 100.01, "almost all"),
    ):
        if low <= percent < high:
            return word
    return None


def one_record_margin(step: dict[str, Any], points: list[dict[str, Any]]) -> bool:
    """True when the step's share difference is smaller than one record in either year."""
    left = next(p for p in points if p["year"] == step["from_year"])
    right = next(p for p in points if p["year"] == step["to_year"])
    if not left["denominator"] or not right["denominator"] or step["delta_pp"] is None:
        return False
    return abs(step["delta_pp"]) < 100 * max(
        1 / left["denominator"], 1 / right["denominator"]
    )


def ytd_context(engine: Engine, fraction: Any, target: Selection, key: str) -> str:
    """Labelled year-to-date row for reasons; never used in website sentences."""
    year = engine.analysis_date.year
    result = fraction(key, target, Selection(years=[year]))
    return f"{year} year-to-date through {engine.analysis_date} (incomplete; context only, not comparable with whole years): {fraction_text(result)}"


def current_check(
    engine: Engine, claim: dict[str, Any], spec: dict[str, Any]
) -> dict[str, Any]:
    identifier = claim["claim_id"]
    kind = spec["handler"]
    out: dict[str, Any] = {
        "interpretation": "Distinct incident records; primary scalar classification; all incidents in each stated date window are the denominator unless specified.",
        "status": UNVERIFIABLE,
        "evidence_ids": [],
        "component_checks": [],
        "reason": "",
        "proposed_revision": None,
        "editorial_flags": [],
    }
    evidence = out["evidence_ids"]
    components = out["component_checks"]

    def fraction(
        key: str, target: Selection, population: Selection | None = None
    ) -> Any:
        result = engine.fraction(f"claim.{identifier}.{key}", target, population)
        evidence.append(result.calculation_id)
        return result

    def series(
        key: str,
        target: Selection,
        start: int,
        end: int,
        population: Selection | None = None,
        denominator: str = "incidents",
    ) -> dict[str, Any]:
        result = engine.series(
            f"claim.{identifier}.{key}", target, start, end, population, denominator
        )
        evidence.extend(series_ids(result))
        return result

    if kind == "dataset_size":
        result = fraction("size", Selection())
        observation = spec.get("browser_observation")
        proxy = prefix_with_count(
            prefix_scan(engine.rows, {"all": lambda r: True}), spec["published_count"]
        )
        observed_text = (
            f" A headless {observation['engine']} render on {observation['observed_at_utc']} showed the live count {observation['rendered_count']:,} in place of the static text (source: {observation['source']}); the published figure is therefore a stale no-JavaScript fallback with no 'as of' date, not a wrong rendered count."
            if observation
            else " No browser-rendered count was recorded for this run."
        )
        proxy_text = (
            f" Under the ID-prefix proxy, {spec['published_count']:,} records corresponds to aiid_id ≤ {proxy['max_id']} (latest incident date {proxy['latest_incident_date']}); {ASSUMPTION}"
            if proxy
            else ""
        )
        out.update(
            status=SUPPORTED if result.numerator == spec["published_count"] else UPDATE,
            interpretation=spec["interpretation"],
            reason=f"The supplied export contains {result.numerator:,} unique incident records. The page's static HTML says {spec['published_count']:,}.{observed_text}{proxy_text}",
            proposed_revision="The MIT AI Incident Tracker classifies [live count, shown with its 'as of' date] incident records from the AI Incident Database by risk, cause, harm, severity and other dimensions.",
        )
        out["discrepancy_explanation"] = (
            "changed dataset: stale static fallback; the rendered count is the live mirror's record count"
            if observation
            else "cannot be determined without a rendered observation"
        )
        out["editorial_flags"] = [
            "Update the static fallback whenever the page is edited; a 'count updated nightly' note is an option for the maintainers (the mirror syncs daily), not a promise this analysis can make.",
            "Unit: incident records, not reports or events.",
        ]
        if observation:
            components.append(
                {
                    "component": "rendered count observed",
                    "status": SUPPORTED,
                    "interpretation": f"{observation['engine']} at {observation['observed_at_utc']}: {observation['rendered_count']:,}; export {result.numerator:,}; static fallback {spec['published_count']:,}.",
                }
            )
    elif kind in {"unbounded_rise", "qualitative_frame"}:
        start, end = spec["context_years"]
        result = series("context_counts", Selection(), start, end)
        safety = fraction("primary_safety", Selection(domains=["7"]))
        missing = fraction(
            "missing_information_flag",
            Selection(equals={"missing_information": ["true"]}),
        )
        out.update(
            reason=f"No time window or population exposure denominator is stated. Contextual complete-year record counts: {points_text(result)}. Primary system-safety domain: {fraction_text(safety)}. Classifier missing-information flag: {fraction_text(missing)}, which is not a measure of all reporting omissions.",
            proposed_revision=f"In the current export, {result['points'][0]['numerator']:,} incident records are dated {start} and {result['points'][-1]['numerator']:,} are dated {end}. These counts describe records in the database and reflect reporting and coverage as well as underlying events; they do not measure the incidence of AI incidents.",
        )
        out["editorial_flags"] = [
            "Undefined population/time window",
            "Database prevalence is not population prevalence",
        ]
        if kind == "qualitative_frame":
            intentional = series(
                "intentional_context",
                Selection(equals={"causal_intent": ["Intentional"]}),
                start,
                end,
            )
            components.extend(
                [
                    {
                        "component": "charts display classifications and counts",
                        "status": SUPPORTED,
                        "interpretation": "Verified from preserved client source and API; browser rendering was not tested.",
                    },
                    {
                        "component": "system-safety prevalence",
                        "status": UNVERIFIABLE,
                        "interpretation": f"Only database composition is measurable: {fraction_text(safety)} primary domain 7 records. No population prevalence denominator exists.",
                    },
                    {
                        "component": "intentional-misuse framing",
                        "status": UNVERIFIABLE,
                        "interpretation": f"Intentional tags are not independently verified misuse. Named {start}–{end} context: {points_text(intentional)}.",
                    },
                    {
                        "component": "reporting gaps",
                        "status": UNVERIFIABLE,
                        "interpretation": f"The missing-information flag is {fraction_text(missing)}; missing source URLs and report dates prevent estimating reporting completeness.",
                    },
                ]
            )
            out["proposed_revision"] = (
                "The charts summarize incident-record classifications, including system-safety and intentional-cause tags. Their distributions describe this database; reporting completeness and population prevalence cannot be estimated from this export."
            )
    elif kind == "subdomain_trend":
        start, end = spec["years"]
        alternatives = {}
        for scope in ("primary", "any"):
            result = series(
                scope,
                Selection(subdomains=[spec["subdomain"]], classification=scope),
                start,
                end,
            )
            alternatives[scope] = result
            test = result["trend"][
                (
                    "strictly_increasing_share"
                    if spec["direction"] == "up"
                    else "strictly_decreasing_share"
                )
            ]
            components.append(
                {
                    "component": f"{scope} annual incident share",
                    "status": SUPPORTED if test else UNSUPPORTED,
                    "trend": result["trend"],
                    "series_id": result["series_id"],
                }
            )
        primary = alternatives["primary"]
        delta = primary["trend"]["endpoint_delta_pp"]
        endpoint_ok = delta is not None and (
            delta > 0 if spec["direction"] == "up" else delta < 0
        )
        monotonic = primary["trend"][
            (
                "strictly_increasing_share"
                if spec["direction"] == "up"
                else "strictly_decreasing_share"
            )
        ]
        passed = monotonic if spec["strict_annual"] else endpoint_ok
        out["status"] = (
            UNVERIFIABLE if delta is None else SUPPORTED if passed else UNSUPPORTED
        )
        verb = (
            "was unchanged"
            if delta is None or delta == 0
            else "rose" if delta > 0 else "fell"
        )
        first, last = primary["points"][0], primary["points"][-1]
        label = subdomain_label(engine, spec["subdomain"])
        monotone_share = (
            primary["trend"]["strictly_increasing_share"]
            or primary["trend"]["strictly_decreasing_share"]
        )
        count_change = primary["trend"]["endpoint_count_change"]
        count_clause = (
            f", while the number of such records rose from {first['numerator']} to {last['numerator']}"
            if count_change > 0
            else (
                f", while the number of such records fell from {first['numerator']} to {last['numerator']}"
                if count_change < 0
                else f", while the number of such records was unchanged at {first['numerator']}"
            )
        )
        if delta is not None and delta < 0:
            trailer = " The falling share reflects faster growth in other categories; it is not evidence that AI systems became more robust."
        else:
            trailer = " These are shares of records in the database, not measures of how common such incidents are."
        span = (
            f"{verb} each year, from {of_text(first)} in {start} to {of_text(last)} in {end}"
            if monotone_share and verb != "was unchanged"
            else f"{verb} between {start} and {end}, from {of_text(first)} to {of_text(last)}, with intervening reversals or flats"
        )
        ytd = ytd_context(
            engine, fraction, Selection(subdomains=[spec["subdomain"]]), "ytd_primary"
        )
        out["reason"] = (
            f"Primary: {points_text(primary)}. Any-label incident denominator: {points_text(alternatives['any'])}. Endpoint change {signed_text(delta)} percentage points; counts change {count_change:+d}. {ytd}."
        )
        out["proposed_revision"] = (
            f"Among incident records dated {start}–{end}, the share whose primary subdomain is ‘{label}’ {span}{count_clause if delta is not None and delta < 0 else ''}.{trailer}"
        )
        if not spec["strict_annual"]:
            out[
                "interpretation"
            ] += " ‘Decreasing between’ is assessed as an endpoint statement; stricter annual decline and absolute counts are checked separately."
        if (
            min(point["numerator"] for point in primary["points"])
            < engine.config.min_category_count
        ):
            out["editorial_flags"].append(
                "Some annual category counts are below the new-candidate minimum; the published claim is still audited."
            )
    elif kind == "generation_ambiguity":
        start, end = spec["context_years"]
        groups = {
            "strict_primary": Selection(
                purposes=engine.config.strict_generation_purposes
            ),
            "expanded_primary": Selection(
                purposes=engine.config.expanded_generation_purposes
            ),
            "strict_primary_secondary": Selection(
                purposes=engine.config.strict_generation_purposes,
                purpose_scope="primary_or_secondary",
            ),
        }
        results = {
            key: series(key, target, start, end) for key, target in groups.items()
        }
        all_now = fraction("strict_all_dates", groups["strict_primary"])
        current_year = fraction(
            "strict_partial_current_year",
            groups["strict_primary"],
            Selection(years=[engine.analysis_date.year]),
        )
        context = results["strict_primary"]
        out["interpretation"] = (
            "No original purpose set or dated meaning of ‘now’ is supplied. Named purpose sets are alternative analyst operationalizations, not assumed author definitions."
        )
        out["reason"] = (
            "; ".join(f"{key}: {points_text(value)}" for key, value in results.items())
            + f". All-date narrow share: {fraction_text(all_now)}; incomplete {engine.analysis_date.year}: {fraction_text(current_year)} (not a full-year comparison)."
        )
        purposes = engine.config.strict_generation_purposes
        out["proposed_revision"] = (
            f"Using the primary-purpose labels {', '.join(purposes[:-1])} and {purposes[-1]}, such incident records rose from {of_text(context['points'][0])} in {start} to {of_text(context['points'][-1])} in {end}; across all records in the export (all dates) they are {of_text(all_now)}."
        )
        out["editorial_flags"] = [
            "‘Dramatically’ and ‘around half’ have no predeclared quantitative threshold.",
            "Fix ‘now’, the year, primary/secondary scope, and purpose set before passing/failing the prose.",
        ]
        components.extend(
            {
                "component": key,
                "status": (
                    SUPPORTED
                    if value["trend"]["strictly_increasing_count"]
                    else UNSUPPORTED
                ),
                "interpretation": "Strictly increasing counts under this named operationalization only",
                "trend": value["trend"],
            }
            for key, value in results.items()
        )
    elif kind == "eu_annual":
        start, end = spec["years"]
        target = Selection(equals={"eu_ai_act_risk_level": [spec["level"]]})
        result = series("level1", target, start, end)
        annual = result["trend"]["strictly_increasing_share"]
        last = result["points"][-1]
        numerical = (
            last["percent"] is not None
            and round(last["percent"], spec["rounding_decimals"])
            == spec["published_endpoint_percent"]
        )
        failing = [
            step for step in result["trend"]["steps"] if step["share_direction"] != "up"
        ]
        margin_steps = [
            (
                f"{step['from_year']}→{step['to_year']} ({signed_text(step['delta_pp'])} pp; within one record)"
                if one_record_margin(step, result["points"])
                else f"{step['from_year']}→{step['to_year']} ({signed_text(step['delta_pp'])} pp)"
            )
            for step in failing
        ]
        context_before = spec.get("context_years_before", 0)
        context_text = ""
        minimum_note = ""
        if context_before:
            context = series(
                "level1_context_before", target, start - context_before, start - 1
            )
            context_text = (
                " Years before the claim's window (context only; small cells): "
                + points_text(context)
                + "."
            )
            longer = context["points"] + result["points"]
            defined = [p for p in longer if p["denominator"]]
            if defined:
                lowest = min(defined, key=lambda p: p["percent"])
                if lowest["year"] == start:
                    minimum_note = f" {start} is the lowest year of {start - context_before}–{end}."
        # Full tier composition at both endpoints: the complement labels move together.
        composition = []
        for year in (start, end):
            parts = []
            for level in ("1", "2", "3", "4"):
                measure = fraction(
                    f"tier{level}.{year}",
                    Selection(equals={"eu_ai_act_risk_level": [level]}),
                    Selection(years=[year]),
                )
                parts.append(f"tier {level} {fraction_text(measure)}")
            composition.append(f"{year}: " + ", ".join(parts))
        ytd = ytd_context(engine, fraction, target, "ytd_level1")
        components.extend(
            [
                {
                    "component": "increases each year",
                    "status": SUPPORTED if annual else UNSUPPORTED,
                    "trend": result["trend"],
                    "interpretation": (
                        "Every adjacent step rises on unrounded fractions."
                        if annual
                        else "Failing step(s): "
                        + "; ".join(margin_steps)
                        + ". Protocol-correct on unrounded fractions; a one-record margin is fragile to backfill."
                    ),
                },
                {
                    "component": "quoted endpoint",
                    "status": SUPPORTED if numerical else UPDATE,
                    "observed": last,
                    "rounding_decimals": spec["rounding_decimals"],
                    "interpretation": f"Observed {fraction_text(last)}; published {spec['published_endpoint_percent']}% at {spec['rounding_decimals']} decimals.",
                },
                {
                    "component": "full tier composition at the endpoints (complement labels move together)",
                    "status": UNVERIFIABLE,
                    "interpretation": "; ".join(composition),
                },
            ]
        )
        values = join_clauses(
            [f"{of_text(p)} in {p['year']}" for p in result["points"]]
        )
        out.update(
            status=UNSUPPORTED if not annual else SUPPORTED if numerical else UPDATE,
            reason=points_text(result)
            + ". Adjacent changes use unrounded fractions"
            + (": " + "; ".join(margin_steps) if failing else "")
            + f".{context_text}{minimum_note} {ytd}. These are automated tier classifications, not legal rulings.",
            proposed_revision=(
                f"Incident records tagged tier 1 (Unacceptable) under the EU AI Act were {values}.{minimum_note.replace(' is the lowest', ' was the lowest')} These are automated tier tags that change as records are reclassified; they are not legal determinations."
            ),
        )
        out["discrepancy_explanation"] = (
            "not a calculation error: the annual-increase clause fails on unrounded fractions in this export and on the live mirror; the 4% endpoint is not reproduced by any ID-prefix snapshot proxy together with a strict rise"
        )
        out["editorial_flags"] = [
            "Remove literal trailing bracket",
            "Legal applicability/prohibition is not independently established",
            "Temporal applicability for the human legal reviewer: confirm from which date the Act's prohibitions applied; most tier-1-tagged records are dated before 2025.",
        ]
    elif kind == "causal_annual":
        start, end = spec["years"]
        results = {}
        for field, label in spec["targets"].items():
            result = series(field, Selection(equals={field: [label]}), start, end)
            known = series(
                field + ".known",
                Selection(equals={field: [label]}),
                start,
                end,
                Selection(
                    known_fields=[field],
                    exclude_other=field
                    in engine.config.other_is_unknown_for_sensitivity_only,
                ),
            )
            results[field] = result
            components.append(
                {
                    "component": field,
                    "status": (
                        SUPPORTED
                        if result["trend"]["strictly_increasing_share"]
                        else UNSUPPORTED
                    ),
                    "all_incidents": result["trend"],
                    "known_only_sensitivity": known["trend"],
                }
            )
        passed = all(
            result["trend"]["strictly_increasing_share"] for result in results.values()
        )
        phrasing = {
            (
                "causal_intent",
                "Intentional",
            ): "the share tagged as intentionally caused",
            (
                "causal_entity",
                "Human",
            ): "the share whose causal entity is tagged Human rather than AI",
        }
        clauses = []
        for field, result in results.items():
            label = spec["targets"][field]
            subject = phrasing.get(
                (field, label), f"the share tagged {label} ({field})"
            )
            trend_ = result["trend"]
            verb = (
                "rose"
                if (trend_["endpoint_delta_pp"] or 0) > 0
                else (
                    "fell"
                    if (trend_["endpoint_delta_pp"] or 0) < 0
                    else "was unchanged"
                )
            )
            each = (
                " each year"
                if (
                    trend_["strictly_increasing_share"]
                    or trend_["strictly_decreasing_share"]
                )
                else ""
            )
            clauses.append(
                f"{subject} {verb}{each}, from {of_text(result['points'][0])} to {of_text(result['points'][-1])}"
            )
        ytd = "; ".join(
            ytd_context(
                engine, fraction, Selection(equals={field: [label]}), f"ytd_{field}"
            )
            for field, label in spec["targets"].items()
        )
        out.update(
            status=SUPPORTED if passed else UNSUPPORTED,
            reason=". ".join(
                f"{field}: {points_text(result)}" for field, result in results.items()
            )
            + f". {ytd}.",
            proposed_revision=f"Among incident records dated {start}–{end}, "
            + ", and ".join(clauses)
            + ". These are LLM-assigned causal tags, not verified causes.",
        )
    elif kind == "timing_any_year":
        first_year = min(
            (row.year for row in engine.rows if row.year is not None),
            default=spec["context_start"],
        )
        end = engine.analysis_date.year - 1
        first_year = min(first_year, end)
        result = series(
            "pre",
            Selection(equals={"causal_timing": ["Pre-deployment"]}),
            first_year,
            end,
        )
        nonempty = [point for point in result["points"] if point["denominator"]]
        if not nonempty:
            out["reason"] = (
                "No dated records in any complete year; annual wording cannot be checked."
            )
            return out
        full_max = max(nonempty, key=lambda point: point["percent"])
        displayed = [
            point for point in nonempty if point["year"] >= spec["context_start"]
        ]
        visible_max = (
            max(displayed, key=lambda point: point["percent"]) if displayed else None
        )
        visible_text = (
            f"{visible_max['year']} {fraction_text(visible_max)}"
            if visible_max
            else "no dated records"
        )
        post = fraction(
            "post", Selection(equals={"causal_timing": ["Post-deployment"]})
        )
        window = sorted(displayed, key=lambda p: p["year"])
        ranked = sorted(window, key=lambda p: (-(p["percent"] or 0), p["year"]))
        top_two = sorted(ranked[:2], key=lambda p: p["year"])
        rest = [p for p in window if p not in top_two]
        current_year = engine.analysis_date.year
        ytd = fraction(
            "ytd_pre",
            Selection(equals={"causal_timing": ["Pre-deployment"]}),
            Selection(years=[current_year]),
        )
        rest_text = (
            f", and between {percent_text(min(p['percent'] for p in rest))} and {percent_text(max(p['percent'] for p in rest))} in each other year from {rest[0]['year']} to {rest[-1]['year']}"
            if rest
            else ""
        )
        top_text = " and ".join(f"{of_text(p)} in {p['year']}" for p in top_two)
        out.update(
            reason=f"Post-deployment overall: {fraction_text(post)}. Largest pre-deployment share across observed complete years: {full_max['year']} {fraction_text(full_max)}. In the default chart's complete-year scope ({spec['context_start']}–{end}), maximum: {visible_text}; full annual series in the component below. Sparse years and unstated scope/‘few’ definitions leave the parent wording ambiguous; see the literal-universe component. {current_year} year-to-date (incomplete; context only): {fraction_text(ytd)}.",
            proposed_revision=f"Almost all incident records are tagged post-deployment: {of_text(post)}. Pre-deployment tags were {top_text}{rest_text}; {current_year} to date they are {of_text(ytd)}.",
        )
        components.append(
            {
                "component": f"pre-deployment share by year, default chart scope {spec['context_start']}–{end} (no threshold asserted)",
                "status": UNVERIFIABLE,
                "interpretation": "; ".join(
                    f"{p['year']}: {fraction_text(p)}" for p in window
                )
                + f"; {current_year} to date (incomplete): {fraction_text(ytd)}",
            }
        )
        out["editorial_flags"] = spec["vague_terms"]
        components.append(
            {
                "component": "maximum pre-deployment complete-year share",
                "all_observed_years": full_max,
                "default_chart_years": visible_max,
            }
        )
        components.append(
            {
                "component": "literal ‘few percent in any year’, if every observed calendar year is included",
                "status": (
                    UNSUPPORTED
                    if full_max["numerator"] == full_max["denominator"]
                    else UNVERIFIABLE
                ),
                "interpretation": f"The maximum is {full_max['year']}: {fraction_text(full_max)}. An entirely pre-deployment year contradicts this literal reading without inventing a tolerance for ‘few’; sparse years and the intended publication scope need editorial review.",
            }
        )
    elif kind == "vague_half":
        target = Selection(equals={spec["field"]: [spec["value"]]})
        result = fraction("all", target)
        known = fraction(
            "known",
            target,
            Selection(
                known_fields=[spec["field"]],
                exclude_other=spec["field"]
                in engine.config.other_is_unknown_for_sensitivity_only,
            ),
        )
        out.update(
            reason=f"All records: {fraction_text(result)}; omitting Other/unknown as a sensitivity: {fraction_text(known)}. No numerical tolerance is invented for ‘About half’.",
            proposed_revision=f"In this export, {result.numerator:,} of {result.denominator:,} incident records ({percent_text(result.percent)}) are tagged as intentionally caused.",
        )
        out["editorial_flags"] = spec["vague_terms"]
    elif kind == "timing_rounded":
        pre = fraction("pre", Selection(equals={"causal_timing": ["Pre-deployment"]}))
        post = fraction(
            "post", Selection(equals={"causal_timing": ["Post-deployment"]})
        )
        other = fraction("other", Selection(equals={"causal_timing": ["Other"]}))
        passed = (
            pre.percent is not None
            and round(pre.percent, spec["rounding_decimals"])
            == spec["published_percent"]
        )
        out.update(
            status=SUPPORTED if passed else UPDATE,
            interpretation="Verify the explicit 2% using nearest-whole-percent rounding over all records; ‘Almost all’ is an editorial qualifier, not a separately thresholded hypothesis.",
            reason=f"Pre: {fraction_text(pre)}; post: {fraction_text(post)}; Other: {fraction_text(other)}.",
            proposed_revision=f"Post-deployment is tagged for {fraction_text(post)} of records; pre-deployment for {fraction_text(pre)}, with {other.numerator} Other timing tags.",
        )
        out["editorial_flags"] = [
            "‘Almost all’ remains an editorial judgment; numeric component drives status."
        ]
    elif kind == "eu_distribution":
        results = {}
        for level, expected in spec["quoted_percents"].items():
            result = fraction(
                f"level{level}", Selection(equals={"eu_ai_act_risk_level": [level]})
            )
            results[level] = result
            passed = (
                result.percent is not None
                and round(result.percent, spec["rounding_decimals"][level]) == expected
            )
            components.append(
                {
                    "component": f"tier {level} percentage",
                    "status": SUPPORTED if passed else UPDATE,
                    "observed_percent": result.percent,
                    "expected_percent": expected,
                }
            )
        components.append(
            {
                "component": "therefore prohibited",
                "status": UNVERIFIABLE,
                "reason": "No legal adjudication, jurisdiction/time-of-use applicability or human-verified tier assignment is supplied.",
            }
        )
        proxy_text = ""
        if spec.get("snapshot_proxy"):
            scan = prefix_scan(
                engine.rows,
                {
                    level: (lambda r, lvl=level: r.raw["eu_ai_act_risk_level"] == lvl)
                    for level in spec["quoted_percents"]
                },
            )
            match = prefixes_matching(
                scan,
                {
                    level: (expected, spec["rounding_decimals"][level])
                    for level, expected in spec["quoted_percents"].items()
                },
            )
            components.append(
                {
                    "component": "earlier-snapshot proxy (diagnostic, not a reconciliation)",
                    "status": UNVERIFIABLE,
                    **match,
                }
            )
            if match["first_joint_match"]:
                proxy_text = f" Under the ID-prefix proxy, both published figures are reproduced jointly by {match['joint_matching_prefixes']} prefixes ending at aiid_id {match['first_joint_match']['max_id']}–{match['last_joint_match']['max_id']} (n {match['first_joint_match']['n']:,}–{match['last_joint_match']['n']:,}; latest incident dates {match['first_joint_match']['latest_incident_date']} to {match['last_joint_match']['latest_incident_date']}); single figures match {match['single_figure_matching_prefixes']} prefixes respectively, so the joint match is suggestive, not conclusive. {ASSUMPTION}"
            else:
                proxy_text = " No ID-prefix reproduces both published figures jointly."
        # Context by incident year does not reconstruct historical database snapshots.
        tier2 = series(
            "level2_context",
            Selection(equals={"eu_ai_act_risk_level": ["2"]}),
            engine.analysis_date.year - 5,
            engine.analysis_date.year - 1,
        )
        live = spec.get("live_observation")
        live_text = (
            f" The live mirror on {live['observed_at_utc']} showed tier 1 {live['tier1_count']}/{live['records']} and tier 2 {live['tier2_count']}/{live['records']}; {live['note']}"
            if live
            else ""
        )
        out.update(
            status=UPDATE,
            reason="; ".join(
                f"Tier {level}: {fraction_text(result)}"
                for level, result in results.items()
            )
            + f". Tier-2 share by complete year: {points_text(tier2)}.{proxy_text}{live_text} Classifier tags cannot establish prohibition.",
            proposed_revision=f"In the current export, the LLM classifier assigns EU AI Act tier 1 (Unacceptable) to {results['1'].numerator:,} of {results['1'].denominator:,} incident records ({percent_text(results['1'].percent)}) and tier 2 (High Risk) to {results['2'].numerator:,} ({percent_text(results['2'].percent)}). These are automated tags that change between exports; they are not legal determinations, and whether a practice is prohibited depends on the Act's scope, exemptions and dates of application, which the tags do not assess.",
        )
        out["discrepancy_explanation"] = (
            "unconfirmed historical explanation: current-label ID prefixes reproduce the published pair, consistent with a different dataset composition; the original snapshot is required to establish its origin, and calculation error is not excluded"
            if proxy_text.startswith(" Under")
            else "cannot be determined: no original snapshot"
        )
        out["editorial_flags"] = [
            "Automated taxonomy tags are not legal conclusions",
            "Original all-dataset snapshot not supplied",
            "Temporal applicability for the human legal reviewer: confirm from which date the Act's prohibitions applied; most tier-1-tagged records are dated before 2025.",
        ]
    elif kind == "ranking":
        distribution = engine.distribution(spec["field"])
        winners = [
            item["category"] for item in distribution[: len(spec["expected_order"])]
        ]
        selected = []
        for item in distribution[: max(3, len(spec["expected_order"]))]:
            result = fraction(
                safe_label(item["category"]),
                Selection(equals={spec["field"]: [item["category"]]}),
            )
            selected.append((item["category"], result))
        unique = all(
            distribution[index]["count"] > distribution[index + 1]["count"]
            for index in range(min(len(spec["expected_order"]), len(distribution) - 1))
        )
        passed = winners == spec["expected_order"] and unique
        nouns = {
            "ai_goal_primary": "primary AI-purpose tag",
            "domain_code": "primary risk domain",
            "subdomain_code": "primary risk subdomain",
        }
        noun = nouns.get(spec["field"], spec["field"].replace("_", " "))
        winner_label, winner = selected[0]
        runner = selected[1] if len(selected) > 1 else None
        if spec["field"] == "ai_goal_primary":
            named = 15
            other = sum(item["count"] for item in distribution[named:])
            other_text = (
                f" The chart's ‘Other’ slice groups the tail beyond the {named} named purposes ({other:,} records here)"
                + (
                    " and is larger than any single named category."
                    if other > winner.numerator
                    else "."
                )
            )
        else:
            other_text = ""
        if len(spec["expected_order"]) == 1:
            revision = (
                f"Across all incident records in the export, the most frequent single {noun} is ‘{winner_label}’, assigned to {winner.numerator:,} of {winner.denominator:,} incident records ({percent_text(winner.percent)})"
                + (
                    f", followed by ‘{runner[0]}’ ({runner[1].numerator:,}, {percent_text(runner[1].percent)})."
                    if runner
                    else "."
                )
                + other_text
            )
        else:
            ordered = selected[: len(spec["expected_order"])]
            revision = (
                f"Across all incident records in the export, the most frequent {noun} is ‘{ordered[0][0]}’ ({of_text(ordered[0][1])}), followed by "
                + ", then ".join(
                    f"‘{label}’ ({result.numerator:,}, {percent_text(result.percent)})"
                    for label, result in ordered[1:]
                )
                + "."
            )
        out.update(
            status=SUPPORTED if passed else UNSUPPORTED,
            reason="; ".join(
                f"{label}: {fraction_text(result)}" for label, result in selected
            )
            + ". Ranking counts primary labels over all incident dates, including the partial current year as snapshot composition.",
            proposed_revision=revision,
        )
        components.append(
            {"component": "complete ranking", "ordered_distribution": distribution}
        )
    elif kind == "within_domain":
        result = fraction(
            "primary",
            Selection(subdomains=[spec["subdomain"]]),
            Selection(domains=[spec["domain"]]),
        )
        any_label = fraction(
            "any_subdomain_within_primary_domain",
            Selection(subdomains=[spec["subdomain"]], classification="any"),
            Selection(domains=[spec["domain"]]),
        )
        bar = fraction(
            "bar_default",
            Selection(subdomains=[spec["subdomain"]]),
            Selection(domains=[spec["domain"]], min_year=2016),
        )
        word = fraction_word(result.percent)
        out.update(
            reason=f"Primary within primary domain: {fraction_text(result)}; any subdomain within the same primary-domain population: {fraction_text(any_label)}; default bar floor: {fraction_text(bar)}. ‘Vast majority’ has no declared threshold.",
            proposed_revision=(
                f"Within incident records primarily tagged ‘{domain_label(engine, spec['domain'])}’, "
                + (f"{word}, {of_text(result)}," if word else f"{of_text(result)}")
                + f" have the primary subdomain ‘{subdomain_label(engine, spec['subdomain'])}’; on the default chart (2016 onwards) the figure is {of_text(bar)}."
            ),
        )
        components.append(
            {
                "component": "literal majority (>50%)",
                "status": (
                    SUPPORTED
                    if result.percent is not None and result.percent > 50
                    else UNSUPPORTED
                ),
            }
        )
        out["editorial_flags"] = spec["vague_terms"] + [
            "All-time prose versus default bar's 2016 floor"
        ]
    elif kind == "validation_unavailable":
        confidence = Counter(row.raw.get("confidence", "") for row in engine.rows)
        high = confidence.get("High", 0)
        models = Counter(row.raw["model_name"] for row in engine.rows).most_common()
        model_text = ", ".join(f"{name} ({count:,})" for name, count in models)
        pilot = spec.get("pilot", {})
        out.update(
            interpretation="Agreement/reliability against human experts; requires the study's paired labels, sampling and scoring procedures.",
            reason=(
                "The CSV contains one retained classification per incident and no human reference labels or repeated model runs. "
                f"The linked June 2026 article reports a small pilot ({pilot.get('incidents', 'ten')} incidents, {pilot.get('reviewers', 'two')} expert reviewers, {pilot.get('models', 'eight')} models), not a full-dataset validation; its production model was {pilot.get('production_model', 'not stated')}, whereas this export's classifications carry model_name {model_text}, so the pilot validates neither this export's model nor its prompt. "
                f"The pilot's human–human agreement was itself only fair to moderate (QWK {pilot.get('qwk_harm', 'n/a')} for harm severity, {pilot.get('qwk_eu', 'n/a')} for the EU tier), and the EU AI Act tier was its weakest taxonomy. "
                f"The export's confidence field is 'High' for {high:,}/{len(engine.rows):,} records ({percent_text(100 * high / len(engine.rows))}) with no 'Low' values and carries no discriminating information. The article is published, making ‘forthcoming’ stale."
            ),
            proposed_revision=(
                f"The classifier was evaluated in a small pilot (June 2026: {pilot.get('incidents', 'ten')} incidents, {pilot.get('reviewers', 'two')} expert reviewers, {pilot.get('models', 'eight')} models); the best models agreed with the reviewers' consensus about as often as the two reviewers agreed with each other, which was itself only fair to moderate (QWK {pilot.get('qwk_harm', 'n/a')} for harm severity, {pilot.get('qwk_eu', 'n/a')} for the EU AI Act tier). The pilot did not include the model used for the current classifications, and misclassifications remain likely, especially for the EU AI Act risk tier. [Link the 30 June 2026 update in place of ‘article forthcoming’.]"
            ),
        )
        out["editorial_flags"] = [
            "Replace ‘(article forthcoming)’ with a link to the 30 June 2026 update",
            "Do not turn agreement/self-consistency into statistical confidence",
        ]
    else:
        raise ValueError(f"Unknown current audit handler: {kind}")
    return out


def safe_label(label: str) -> str:
    import hashlib

    return hashlib.sha256(label.encode()).hexdigest()[:12]


def archival_check(
    engine: Engine, claim: dict[str, Any], replay: dict[str, Any] | None = None
) -> dict[str, Any]:
    """Bounded replay: never pretend the archive defines its missing snapshot/window."""
    identifier = claim["claim_id"]
    out: dict[str, Any] = {
        "interpretation": "Archived prose; any current-export replay below is retrospective, not a reconstruction of the unpublished original snapshot.",
        "status": UNVERIFIABLE,
        "evidence_ids": [],
        "component_checks": [],
        "reason": "The original snapshot and/or relative time-window endpoint is unavailable. The archived Airtable chart's internal field/threshold definitions were not recovered.",
        "proposed_revision": None,
        "editorial_flags": ["Archived, not a current dashboard claim"],
    }

    def fraction(
        name: str, target: Selection, population: Selection | None = None
    ) -> Any:
        result = engine.fraction(f"claim.{identifier}.{name}", target, population)
        out["evidence_ids"].append(result.calculation_id)
        return result

    def series(
        name: str,
        target: Selection,
        start: int,
        end: int,
        population: Selection | None = None,
    ) -> dict[str, Any]:
        result = engine.series(
            f"claim.{identifier}.{name}", target, start, end, population
        )
        out["evidence_ids"].extend(series_ids(result))
        return result

    replay = replay or {
        "frozen_illustrative_endpoint_year": 2025,
        "page_scope_by_claim_prefix": {"ARCH-TIMELINE-SUB-DOMAINS-": [2015, 2025]},
    }
    expectations = replay.get("expectations", {})
    expected = expectations.get(identifier, {})
    end = replay["frozen_illustrative_endpoint_year"]
    out["editorial_flags"].append(
        "Current-export replay, not a correction of the archived text; original snapshot unavailable"
    )
    out[
        "reason"
    ] += f" Open-ended illustrative series are frozen at {end}, rather than extended when new exports arrive."
    if identifier.startswith("ARCH-RISK-CLASSIFICATION-"):
        index = int(identifier.rsplit("-", 1)[-1])
        if index == 1:
            vals = [fraction(f"domain{d}", Selection(domains=[d])) for d in ("4", "7")]
            out["reason"] += (
                " Current full-export replay, domains 4/7: "
                + "; ".join(fraction_text(v) for v in vals)
                + ". The ordering is tested by current OVERVIEW-05."
            )
        elif index == 2:
            result = fraction("2025", Selection(domains=["4"]), Selection(years=[2025]))
            out.update(
                status=(
                    SUPPORTED
                    if result.percent is not None
                    and round(result.percent) == expected.get("published_percent", 57)
                    else UPDATE
                ),
                reason=f"Fixed 2025 incident-date window recalculated as {fraction_text(result)}. Original 2025 cutoff may have been year-to-date; this does not reconstruct that earlier database.",
                proposed_revision=f"In the current export, {fraction_text(result)} of records dated 2025 are primarily tagged domain 4.",
            )
        elif index == 3:
            result = fraction(
                "fraud", Selection(subdomains=["4.3"]), Selection(domains=["4"])
            )
            out[
                "reason"
            ] += f" Current primary replay: {fraction_text(result)}; original quote was {expected.get('published_fraction', '329/426')}."
        elif index in (4, 5, 6):
            fields = (
                [("causal_intent", "Intentional")]
                if index == 4
                else (
                    [("causal_timing", "Pre-deployment")]
                    if index == 5
                    else [("eu_ai_act_risk_level", "1"), ("eu_ai_act_risk_level", "2")]
                )
            )
            vals = [
                fraction(f"{field}.{label}", Selection(equals={field: [label]}))
                for field, label in fields
            ]
            out["reason"] += " Current scalar replay: " + "; ".join(
                fraction_text(v) for v in vals
            )
            if index == 6:
                out["editorial_flags"].append(
                    "Tier tags cannot establish legal prohibition"
                )
        elif index == 7:
            distribution = engine.distribution("ai_goal_primary")
            result = fraction(
                "deepfake",
                Selection(equals={"ai_goal_primary": ["Deepfake Video Generation"]}),
            )
            out[
                "reason"
            ] += f" Current ranking winner: {distribution[0]['category']}; quoted category: {fraction_text(result)}."
    elif identifier.startswith("ARCH-TIMELINE-RISK-CLASSIFICATION-"):
        index = int(identifier.rsplit("-", 1)[-1])
        if index in (1, 2):
            codes = ["4.3", "3.1"] if index == 1 else ["7.3"]
            start = 2022 if index == 1 else 2021
            for sub in codes:
                for scope in ("primary", "any"):
                    result = series(
                        f"{sub}.{scope}",
                        Selection(subdomains=[sub], classification=scope),
                        start,
                        end,
                    )
                    out[
                        "reason"
                    ] += f" Bounded replay {sub}/{scope}: {points_text(result)}."
                    out["component_checks"].append(
                        {"series_id": result["series_id"], "trend": result["trend"]}
                    )
        elif index == 3:
            result = series(
                "generation",
                Selection(purposes=engine.config.strict_generation_purposes),
                2022,
                end,
            )
            out[
                "reason"
            ] += f" Defined four-purpose replay: {points_text(result)}. ‘Dramatically’, ‘around half’, and ‘now’ remain ambiguous."
        elif index == 4:
            current = current_check(
                engine,
                claim,
                {
                    "handler": "eu_annual",
                    "years": [2022, 2025],
                    "level": "1",
                    "published_endpoint_percent": 4,
                    "rounding_decimals": 0,
                },
            )
            current["editorial_flags"].append(
                "Archived version; fixed 2025 window recalculated"
            )
            return current
        elif index == 5:
            for field, label in (
                ("causal_intent", "Intentional"),
                ("causal_entity", "Human"),
            ):
                result = series(field, Selection(equals={field: [label]}), 2021, end)
                out["reason"] += f" Bounded {field} replay: {points_text(result)}."
    elif identifier.startswith("ARCH-TIMELINE-SUB-DOMAINS-"):
        index = int(identifier.rsplit("-", 1)[-1])
        page_start, page_end = replay["page_scope_by_claim_prefix"][
            "ARCH-TIMELINE-SUB-DOMAINS-"
        ]
        out[
            "reason"
        ] += f" The captured page explicitly scopes its view to {page_start}–{page_end}; that scope is replayed below."
        if index == 1:
            for sub in ("1.1", "1.2"):
                result = series(
                    sub,
                    Selection(subdomains=[sub]),
                    2020,
                    page_end,
                    Selection(domains=["1"]),
                )
                out[
                    "reason"
                ] += f" Within-primary-domain replay {sub}: {points_text(result)}."
        elif index == 2:
            result = series("domain6", Selection(domains=["6"]), page_start, page_end)
            maximum = max(result["points"], key=lambda x: x["numerator"])
            out[
                "reason"
            ] += f" Captured-scope maximum: {maximum['year']}, {fraction_text(maximum)}. The ‘no more than 3’ component is checked within that scope."
            out["component_checks"].append(
                {
                    "component": "captured-page-scope annual count <=3",
                    "status": (
                        SUPPORTED
                        if maximum["numerator"]
                        <= expected.get("maximum_annual_count", 3)
                        else UNSUPPORTED
                    ),
                }
            )
        elif index == 3:
            result = fraction(
                "robustness",
                Selection(subdomains=["7.3"]),
                Selection(domains=["7"], min_year=page_start, max_year=page_end),
            )
            out[
                "reason"
            ] += f" Captured-scope within-domain share: {fraction_text(result)}; overwhelming is not thresholded."
            all_dates = fraction(
                "robustness_all_dates_context",
                Selection(subdomains=["7.3"]),
                Selection(domains=["7"]),
            )
            out[
                "reason"
            ] += f" Separately labeled all-date context: {fraction_text(all_dates)}."
        elif index == 4:
            for sub in ("4.3", "4.1"):
                result = fraction(
                    sub,
                    Selection(subdomains=[sub]),
                    Selection(domains=["4"], min_year=page_end - 2, max_year=page_end),
                )
                out[
                    "reason"
                ] += f" Illustrative last-three-complete-year replay {sub}: {fraction_text(result)}."
    elif identifier.startswith("ARCH-ALLEGED-DEVELOPERS-"):
        index = int(identifier.rsplit("-", 1)[-1])
        out["editorial_flags"].append(
            "Alleged-developer free text and registry-derived ai_developers arrays are distinct. Do not split free text on commas or silently swap identities."
        )
        if index in (2, 3):
            population = Selection(identity_contains={"ai_developers": ["OpenAI"]})
            if index == 3:
                population = Selection(numeric_min={"natsec_overall_score": 3})
                target = Selection(identity_contains={"ai_developers": ["OpenAI"]})
            else:
                target = Selection(identity_contains={"ai_developers": ["OpenAI"]})
                population = Selection()
            result = series("identity_array_sensitivity", target, 2021, end, population)
            out[
                "reason"
            ] += f" Different-field sensitivity only: {points_text(result)}."
    elif identifier in {
        "ARCH-HARM-SEVERITY-01",
        "ARCH-TIMELINE-HIGH-SEVERITY-INCIDENTS-03",
    }:
        result = fraction(
            "environmental_direct_ge2",
            Selection(
                severity=SeveritySpec(
                    categories=["environmental_damage"],
                    channels=["direct"],
                    threshold=2,
                )
            ),
        )
        out[
            "reason"
        ] += f" Current direct environmental score ≥2: {fraction_text(result)}. ‘Medium/high’ in the second archive is not a recovered threshold."
        if identifier == "ARCH-HARM-SEVERITY-01":
            out["component_checks"].append(
                {
                    "component": f"current-export direct environmental >1 count={expected.get('published_count', 1)}",
                    "status": (
                        SUPPORTED
                        if result.numerator == expected.get("published_count", 1)
                        else UPDATE
                    ),
                }
            )
    elif identifier == "ARCH-HARM-SEVERITY-02":
        result = series(
            "above_negligible_direct",
            Selection(
                severity=SeveritySpec(
                    categories=["toxic_or_malicious_content"],
                    channels=["direct"],
                    threshold=2,
                )
            ),
            end - 6,
            end,
        )
        out[
            "reason"
        ] += f" Illustrative last-seven-complete-year direct score ≥2 share: {points_text(result)}. No average ordinal severity is computed."
    elif identifier.startswith("ARCH-TIMELINE-HIGH-SEVERITY-INCIDENTS-"):
        index = int(identifier.rsplit("-", 1)[-1])
        if index == 1:
            for channels in (
                ["direct"],
                ["direct", "indirect"],
                ["direct", "indirect", "inferred"],
            ):
                result = fraction(
                    "2025." + "+".join(channels),
                    Selection(domains=["4"]),
                    Selection(
                        years=[2025],
                        severity=SeveritySpec(
                            dimensions=13, channels=channels, threshold=4
                        ),
                    ),
                )
                out[
                    "reason"
                ] += f" 2025 ≥4/{'+'.join(channels)} sensitivity: {fraction_text(result)}."
        elif index == 2:
            target = Selection(
                severity=SeveritySpec(
                    categories=["financial_loss"], channels=["direct"], threshold=3
                )
            )
            result = series("financial_ge3", target, 2021, end)
            share = fraction("malicious", Selection(domains=["4"]), target)
            out[
                "reason"
            ] += f" Published 1–5 scale uses $1M–$100M for financial level 3; strict >$1M cannot be recovered from the ordinal band. ≥3 proxy: {points_text(result)}. Domain 4 among proxy: {fraction_text(share)}."
    elif identifier.startswith("ARCH-TIMELINE-HIGH-SEVERITY-MULTIPLE-CATEGORIES-"):
        for threshold in (2, 3, 4):
            population = Selection(
                severity=SeveritySpec(
                    dimensions=10,
                    channels=["direct"],
                    threshold=threshold,
                    minimum_categories=2,
                )
            )
            if identifier.endswith("01"):
                result = series(f"direct_multiple_ge{threshold}", population, 2012, end)
            else:
                result = series(
                    f"domain4_multiple_ge{threshold}",
                    Selection(domains=["4"]),
                    end - 4,
                    end,
                    population,
                )
            out[
                "reason"
            ] += f" Explicit direct/ten-dimension/≥2-categories/score≥{threshold} sensitivity: {points_text(result)}."
        out["editorial_flags"].append(
            "‘Moderate/high’ thresholds and channels are ambiguous; ordinal-score sums are not used as category counts."
        )
    elif identifier.startswith("ARCH-TIMELINE-NUMBER-OF-PEOPLE-AFFECTED-"):
        field = (
            "total_people_reported_exposed"
            if identifier.endswith("01")
            else "total_people_reported_harmed"
        )
        cutoff = 1000000 if identifier.endswith("01") else 1000
        for score in (3, 4):
            population = Selection(
                numeric_gt={field: cutoff},
                severity=SeveritySpec(dimensions=10, threshold=score),
                domains=["4"] if identifier.endswith("02") else None,
            )
            result = series(f"reported_people_and_score{score}", population, 2023, 2024)
            out[
                "reason"
            ] += f" Illustrative 2023/2024 replay of records with more than {cutoff:,} people reportedly {'exposed' if identifier.endswith('01') else 'harmed'} and a direct or indirect score ≥{score} in the original ten dimensions ({'primary domain 4 only' if identifier.endswith('02') else 'all domains'}): {points_text(result)}; counts too small to support any trend statement."
        out["editorial_flags"].append(
            "People-count estimates lack unknown/overlap semantics and report-level validation; no population totals are inferred."
        )
    elif identifier == "ARCH-NATSEC-IMPACT-01":
        result = series(
            "natsec4", Selection(numeric_min={"natsec_overall_score": 4}), 2023, 2024
        )
        n0, n1 = [p["numerator"] for p in result["points"]]
        published = tuple(expected.get("published_counts", (10, 29)))
        out.update(
            status=SUPPORTED if (n0, n1) == published else UPDATE,
            reason=f"Fixed 2023/2024 window, overall score ≥4: {points_text(result)}. Original quote: {published[0]}→{published[1]}. Current retained tags differ; no prior export is available to attribute differences to backfill versus reclassification.",
            proposed_revision=f"In the current export, national-security overall score ≥4 is assigned to {n0} records dated 2023 and {n1} dated 2024. These are small counts; omit ‘almost tripled’. ",
        )
    elif identifier == "ARCH-NATSEC-IMPACT-02":
        result = series(
            "full_autonomy",
            Selection(equals={"natsec_autonomy_level": ["Full autonomy"]}),
            2022,
            end,
        )
        controlled = fraction(
            "controlled",
            Selection(equals={"natsec_autonomy_level": ["Human-controlled"]}),
        )
        out[
            "reason"
        ] += f" Bounded current replay: {points_text(result)}. Human-controlled: {fraction_text(controlled)}."
        out["component_checks"].append(
            {
                "component": "bounded strict count decline",
                "status": (
                    SUPPORTED
                    if result["trend"]["strictly_decreasing_count"]
                    else UNSUPPORTED
                ),
            }
        )
    elif identifier == "ARCH-NATSEC-IMPACT-03":
        for minimum in (2, 3):
            target = Selection(
                numeric_min={"natsec_overall_score": minimum},
                equals={"natsec_imminence_level": ["Near-term", "Immediate"]},
            )
            result = series(f"ge{minimum}_all_denominator", target, 2019, 2024)
            within = series(
                f"ge{minimum}_qualified_denominator",
                target,
                2019,
                2024,
                Selection(numeric_min={"natsec_overall_score": minimum}),
            )
            out[
                "reason"
            ] += f" 2019–2024 ≥{minimum} proxy, all records: {points_text(result)}; within-qualified: {points_text(within)}."
        out["editorial_flags"].append(
            "NatSec rubric starts at Minor, not Negligible; ‘non-negligible’ and ‘total’ need definitions."
        )
    return out


def nonempirical_check(engine: Engine, claim: dict[str, Any]) -> dict[str, Any]:
    identifier = claim["claim_id"]
    out: dict[str, Any] = {
        "interpretation": "Scope, methodology, reference definition, or dated study statement; not a population pattern calculated from this CSV.",
        "status": UNVERIFIABLE,
        "evidence_ids": [],
        "component_checks": [],
        "reason": "This export does not independently verify source-process, reference-framework, interface or historical study assertions. See preserved source and chart inventory for source/code checks.",
        "proposed_revision": None,
        "editorial_flags": [],
    }
    if claim["publication_status"] == "dated_publication":
        out["reason"] = (
            "A dated publication is not a current dashboard insight. Original pilot human/model annotations, prior export, and execution materials are absent. Today’s export cannot independently reproduce the study's agreement, model rankings, prompt improvements, or historical coverage/reclassification claims. Published figures/table transcriptions are preserved as reported evidence, not verification."
        )
        out["editorial_flags"] = [
            "Preserve original publication date and pilot scope",
            "No conversion of model agreement into statistical confidence",
        ]
    elif identifier in {"OVERVIEW-SCOPE-01", "TIME-SCOPE-02", "OVERVIEW-SCOPE-02"}:
        out.update(
            status=UPDATE,
            reason="Deployed source/API and representative browser checks establish thirteen pie grouping dimensions versus nine in the domain bar, an all-time pie versus a 2016-floor bar, inclusive ≥ severity thresholds, and an ineffective timeline preset: it sends minSeverity=4, which the API ignores (the response is byte-identical to no filter), while the effective key minSeverityHighest selects on the 13-dimension headline that includes model-inferred scores. Representative interactive checks in the in-app browser and Safari on September 27–28, 2026 reproduced both severity issues; see review/browser/BROWSER_CHECKS.md for coverage.",
            proposed_revision="Document each chart's actual year floor and available grouping choices, describe inclusive severity thresholds, change the severe-harm preset key to minSeverityHighest and relabel it 'highest severity score of 4 or more in any harm category, including harm inferred by the model'.",
        )
    elif identifier in {"HOME-SCOPE-03", "TIME-SCOPE-01", "VIEW-SCOPE-01"}:
        out.update(
            status=UPDATE,
            reason=f"The export has {len(HARM13)} component harm dimensions; the linked rubric defines {len(HARM10)}. The incident-view page says 13 categories of harm while the homepage, timeline, overview and NatSec pages say 10; the API offers 13 harm-category options and the detail source conditionally supports 15. Blanket complete-AIID coverage cannot be verified without the source roster.",
            proposed_revision="Use one consistent category count across pages, name the harm categories and rubric version actually used, link definitions for the added categories (psychological, epistemic, CSEA), and identify the dataset snapshot rather than asserting unqualified complete coverage.",
        )
    elif identifier == "APP-HIGHEST":
        out["reason"] = (
            "The client labels the API scalar highestSeverityScore 'Highest Direct Severity Score', but the export's highest_severity, which the live detail probes show is what the headline displays, equals the maximum over 13 harm dimensions and all three channels including model-inferred scores (1,698/1,698 rows). The precedence question is resolved empirically: the headline is not a direct score."
        )
        out["proposed_revision"] = (
            "Relabel as 'Highest severity score in any harm category (includes harm inferred by the model)', or switch the headline to a direct-only maximum and say so."
        )
        out["status"] = UPDATE
    return out


def audit_claims(
    engine: Engine, registry: dict[str, Any], definitions: dict[str, Any]
) -> list[AuditRecord]:
    results = []
    for claim in registry["claims"]:
        identifier = claim["claim_id"]
        if identifier in definitions["current_checks"]:
            definition = definitions["current_checks"][identifier]
            outcome = current_check(engine, claim, definition)
        elif claim["publication_status"] == "current_tracker" and claim["empirical"]:
            raise ValueError(f"Unmapped current empirical claim: {identifier}")
        elif claim["publication_status"] == "archived_tracker" and claim["empirical"]:
            definition = {
                "handler": "archival_check",
                "implementation": "tracker/audit.py:archival_check",
                "historical_snapshot_available": False,
                "replay": definitions["archived_replay"],
            }
            outcome = archival_check(engine, claim, definitions["archived_replay"])
        else:
            definition = {
                "handler": "source_or_study_disposition",
                "implementation": "tracker/audit.py:nonempirical_check",
            }
            outcome = nonempirical_check(engine, claim)
        missing = set(outcome["evidence_ids"]) - set(engine.measures)
        if missing:
            raise ValueError(f"Unresolved claim evidence: {missing}")
        results.append(
            AuditRecord(
                claim_id=identifier,
                exact_wording=claim["exact_wording"],
                source_url=claim["source_url"],
                retrieval_date_utc=claim["retrieval_date_utc"],
                retrieved_at_utc=claim["retrieved_at_utc"],
                quote_sha256=claim["quote_sha256"],
                source_snapshot=claim["source_snapshot"],
                publication_status=claim["publication_status"],
                empirical=claim["empirical"],
                original_time_window=claim["contextual_time_window"],
                calculation_definition=definition,
                **outcome,
            )
        )
    return results
