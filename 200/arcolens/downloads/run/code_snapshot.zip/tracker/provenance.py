"""Conditional ID-order diagnostics from one export.

These calculations use current labels and incident dates. They cannot recover
database-entry timestamps or historical classifications. A prefix match is a
hypothesis about composition, not a reconstruction of an earlier snapshot.
"""

from __future__ import annotations

from typing import Any, Callable, Sequence

from .data import Incident

Predicate = Callable[[Incident], bool]
ASSUMPTION = (
    "aiid_id is assumed to be assigned sequentially at AIID incident creation; "
    "this is unverified. Even if verified, ID order does not establish calendar entry dates or "
    "when it was reported, and cannot recover classifications in force at that time."
)


def ordered_by_id(rows: Sequence[Incident]) -> list[Incident]:
    return sorted(rows, key=lambda row: int(row.incident_id))


def prefix_scan(
    rows: Sequence[Incident], predicates: dict[str, Predicate]
) -> list[dict[str, Any]]:
    """Cumulative counts for each predicate over ID-ordered prefixes."""
    out: list[dict[str, Any]] = []
    totals = {name: 0 for name in predicates}
    n = 0
    latest = None
    for row in ordered_by_id(rows):
        n += 1
        for name, predicate in predicates.items():
            totals[name] += bool(predicate(row))
        if row.incident_date and (latest is None or row.incident_date > latest):
            latest = row.incident_date
        out.append(
            {
                "max_id": int(row.incident_id),
                "n": n,
                "latest_incident_date": str(latest) if latest else None,
                **totals,
            }
        )
    return out


def prefixes_matching(
    scan: list[dict[str, Any]],
    targets: dict[str, tuple[float, int]],
    minimum_n: int = 50,
) -> dict[str, Any]:
    """Prefixes where every predicate's share rounds (half-even) to its published value.

    targets maps predicate name -> (published_percent, rounding_decimals). The result
    is a labeled diagnostic, not an automatic reconciliation: single-figure match
    counts show how easily one rounded figure is met by chance.
    """
    joint = []
    single: dict[str, int] = {name: 0 for name in targets}
    for point in scan:
        if point["n"] < minimum_n:
            continue
        hits = {
            name: round(100 * point[name] / point["n"], decimals) == published
            for name, (published, decimals) in targets.items()
        }
        for name, hit in hits.items():
            single[name] += hit
        if all(hits.values()):
            joint.append(point)
    summary = lambda p: {
        k: p[k] for k in ("max_id", "n", "latest_incident_date")
    }  # noqa: E731
    return {
        "proxy": "ID-prefix snapshot proxy",
        "assumption": ASSUMPTION,
        "targets": {
            name: {"published_percent": p, "rounding_decimals": d}
            for name, (p, d) in targets.items()
        },
        "prefixes_scanned": sum(1 for p in scan if p["n"] >= minimum_n),
        "joint_matching_prefixes": len(joint),
        "single_figure_matching_prefixes": single,
        "first_joint_match": summary(joint[0]) if joint else None,
        "last_joint_match": summary(joint[-1]) if joint else None,
        "interpretation": (
            "Current-label ID prefixes reproduce the rounded published figures. This is consistent with a different dataset composition, but does not establish the origin or date of the published values, recover historical labels, or exclude a calculation error. The original snapshot is required."
            if joint
            else "No tested current-label ID prefix reproduces the figures jointly. This does not rule out an earlier dataset: deletions, reclassifications and nonsequential IDs are not reconstructed. The historical cause remains unknown."
        ),
    }


def prefix_with_count(scan: list[dict[str, Any]], count: int) -> dict[str, Any] | None:
    for point in scan:
        if point["n"] == count:
            return {k: point[k] for k in ("max_id", "n", "latest_incident_date")}
    return None


def first_id_by_year(rows: Sequence[Incident]) -> dict[int, int]:
    first: dict[int, int] = {}
    for row in rows:
        if row.year is None:
            continue
        identifier = int(row.incident_id)
        if row.year not in first or identifier < first[row.year]:
            first[row.year] = identifier
    return dict(sorted(first.items()))


def late_entry_table(
    rows: Sequence[Incident], years: Sequence[int]
) -> list[dict[str, Any]]:
    """Share of each year's records whose aiid_id exceeds the first id of the following year."""
    first = first_id_by_year(rows)
    table = []
    for year in years:
        cohort = [row for row in rows if row.year == year]
        next_first = first.get(year + 1)
        late = (
            [
                row
                for row in cohort
                if next_first is not None and int(row.incident_id) > next_first
            ]
            if next_first is not None
            else []
        )
        table.append(
            {
                "year": year,
                "records": len(cohort),
                "first_id_of_following_year": next_first,
                "records_above_following_year_minimum_id": len(late),
                "interpretation": "ID-order diagnostic only; incident dates are not database-entry timestamps.",
                "share_percent": (
                    round(100 * len(late) / len(cohort), 2) if cohort else None
                ),
            }
        )
    return table


def entry_order_composition(
    rows: Sequence[Incident],
    year: int,
    predicates: dict[str, Predicate],
    parts: int = 3,
) -> dict[str, Any]:
    cohort = ordered_by_id([row for row in rows if row.year == year])
    size = len(cohort)
    if size < parts * 10:
        return {
            "year": year,
            "records": size,
            "evaluable": False,
            "reason": f"fewer than {parts * 10} records",
        }
    bounds = [round(i * size / parts) for i in range(parts + 1)]
    groups = []
    for index in range(parts):
        chunk = cohort[bounds[index] : bounds[index + 1]]
        groups.append(
            {
                "id_order_part": index + 1,
                "records": len(chunk),
                "id_range": [int(chunk[0].incident_id), int(chunk[-1].incident_id)],
                **{
                    name: {
                        "count": sum(bool(p(r)) for r in chunk),
                        "percent": round(
                            100 * sum(bool(p(r)) for r in chunk) / len(chunk), 2
                        ),
                    }
                    for name, p in predicates.items()
                },
            }
        )
    return {
        "year": year,
        "records": size,
        "evaluable": True,
        "proxy": f"ID-ordered parts ({parts}) within one incident year; not verified entry chronology",
        "assumption": ASSUMPTION,
        "parts": groups,
        "interpretation": "These are differences between ID-ordered subsets of the current export. They do not establish historical backfill or its direction; database-entry timestamps and distinct historical exports are unavailable.",
    }


def monthly_counts(rows: Sequence[Incident], year: int) -> dict[str, int]:
    counts = {f"{year}-{month:02d}": 0 for month in range(1, 13)}
    for row in rows:
        if row.incident_date and row.incident_date.year == year:
            counts[f"{year}-{row.incident_date.month:02d}"] += 1
    return counts
