"""Input diagnostics and run invariants, separate from editorial judgments."""

from __future__ import annotations

import hashlib
import json
from collections import Counter
from pathlib import Path
from typing import Any

from .calc import Engine
from .candidates import cohort_info
from .data import CHANNELS, HARM10, HARM13, json_bytes, sha256_file
from .models import AuditRecord, Candidate
from .provenance import (
    entry_order_composition,
    first_id_by_year,
    late_entry_table,
    monthly_counts,
)


def quality_summary(engine: Engine) -> dict[str, Any]:
    rows = engine.rows
    fields = list(rows[0].raw)
    years = Counter(row.year for row in rows)
    unknown_scores = []
    aggregate_mismatches = []
    repeated_memberships = []
    missing_fields = {
        field: sum(not row.raw[field].strip() for row in rows) for field in fields
    }
    zero_coded: list[str] = []
    blank_cells: list[str] = []
    for row in rows:
        if row.zero_coded_severity_cells:
            zero_coded.append(row.incident_id)
        if row.blank_severity_cells:
            blank_cells.append(row.incident_id)
        if row.zero_coded_severity_cells or row.blank_severity_cells:
            unknown_scores.append(row.incident_id)
        if (
            len(row.additional) != len(set(row.additional))
            or row.primary in row.additional
        ):
            repeated_memberships.append(row.incident_id)
        for dimensions, field in (
            (HARM10, "highest_severity_10"),
            (HARM13, "highest_severity"),
        ):
            values = [
                row.severity[category][channel]
                for category in dimensions
                for channel in CHANNELS
            ]
            observed = max(
                (value for value in values if value is not None), default=None
            )  # the export's own aggregate treats 0 as a value, so 0 participates here
            raw = row.raw[field].strip()
            if raw and observed is not None and int(raw) != observed:
                aggregate_mismatches.append(
                    {
                        "incident_id": row.incident_id,
                        "field": field,
                        "raw": raw,
                        "observed_max": observed,
                    }
                )
    return {
        "rows": len(rows),
        "columns": len(fields),
        "unique_incident_ids": len({row.incident_id for row in rows}),
        "unit": "incident records, not reports/events/people",
        "missing_cells_by_field": missing_fields,
        "undated_ids": [row.incident_id for row in rows if row.year is None],
        "annual_counts": [
            {
                "year": year,
                "records": count,
                "complete_calendar_year": year is not None
                and year < engine.analysis_date.year,
            }
            for year, count in sorted(
                years.items(), key=lambda item: item[0] if item[0] is not None else -1
            )
        ],
        "unknown_or_zero_severity_ids": unknown_scores,
        "zero_coded_severity_ids": zero_coded,
        "blank_severity_ids": blank_cells,
        "zero_semantics_note": "Zero-coded and blank components are both treated as unknown by the calculations (methodology item 6); the exporter's own aggregates treat 0 as a value, which remains an open question for the exporter.",
        "first_id_by_year": first_id_by_year(rows),
        "late_entry_by_year": late_entry_table(
            rows,
            [
                year
                for year in sorted(years)
                if year is not None
                and year >= engine.analysis_date.year - 5
                and year < engine.analysis_date.year
            ],
        ),
        "current_year_monthly_counts": monthly_counts(rows, engine.analysis_date.year),
        "entry_order_composition": {
            str(year): entry_order_composition(
                rows,
                year,
                {
                    f"primary_{code}": (lambda r, c=code: r.primary == c)
                    for code, _ in Counter(
                        row.primary for row in rows if row.primary
                    ).most_common(3)
                }
                | {"eu_tier_1": lambda r: r.raw["eu_ai_act_risk_level"] == "1"},
                parts=2,
            )
            for year in (engine.analysis_date.year - 1, engine.analysis_date.year)
        },
        "dominant_cohort": cohort_info(engine),
        "duplicate_membership_ids_deduplicated_by_core": repeated_memberships,
        "highest_severity_observed_max_mismatches": aggregate_mismatches,
        "primary_subdomain_count": len({row.primary for row in rows if row.primary}),
        "all_subdomain_assignment_count": sum(len(row.subdomains) for row in rows),
        "model_prompt_cohorts": [
            {"model": key[0], "prompt_version": key[1], "count": count}
            for key, count in Counter(
                (row.raw["model_name"], row.raw["prompt_version"]) for row in rows
            ).most_common()
        ],
        "baseline_warning": "No historical export-to-export change is inferred. Source/prompt text and human reference labels are absent.",
    }


def verify_source_registry(root: Path, registry: dict[str, Any]) -> dict[str, Any]:
    paths = {}
    for claim in registry["claims"]:
        expected = hashlib.sha256(claim["exact_wording"].encode()).hexdigest()
        if expected != claim["quote_sha256"]:
            raise ValueError(f"Quotation hash mismatch: {claim['claim_id']}")
        for kind in ("raw", "text"):
            source = claim["source_snapshot"]
            if source.get(f"{kind}_path") and source.get(f"{kind}_sha256"):
                paths[source[f"{kind}_path"]] = source[f"{kind}_sha256"]
    for relative, expected in paths.items():
        if sha256_file(root / relative) != expected:
            raise ValueError(f"Source snapshot hash mismatch: {relative}")
    return {
        "quote_hashes_checked": len(registry["claims"]),
        "source_paths_checked": len(paths),
        "status": "passed",
        "scope": "Capture integrity, not source truth or browser rendering.",
    }


def validate_results(
    engine: Engine,
    candidates: list[Candidate],
    audit: list[AuditRecord],
    registry: dict[str, Any],
) -> dict[str, Any]:
    checks = {
        "unique_incident_ids": len(engine.rows)
        == len({row.incident_id for row in engine.rows}),
        "all_source_claims_have_disposition": {c.claim_id for c in audit}
        == {c["claim_id"] for c in registry["claims"]},
        "unique_claim_ids": len(audit) == len({c.claim_id for c in audit}),
        "unique_candidate_ids": len(candidates)
        == len({c.candidate_id for c in candidates}),
        "all_measure_fractions_revalidated": True,
        "numerator_ids_are_subset_of_denominator": True,
        "all_evidence_ids_refer_to_input": True,
        "no_current_year_in_full_year_trends": True,
        "all_candidate_and_claim_evidence_resolves": True,
        "id_set_content_hashes_match": True,
    }
    universe = {row.incident_id for row in engine.rows}
    for digest, ids in engine.id_sets.items():
        checks["id_set_content_hashes_match"] &= (
            hashlib.sha256(json_bytes(ids)).hexdigest() == digest
        )
        checks["all_evidence_ids_refer_to_input"] &= set(ids).issubset(universe)
    for measure in engine.measures.values():
        type(measure).model_validate(measure.model_dump())
        numerator = engine.id_sets[Path(measure.numerator_ids_ref).stem]
        denominator = engine.id_sets[Path(measure.denominator_ids_ref).stem]
        checks["numerator_ids_are_subset_of_denominator"] &= set(numerator).issubset(
            denominator
        )
        if (
            len(numerator) != measure.numerator
            or len(denominator) != measure.denominator_incident_count
        ):
            checks["all_measure_fractions_revalidated"] = False
    for series in engine.series_results.values():
        checks["no_current_year_in_full_year_trends"] &= all(
            point["year"] < engine.analysis_date.year for point in series["points"]
        )
    for item in candidates + audit:
        checks["all_candidate_and_claim_evidence_resolves"] &= set(
            item.evidence_ids
        ).issubset(engine.measures)
    if not all(checks.values()):
        raise AssertionError(json.dumps(checks, indent=2))
    return {
        "status": "passed",
        "checks": checks,
        "measures_checked": len(engine.measures),
        "id_sets_checked": len(engine.id_sets),
        "series_checked": len(engine.series_results),
        "limitation": "Internal invariant validation; the independent verifier additionally recalculates important results from the raw CSV.",
    }
