"""Read-only ingestion; explicit parsing rather than implicit NA conversion.

Every ingestion failure names the incident record and the field so that an
unattended monthly run reports what to fix. Digits are ASCII only; incident IDs
are normalised to canonical integers so that '01' and '1' collide; an explicit
severity score of 0 is kept distinct from a blank cell (both are treated as
unknown by the calculations, per the protocol, but are reported separately).
"""

from __future__ import annotations

import csv
import hashlib
import json
import re
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from typing import Any, Iterable

HARM10 = (
    "physical_harm",
    "infrastructure_damage",
    "property_damage",
    "financial_loss",
    "environmental_damage",
    "toxic_or_malicious_content",
    "differential_treatment",
    "human_and_civil_rights",
    "democratic_norms",
    "privacy",
)
HARM13 = HARM10 + ("psychological_harm", "epistemic_harm", "csea")
CHANNELS = ("direct", "indirect", "inferred")
SCALARS = (
    "causal_entity",
    "causal_intent",
    "causal_timing",
    "eu_ai_act_risk_level",
    "ai_goal_primary",
    "behaviour_type",
    "natsec_autonomy_level",
    "natsec_imminence_level",
    "natsec_novelty_level",
)
REQUIRED = (
    {
        "aiid_id",
        "title",
        "date",
        "classified_at",
        "domain_code",
        "subdomain_code",
        "additional_subdomains",
        "model_name",
        "prompt_version",
        "highest_severity",
        "highest_severity_10",
        "ai_goal_secondary",
        "natsec_overall_score",
        "missing_information",
        "ai_developers",
        "ai_models",
        "total_people_reported_harmed",
        "total_people_reported_exposed",
    }
    | set(SCALARS)
    | {f"{category}_severity_{channel}" for category in HARM13 for channel in CHANNELS}
)
ASCII_INTEGER = re.compile(r"[0-9]+")
# Leading numeric code with at most one dotted level; a third level is rejected, not truncated.
CODE = re.compile(r"^([0-9]+(?:\.[0-9]+)?)(?![.0-9])")
COUNT_FIELDS = {
    "report_count",
    "number_of_occurrences",
    "total_people_reported_harmed",
    "total_people_inferred_harmed",
    "total_people_reported_exposed",
    "total_people_inferred_exposed",
    "severity_sum_direct",
    "severity_sum_direct_10",
    "severity_sum_indirect_10",
    "severity_sum_inferred_10",
}
SCORE_FIELDS = {"highest_severity", "highest_severity_10", "natsec_overall_score"} | {
    f"natsec_{name}_score"
    for name in ("physical", "information", "sovereignty", "economic", "societal")
}


class IngestionError(ValueError):
    """A ValueError that always names the incident record and the field."""


def fail(identifier: str, field: str, message: str) -> IngestionError:
    return IngestionError(f"Incident {identifier}: {field}: {message}")


def ascii_integer(value: str, identifier: str, field: str) -> int:
    text = value.strip()
    if ASCII_INTEGER.fullmatch(text) is None:
        raise fail(
            identifier,
            field,
            f"requires a finite nonnegative ASCII integer, got {value!r}",
        )
    return int(text)


def validate_numeric_cells(raw: dict[str, str], identifier: str) -> None:
    """Reject nonfinite, fractional, signed, underscore or non-ASCII encodings; retain blanks."""
    for field in sorted((COUNT_FIELDS | SCORE_FIELDS).intersection(raw)):
        value = raw[field]
        if not value.strip():
            continue
        number = ascii_integer(value, identifier, field)
        if field in SCORE_FIELDS and number > 5:
            raise fail(identifier, field, f"outside 0..5, got {value!r}")


def code(value: str, identifier: str = "?", field: str = "classification") -> str:
    match = CODE.match(value.strip())
    if not match:
        raise fail(
            identifier,
            field,
            f"invalid classification code {value!r} (expected 'N' or 'N.N' followed by a label)",
        )
    return match.group(1)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def json_bytes(value: Any) -> bytes:
    return (
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    ).encode()


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(json_bytes(value))


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow(
                {
                    key: (
                        json.dumps(value, ensure_ascii=False)
                        if isinstance(value, (list, dict, tuple))
                        else value
                    )
                    for key, value in row.items()
                }
            )


def sorted_ids(ids: Iterable[str]) -> list[str]:
    return sorted(set(ids), key=lambda item: int(item))


@dataclass(frozen=True)
class Incident:
    raw: dict[str, str]
    incident_id: str
    incident_date: date | None
    domain: str | None
    primary: str | None
    additional: tuple[str, ...]
    severity: dict[str, dict[str, int | None]]
    identities: dict[str, tuple[str, ...] | None]

    @property
    def year(self) -> int | None:
        return self.incident_date.year if self.incident_date else None

    @property
    def subdomains(self) -> set[str]:
        return ({self.primary} if self.primary else set()) | set(self.additional)

    @property
    def domains(self) -> set[str]:
        return {item.split(".")[0] for item in self.subdomains}

    @property
    def zero_coded_severity_cells(self) -> int:
        return sum(
            value == 0
            for channels in self.severity.values()
            for value in channels.values()
        )

    @property
    def blank_severity_cells(self) -> int:
        return sum(
            value is None
            for channels in self.severity.values()
            for value in channels.values()
        )


def parse_timestamp(value: str, identifier: str, field: str) -> datetime:
    try:
        return datetime.fromisoformat(value.strip())
    except ValueError as error:
        raise fail(
            identifier, field, f"unparseable timestamp {value!r} ({error})"
        ) from error


def parse_row(raw: dict[str, str], analysis_date: date) -> Incident:
    identifier_text = raw["aiid_id"].strip()
    if ASCII_INTEGER.fullmatch(identifier_text) is None:
        raise IngestionError(
            f"Incident {identifier_text!r}: aiid_id: missing or non-numeric incident ID"
        )
    identifier = str(
        int(identifier_text)
    )  # canonical form: '01' and '1' are the same record
    validate_numeric_cells(raw, identifier)
    incident_date = (
        parse_timestamp(raw["date"], identifier, "date").date()
        if raw["date"].strip()
        else None
    )
    if incident_date and incident_date > analysis_date:
        raise fail(identifier, "date", f"future-dated: {incident_date}")
    if raw["classified_at"].strip():
        classified = parse_timestamp(raw["classified_at"], identifier, "classified_at")
        if classified.date() > analysis_date:
            raise fail(
                identifier, "classified_at", "classified after the analysis date"
            )
    primary = (
        code(raw["subdomain_code"], identifier, "subdomain_code")
        if raw["subdomain_code"].strip()
        else None
    )
    domain = (
        code(raw["domain_code"], identifier, "domain_code")
        if raw["domain_code"].strip()
        else None
    )
    if primary and domain and primary.split(".")[0] != domain:
        raise fail(
            identifier,
            "domain_code",
            f"primary domain {domain} does not match subdomain {primary}",
        )
    if primary and not domain:
        domain = primary.split(".")[
            0
        ]  # derived from the primary code; recorded, not guessed
    try:
        additional_raw = json.loads(raw["additional_subdomains"] or "[]")
    except json.JSONDecodeError as error:
        raise fail(
            identifier, "additional_subdomains", f"invalid JSON ({error})"
        ) from error
    if not isinstance(additional_raw, list):
        raise fail(identifier, "additional_subdomains", "must be a JSON list")
    additional: list[str] = []
    for index, item in enumerate(additional_raw):
        if not isinstance(item, dict) or not isinstance(item.get("code"), str):
            raise fail(
                identifier,
                "additional_subdomains",
                f"item {index} must be an object with a string 'code'",
            )
        additional.append(
            code(item["code"], identifier, f"additional_subdomains[{index}].code")
        )
    # Duplicated memberships do not become extra incidents. Audit exposes duplicates.
    severity: dict[str, dict[str, int | None]] = {}
    for category in HARM13:
        severity[category] = {}
        for channel in CHANNELS:
            field = f"{category}_severity_{channel}"
            if not raw[field].strip():
                severity[category][channel] = None  # blank: not assessed
                continue
            score = ascii_integer(raw[field], identifier, field)
            if not 0 <= score <= 5:
                raise fail(identifier, field, f"outside 0..5, got {raw[field]!r}")
            severity[category][
                channel
            ] = score  # 0 is kept as zero-coded; calculations treat it as unknown
    identities: dict[str, tuple[str, ...] | None] = {}
    for field in ("ai_models", "ai_developers"):
        if not raw[field].strip():
            identities[field] = None
            continue
        try:
            parsed = json.loads(raw[field])
        except json.JSONDecodeError as error:
            raise fail(
                identifier, field, f"invalid JSON identity array ({error})"
            ) from error
        if parsed is not None and (
            not isinstance(parsed, list) or any(not isinstance(x, str) for x in parsed)
        ):
            raise fail(
                identifier,
                field,
                "identity array must be a JSON list of strings or null",
            )
        identities[field] = tuple(parsed) if parsed is not None else None
    return Incident(
        raw,
        identifier,
        incident_date,
        domain,
        primary,
        tuple(additional),
        severity,
        identities,
    )


def load_incidents(path: Path, analysis_date: date) -> list[Incident]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        fields = reader.fieldnames or []
        if len(fields) != len(set(fields)):
            raise ValueError("Duplicate CSV column names")
        missing = REQUIRED - set(fields)
        if missing:
            raise ValueError(f"Required fields missing: {sorted(missing)}")
        rows: list[Incident] = []
        for logical_row, raw in enumerate(reader, 2):
            if None in raw or any(value is None for value in raw.values()):
                raise ValueError(f"Malformed CSV logical record {logical_row}")
            rows.append(parse_row(raw, analysis_date))
    if not rows:
        raise ValueError("CSV contains no data records")
    seen: dict[str, str] = {}
    for row in rows:
        if row.incident_id in seen:
            raise ValueError(
                f"Duplicate incident IDs: {row.incident_id} appears as {seen[row.incident_id]!r} and {row.raw['aiid_id']!r}; resolve explicitly before analysis"
            )
        seen[row.incident_id] = row.raw["aiid_id"]
    return rows
