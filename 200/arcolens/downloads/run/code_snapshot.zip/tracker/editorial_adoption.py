"""Reuse a completed review only when its entire evidence is exactly equivalent.

No model is called and no source artifact is changed. Only the top-level run_id
may differ. A successful record is a provenance link, never publication approval.
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from . import editorial
from .data import json_bytes, sha256_file

ADOPTED = "adopted_equivalent_evidence_requires_human_review"


def _load(path: Path) -> Any:
    def unique(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"Duplicate JSON key {key!r} in {path}")
            result[key] = value
        return result

    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=unique)


def differences(expected: Any, actual: Any, path: str = "") -> list[dict[str, Any]]:
    """Type-sensitive JSON comparison; object order is immaterial, list order isn't."""
    if type(expected) is not type(actual):
        return [
            {
                "path": path or "/",
                "expected": expected,
                "actual": actual,
                "reason": "different type",
            }
        ]
    if isinstance(expected, dict):
        result = []
        for key in sorted(expected.keys() | actual.keys()):
            child = path + "/" + key.replace("~", "~0").replace("/", "~1")
            if key not in expected or key not in actual:
                result.append(
                    {
                        "path": child,
                        "expected": expected.get(key),
                        "actual": actual.get(key),
                        "reason": "missing field",
                        "missing_from": "expected" if key not in expected else "actual",
                    }
                )
            else:
                result.extend(differences(expected[key], actual[key], child))
        return result
    if isinstance(expected, list):
        if len(expected) != len(actual):
            return [
                {
                    "path": path or "/",
                    "expected": expected,
                    "actual": actual,
                    "reason": "different list length",
                }
            ]
        return [
            d
            for index, (left, right) in enumerate(zip(expected, actual))
            for d in differences(left, right, path + "/" + str(index))
        ]
    if expected != actual:
        return [
            {
                "path": path or "/",
                "expected": expected,
                "actual": actual,
                "reason": "different value",
            }
        ]
    return []


def _manifest(folder: Path, manifest: Path) -> dict[str, Any]:
    """Check every file, including nested manifests; reject unsafe paths/symlinks."""
    folder, manifest = folder.resolve(), manifest.resolve()
    if manifest.parent != folder or not manifest.is_file():
        raise ValueError("Manifest must be an existing direct child of its folder")
    raw = _load(manifest)
    listed = raw["files"]
    if not isinstance(listed, dict):
        raise ValueError("Manifest files must be an object")
    actual: dict[str, str] = {}
    for path in folder.rglob("*"):
        if path.is_symlink():
            raise ValueError(f"Symlinks cannot be adopted: {path}")
        if path.is_file() and path != manifest:
            actual[path.relative_to(folder).as_posix()] = sha256_file(path)
    for relative, expected in listed.items():
        rel = Path(relative)
        if (
            rel.is_absolute()
            or ".." in rel.parts
            or rel.as_posix() != relative
            or not isinstance(expected, str)
            or len(expected) != 64
        ):
            raise ValueError(f"Invalid manifest entry: {relative!r}")
    mismatches = differences(listed, actual)
    if mismatches:
        raise ValueError("Manifest integrity failure: " + json.dumps(mismatches))
    return {"sha256": sha256_file(manifest), "files_checked": len(actual)}


def _require_equal(expected: Any, actual: Any, stage: str) -> None:
    found = differences(expected, actual)
    if found:
        raise _Mismatch(stage, found)


class _Mismatch(ValueError):
    def __init__(self, stage: str, found: list[dict[str, Any]]) -> None:
        self.stage, self.found = stage, found
        super().__init__(stage)


def _recorded_attempt(
    cycle: Path, name: str, payload: dict[str, Any], response: Any
) -> dict[str, Any]:
    """Follow the adapter's bounded retry chain, retaining earlier failures."""
    baseline: dict[str, Any] | None = None
    failures = []
    for number in range(3):
        directory = cycle / (name if number == 0 else f"{name}-retry-{number}")
        call = _load(directory / "call.json")
        request = _load(directory / "request.json")
        schema = _load(directory / "schema.json")
        for field, filename in (
            ("request_sha256", "request.json"),
            ("schema_sha256", "schema.json"),
        ):
            _require_equal(
                sha256_file(directory / filename), call.get(field), name + " " + field
            )
        _require_equal(payload, request["evidence"], name + " request evidence")
        settings = {
            "request": request,
            "schema": schema,
            **{
                key: call.get(key)
                for key in ("provider", "requested_model", "requested_effort")
            },
        }
        if baseline is None:
            baseline = settings
        else:
            _require_equal(baseline, settings, name + " retry request and settings")
        if call.get("status") != "response_received":
            failures.append(
                {
                    "attempt_directory": directory.name,
                    "status": call.get("status", "incomplete"),
                    "call_sha256": sha256_file(directory / "call.json"),
                }
            )
            continue
        _require_equal(
            response.model_dump(),
            _load(directory / "structured_response.json"),
            name + " original response",
        )
        if call.get("stdout_sha256") is not None:
            _require_equal(
                sha256_file(directory / "stdout.txt"),
                call["stdout_sha256"],
                name + " stdout hash",
            )
        # The adapter returns the first successful response. Later attempts
        # would make the final response's selection ambiguous.
        if any(
            (cycle / f"{name}-retry-{later}").exists() for later in range(number + 1, 3)
        ):
            raise ValueError(f"{name} contains attempts after its successful response")
        return {
            **{
                key: call.get(key)
                for key in (
                    "provider",
                    "requested_model",
                    "requested_effort",
                    "started_at_utc",
                    "completed_at_utc",
                )
            },
            "attempt_directory": directory.name,
            "preserved_prior_attempts": failures,
            "call_sha256": sha256_file(directory / "call.json"),
        }
    raise ValueError(f"{name} has no successful response in its bounded retry chain")


def validate_editorial_adoption(
    cycle: Path,
    manifest: Path,
    source_run: Path,
    current_run: Path,
    context: Path,
) -> dict[str, Any]:
    """Return an adoption record, or explicit differences and no adoption.

    Paths are absolute in the record. Save a successful result outside the source
    cycle and immutable runs. Consumers must call verify_adoption_record before
    accepting it for a particular current run.
    """
    paths = {
        key: Path(value).resolve()
        for key, value in {
            "cycle": cycle,
            "manifest": manifest,
            "source_run": source_run,
            "current_run": current_run,
            "context": context,
        }.items()
    }
    cycle, manifest, source_run, current_run, context = paths.values()
    result: dict[str, Any] = {
        "schema_version": 1,
        "status": "not_adopted",
        "paths": {k: str(v) for k, v in paths.items()},
        "model_calls_performed": False,
        "publication_authorized": False,
    }
    stage = "artifact integrity"
    try:
        cycle_manifest = _manifest(cycle, manifest)
        source_manifest = _manifest(source_run, source_run / "artifact_manifest.json")
        current_manifest = _manifest(
            current_run, current_run / "artifact_manifest.json"
        )
        context_hash = sha256_file(context)
        # Use the current run verifier as well as exhaustive artifact hashes.
        from tracker.__main__ import verify_run

        source_checks = verify_run(source_run, root=source_run.parent.parent)
        current_checks = verify_run(current_run, root=current_run.parent.parent)
        stage = "completed cycle"
        status = _load(cycle / "status.json")
        if (
            status.get("status") != "completed_requires_human_review"
            or status.get("publication_authorized") is not False
            or status.get("review_suggestions_grounded") is not True
        ):
            raise ValueError(
                "Cycle is not a completed, grounded review requiring human approval"
            )
        recorded = _load(cycle / "evidence.json")
        evidence_digest = sha256_file(cycle / "evidence.json")
        _require_equal(
            evidence_digest, status.get("evidence_sha256"), "status evidence hash"
        )
        _require_equal(recorded["run_id"], status.get("run_id"), "status source run")
        _require_equal(
            context_hash,
            recorded.get("additional_context_sha256"),
            "exact context file",
        )
        _require_equal(
            _load(context),
            recorded.get("additional_verified_context"),
            "context content",
        )
        stage = "reconstructed evidence"
        source_evidence = editorial.evidence_payload(source_run, context)
        current_evidence = editorial.evidence_payload(current_run, context)
        _require_equal(
            recorded, source_evidence, "recorded versus reconstructed source evidence"
        )
        source_comparable = {k: v for k, v in source_evidence.items() if k != "run_id"}
        current_comparable = {
            k: v for k, v in current_evidence.items() if k != "run_id"
        }
        _require_equal(
            source_comparable,
            current_comparable,
            "source versus proposed current evidence",
        )
        stage = "response and request provenance"
        draft = editorial.EditorialDraft.model_validate(_load(cycle / "draft.json"))
        review = editorial.EditorialReview.model_validate(_load(cycle / "review.json"))
        draft_digest = sha256_file(cycle / "draft.json")
        _require_equal(draft_digest, status.get("draft_sha256"), "status draft hash")
        grounding = editorial.validate_draft(draft, recorded, evidence_digest)
        screening = editorial.validate_review(
            review, recorded, evidence_digest, draft_digest
        )
        if (
            grounding["all_grounded"] is not True
            or screening["all_grounded"] is not True
        ):
            raise ValueError(
                "Completed outputs fail the current numerical/reference screening"
            )
        _require_equal(
            grounding, _load(cycle / "grounding.json"), "recorded draft screening"
        )
        _require_equal(
            screening,
            _load(cycle / "review_screening.json"),
            "recorded review screening",
        )
        expected_payloads = {
            "generation": {**recorded, "evidence_sha256": evidence_digest},
            "review": {
                **recorded,
                "evidence_sha256": evidence_digest,
                "draft": draft.model_dump(),
                "draft_sha256": draft_digest,
                "numerical_screening": grounding,
            },
        }
        providers: dict[str, Any] = {}
        for name, response in (("generation", draft), ("review", review)):
            providers[name] = _recorded_attempt(
                cycle, name, expected_payloads[name], response
            )
        # Ensure input files have not changed while this check ran.
        stage = "final integrity recheck"
        _require_equal(cycle_manifest, _manifest(cycle, manifest), stage + " cycle")
        _require_equal(
            source_manifest,
            _manifest(source_run, source_run / "artifact_manifest.json"),
            stage + " source",
        )
        _require_equal(
            current_manifest,
            _manifest(current_run, current_run / "artifact_manifest.json"),
            stage + " current",
        )
        _require_equal(context_hash, sha256_file(context), stage + " context")
        result.update(
            status=ADOPTED,
            created_at_utc=datetime.now(timezone.utc).isoformat(),
            original_review_run_id=source_evidence["run_id"],
            current_run_id=current_evidence["run_id"],
            input_sha256=current_evidence["input_sha256"],
            analysis_date=current_evidence["analysis_date"],
            original_evidence_sha256=evidence_digest,
            context_sha256=context_hash,
            equivalent_evidence_sha256=hashlib.sha256(
                json_bytes(source_comparable)
            ).hexdigest(),
            original_draft_sha256=draft_digest,
            original_review_sha256=sha256_file(cycle / "review.json"),
            artifact_manifests={
                "cycle": cycle_manifest,
                "source_run": source_manifest,
                "current_run": current_manifest,
            },
            checks={
                "source_run": source_checks,
                "current_run": current_checks,
                "draft_screening": True,
                "review_screening": True,
            },
            original_model_calls=providers,
            allowed_difference="top-level run_id only",
            meaning="The original models reviewed the original recorded request. The current run's evidence is mechanically identical except for its top-level run_id. No new model review occurred. Human review remains required.",
            differences=[],
        )
    except _Mismatch as error:
        result.update(stage=error.stage, differences=error.found)
    except (
        OSError,
        ValueError,
        TypeError,
        KeyError,
        AttributeError,
        SystemExit,
    ) as error:
        result.update(stage=stage, differences=[{"path": "/", "reason": str(error)}])
    return result


def verify_adoption_record(record: dict[str, Any], current_run: Path) -> dict[str, Any]:
    """Revalidate a saved record against its current artifacts and exact run."""
    try:
        if record.get("status") != ADOPTED:
            raise ValueError("Record does not contain a successful adoption")
        paths = record["paths"]
        if Path(paths["current_run"]).resolve() != Path(current_run).resolve():
            raise ValueError("Adoption is bound to a different current run path")
        fresh = validate_editorial_adoption(**{k: Path(v) for k, v in paths.items()})
        if fresh["status"] != ADOPTED:
            return fresh
        # Creation time and the optional latest-run pointer's current state are
        # not stable: neither changes artifact/evidence/model provenance.
        stable = {
            k: v for k, v in record.items() if k not in ("created_at_utc", "checks")
        }
        actual = {
            k: v for k, v in fresh.items() if k not in ("created_at_utc", "checks")
        }
        _require_equal(stable, actual, "saved adoption binding")
        return fresh
    except _Mismatch as error:
        return {
            "status": "not_adopted",
            "publication_authorized": False,
            "stage": error.stage,
            "differences": error.found,
        }
    except (OSError, ValueError, TypeError, KeyError) as error:
        return {
            "status": "not_adopted",
            "publication_authorized": False,
            "differences": [{"path": "/", "reason": str(error)}],
        }
