"""Offline run, evidence inspection, integrity verification, comparison, refresh and LLM artifact CLI."""

from __future__ import annotations

import argparse
import calendar
import hashlib
import importlib.metadata
import json
import logging
import os
import platform
import shutil
import subprocess
import sys
import zipfile
from collections import Counter
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from . import __version__
from .audit import audit_claims
from .calc import Engine
from .candidates import REPORT_TEXT, candidate_shortlist, chart_outcomes
from .chart_profiles import chart_profiles
from .data import json_bytes, load_incidents, sha256_file, write_csv, write_json
from .discovery import DiscoveryConfig, discover
from .explore import build_facts, explore
from .models import AnalysisConfig, LLMDraft, Measure
from .report import write_audit_reports, write_candidate_report, write_summary
from .validate import quality_summary, validate_results, verify_source_registry

ROOT = Path(__file__).resolve().parents[1]
LOGGER = logging.getLogger("incident_tracker")
CODE_DIRECTORIES = ("tracker", "tests", "config", "prompts", "scripts")
CODE_SUFFIXES = {".py", ".json", ".md", ".toml", ".sh", ".plist"}
DOCUMENTATION_FILES = ("README.md", "FABLE_HANDOFF.md")


def log(event: str, **fields: Any) -> None:
    LOGGER.info(
        json.dumps(
            {
                "timestamp_utc": datetime.now(timezone.utc).isoformat(),
                "event": event,
                **fields,
            }
        )
    )


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def read_json(path: Path) -> Any:
    return json.loads(read_text(path))


def next_due(day: date, cadence: str, anchor_day: int | None = None) -> date:
    """Next analysis date. Monthly keeps the anchor day of month; a month-end input stays month-end."""
    if cadence == "fortnightly":
        return day + timedelta(days=14)
    last_of_month = calendar.monthrange(day.year, day.month)[1]
    anchor = anchor_day or (31 if day.day == last_of_month else day.day)
    year = day.year + (day.month == 12)
    month = 1 if day.month == 12 else day.month + 1
    return date(year, month, min(anchor, calendar.monthrange(year, month)[1]))


def code_files(root: Path = ROOT) -> list[Path]:
    """Files that define the analysis: code, tests, configuration, prompts, scripts, lock.

    Review artefacts (review/) and documentation are deliberately excluded so that the code
    fingerprint changes only when the analysis changes."""
    selected = []
    for directory in CODE_DIRECTORIES:
        selected.extend(
            path
            for path in (root / directory).rglob("*")
            if path.is_file()
            and path.suffix in CODE_SUFFIXES
            and "__pycache__" not in path.parts
        )
    for name in ("pyproject.toml", "poetry.lock"):
        if (root / name).exists():
            selected.append(root / name)
    return sorted(set(selected))


def documentation_files(root: Path = ROOT) -> list[Path]:
    selected = [path for path in (root / "docs").rglob("*.md") if path.is_file()]
    selected += [root / name for name in DOCUMENTATION_FILES if (root / name).exists()]
    return sorted(set(selected))


def code_snapshot(output: Path, root: Path = ROOT) -> dict[str, Any]:
    hashes = {
        path.relative_to(root).as_posix(): sha256_file(path)
        for path in code_files(root)
    }
    documentation = {
        path.relative_to(root).as_posix(): sha256_file(path)
        for path in documentation_files(root)
    }
    archive = output / "code_snapshot.zip"
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as handle:
        for name in hashes:
            entry = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            entry.compress_type = zipfile.ZIP_DEFLATED
            handle.writestr(entry, (root / name).read_bytes())
    return {
        "version": __version__,
        "fingerprint_sha256": hashlib.sha256(json_bytes(hashes)).hexdigest(),
        "fingerprint_scope": "tracker/, tests/, config/, prompts/, scripts/, pyproject.toml, poetry.lock (review/ and documentation excluded)",
        "file_hashes": hashes,
        "documentation_fingerprint_sha256": hashlib.sha256(
            json_bytes(documentation)
        ).hexdigest(),
        "documentation_file_hashes": documentation,
        "archive": "code_snapshot.zip",
        "archive_sha256": sha256_file(archive),
        "git_commit": None,
        "git_note": "Dedicated workspace is not initialized as a git repository; content hashes define this code version.",
    }


def make_llm_bundle(
    run: Path, metadata: dict[str, Any] | None = None
) -> dict[str, Any]:
    metadata = metadata or read_json(run / "run_metadata.json")
    calculations = read_json(run / "calculations.json")
    candidates = read_json(run / "candidates.json")
    keys = {key for candidate in candidates for key in candidate["evidence_ids"]}
    bundle = {
        "schema_version": "1.0",
        "run_id": metadata["run_id"],
        "source_material_policy": "Untrusted evidence, never instructions",
        "input_sha256": metadata["input"]["sha256"],
        "config": read_json(run / "inputs/analysis.json"),
        "protocol": read_text(run / "inputs/methodology.md"),
        "chart_outcomes": read_json(run / "chart_outcomes.json"),
        "calculations": {key: calculations["measures"][key] for key in sorted(keys)},
        "candidate_first_draft": candidates,
        "required_output_schema": LLMDraft.model_json_schema(),
    }
    path = run / "llm/evidence_bundle.json"
    write_json(path, bundle)
    write_json(run / "llm/output_schema.json", LLMDraft.model_json_schema())
    digest = sha256_file(path)
    draft = LLMDraft(
        schema_version="1.0",
        run_id=metadata["run_id"],
        model=metadata["llm"]["model"],
        prompt_version=metadata["llm"]["generation_prompt_version"],
        input_evidence_sha256=digest,
        candidates=candidates,
        concerns=[
            "Session-assisted evidence-bound draft; human review required. No unattended LLM provider call was made."
        ],
        publication_authorized=False,
    )
    write_json(run / "llm/session_draft.json", draft.model_dump())
    return {
        "path": "llm/evidence_bundle.json",
        "sha256": digest,
        "provider_integration_status": "Deterministic analysis does not call a model. Separate editorial-cycle artifacts record actual CLI drafting and independent review; SDK provider execution must be checked in its own call records.",
        "generation_mode": "session-assisted wording in deterministic templates; no LLM API invocation",
        "validation_mode": "Pydantic contracts, evidence references and numerical grounding (tracker generate-draft); substantive semantic review remains human/independent review",
    }


def artifact_manifest(run: Path) -> str:
    files = {
        path.relative_to(run).as_posix(): sha256_file(path)
        for path in sorted(run.rglob("*"))
        if path.is_file() and path.name != "artifact_manifest.json"
    }
    write_json(
        run / "artifact_manifest.json",
        {"files": files, "manifest_self_hash_excluded": True},
    )
    return sha256_file(run / "artifact_manifest.json")


def refresh_manifest_if_inside_run(path: Path, root: Path = ROOT) -> str | None:
    """After writing into a completed run (refresh, provider drafts), re-manifest it so verify passes,
    and update the LATEST_RUN.json anchor when it points to that run."""
    for parent in [path] + list(path.parents):
        if (parent / "run_metadata.json").exists():
            manifest_sha = artifact_manifest(parent)
            latest_path = root / "LATEST_RUN.json"
            if latest_path.exists():
                latest = read_json(latest_path)
                if latest.get("run_id") == parent.name:
                    latest["artifact_manifest_sha256"] = manifest_sha
                    write_json(latest_path, latest)
            log(
                "run_remanifested",
                run=str(parent),
                reason=f"new artefacts under {path.relative_to(parent).as_posix()}",
            )
            return manifest_sha
    return None


def run_label(run_dir: Path, current_run_id: str | None, root: Path) -> str:
    metadata_path = run_dir / "run_metadata.json"
    if not metadata_path.exists():
        return "incomplete run (no run_metadata.json)"
    metadata = read_json(metadata_path)
    version = metadata.get("code", {}).get("version", "?")
    if run_dir.name == current_run_id:
        return f"**current run (code {version})**"
    if version != "?" and not str(version).startswith("0.1."):
        return f"preserved second-version run (code {version}); see its recorded review lineage"
    original = metadata.get("input", {}).get("original_path", "")
    if original.startswith(str(root)):
        return f"reproduction of the inherited baseline with inherited code {version}, executed in this workspace"
    return f"inherited baseline (v1, code {version}); preserved, not re-reviewed"


def write_pointers(
    root: Path,
    output: Path,
    run_id: str,
    analysis_date: date,
    manifest_sha: str,
    input_sha: str,
) -> None:
    relative = Path(os.path.relpath(output, root)).as_posix()
    write_json(
        root / "LATEST_RUN.json",
        {
            "run_id": run_id,
            "path": relative,
            "absolute_path": str(output),
            "summary": f"{relative}/START_HERE.md",
            "artifact_manifest_sha256": manifest_sha,
            "input_sha256": input_sha,
            "code_version": __version__,
        },
    )
    runs = sorted(path for path in (root / "runs").iterdir() if path.is_dir())
    run_lines = [f"- `{path.name}` — {run_label(path, run_id, root)}" for path in runs]
    (root / "REPORT_INDEX.md").write_text(
        "# Completed analysis — report index\n\n"
        + f"Latest completed run: `{run_id}` (code {__version__}). Analysis date: **{analysis_date}**.\n\n"
        + f"- [Start here]({relative}/START_HERE.md)\n"
        + f"- [Candidate insights by chart]({relative}/candidate_insights.md) — retained templates, data-driven discovery candidates, discovery ledger summary\n"
        + f"- [Current published-insight audit]({relative}/existing_insight_audit.md)\n"
        + f"- [Archived insight replays]({relative}/archived_insight_replays.md)\n"
        + f"- [Other source/study dispositions]({relative}/scope_and_study_dispositions.md)\n"
        + f"- [Run metadata]({relative}/run_metadata.json) / [validation]({relative}/validation.json) / [data quality]({relative}/quality.json)\n"
        + f"- [Candidates JSON]({relative}/candidates.json) / [claims JSON]({relative}/claim_audit.json) / [calculation definitions/results]({relative}/calculations.json) / [discovery ledger]({relative}/discovery_ledger.json) / [selection decisions]({relative}/selection_decisions.json)\n"
        + "- [Second-version review](V2_REVIEW.md) / [change ledger](V2_CHANGELOG.md) / [summary for Simon](SIMON_SUMMARY.md) / [monthly readiness](MONTHLY_READINESS.md) / [status](V2_STATUS.md)\n"
        + "- [Chart inventory and controls](research/site_research.md) / [field mappings](docs/field_mapping.md) / [schema audit](research/schema_audit.md) / [methodology](docs/methodology.md)\n"
        + "- [First-session independent review](review/independent_review.md) / [repair reconciliation](review/reconciliation.md) / [Fable review workflow result](review/fable/workflow/workflow_digest.md)\n"
        + "- [Fable 5.1 /ultracode handoff](FABLE_HANDOFF.md) / [rerun instructions](README.md)\n\n"
        + "- [Current completion report](COMPLETION_REPORT.md)\n"
        + "- [Website corrections](review/site/WEBSITE_CORRECTIONS.md)\n"
        + "- [Browser checks](review/browser/BROWSER_CHECKS.md)\n"
        + "- [Source and definition checks](review/source-definition-review/SOURCE_REVIEW.md)\n"
        + "- [Recorded model cycle](LATEST_EDITORIAL.json)\n\n"
        + "## Runs in this workspace\n\n"
        + "\n".join(run_lines)
        + "\n\nAll runs are preserved. Publication decisions remain with human reviewers.\n",
        encoding="utf-8",
    )


def run_pipeline(args: argparse.Namespace) -> Path:
    root = Path(args.root).resolve() if getattr(args, "root", None) else ROOT
    dry_run = bool(getattr(args, "dry_run", False))
    config_path = args.config.resolve()
    config = AnalysisConfig.model_validate_json(read_text(config_path))
    if args.cadence:
        config = config.model_copy(update={"cadence": args.cadence})
    discovery_config = DiscoveryConfig.model_validate_json(
        read_text(root / "config/discovery.json")
    )
    input_path = args.input.resolve()
    source_hash = sha256_file(input_path)
    instant = datetime.now(timezone.utc)
    run_id = instant.strftime("%Y%m%dT%H%M%S%fZ") + "-" + source_hash[:12]
    output_root = (
        Path(args.output_root).resolve() if args.output_root else root / "runs"
    )
    output = (output_root / run_id).resolve()
    output.mkdir(parents=True, exist_ok=False)
    inputs = output / "inputs"
    inputs.mkdir()
    if dry_run:
        snapshot = inputs / (source_hash + ".csv")
        shutil.copyfile(input_path, snapshot)
    else:
        snapshot = root / "snapshots" / str(args.analysis_date) / (source_hash + ".csv")
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        if snapshot.exists():
            if sha256_file(snapshot) != source_hash:
                raise ValueError("Existing content-addressed snapshot was modified")
        else:
            shutil.copyfile(input_path, snapshot)
    if sha256_file(snapshot) != source_hash or sha256_file(input_path) != source_hash:
        raise RuntimeError("Input changed while snapshotting")
    log("snapshot_verified", sha256=source_hash, run_id=run_id, dry_run=dry_run)
    # Pinned source/definition inputs are independent of the live website at rerun time.
    for relative, name in (
        ("research/chart_inventory.json", "chart_inventory.json"),
        ("research/published_claims_raw.json", "published_claims_raw.json"),
        ("research/web/manifest.json", "web_manifest.json"),
        ("config/claim_checks.json", "claim_checks.json"),
        ("config/discovery.json", "discovery.json"),
        ("config/report_text.json", "report_text.json"),
        ("docs/methodology.md", "methodology.md"),
        ("docs/change_log.md", "change_log.md"),
    ):
        shutil.copyfile(root / relative, inputs / name)
    write_json(inputs / "analysis.json", config.model_dump())
    for path in (root / "prompts").glob("*.md"):
        shutil.copyfile(path, inputs / path.name)
    registry = read_json(inputs / "published_claims_raw.json")
    definitions = read_json(inputs / "claim_checks.json")
    inventory = read_json(inputs / "chart_inventory.json")
    source_verification = verify_source_registry(root, registry)
    engine = Engine(
        load_incidents(snapshot, args.analysis_date), config, args.analysis_date
    )
    quality = quality_summary(engine)
    log("input_validated", rows=len(engine.rows), columns=quality["columns"])
    facts = build_facts(engine)
    search_ledger = explore(engine)
    templates, decisions = candidate_shortlist(engine, facts)
    discovered, discovery_ledger = discover(
        engine, facts, search_ledger, discovery_config
    )
    profiles, profile_evidence = chart_profiles(engine)
    write_json(output / "chart_profiles.json", profile_evidence)
    candidates = templates + discovered + profiles
    decisions.extend(
        {
            "candidate_id": c.candidate_id,
            "decision": c.review_state,
            "selection_stage": c.selection_stage,
            "eligibility": c.eligibility,
        }
        for c in profiles
    )
    for entry in discovery_ledger["entries"]:
        if entry["decision"] != "screened_out":
            decisions.append(
                {
                    "search_id": entry["search_id"],
                    "family": entry["family"],
                    "cell": entry["name"],
                    "selection_stage": "data_driven_discovery",
                    "decision": entry["decision"],
                    "rank": entry.get("rank"),
                    "score": entry["score"],
                    "components": entry["components"],
                    "reason": entry["reason"],
                    "published_claim_ids": entry["published_claim_ids"],
                }
            )
    audit = audit_claims(engine, registry, definitions)
    outcomes = chart_outcomes(inventory, candidates, engine)
    validation = validate_results(engine, candidates, audit, registry)
    validation["sources"] = source_verification
    tests = subprocess.run(
        [sys.executable, "-B", "-m", "unittest", "discover", "-s", "tests"],
        cwd=root,
        text=True,
        capture_output=True,
    )
    (output / "unit_tests.log").write_text(
        tests.stdout + tests.stderr, encoding="utf-8"
    )
    validation["unit_tests"] = {
        "command": "python3 -B -m unittest discover -s tests",
        "returncode": tests.returncode,
        "log": "unit_tests.log",
        "platform": platform.platform(),
        "cross_platform_limit": "Portable pathlib/csv/stdlib code with explicit UTF-8 reads and path-with-spaces tests; no Linux/Windows runtime was available for this run.",
    }
    if tests.returncode:
        write_json(output / "validation.json", validation)
        raise RuntimeError(f"Unit tests failed; see {output / 'unit_tests.log'}")
    engine.export(output)
    write_json(output / "facts.json", facts)
    write_json(output / "quality.json", quality)
    write_json(output / "validation.json", validation)
    write_json(
        output / "candidates.json", [candidate.model_dump() for candidate in candidates]
    )
    write_json(output / "claim_audit.json", [record.model_dump() for record in audit])
    write_json(
        output / "published_claim_registry.json",
        {
            "schema_version": "1.0",
            "claims": [
                {
                    **raw,
                    "check_definition": record.calculation_definition,
                    "last_evidence_ids": record.evidence_ids,
                    "last_audit_status": record.status,
                    "last_audit_run": run_id,
                }
                for raw, record in zip(registry["claims"], audit)
            ],
        },
    )
    write_json(output / "selection_decisions.json", decisions)
    write_json(output / "discovery_ledger.json", discovery_ledger)
    write_csv(
        output / "tables/discovery_ledger.csv",
        [
            {k: v for k, v in entry.items() if k != "components"}
            | {f"component_{k}": v for k, v in (entry["components"] or {}).items()}
            for entry in discovery_ledger["entries"]
        ],
    )
    write_json(output / "chart_outcomes.json", outcomes)
    write_json(output / "search_ledger.json", search_ledger)
    write_csv(output / "tables/search_ledger.csv", search_ledger)
    write_csv(output / "tables/severity_sensitivity.csv", facts["severity"])
    write_csv(
        output / "tables/annual_summary.csv",
        [
            {"series": key, **point}
            for key, value in facts["series"].items()
            for point in value["points"]
        ],
    )
    write_csv(
        output / "tables/claim_statuses.csv",
        [
            {
                "claim_id": record.claim_id,
                "publication_status": record.publication_status,
                "empirical": record.empirical,
                "status": record.status,
                "discrepancy_explanation": record.discrepancy_explanation,
                "source_url": record.source_url,
                "retrieved_at_utc": record.retrieved_at_utc,
            }
            for record in audit
        ],
    )
    write_csv(
        output / "tables/incident_index.csv",
        [
            {
                "aiid_id": row.incident_id,
                "date": row.raw["date"],
                "year": row.year,
                "title": row.raw["title"],
                "primary_subdomain": row.raw["subdomain_code"],
                "all_subdomain_codes": sorted(row.subdomains),
                "classifier_model": row.raw["model_name"],
                "prompt_version": row.raw["prompt_version"],
                "constructed_aiid_url": f"https://incidentdatabase.ai/cite/{row.incident_id}/",
                "url_provenance": "constructed lookup link, not original report URL",
            }
            for row in engine.rows
        ],
    )
    # Mechanistic examples for targeted inspection, not a representative validation sample.
    crossing = engine.measures["candidate.IT-C005.inferred_only_crossings"]
    selected_ids = engine.id_sets[Path(crossing.numerator_ids_ref).stem][:3]
    write_json(
        output / "evidence/targeted_record_examples.json",
        [
            {
                "selection_reason": "first three numeric IDs crossing severity ≥4 only with inference, original ten dimensions; not a validation sample",
                "aiid_id": row.incident_id,
                "raw_record": row.raw,
            }
            for row in engine.rows
            if row.incident_id in selected_ids
        ],
    )
    code = code_snapshot(output, root)
    input_hashes = {
        path.name: sha256_file(path)
        for path in sorted(inputs.iterdir())
        if path.is_file()
    }
    claim_dates = sorted({claim["retrieval_date_utc"] for claim in registry["claims"]})
    lineage = {
        "inherited_v1_runs": sorted(
            path.name
            for path in (root / "runs").iterdir()
            if path.is_dir()
            and path.name != run_id
            and (path / "run_metadata.json").exists()
            and read_json(path / "run_metadata.json").get("code", {}).get("version")
            == "0.1.1"
        ),
        "review": "review/fable/ (three reviewers, three adversarial verifiers, one completeness critic; workflow wf_f83223db-c48)",
    }
    comparison_note: Any = (
        "not performed; each run analyzes one supplied export. Use `tracker compare` when an earlier registered snapshot exists."
    )
    baseline = True
    previous_run = getattr(args, "previous_run", None)
    if previous_run:
        from .compare import run_comparison

        previous_dir = resolve_run(Path(previous_run), root)
        previous_meta = read_json(previous_dir / "run_metadata.json")
        previous_csv = root / previous_meta["input"]["snapshot_path"]
        comparison = run_comparison(
            previous_csv,
            date.fromisoformat(previous_meta["analysis_date"]),
            snapshot,
            args.analysis_date,
            output / "export_comparison",
            root,
        )
        comparison_note = {
            "path": "export_comparison/export_comparison.json",
            "counts": comparison["counts"],
            "inputs": comparison["inputs"],
        }
        baseline = not comparison["inputs"].get("historical_observation", False)
    text = REPORT_TEXT["versions"].get(__version__, {})
    metadata = {
        "schema_version": "1.1",
        "run_id": run_id,
        "analysis_date": str(args.analysis_date),
        "started_at_utc": instant.isoformat(),
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        "dry_run": dry_run,
        "input": {
            "original_path": str(input_path),
            "snapshot_path": Path(os.path.relpath(snapshot, root)).as_posix(),
            "sha256": source_hash,
            "bytes": snapshot.stat().st_size,
        },
        "code": code,
        "configuration_sha256": input_hashes["analysis.json"],
        "input_artifact_hashes": input_hashes,
        "definitions_version": config.definitions_version,
        "discovery_version": discovery_config.discovery_version,
        "python_version": sys.version,
        "platform": platform.platform(),
        "dependencies": {
            name: importlib.metadata.version(name) for name in ("pydantic", "httpx")
        },
        "cadence": config.cadence,
        "next_due_analysis_date": str(next_due(args.analysis_date, config.cadence)),
        "baseline": baseline,
        "previous_export_comparison": comparison_note,
        "version_lineage": lineage,
        "published_claim_source_retrieval_dates": claim_dates,
        "source_freshness_notice": "Reruns audit the pinned retrieved wording. `tracker refresh-claims` reports changed or absent quotes; the registry is only ever updated by a human.",
        "llm": {
            "mode": config.llm_mode,
            "model": config.llm_model,
            "generation_prompt_version": config.generation_prompt_version,
            "review_prompt_version": config.review_prompt_version,
            "report_style_version": config.report_style_version,
            "api_provider": None,
            "api_calls": 0,
            "temperature": None,
            "seed": None,
            "session_role": "analysis design, template and discovery-rule authorship, caveats and report templates; all counts executed in Python",
            "review_lineage": text.get("review_lineage", ""),
        },
        "result_counts": {
            "records": len(engine.rows),
            "candidates": len(candidates),
            "session_templates": len(templates),
            "discovered_candidates": len(discovered),
            "claim_occurrences": len(audit),
            "current_empirical_claims": sum(
                r.publication_status == "current_tracker" and r.empirical for r in audit
            ),
            "calculations": len(engine.measures),
            "id_sets": len(engine.id_sets),
            "exploratory_comparisons": len(search_ledger),
            "emergence_candidates": sum(
                1 for item in search_ledger if item.get("emergence_candidate")
            ),
        },
        "current_claim_status_counts": dict(
            Counter(
                r.status
                for r in audit
                if r.publication_status == "current_tracker" and r.empirical
            )
        ),
        "publication_authorized": False,
    }
    write_json(output / "run_metadata.json", metadata)
    metadata["llm_bundle"] = make_llm_bundle(output, metadata)
    write_candidate_report(
        output,
        engine,
        candidates,
        outcomes,
        search_ledger,
        discovery_ledger,
        __version__,
    )
    write_audit_reports(output, audit)
    write_summary(output, metadata, candidates, audit, quality)
    metadata["completed_at_utc"] = datetime.now(timezone.utc).isoformat()
    write_json(output / "run_metadata.json", metadata)
    if sha256_file(snapshot) != source_hash:
        raise RuntimeError("Snapshot changed during run")
    manifest_sha = artifact_manifest(output)
    if not dry_run:
        write_pointers(
            root, output, run_id, args.analysis_date, manifest_sha, source_hash
        )
    log(
        "run_complete",
        run_path=str(output),
        dry_run=dry_run,
        **metadata["result_counts"],
    )
    print(
        json.dumps(
            {
                "run": str(output),
                "dry_run": dry_run,
                "validation": "passed",
                "candidate_ids": [c.candidate_id for c in candidates],
                "current_claim_statuses": metadata["current_claim_status_counts"],
            },
            indent=2,
        )
    )
    return output


def evidence_command(args: argparse.Namespace) -> None:
    run = resolve_run(args.run)
    calculations = read_json(run / "calculations.json")["measures"]
    if args.calculation:
        keys = [args.calculation]
    else:
        file = "candidates.json" if args.candidate else "claim_audit.json"
        id_field = "candidate_id" if args.candidate else "claim_id"
        wanted = args.candidate or args.claim
        entries = read_json(run / file)
        item = next((item for item in entries if item[id_field] == wanted), None)
        if item is None:
            raise SystemExit(f"Unknown {id_field} {wanted!r} in {run / file}")
        keys = item["evidence_ids"]
    result = []
    for key in keys:
        if key not in calculations:
            raise SystemExit(
                f"Unknown calculation ID {key!r} in {run / 'calculations.json'}"
            )
        measure = calculations[key]
        result.append(
            {
                **measure,
                "numerator_ids": read_json(run / measure["numerator_ids_ref"]),
                "denominator_ids": (
                    read_json(run / measure["denominator_ids_ref"])
                    if args.include_denominator_ids
                    else measure["denominator_ids_ref"]
                ),
            }
        )
    print(json.dumps(result, ensure_ascii=False, indent=2))


def verify_run(run: Path, root: Path = ROOT) -> dict[str, Any]:
    """Artifact hashes, unmanifested files, snapshot, measure contracts, id-set content addressing,
    evidence resolution and, when present, the LATEST_RUN.json manifest anchor."""
    manifest_path = run / "artifact_manifest.json"
    if not manifest_path.exists():
        raise SystemExit(
            f"Incomplete run: {run} has no artifact_manifest.json (the run did not finish)"
        )
    manifest = read_json(manifest_path)
    for relative, expected in manifest["files"].items():
        if not (run / relative).exists():
            raise ValueError(f"Manifested file missing: {relative}")
        if sha256_file(run / relative) != expected:
            raise ValueError(f"Artifact hash mismatch: {relative}")
    unmanifested = [
        path.relative_to(run).as_posix()
        for path in run.rglob("*")
        if path.is_file()
        and path.name != "artifact_manifest.json"
        and path.relative_to(run).as_posix() not in manifest["files"]
    ]
    if unmanifested:
        raise ValueError(f"Files present but not in the manifest: {unmanifested[:10]}")
    metadata = read_json(run / "run_metadata.json")
    snapshot = root / metadata["input"]["snapshot_path"]
    if not snapshot.exists():
        snapshot = run / metadata["input"]["snapshot_path"]
    if sha256_file(snapshot) != metadata["input"]["sha256"]:
        raise ValueError("Snapshot integrity failure")
    measures = read_json(run / "calculations.json")["measures"]
    for value in measures.values():
        measure = Measure.model_validate(value)
        numerator = read_json(run / measure.numerator_ids_ref)
        denominator = read_json(run / measure.denominator_ids_ref)
        for ref, ids in (
            (measure.numerator_ids_ref, numerator),
            (measure.denominator_ids_ref, denominator),
        ):
            if Path(ref).stem != hashlib.sha256(json_bytes(ids)).hexdigest():
                raise ValueError(
                    f"ID-set content hash mismatch: {ref} ({measure.calculation_id})"
                )
        if len(set(numerator)) != measure.numerator or not set(numerator).issubset(
            denominator
        ):
            raise ValueError(f"ID evidence mismatch: {measure.calculation_id}")
        if len(set(denominator)) != measure.denominator_incident_count:
            raise ValueError(f"Denominator evidence mismatch: {measure.calculation_id}")
    unresolved = []
    for file, id_field in (
        ("candidates.json", "candidate_id"),
        ("claim_audit.json", "claim_id"),
    ):
        for item in read_json(run / file):
            unresolved.extend(
                f"{item[id_field]}:{key}"
                for key in item["evidence_ids"]
                if key not in measures
            )
    if unresolved:
        raise ValueError(f"Evidence IDs do not resolve: {unresolved[:10]}")
    anchor = None
    latest_path = root / "LATEST_RUN.json"
    if latest_path.exists():
        latest = read_json(latest_path)
        if latest.get("run_id") == run.name and latest.get("artifact_manifest_sha256"):
            anchor = latest["artifact_manifest_sha256"] == sha256_file(manifest_path)
            if not anchor:
                raise ValueError(
                    "LATEST_RUN.json manifest anchor does not match the run's artifact manifest"
                )
    return {
        "status": "passed",
        "artifacts_checked": len(manifest["files"]),
        "unmanifested_files": 0,
        "measures_checked": len(measures),
        "id_set_content_hashes_checked": 2 * len(measures),
        "evidence_ids_resolved": True,
        "latest_run_manifest_anchor": (
            anchor
            if anchor is not None
            else "not applicable (no anchor recorded for this run)"
        ),
        "snapshot_sha256": metadata["input"]["sha256"],
    }


def verify_command(args: argparse.Namespace) -> None:
    print(json.dumps(verify_run(resolve_run(args.run)), indent=2))


def validate_draft_command(args: argparse.Namespace) -> None:
    run = resolve_run(args.run)
    draft = LLMDraft.model_validate_json(
        read_text(args.draft or run / "llm/session_draft.json")
    )
    metadata = read_json(run / "run_metadata.json")
    if draft.run_id != metadata["run_id"] or draft.input_evidence_sha256 != sha256_file(
        run / "llm/evidence_bundle.json"
    ):
        raise ValueError("Draft does not bind to this evidence bundle/run")
    calculations = read_json(run / "calculations.json")["measures"]
    valid_charts = {item["chart_id"] for item in read_json(run / "chart_outcomes.json")}
    for candidate in draft.candidates:
        if not set(candidate.evidence_ids).issubset(calculations):
            raise ValueError("Draft references unknown calculation IDs")
        if not set(candidate.chart_ids).issubset(valid_charts):
            raise ValueError("Draft references unknown chart IDs")
    print(
        json.dumps(
            {
                "status": "structure_and_references_valid",
                "candidates": len(draft.candidates),
                "semantic_grounding": "Run `tracker generate-draft`'s grounding report or human/independent review; schema validation does not prove prose is numerically or methodologically correct.",
            },
            indent=2,
        )
    )


def compare_command(args: argparse.Namespace) -> None:
    from .compare import run_comparison

    def resolve_input(value: str, given_date: date | None) -> tuple[Path, date]:
        path = Path(value)
        if value == "latest" or (path.exists() and path.is_dir()):
            run = resolve_run(path)
            metadata = read_json(run / "run_metadata.json")
            csv_path = ROOT / metadata["input"]["snapshot_path"]
            if not csv_path.exists():
                csv_path = run / metadata["input"]["snapshot_path"]
            return csv_path, date.fromisoformat(metadata["analysis_date"])
        if given_date is None:
            raise SystemExit(
                f"--previous-date/--current-date is required when {value} is a CSV rather than a run"
            )
        return path.resolve(), given_date

    previous_csv, previous_date = resolve_input(args.previous, args.previous_date)
    current_csv, current_date = resolve_input(args.current, args.current_date)
    result = run_comparison(
        previous_csv,
        previous_date,
        current_csv,
        current_date,
        Path(args.output).resolve(),
        ROOT,
        synthetic=args.synthetic,
    )
    refresh_manifest_if_inside_run(Path(args.output).resolve())
    print(
        json.dumps(
            {
                "output": str(Path(args.output).resolve()),
                "counts": result["counts"],
                "inputs": {
                    k: v
                    for k, v in result["inputs"].items()
                    if k in ("synthetic", "historical_observation", "self_comparison")
                },
                "warning": result.get("WARNING"),
            },
            indent=2,
        )
    )


def refresh_command(args: argparse.Namespace) -> None:
    from .refresh import capture_fetcher, live_fetcher, refresh_claims

    registry = read_json(ROOT / "research/published_claims_raw.json")
    output = (
        Path(args.output).resolve()
        if args.output
        else ROOT
        / "research/web/refresh"
        / datetime.now(timezone.utc).strftime("%Y-%m-%d")
    )
    fetcher = (
        capture_fetcher(ROOT, registry)
        if args.offline_from_captures
        else live_fetcher()
    )
    report = refresh_claims(
        registry,
        fetcher,
        output,
        mode="offline-captures" if args.offline_from_captures else "live",
    )
    refresh_manifest_if_inside_run(output)
    print(json.dumps({"output": str(output), "summary": report["summary"]}, indent=2))
    if report["summary"]["page_unavailable"]:
        raise SystemExit(3)
    if (
        report["summary"]["changed"]
        or report["summary"]["absent"]
        or report["summary"]["app_source_changed_quote_unverifiable"]
        or report["summary"]["reference_source_changed_quote_unverifiable"]
    ):
        raise SystemExit(2)


def generate_draft_command(args: argparse.Namespace) -> None:
    from .llm_adapter import AnthropicProvider, FakeProvider, generate_draft

    run = resolve_run(args.run)
    provider = FakeProvider() if args.provider == "fake" else AnthropicProvider()
    prompt = ROOT / "prompts" / f"{args.prompt_version}.md"
    output = (
        run
        / "llm"
        / "provider_runs"
        / (datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + args.provider)
    )
    result = generate_draft(run, provider, prompt, args.model, args.effort, output)
    refresh_manifest_if_inside_run(output)
    print(json.dumps({"output": str(output), **result}, indent=2, default=str))
    if not result["draft_valid"] or not (result.get("grounding") or {}).get(
        "all_grounded", False
    ):
        raise SystemExit(4)


def resolve_run(value: Path, root: Path = ROOT) -> Path:
    if str(value) == "latest":
        latest_path = root / "LATEST_RUN.json"
        if not latest_path.exists():
            raise SystemExit("No LATEST_RUN.json pointer exists yet")
        latest = read_json(latest_path)
        candidate = Path(latest["path"])
        run = candidate if candidate.is_absolute() else root / candidate
        if not run.exists() and latest.get("absolute_path"):
            run = Path(latest["absolute_path"])
    else:
        run = value.resolve()
    if not run.exists():
        raise SystemExit(f"Run directory does not exist: {run}")
    return run


def editorial_command(args: argparse.Namespace) -> None:
    from .editorial import run_editorial_cycle

    run = resolve_run(args.run)
    # Verify the bound source before transmitting its selected evidence.
    verify_run(run)
    result = run_editorial_cycle(
        run,
        args.output.resolve(),
        args.draft_model,
        args.draft_effort,
        args.review_model,
        args.review_effort,
        args.context,
        args.resume,
    )
    print(json.dumps(result, indent=2))


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    run = commands.add_parser(
        "run",
        help="Snapshot and analyze a CSV; emits a new immutable-by-convention run directory",
    )
    run.add_argument("--input", type=Path, required=True)
    run.add_argument("--analysis-date", type=date.fromisoformat, required=True)
    run.add_argument("--config", type=Path, default=ROOT / "config/analysis.json")
    run.add_argument("--output-root", type=Path, default=None)
    run.add_argument("--cadence", choices=["monthly", "fortnightly"])
    run.add_argument(
        "--previous-run",
        type=str,
        default=None,
        help="Earlier run (or 'latest') whose registered snapshot is compared with this input",
    )
    run.add_argument(
        "--dry-run",
        action="store_true",
        help="Write only under --output-root; do not copy the snapshot into the workspace or move LATEST_RUN.json/REPORT_INDEX.md",
    )
    run.add_argument("--root", type=Path, default=None, help=argparse.SUPPRESS)
    run.set_defaults(func=run_pipeline)
    ev = commands.add_parser(
        "evidence",
        help="Print exact calculation definitions and contributing incident IDs",
    )
    ev.add_argument("--run", type=Path, required=True)
    group = ev.add_mutually_exclusive_group(required=True)
    group.add_argument("--candidate")
    group.add_argument("--claim")
    group.add_argument("--calculation")
    ev.add_argument("--include-denominator-ids", action="store_true")
    ev.set_defaults(func=evidence_command)
    verify = commands.add_parser(
        "verify",
        help="Verify run artifact/input checksums, id-set content addressing and evidence-set arithmetic",
    )
    verify.add_argument("--run", type=Path, required=True)
    verify.set_defaults(func=verify_command)
    llm = commands.add_parser(
        "validate-draft",
        help="Validate an externally generated LLM JSON artifact; no provider API call",
    )
    llm.add_argument("--run", type=Path, required=True)
    llm.add_argument("--draft", type=Path)
    llm.set_defaults(func=validate_draft_command)
    compare = commands.add_parser(
        "compare",
        help="Compare two exports (runs or CSVs): added/removed records, reclassifications, date changes, backfill by year",
    )
    compare.add_argument(
        "--previous", required=True, help="run directory, 'latest', or CSV path"
    )
    compare.add_argument(
        "--current", required=True, help="run directory, 'latest', or CSV path"
    )
    compare.add_argument("--previous-date", type=date.fromisoformat, default=None)
    compare.add_argument("--current-date", type=date.fromisoformat, default=None)
    compare.add_argument("--output", required=True)
    compare.add_argument(
        "--synthetic",
        action="store_true",
        help="Declare synthetic test inputs (content markers are also auto-detected)",
    )
    compare.set_defaults(func=compare_command)
    refresh = commands.add_parser(
        "refresh-claims",
        help="Read-only check that registered claim wording is still live; never edits the registry",
    )
    refresh.add_argument("--output", default=None)
    refresh.add_argument(
        "--offline-from-captures",
        action="store_true",
        help="Serve the pinned captures instead of fetching (tests)",
    )
    refresh.set_defaults(func=refresh_command)
    draft = commands.add_parser(
        "generate-draft",
        help="Produce a provider draft with provenance and grounding checks (fake provider by default)",
    )
    draft.add_argument("--run", type=Path, required=True)
    draft.add_argument("--provider", choices=["fake", "anthropic"], default="fake")
    draft.add_argument("--model", default="claude-opus-5")
    draft.add_argument("--effort", default="high")
    draft.add_argument("--prompt-version", default="candidate-generation.v1")
    draft.set_defaults(func=generate_draft_command)
    editorial = commands.add_parser(
        "editorial-cycle",
        help="Run authenticated drafting and separate model review; preserve all call evidence outside source runs",
    )
    editorial.add_argument("--run", type=Path, required=True)
    editorial.add_argument("--output", type=Path, required=True)
    editorial.add_argument("--context", type=Path)
    editorial.add_argument(
        "--resume",
        action="store_true",
        help="Reuse a preserved successful model response for identical evidence after a local validation failure",
    )
    editorial.add_argument("--draft-model", default="gpt-6-astra")
    editorial.add_argument("--draft-effort", default="ultra")
    editorial.add_argument("--review-model", default="fable")
    editorial.add_argument("--review-effort", default="max")
    editorial.set_defaults(func=editorial_command)
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
