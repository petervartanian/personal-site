"""Deterministic set-based calculations with content-addressed ID evidence."""

from __future__ import annotations

import hashlib
import math
from collections import Counter
from datetime import date
from fractions import Fraction
from pathlib import Path
from typing import Any

from .data import (
    HARM10,
    HARM13,
    Incident,
    json_bytes,
    sorted_ids,
    write_csv,
    write_json,
)
from .models import AnalysisConfig, Calculation, Measure, Selection, SeveritySpec


def severity_state(row: Incident, spec: SeveritySpec) -> tuple[bool, bool]:
    """Return definite/possible threshold membership, retaining missing-score bounds."""
    categories = spec.categories or list(HARM10 if spec.dimensions == 10 else HARM13)
    if any(category not in HARM13 for category in categories):
        raise ValueError("Unknown harm category in calculation")
    definite = possible = 0
    has_missing = False
    for category in categories:
        values = [row.severity[category][channel] for channel in spec.channels]
        # Blank (None) and zero-coded (0) components are both unknown under methodology item 6.
        unknown = any(value is None or value == 0 for value in values)
        has_missing |= unknown
        passes = any(value is not None and value >= spec.threshold for value in values)
        definite += passes
        possible += passes or unknown
    if spec.missing_policy == "complete_only" and has_missing:
        return False, False
    return definite >= spec.minimum_categories, possible >= spec.minimum_categories


def matches(row: Incident, selection: Selection, config: AnalysisConfig) -> bool:
    if selection.years is not None and row.year not in selection.years:
        return False
    if selection.min_year is not None and (
        row.year is None or row.year < selection.min_year
    ):
        return False
    if selection.max_year is not None and (
        row.year is None or row.year > selection.max_year
    ):
        return False
    if selection.ids is not None and row.incident_id not in selection.ids:
        return False
    if row.incident_id in selection.exclude_ids:
        return False
    for field, options in selection.equals.items():
        if field not in row.raw:
            raise ValueError(f"Unknown CSV field: {field}")
        if row.raw[field] not in options:
            return False
    for field in selection.known_fields:
        if field not in row.raw:
            raise ValueError(f"Unknown known-only field: {field}")
        if row.raw[field] in config.unknown_values:
            return False
        if selection.exclude_other and row.raw[field] == "Other":
            return False
    if selection.subdomains is not None:
        labels = (
            {row.primary} if selection.classification == "primary" else row.subdomains
        )
        if not labels.intersection(selection.subdomains):
            return False
    if selection.domains is not None:
        labels = {row.domain} if selection.classification == "primary" else row.domains
        if not labels.intersection(selection.domains):
            return False
    if selection.purposes is not None:
        labels = {row.raw["ai_goal_primary"]}
        if selection.purpose_scope == "primary_or_secondary":
            labels.add(row.raw["ai_goal_secondary"])
        if not labels.intersection(selection.purposes):
            return False
    if selection.severity:
        definite, possible = severity_state(row, selection.severity)
        if not (
            possible if selection.severity.missing_policy == "upper_bound" else definite
        ):
            return False
    for field, threshold in selection.numeric_min.items():
        value = numeric_cell(row, field)
        if value is None or not value >= threshold:
            return False
    for field, threshold in selection.numeric_gt.items():
        value = numeric_cell(row, field)
        if value is None or not value > threshold:
            return False
    for field, names in selection.identity_contains.items():
        if field not in row.identities:
            raise ValueError(
                f"Unknown identity field: {field} (expected one of {sorted(row.identities)})"
            )
        if not set(row.identities[field] or ()).intersection(names):
            return False
    return True


def numeric_cell(row: Incident, field: str) -> float | None:
    if field not in row.raw:
        raise ValueError(f"Unknown numeric field: {field}")
    text = row.raw[field].strip()
    if not text:
        return None
    try:
        value = float(text)
    except ValueError as error:
        raise ValueError(
            f"Field {field} is not numeric for incident {row.incident_id}: {text!r}"
        ) from error
    if not math.isfinite(value):
        raise ValueError(
            f"Field {field} is not finite for incident {row.incident_id}: {text!r}"
        )
    return value


def proportion(numerator: int, denominator: int) -> float | None:
    return 100 * numerator / denominator if denominator else None


def trend(points: list[dict[str, Any]]) -> dict[str, Any]:
    """Exact rational comparisons; zero denominator/gaps cannot imply monotonicity."""
    if not points:
        return {"evaluable": False, "reason": "no points"}
    years = [point["year"] for point in points]
    continuous = years == list(range(years[0], years[-1] + 1))
    defined = all(point["denominator"] > 0 for point in points)
    comparable = continuous and defined and len(points) >= 2
    proportions = [
        (
            Fraction(point["numerator"], point["denominator"])
            if point["denominator"]
            else None
        )
        for point in points
    ]
    steps: list[dict[str, Any]] = []
    for left, right, a, b in zip(points, points[1:], proportions, proportions[1:]):
        steps.append(
            {
                "from_year": left["year"],
                "to_year": right["year"],
                "share_direction": (
                    None
                    if a is None or b is None
                    else ("up" if b > a else "down" if b < a else "flat")
                ),
                "count_direction": (
                    "up"
                    if right["numerator"] > left["numerator"]
                    else ("down" if right["numerator"] < left["numerator"] else "flat")
                ),
                "delta_pp": (
                    float((b - a) * 100) if a is not None and b is not None else None
                ),
            }
        )
    first, last = points[0], points[-1]
    first_pct, last_pct = proportions[0], proportions[-1]
    return {
        "evaluable": comparable,
        "continuous_years": continuous,
        "all_denominators_positive": defined,
        "strictly_increasing_share": comparable
        and all(x["share_direction"] == "up" for x in steps),
        "strictly_decreasing_share": comparable
        and all(x["share_direction"] == "down" for x in steps),
        "strictly_increasing_count": comparable
        and all(x["count_direction"] == "up" for x in steps),
        "strictly_decreasing_count": comparable
        and all(x["count_direction"] == "down" for x in steps),
        "endpoint_delta_pp": (
            float((last_pct - first_pct) * 100)
            if first_pct is not None and last_pct is not None
            else None
        ),
        "relative_share_change_pct": (
            float((last_pct / first_pct - 1) * 100)
            if first_pct and last_pct is not None
            else None
        ),
        "endpoint_count_change": last["numerator"] - first["numerator"],
        "relative_count_change_pct": (
            100 * (last["numerator"] - first["numerator"]) / first["numerator"]
            if first["numerator"]
            else None
        ),
        "steps": steps,
    }


class Engine:
    def __init__(
        self, rows: list[Incident], config: AnalysisConfig, analysis_date: date
    ):
        self.rows = rows
        self.config = config
        self.analysis_date = analysis_date
        self.measures: dict[str, Measure] = {}
        self.id_sets: dict[str, list[str]] = {}
        self.series_results: dict[str, dict[str, Any]] = {}

    def select(self, selection: Selection) -> list[Incident]:
        return [row for row in self.rows if matches(row, selection, self.config)]

    def remember_ids(self, rows: list[Incident]) -> str:
        ids = sorted_ids(row.incident_id for row in rows)
        key = hashlib.sha256(json_bytes(ids)).hexdigest()
        self.id_sets[key] = ids
        return f"evidence/id_sets/{key}.json"

    def measure(self, calculation_id: str, definition: Calculation) -> Measure:
        if calculation_id in self.measures:
            previous = self.measures[calculation_id]
            if previous.definition != definition:
                raise ValueError(
                    f"Calculation ID reused with different definition: {calculation_id}"
                )
            return previous
        population = self.select(definition.population)
        numerator_rows = [
            row for row in population if matches(row, definition.target, self.config)
        ]
        denominator = (
            len(population)
            if definition.denominator == "incidents"
            else sum(len(row.subdomains) for row in population)
        )
        dates = [row.incident_date for row in population if row.incident_date]
        result = Measure(
            calculation_id=calculation_id,
            definition=definition,
            numerator=len(numerator_rows),
            denominator=denominator,
            percent=proportion(len(numerator_rows), denominator),
            numerator_ids_ref=self.remember_ids(numerator_rows),
            denominator_ids_ref=self.remember_ids(population),
            numerator_incident_count=len(numerator_rows),
            denominator_incident_count=len(population),
            window={
                "date_field": "date",
                "min_observed": str(min(dates)) if dates else None,
                "max_observed": str(max(dates)) if dates else None,
                "undated_count": len(population) - len(dates),
                "includes_incomplete_year": any(
                    row.year == self.analysis_date.year for row in population
                ),
                "requested_years": definition.population.years,
                "requested_min_year": definition.population.min_year,
                "requested_max_year": definition.population.max_year,
            },
        )
        self.measures[calculation_id] = result
        return result

    def fraction(
        self,
        key: str,
        target: Selection | None = None,
        population: Selection | None = None,
        description: str = "",
        denominator: str = "incidents",
    ) -> Measure:
        return self.measure(
            key,
            Calculation(
                population=population or Selection(),
                target=target or Selection(),
                denominator=denominator,
                description=description or key,
            ),
        )

    def series(
        self,
        key: str,
        target: Selection,
        start: int,
        end: int,
        population: Selection | None = None,
        denominator: str = "incidents",
    ) -> dict[str, Any]:
        if end >= self.analysis_date.year:
            raise ValueError(
                "Full-year trend must exclude current/future incomplete years"
            )
        if end < start:
            raise ValueError("Reversed time window")
        base_population = population or Selection()
        if (
            base_population.min_year is not None and base_population.min_year > start
        ) or (base_population.max_year is not None and base_population.max_year < end):
            raise ValueError(
                f"Population window ({base_population.min_year}-{base_population.max_year}) conflicts with the series range {start}-{end}"
            )
        points: list[dict[str, Any]] = []
        for year in range(start, end + 1):
            base = (population or Selection()).model_dump()
            if base["years"] is not None:
                base["years"] = [year] if year in base["years"] else []
            else:
                base["years"] = [year]
            result = self.fraction(
                f"{key}.{year}", target, Selection(**base), denominator=denominator
            )
            points.append(
                {
                    "year": year,
                    "calculation_id": result.calculation_id,
                    "numerator": result.numerator,
                    "denominator": result.denominator,
                    "percent": result.percent,
                }
            )
        value = {
            "series_id": key,
            "points": points,
            "trend": trend(points),
            "definition": {
                "target": target.model_dump(),
                "population": (population or Selection()).model_dump(),
                "start_year": start,
                "end_year": end,
                "denominator": denominator,
            },
        }
        self.series_results[key] = value
        return value

    def distribution(
        self, field: str, population: Selection | None = None
    ) -> list[dict[str, Any]]:
        rows = self.select(population or Selection())
        counts = Counter(row.raw[field] for row in rows)
        return [
            {
                "category": category,
                "count": count,
                "denominator": len(rows),
                "percent": proportion(count, len(rows)),
            }
            for category, count in sorted(counts.items(), key=lambda x: (-x[1], x[0]))
        ]

    def export(self, output: Path) -> None:
        write_json(
            output / "calculations.json",
            {
                "schema_version": "1.0",
                "unit": "distinct incident records",
                "measures": {
                    key: value.model_dump()
                    for key, value in sorted(self.measures.items())
                },
                "series": self.series_results,
            },
        )
        for key, ids in self.id_sets.items():
            write_json(output / "evidence/id_sets" / f"{key}.json", ids)
        write_csv(
            output / "tables/calculations.csv",
            [
                {
                    "calculation_id": value.calculation_id,
                    "numerator": value.numerator,
                    "denominator": value.denominator,
                    "percent": value.percent,
                    "denominator_unit": value.definition.denominator,
                    "numerator_ids_ref": value.numerator_ids_ref,
                    "denominator_ids_ref": value.denominator_ids_ref,
                    "definition": value.definition.model_dump(),
                }
                for value in self.measures.values()
            ],
        )
