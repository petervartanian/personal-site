"""Evidence-bound editorial shortlist; selection reasons remain inspectable."""

from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from typing import Any

from .audit import fraction_text, percent_text, series_ids
from .calc import Engine, matches, trend
from .data import HARM13
from .models import Candidate, Selection, SeveritySpec
from .provenance import entry_order_composition, late_entry_table, monthly_counts

ROOT = Path(__file__).resolve().parents[1]
REPORT_TEXT = json.loads((ROOT / "config/report_text.json").read_text(encoding="utf-8"))
SHARED_CAVEATS = [
    "Voluntary selective reporting and changing public attention make this an unrepresentative incident-record collection; no population prevalence or exposure denominator is available.",
    "Incident dates can use legal/report/publication proxies. Report dates are absent, so reporting-lag durations cannot be estimated; aiid_id order provides only a conditional ordering diagnostic and cannot establish calendar entry dates or historical backfill from one export.",
    "LLM classification and changing model/prompt methods may affect every tag. Recorded confidence and model agreement are not statistical confidence or ground-truth validation; the export's confidence field is 'High' for almost every record and provides little discrimination and is not an accuracy estimate.",
    "Source report URLs/dates/IDs are absent from the export; this report verifies export calculations, not all underlying allegations.",
]
CHART_CAVEAT = REPORT_TEXT["chart_caveat"]
SEVERITY_SOURCE_OF_TRUTH = REPORT_TEXT["severity_source_of_truth"]


def cohort_info(engine: Engine) -> dict[str, Any]:
    """Dominant classifier/prompt cohort with a deterministic tie-break (count desc, model, prompt)."""
    counts = Counter(
        (row.raw["model_name"], row.raw["prompt_version"]) for row in engine.rows
    )
    ordered = sorted(
        counts.items(), key=lambda item: (-item[1], item[0][0], item[0][1])
    )
    (model, prompt), size = ordered[0]
    tie = len(ordered) > 1 and ordered[1][1] == size
    return {
        "model": model,
        "prompt_version": prompt,
        "records": size,
        "excluded_records": len(engine.rows) - size,
        "tie_broken_by_name": tie,
        "note": "restriction to the dominant cohort removes records; it is not a label validation",
    }


def common_cohort(engine: Engine) -> Selection:
    info = cohort_info(engine)
    return Selection(
        equals={
            "model_name": [info["model"]],
            "prompt_version": [info["prompt_version"]],
        }
    )


def cohort_label(engine: Engine) -> str:
    info = cohort_info(engine)
    return f"dominant model/prompt cohort (excludes {info['excluded_records']} records; not a label validation)"


def flag_series_variant(
    variant: dict[str, Any], base_points: list[dict[str, Any]]
) -> dict[str, Any]:
    """Mark robustness rows that cannot differ from the base so they are not read as independent support."""
    base = {point["year"]: point for point in base_points}
    overlap = [point for point in variant["points"] if point["year"] in base]
    identical = (
        bool(overlap)
        and all(
            point["numerator"] == base[point["year"]]["numerator"]
            and point["denominator"] == base[point["year"]]["denominator"]
            for point in overlap
        )
        and len(overlap) == len(base_points) == len(variant["points"])
    )
    removed = sum(
        base[point["year"]]["denominator"] - point["denominator"] for point in overlap
    )
    variant["identical_to_base"] = identical
    variant["records_removed"] = removed
    return variant


def flag_fraction_variant(variant: dict[str, Any], base: Any) -> dict[str, Any]:
    variant["identical_to_base"] = (
        variant["numerator"] == base.numerator
        and variant["denominator"] == base.denominator
    )
    variant["records_removed"] = base.denominator - variant["denominator"]
    return variant


def entry_order_caveat(engine: Engine, code_value: str, latest_complete: int) -> str:
    """Data-derived sentence about late-entry composition for one subdomain code."""
    current = engine.analysis_date.year
    predicate = {"target": lambda r: r.primary == code_value}
    late_complete = entry_order_composition(
        engine.rows, latest_complete, predicate, parts=2
    )
    late_current = entry_order_composition(engine.rows, current, predicate, parts=2)
    parts = []
    if late_complete.get("evaluable"):
        early, late = late_complete["parts"]
        parts.append(
            f"{latest_complete}: {early['target']['percent']:.1f}% of the lower-ID half versus {late['target']['percent']:.1f}% of the higher-ID half"
        )
    if late_current.get("evaluable"):
        early, late = late_current["parts"]
        parts.append(
            f"{current} to date: {early['target']['percent']:.1f}% versus {late['target']['percent']:.1f}%"
        )
    if not parts:
        return "ID-order composition could not be evaluated (too few records)."
    return f"ID-ordered subsets have these shares ({'; '.join(parts)}). Without database-entry timestamps or historical exports, these differences do not establish backfill or predict future revisions."


def difference(a: float | None, b: float | None) -> float | None:
    return b - a if a is not None and b is not None else None


def number_text(value: float | None, decimals: int = 2) -> str:
    return f"{value:+.{decimals}f}" if value is not None else "undefined"


def direction(value: float | None) -> str:
    return (
        "undefined"
        if value is None
        else "up" if value > 0 else "down" if value < 0 else "flat"
    )


def comparison_eligibility(
    engine: Engine, first: dict[str, Any], last: dict[str, Any]
) -> dict[str, Any]:
    reasons = []
    if (
        min(first["denominator"], last["denominator"])
        < engine.config.min_comparison_denominator
    ):
        reasons.append("endpoint denominator below minimum")
    if min(first["numerator"], last["numerator"]) < engine.config.min_category_count:
        reasons.append("endpoint category count below minimum")
    delta = (
        last["percent"] - first["percent"]
        if first["percent"] is not None and last["percent"] is not None
        else None
    )
    if delta is None or abs(delta) < engine.config.share_change_materiality_pp:
        reasons.append("endpoint share shift below materiality")
    return {
        "passed": not reasons,
        "rule": "comparative share shift",
        "reasons": reasons,
        "endpoint_delta_pp": delta,
        "minimum_denominator": engine.config.min_comparison_denominator,
        "minimum_category_count": engine.config.min_category_count,
        "materiality_pp": engine.config.share_change_materiality_pp,
    }


def candidate_shortlist(
    engine: Engine, facts: dict[str, Any]
) -> tuple[list[Candidate], list[dict[str, Any]]]:
    end = facts["end_year"]
    start = facts["start_year"]
    candidates: list[Candidate] = []
    decisions: list[dict[str, Any]] = []

    # IT-C001: counts are useful context, not a safety trend.
    annual = engine.series("candidate.IT-C001.counts", Selection(), start, end)
    first, last = annual["points"][0], annual["points"][-1]
    count_change = last["numerator"] - first["numerator"]
    relative = 100 * count_change / first["numerator"] if first["numerator"] else None
    passed = (
        min(first["numerator"], last["numerator"])
        >= engine.config.min_comparison_denominator
        and abs(count_change) >= engine.config.count_change_materiality_absolute
        and relative is not None
        and abs(relative) >= engine.config.count_change_materiality_relative_pct
    )
    robust = []
    evidence = series_ids(annual)
    for name, a, b, population in (
        ("start one year later", start + 1, end, Selection()),
        ("exclude latest complete year", start, end - 1, Selection()),
        ("include prior year", start - 1, end, Selection()),
        (
            "drop probable duplicate #353",
            start,
            end,
            Selection(
                exclude_ids=engine.config.probable_duplicate_sensitivity_drop_ids
            ),
        ),
        (cohort_label(engine), start, end, common_cohort(engine)),
    ):
        value = engine.series(
            f"candidate.IT-C001.sensitivity{len(robust)}", Selection(), a, b, population
        )
        evidence.extend(series_ids(value))
        robust.append(
            flag_series_variant(
                {
                    "alternative": name,
                    "series_id": value["series_id"],
                    "trend": value["trend"],
                    "points": value["points"],
                    "display_unit": "counts",
                },
                annual["points"],
            )
        )
    current_year = engine.analysis_date.year
    partial = engine.fraction(
        "candidate.IT-C001.partial_current_year",
        Selection(),
        Selection(years=[current_year]),
    )
    evidence.append(partial.calculation_id)
    robust.append(
        {
            "alternative": f"{current_year} year-to-date through {engine.analysis_date} (incomplete; not comparable with whole years)",
            "points": [{"label": f"{current_year} to date", **partial.model_dump()}],
            "display_unit": "counts",
        }
    )
    aggregate = {
        year: sum(
            1
            for row in engine.rows
            if row.year == year
            and row.raw.get("number_of_occurrences", "").strip().isdigit()
            and int(row.raw["number_of_occurrences"]) > 1
        )
        for year in range(start, end + 1)
    }
    late_entry = late_entry_table(engine.rows, list(range(start, end + 1)))
    months = monthly_counts(engine.rows, current_year)
    observed_months = {
        k: v
        for k, v in months.items()
        if k <= f"{current_year}-{engine.analysis_date.month:02d}"
    }
    count_verb = (
        "rose" if count_change > 0 else "fell" if count_change < 0 else "were unchanged"
    )
    strictly = annual["trend"]["strictly_increasing_count"]
    candidate = Candidate(
        candidate_id="IT-C001",
        title="Complete-year incident record counts",
        finding=f"The export contains {first['numerator']:,} incident records dated {start} and {last['numerator']:,} dated {end}: {count_change:+,} records ({number_text(relative, 1)}% relative change). Strict annual count increase over the stated complete-year window: {annual['trend']['strictly_increasing_count']}. Annual denominators are the full dated cohorts, not reports or exposed people.",
        chart_ids=["C01", "C02"],
        evidence_ids=evidence,
        chart_configuration={
            "primary_chart": "C01",
            "stacking_category": "Domain (all seven domains visible)",
            "filters": {},
            "date_range": f"{start}-01-01 to {end}-12-31",
            "setting": "Counts; sum stacked domains for yearly record totals",
            "available_controls": "Year ≥; no ordinary timeline maximum-year control",
            "programmatic_preset": {
                "year": [str(year) for year in range(start, end + 1)],
                "stackBy": "domain",
                "viewMode": "counts",
            },
            "compatibility": "Counts and stacks are supported. A host/programmatic exact-year preset is needed to suppress the partial current year; the ordinary controls alone do not give this exact closed interval.",
            "verification": CHART_CAVEAT,
            "container_id": "incident-domain-chart",
            "dataset": "incidents-arcola",
        },
        eligibility={
            "passed": passed,
            "rule": "complete-year counts",
            "baseline_count": first["numerator"],
            "absolute_change": count_change,
            "relative_change_pct": relative,
        },
        calculation_confidence="High for the retained distinct-record counts and date parsing; not an estimate of new submissions, events or people.",
        interpretation_confidence="Low for actual incident incidence or safety changes. Moderate as a description of this database snapshot.",
        caveats=SHARED_CAVEATS
        + [
            "The preceding year is included as a robustness check; the five-year pattern must not be called a trend extending indefinitely backwards.",
            "ID-order diagnostic, not observed database-entry timing: "
            + "; ".join(
                f"{row['year']}: {row['records_above_following_year_minimum_id']}/{row['records']} ({row['share_percent']}%) have an ID above the minimum ID associated with the following incident year"
                for row in late_entry
                if row["share_percent"] is not None
            )
            + ".",
            f"Recent-month record counts are: {current_year} monthly counts to date {', '.join(f'{k[-2:]}={v}' for k, v in observed_months.items())}; the current year is shown only as a labeled year-to-date row.",
            f"Records aggregating several occurrences (number_of_occurrences > 1) in {start}–{end}: {', '.join(f'{year}: {n}' for year, n in aggregate.items())}; annual record counts are not event counts.",
        ],
        robustness=robust,
        proposed_website_text=(
            f"As of the {engine.analysis_date.strftime('%-d %B %Y')} export, the number of incident records dated in each year "
            + (
                f"rose every year from {first['numerator']:,} ({start}) to {last['numerator']:,} ({end})."
                if strictly
                else f"{count_verb} from {first['numerator']:,} ({start}) to {last['numerator']:,} ({end}), with intervening reversals."
            )
            + " These counts describe the database's recorded incidents and may reflect changes in reporting and coverage."
        ),
        review_state="human_review_required" if passed else "withheld",
    )
    candidates.append(candidate)

    # IT-C002: required capability/robustness worked example.
    primary = engine.series(
        "candidate.IT-C002.primary", Selection(subdomains=["7.3"]), start, end
    )
    evidence = series_ids(primary)
    robust = []
    variations = [
        (
            "any-label incident denominator",
            Selection(subdomains=["7.3"], classification="any"),
            Selection(),
            start,
            end,
            "incidents",
        ),
        (
            "any-label assignment denominator (different estimand)",
            Selection(subdomains=["7.3"], classification="any"),
            Selection(),
            start,
            end,
            "subdomain_assignments",
        ),
        (
            "known primary classification only",
            Selection(subdomains=["7.3"]),
            Selection(known_fields=["subdomain_code"]),
            start,
            end,
            "incidents",
        ),
        (
            "within primary domain 7 (different denominator)",
            Selection(subdomains=["7.3"]),
            Selection(domains=["7"]),
            start,
            end,
            "incidents",
        ),
        (
            "start one year later",
            Selection(subdomains=["7.3"]),
            Selection(),
            start + 1,
            end,
            "incidents",
        ),
        (
            "exclude latest complete year",
            Selection(subdomains=["7.3"]),
            Selection(),
            start,
            end - 1,
            "incidents",
        ),
        (
            cohort_label(engine),
            Selection(subdomains=["7.3"]),
            common_cohort(engine),
            start,
            end,
            "incidents",
        ),
        (
            "drop probable duplicate #353",
            Selection(subdomains=["7.3"]),
            Selection(
                exclude_ids=engine.config.probable_duplicate_sensitivity_drop_ids
            ),
            start,
            end,
            "incidents",
        ),
        (
            "reported direct/indirect severity ≥2 (ten dimensions)",
            Selection(subdomains=["7.3"]),
            Selection(severity=SeveritySpec(dimensions=10, threshold=2)),
            start,
            end,
            "incidents",
        ),
        (
            "all-channel severity ≥2 (thirteen dimensions)",
            Selection(subdomains=["7.3"]),
            Selection(
                severity=SeveritySpec(
                    dimensions=13,
                    channels=["direct", "indirect", "inferred"],
                    threshold=2,
                )
            ),
            start,
            end,
            "incidents",
        ),
        # v2 addition, appended so that inherited calculation IDs keep their definitions.
        (
            "excluding records primarily in domain 4 (sensitivity to the fraud/malicious-actor surge; not a decomposition)",
            Selection(subdomains=["7.3"]),
            Selection(
                domains=sorted(
                    {row.domain for row in engine.rows if row.domain} - {"4"}
                )
            ),
            start,
            end,
            "incidents",
        ),
    ]
    for name, target, population, a, b, denominator in variations:
        result = engine.series(
            f"candidate.IT-C002.sensitivity{len(robust)}",
            target,
            a,
            b,
            population,
            denominator,
        )
        evidence.extend(series_ids(result))
        variant = flag_series_variant(
            {
                "alternative": name,
                "series_id": result["series_id"],
                "trend": result["trend"],
                "points": result["points"],
            },
            primary["points"],
        )
        if variant["identical_to_base"]:
            variant["alternative"] += " — no effect (0 records removed in this export)"
        robust.append(variant)
    current_year = engine.analysis_date.year
    ytd = engine.fraction(
        "candidate.IT-C002.partial_current_year",
        Selection(subdomains=["7.3"]),
        Selection(years=[current_year]),
    )
    evidence.append(ytd.calculation_id)
    robust.append(
        {
            "alternative": f"{current_year} year-to-date through {engine.analysis_date} (incomplete; context only, not a trend point)",
            "points": [{"label": f"{current_year} to date", **ytd.model_dump()}],
        }
    )
    # Growth attribution: which primary subdomains account for the additional records at the end year.
    growth_rows = []
    for code_value in sorted({row.primary for row in engine.rows if row.primary}):
        a_measure = engine.fraction(
            f"candidate.IT-C002.growth.{code_value}.{start}",
            Selection(subdomains=[code_value]),
            Selection(years=[start]),
        )
        b_measure = engine.fraction(
            f"candidate.IT-C002.growth.{code_value}.{end}",
            Selection(subdomains=[code_value]),
            Selection(years=[end]),
        )
        evidence.extend([a_measure.calculation_id, b_measure.calculation_id])
        growth_rows.append(
            {
                "subdomain": code_value,
                "start_count": a_measure.numerator,
                "end_count": b_measure.numerator,
                "growth": b_measure.numerator - a_measure.numerator,
                "derived_from": [a_measure.calculation_id, b_measure.calculation_id],
            }
        )
    total_growth = (
        primary["points"][-1]["denominator"] - primary["points"][0]["denominator"]
    )
    growth_rows.sort(key=lambda row: (-row["growth"], row["subdomain"]))
    for row in growth_rows:
        row["share_of_total_growth_pct"] = (
            round(100 * row["growth"] / total_growth, 2) if total_growth > 0 else None
        )
    robust.append(
        {
            "alternative": f"share of {start}→{end} record growth by primary subdomain (derived from the annual counts; top five)",
            "total_growth": total_growth,
            "top_categories_growth": growth_rows[:5],
        }
    )
    top_growth = growth_rows[0] if growth_rows else None
    labels = {
        row.primary: row.raw["subdomain_code"].strip()
        for row in engine.rows
        if row.primary
    }
    pooled = []
    for label, years in (("early", [start, start + 1]), ("late", [end - 1, end])):
        result = engine.fraction(
            f"candidate.IT-C002.pooled.{label}",
            Selection(subdomains=["7.3"]),
            Selection(years=years),
        )
        evidence.append(result.calculation_id)
        pooled.append({"label": f"{years[0]}–{years[-1]}", **result.model_dump()})
    robust.append(
        {
            "alternative": "pooled first two versus last two years",
            "points": pooled,
            "endpoint_delta_pp": difference(pooled[0]["percent"], pooled[1]["percent"]),
        }
    )
    first, last = primary["points"][0], primary["points"][-1]
    delta = primary["trend"]["endpoint_delta_pp"]
    eligibility = comparison_eligibility(engine, first, last)
    annual_decline = primary["trend"]["strictly_decreasing_share"]
    directions_text = (
        f"The share direction is {direction(delta)}; the count direction is "
        f"{direction(primary['trend']['endpoint_count_change'])}."
    )
    count_change_text = (
        f"rose from {first['numerator']} to {last['numerator']}"
        if last["numerator"] > first["numerator"]
        else (
            f"fell from {first['numerator']} to {last['numerator']}"
            if last["numerator"] < first["numerator"]
            else f"was unchanged at {first['numerator']}"
        )
    )
    attribution = ""
    if (
        (delta or 0) < 0
        and top_growth is not None
        and top_growth["subdomain"] != "7.3"
        and total_growth > 0
        and top_growth["growth"] > 0
    ):
        attribution = f", chiefly {labels.get(top_growth['subdomain'], top_growth['subdomain'])} ({top_growth['growth']} of the {total_growth} additional records dated {end} versus {start})"
    share_verb = (
        "fell" if (delta or 0) < 0 else "rose" if (delta or 0) > 0 else "was unchanged"
    )
    website_text = (
        f"Among incident records dated {start}–{end}, the share whose primary subdomain is ‘{labels.get('7.3', '7.3')}’ "
        + (
            f"{share_verb} each year, "
            if (annual_decline or primary["trend"]["strictly_increasing_share"])
            else f"{share_verb} "
        )
        + f"from {first['numerator']} of {first['denominator']} ({percent_text(first['percent'])}) in {start} to {last['numerator']} of {last['denominator']} ({percent_text(last['percent'])}) in {end}, while the number of such records {count_change_text}."
        + (
            f" The falling share reflects faster growth in other categories{attribution}; it is not evidence that AI systems became more robust."
            if (delta or 0) < 0
            else " These are shares of database records, not measures of underlying AI safety."
        )
    )
    duplicate_pair = {
        row.incident_id: row.primary
        for row in engine.rows
        if row.incident_id in {"230", "353"}
    }
    duplicate_note = (
        f" The one preserved probable same-event pair (#230/#353) received different primary subdomains ({duplicate_pair.get('230')} vs {duplicate_pair.get('353')})."
        if len(duplicate_pair) == 2
        and duplicate_pair.get("230") != duplicate_pair.get("353")
        else ""
    )
    candidates.append(
        Candidate(
            candidate_id="IT-C002",
            title="Capability/robustness shares and absolute counts",
            finding=f"Primary subdomain 7.3 accounts for {fraction_text(first)} of records dated {start}, versus {fraction_text(last)} dated {end}: {number_text(delta)} percentage points. Counts change from {first['numerator']} to {last['numerator']} ({number_text(primary['trend']['relative_count_change_pct'], 1)}%). {directions_text} Strict annual share decline: {annual_decline}.",
            chart_ids=["C02"],
            evidence_ids=evidence,
            chart_configuration={
                "primary_chart": "C02",
                "stacking_category": "Primary Subdomain",
                "filters": {},
                "date_range": f"{start}-01-01 to {end}-12-31",
                "setting": "Proportions with all primary-subdomain legend series visible; Counts for the companion count view",
                "programmatic_preset": {
                    "year": [str(year) for year in range(start, end + 1)],
                    "stackBy": "subdomain",
                    "viewMode": "proportion",
                },
                "compatibility": "Primary shares are faithfully representable with an exact-year host preset. Do not filter to 7.3 or hide other subdomains: either changes the denominator. All Subdomains proportions display assignment shares, not the any-label incident percentages used in sensitivity analysis.",
                "verification": CHART_CAVEAT,
                "container_id": "main-chart",
                "dataset": "incidents-arcola",
            },
            eligibility=eligibility,
            calculation_confidence="High for primary/any-label counting and exact annual comparisons in the export.",
            interpretation_confidence="Moderate for a compositional database statement; low for any claim that robustness has improved or failures have become rarer.",
            caveats=SHARED_CAVEATS
            + [
                "Additional risk tags answer a different question from the primary tag. Within-domain percentages and assignment shares are different denominators, not replacements for the all-record headline.",
                "Growing counts in other categories can reduce this share while the capability/robustness count rises; the excluding-domain-4 row is a sensitivity, not a decomposition, because other domains also grew.",
                f"The {start} starting point is a local maximum of the longer series (see the 'include prior years' context in facts.json annual.sub7.3.primary); the {current_year} year-to-date row is context only and is never compared with whole years in the website text.",
                entry_order_caveat(engine, "7.3", end) + duplicate_note,
            ],
            robustness=robust,
            proposed_website_text=website_text,
            review_state=(
                "human_review_required" if eligibility["passed"] else "withheld"
            ),
        )
    )

    # IT-C003: a snapshot ranking with consistent primary-purpose counting.
    distributions = []
    evidence = []
    for label, population in (
        ("all dates", Selection()),
        ("complete years only", Selection(max_year=end)),
        ("recent complete years", Selection(min_year=start, max_year=end)),
        (cohort_label(engine), common_cohort(engine)),
        (
            "drop probable duplicate #353",
            Selection(
                exclude_ids=engine.config.probable_duplicate_sensitivity_drop_ids
            ),
        ),
        ("known primary purpose only", Selection(known_fields=["ai_goal_primary"])),
        (
            f"{engine.analysis_date.year} year-to-date (incomplete; context only)",
            Selection(years=[engine.analysis_date.year]),
        ),
    ):
        distribution = engine.distribution("ai_goal_primary", population)
        top = []
        for item in distribution[:5]:
            result = engine.fraction(
                f"candidate.IT-C003.variant{len(distributions)}.rank{len(top)+1}",
                Selection(equals={"ai_goal_primary": [item["category"]]}),
                population,
            )
            evidence.append(result.calculation_id)
            top.append({"category": item["category"], **result.model_dump()})
        variant = {"alternative": label, "top_categories": top}
        if distributions:
            base_top = distributions[0]["top_categories"]
            variant["identical_to_base"] = [
                (t["category"], t["numerator"], t["denominator"]) for t in top
            ] == [(t["category"], t["numerator"], t["denominator"]) for t in base_top]
            variant["records_removed"] = base_top[0]["denominator"] - (
                top[0]["denominator"] if top else 0
            )
            if variant["identical_to_base"]:
                variant[
                    "alternative"
                ] += " — no effect (0 records removed in this export)"
        distributions.append(variant)
    top_base = distributions[0]["top_categories"]
    # Chart 'Other' slice: the live pie names the leading categories and groups the tail.
    full_distribution = engine.distribution("ai_goal_primary")
    named_slices = 15
    other_slice = sum(item["count"] for item in full_distribution[named_slices:])
    # Illustrative lumpings (analyst-defined; not the taxonomy's categories).
    all_counts = {item["category"]: item["count"] for item in full_distribution}
    assistant_family = [
        "Chatbot",
        "Writing Assistant",
        "Question Answering",
        "Code Generation",
    ]
    synthetic_media_family = [
        "Deepfake Video Generation",
        "Deepfake Image Generation",
        "Voice Generation",
    ]
    lumping_note = (
        "Illustrative lumpings (analyst-defined, not the displayed taxonomy): an assistant family of "
        + " + ".join(f"{name} {all_counts.get(name, 0)}" for name in assistant_family)
        + f" = {sum(all_counts.get(name, 0) for name in assistant_family)}; a synthetic-media family of "
        + " + ".join(
            f"{name} {all_counts.get(name, 0)}" for name in synthetic_media_family
        )
        + f" = {sum(all_counts.get(name, 0) for name in synthetic_media_family)}. The ranking describes the taxonomy as displayed, whose granularity is asymmetric."
    )
    first = top_base[0]
    if len(top_base) > 1:
        second = top_base[1]
    else:
        absent = engine.fraction("candidate.IT-C003.no_runner_up", Selection(ids=[]))
        evidence.append(absent.calculation_id)
        second = {"category": "No other observed category", **absent.model_dump()}
    lead = first["percent"] - second["percent"]
    passed = (
        first["numerator"] >= engine.config.min_comparison_denominator
        and lead >= engine.config.share_change_materiality_pp
        and first["category"] not in engine.config.unknown_values
    )
    # Secondary-purpose membership is explicitly not the live primary-purpose chart.
    counts = Counter(
        value
        for row in engine.rows
        for value in set([row.raw["ai_goal_primary"], row.raw["ai_goal_secondary"]])
        if value not in engine.config.unknown_values
    )
    top_secondary = []
    for label, _ in counts.most_common(3):
        result = engine.fraction(
            f"candidate.IT-C003.secondary{len(top_secondary)}",
            Selection(purposes=[label], purpose_scope="primary_or_secondary"),
        )
        evidence.append(result.calculation_id)
        top_secondary.append({"category": label, **result.model_dump()})
    distributions.append(
        {
            "alternative": "primary or secondary purpose (different estimand)",
            "top_categories": top_secondary,
            "lead_pp": (
                difference(top_secondary[1]["percent"], top_secondary[0]["percent"])
                if len(top_secondary) > 1
                else None
            ),
            "same_ranking_margin_rule_passed": len(top_secondary) > 1
            and top_secondary[0]["percent"] - top_secondary[1]["percent"]
            >= engine.config.share_change_materiality_pp,
        }
    )
    majority_text = (
        "This is a majority of incident records."
        if first["percent"] > 50
        else (
            "This is a plurality, not a majority, of incident records."
            if lead > 0
            else "There is no unique leading primary-purpose category."
        )
    )
    other_text = (
        f" The chart's ‘Other’ slice groups the tail beyond the {named_slices} named purposes ({other_slice:,} records here) and is larger than any single named category."
        if other_slice > first["numerator"]
        else f" The chart's ‘Other’ slice groups the tail beyond the {named_slices} named purposes ({other_slice:,} records here)."
    )
    ranking_revision = (
        f"‘{first['category']}’ is the most frequent single primary-purpose tag, assigned to {first['numerator']:,} of {first['denominator']:,} incident records ({percent_text(first['percent'])})"
        + (
            f", followed by ‘{second['category']}’ ({second['numerator']:,}, {percent_text(second['percent'])})."
            if len(top_base) > 1
            else "; no second primary-purpose category is present."
        )
        + other_text
        if lead > 0
        else "The leading primary-purpose categories are tied; report the full distribution."
    )
    candidates.append(
        Candidate(
            candidate_id="IT-C003",
            title=(
                f"{first['category']} is the largest primary-purpose category"
                if lead > 0
                else "Primary-purpose category ranking"
            ),
            finding=f"Across all export records, {first['category']} has {fraction_text(first)} versus {second['category']} with {fraction_text(second)}; the lead is {lead:.2f} percentage points. {majority_text}",
            chart_ids=["C03"],
            evidence_ids=evidence,
            chart_configuration={
                "primary_chart": "C03",
                "stacking_category": "AI Purpose (primary)",
                "filters": {},
                "date_range": "All dates in this export; includes the incomplete current year as snapshot composition",
                "setting": "Pie proportions; keep all slices, including Other, visible; counts in tooltip",
                "programmatic_preset": {"stackBy": "aiGoal"},
                "compatibility": "Representable. The API presents named leading categories plus Other; Other is an aggregation, not a competing single purpose. Chart numbers will differ until the mirror uses this export.",
                "verification": CHART_CAVEAT,
                "container_id": "main-chart",
                "dataset": "incidents-arcola",
            },
            eligibility={
                "passed": passed,
                "rule": "ranking winner ≥50 and lead ≥5 percentage points",
                "winner_count": first["numerator"],
                "lead_pp": lead,
            },
            calculation_confidence="High for the primary-purpose ranking; alternate purposes are counted separately.",
            interpretation_confidence="Moderate for the retained tag ranking; low for which AI applications are intrinsically riskiest.",
            caveats=SHARED_CAVEATS
            + [
                "Classifier-defined purpose categories are not equal-sized exposure groups. A leading incident count does not imply the highest risk per use.",
                "Purpose labels do not establish whether every implicated system actually used generative AI as described.",
                lumping_note,
                "The exploratory ledger screens rankings on records dated through the last complete year; this candidate ranks all dates (both windows are shown in the robustness table).",
            ],
            robustness=distributions,
            proposed_website_text=ranking_revision,
            review_state="human_review_required" if passed else "withheld",
        )
    )

    # IT-C004: use the current domain-bar floor, with a closed complete-year selection.
    population = Selection(domains=["4"], min_year=2016, max_year=end)
    target = Selection(subdomains=["4.3"])
    base = engine.fraction("candidate.IT-C004.primary", target, population)
    evidence = [base.calculation_id]
    robust = []
    for name, t, p in (
        (
            "all dates (includes incomplete current year)",
            target,
            Selection(domains=["4"]),
        ),
        (
            "recent complete years",
            target,
            Selection(domains=["4"], min_year=start, max_year=end),
        ),
        (
            "any subdomain within primary domain",
            Selection(subdomains=["4.3"], classification="any"),
            population,
        ),
        (
            "any-domain and any-subdomain memberships (different population)",
            Selection(subdomains=["4.3"], classification="any"),
            Selection(domains=["4"], classification="any", min_year=2016, max_year=end),
        ),
        (
            "drop probable duplicate #353",
            target,
            population.model_copy(
                update={
                    "exclude_ids": engine.config.probable_duplicate_sensitivity_drop_ids
                }
            ),
        ),
        (
            cohort_label(engine),
            target,
            population.model_copy(update={"equals": common_cohort(engine).equals}),
        ),
        (
            "known primary subdomain only",
            target,
            population.model_copy(update={"known_fields": ["subdomain_code"]}),
        ),
        (
            f"pooled 2016–{end - 2} (earlier part of the window)",
            target,
            Selection(domains=["4"], min_year=2016, max_year=end - 2),
        ),
        (
            f"pooled {end - 1}–{end} (latest two complete years)",
            target,
            Selection(domains=["4"], min_year=end - 1, max_year=end),
        ),
        (
            f"{engine.analysis_date.year} year-to-date (incomplete; context only)",
            target,
            Selection(domains=["4"], years=[engine.analysis_date.year]),
        ),
    ):
        result = engine.fraction(f"candidate.IT-C004.sensitivity{len(robust)}", t, p)
        evidence.append(result.calculation_id)
        variant = flag_fraction_variant(
            {"alternative": name, **result.model_dump()}, base
        )
        if (
            variant["identical_to_base"]
            and "pooled" not in name
            and "year-to-date" not in name
        ):
            variant["alternative"] += " — no effect (0 records removed in this export)"
        robust.append(variant)
    early_pool = robust[-3]
    late_pool = robust[-2]
    pooled_sentence = f"Pooled, the within-domain 4.3 share was {fraction_text(early_pool)} for 2016–{end - 2} and {fraction_text(late_pool)} for {end - 1}–{end}, which supply {late_pool['denominator']} of the {base.denominator} records; annual cells before 2022 hold few records and are not quoted as a range."
    passed = (
        base.denominator >= engine.config.min_comparison_denominator
        and base.numerator >= engine.config.min_category_count
        and base.percent is not None
        and base.percent >= engine.config.concentration_min_share_pct
    )
    candidates.append(
        Candidate(
            candidate_id="IT-C004",
            title="Fraud/scams within the primary malicious-actors domain",
            finding=f"Among records dated 2016–{end} with primary domain 4 Malicious actors, {fraction_text(base)} have primary subdomain 4.3 Fraud, scams and targeted manipulation.",
            chart_ids=["C04", "C03"],
            evidence_ids=evidence,
            chart_configuration={
                "primary_chart": "C04",
                "stacking_category": "Primary Subdomain",
                "filters": {
                    "domain": ["4 Malicious actors"],
                    "year": [str(year) for year in range(2016, end + 1)],
                },
                "date_range": f"2016-01-01 to {end}-12-31",
                "setting": "Counts (visible chart default); the percentage is derived from the domain total. A host preset can use proportions, but C04 has no visible toggle.",
                "programmatic_preset": {
                    "year": [str(year) for year in range(2016, end + 1)],
                    "domain": "4 Malicious actors",
                    "stackBy": "subdomain",
                    "viewMode": "counts",
                },
                "compatibility": "Representable as the primary-subdomain segment count over the domain total. Select the exact Year values via the bar chart's verified Year control. Alternative C03 pie: same filters, Primary Subdomain; all slices visible.",
                "verification": CHART_CAVEAT,
                "container_id": "main-chart-2",
                "dataset": "incidents-arcola",
            },
            eligibility={
                "passed": passed,
                "rule": "within-domain concentration",
                "minimum_denominator": engine.config.min_comparison_denominator,
                "minimum_share_pct": engine.config.concentration_min_share_pct,
            },
            calculation_confidence="High for the explicitly primary, closed-window numerator and denominator.",
            interpretation_confidence="Moderate for category composition; low for the prevalence or absolute frequency of real-world malicious AI use.",
            caveats=SHARED_CAVEATS
            + [
                "This conditional share is within domain 4, not across all incidents. Additional-domain membership changes the population.",
                "The default bar includes the current partial year; exact Year selection is needed for this candidate's window.",
                pooled_sentence,
                "The exploratory ledger screens concentrations on records dated through the last complete year without the 2016 floor; this candidate uses the bar chart's 2016 floor (both values appear in the robustness table).",
            ],
            robustness=robust,
            proposed_website_text=f"Of the incident records dated 2016–{end} primarily classified as ‘4 Malicious actors’, {base.numerator} of {base.denominator} ({percent_text(base.percent)}) have primary subdomain ‘4.3 Fraud, scams and targeted manipulation’. {pooled_sentence.split(';')[0]}.",
            review_state="human_review_required" if passed else "withheld",
        )
    )

    # IT-C005: measurement insight; current charts cannot faithfully show the channel comparison.
    evidence = []
    robust = []
    for dimensions in (10, 13):
        for channels in (
            ["direct"],
            ["direct", "indirect"],
            ["direct", "indirect", "inferred"],
        ):
            for policy in ("lower_bound", "upper_bound"):
                key = f"candidate.IT-C005.{dimensions}.{'+'.join(channels)}.{policy}"
                result = engine.fraction(
                    key,
                    Selection(
                        severity=SeveritySpec(
                            dimensions=dimensions,
                            channels=channels,
                            threshold=4,
                            missing_policy=policy,
                        )
                    ),
                )
                evidence.append(result.calculation_id)
                robust.append(
                    {
                        "alternative": (
                            f"{dimensions} dimensions / {'+'.join(channels)} / observed scores (lower bound)"
                            if policy == "lower_bound"
                            else f"{dimensions} dimensions / {'+'.join(channels)} / upper bound (treats zero-coded or blank components as possibly ≥4)"
                        ),
                        **result.model_dump(),
                    }
                )
    direct = engine.measures["candidate.IT-C005.10.direct+indirect.lower_bound"]
    inferred = engine.measures[
        "candidate.IT-C005.10.direct+indirect+inferred.lower_bound"
    ]
    delta = inferred.percent - direct.percent
    added = inferred.numerator - direct.numerator
    zero_or_missing_ids = [
        row.incident_id
        for row in engine.rows
        if any(
            score is None or score == 0
            for category in row.severity.values()
            for score in category.values()
        )
    ]
    zero_coded_ids = [
        row.incident_id for row in engine.rows if row.zero_coded_severity_cells
    ]
    blank_ids = [row.incident_id for row in engine.rows if row.blank_severity_cells]
    for name, pop in (
        (
            f"exclude records with any zero-coded or blank component (13 dimensions, all channels; recalculated per export: {len(zero_coded_ids)} zero-coded, {len(blank_ids)} blank)",
            Selection(exclude_ids=zero_or_missing_ids),
        ),
        ("complete years only", Selection(max_year=end)),
        (cohort_label(engine), common_cohort(engine)),
    ):
        group = []
        for channels in (["direct", "indirect"], ["direct", "indirect", "inferred"]):
            result = engine.fraction(
                f"candidate.IT-C005.variant{len(robust)}.{'+'.join(channels)}",
                Selection(
                    severity=SeveritySpec(dimensions=10, channels=channels, threshold=4)
                ),
                pop,
            )
            evidence.append(result.calculation_id)
            group.append({"label": "+".join(channels), **result.model_dump()})
        robust.append(
            {
                "alternative": name,
                "points": group,
                "delta_pp": difference(group[0]["percent"], group[1]["percent"]),
            }
        )
    # Exact record-level difference set is separately attributable to inference.
    direct_ids = set(
        engine.id_sets[direct.numerator_ids_ref.split("/")[-1].removesuffix(".json")]
    )
    inference_ids = set(
        engine.id_sets[inferred.numerator_ids_ref.split("/")[-1].removesuffix(".json")]
    )
    extra = engine.fraction(
        "candidate.IT-C005.inferred_only_crossings",
        Selection(ids=sorted(inference_ids - direct_ids)),
    )
    evidence.append(extra.calculation_id)
    for threshold in (2, 3, 5):
        group = []
        for channels in (["direct", "indirect"], ["direct", "indirect", "inferred"]):
            result = engine.fraction(
                f"candidate.IT-C005.threshold{threshold}.{'+'.join(channels)}",
                Selection(
                    severity=SeveritySpec(
                        dimensions=10, channels=channels, threshold=threshold
                    )
                ),
            )
            evidence.append(result.calculation_id)
            group.append({"label": "+".join(channels), **result.model_dump()})
        robust.append(
            {
                "alternative": f"Alternative cutoff ≥{threshold}, original ten dimensions (different question)",
                "points": group,
                "delta_pp": difference(group[0]["percent"], group[1]["percent"]),
                "eligibility": comparison_eligibility(engine, group[0], group[1]),
            }
        )
    eligibility = comparison_eligibility(
        engine, direct.model_dump(), inferred.model_dump()
    )
    eligibility["rule"] = (
        "same-population measurement-definition contrast (5 pp share-shift rule)"
    )
    eligibility["disclosure"] = (
        "The 5-pp same-population rule was clarified in definitions 2026-09-27.2 after this candidate existed; "
        "this comparison was not a cell of the v1 exploratory ledger. A same-population channel_contrast family was added to the ledger in v2 (definitions 2026-09-27.3)."
    )
    # Public headline field: what the export's own scalars can and cannot express.
    headline = engine.fraction(
        "candidate.IT-C005.export_highest_severity_ge4",
        Selection(numeric_min={"highest_severity": 4}),
    )
    headline10 = engine.fraction(
        "candidate.IT-C005.export_highest_severity_10_ge4",
        Selection(numeric_min={"highest_severity_10": 4}),
    )
    direct13 = engine.fraction(
        "candidate.IT-C005.13.direct.ge4",
        Selection(
            severity=SeveritySpec(dimensions=13, channels=["direct"], threshold=4)
        ),
    )
    reported13 = engine.fraction(
        "candidate.IT-C005.13.direct+indirect.ge4",
        Selection(
            severity=SeveritySpec(
                dimensions=13, channels=["direct", "indirect"], threshold=4
            )
        ),
    )
    above_direct_ids = [
        row.incident_id
        for row in engine.rows
        if row.raw["highest_severity"].strip()
        and int(row.raw["highest_severity"])
        > max(
            (row.severity[category]["direct"] or 0 for category in HARM13),
            default=0,
        )
    ]
    above_direct = engine.fraction(
        "candidate.IT-C005.headline_exceeds_direct_maximum",
        Selection(ids=above_direct_ids),
    )
    evidence.extend(
        [
            headline.calculation_id,
            headline10.calculation_id,
            direct13.calculation_id,
            reported13.calculation_id,
            above_direct.calculation_id,
        ]
    )
    no_direct = headline.numerator - direct13.numerator
    no_reported = headline.numerator - reported13.numerator
    robust.append(
        {
            "alternative": "what the export's public scalars express (context for the chart label)",
            "points": [
                {
                    "label": "highest_severity_10 ≥4 (10 dimensions, all channels incl. inferred)",
                    **headline10.model_dump(),
                },
                {
                    "label": "highest_severity ≥4 (13 dimensions, all channels incl. inferred) — the public headline field",
                    **headline.model_dump(),
                },
                {"label": "13 dimensions, direct only ≥4", **direct13.model_dump()},
                {
                    "label": "13 dimensions, direct or indirect ≥4",
                    **reported13.model_dump(),
                },
                {
                    "label": "records whose headline exceeds their highest direct score (any level)",
                    **above_direct.model_dump(),
                },
            ],
        }
    )
    label_text = (
        f" {inferred.numerator} equals the export's highest_severity_10 ≥4; {direct.numerator} corresponds to no exported scalar or public control. "
        f"The export's 13-dimension all-channel highest_severity reaches ≥4 for {headline.numerator} records, {no_direct} of them ({percent_text(100 * no_direct / headline.numerator if headline.numerator else None)}) without any direct score ≥4 and {no_reported} ({percent_text(100 * no_reported / headline.numerator if headline.numerator else None)}) without any direct or indirect score ≥4; overall the headline exceeds the highest direct score for {fraction_text(above_direct)} of records. "
        "If the deployed headline equals this field, as the live probes indicate, its label ‘Highest Direct Severity Score’ is wrong for those records."
    )
    candidates.append(
        Candidate(
            candidate_id="IT-C005",
            title="Severe-score counts with and without model inference",
            finding=f"Across the original ten harm dimensions, {fraction_text(direct)} of records have an observed direct or indirect severity score ≥4. With inferred scores included, the count is {fraction_text(inferred)}: {added} additional records and {delta:.2f} percentage points. This is a measurement-definition comparison, not evidence that those inferred severe harms occurred.{label_text}",
            chart_ids=["C05", "C03"],
            evidence_ids=evidence,
            chart_configuration={
                "primary_chart": "C05 (incident-level inspection); supporting severity sensitivity table for the aggregate finding",
                "stacking_category": "No current grouping separates direct/indirect from inferred maxima",
                "filters": {},
                "date_range": "All dates in the export, including partial current year; snapshot measurement comparison",
                "setting": "Counts and proportions in the supplied supporting table, not a live aggregate chart setting",
                "compatibility": (
                    "Cannot portray this comparison faithfully in the current aggregate controls. "
                    + SEVERITY_SOURCE_OF_TRUTH
                    + f" On this export the headline field would show {fraction_text(headline)} at ≥4, not {direct.numerator} or {inferred.numerator}. C05 plots direct and indirect scores for one incident and omits an inferred numeric series. Do not publish using the severe-harm preset (it sends an ignored minSeverity key; the effective key minSeverityHighest selects on the inferred-inclusive headline) or relabel highest_severity as direct."
                ),
                "verification": CHART_CAVEAT,
            },
            eligibility=eligibility,
            calculation_confidence=f"High for the observed score thresholds and channel maxima. The {len(zero_coded_ids)} zero-coded records ({', '.join('#' + i for i in zero_coded_ids)}) and {len(blank_ids)} blank-cell records have explicit bounds and an exclusion sensitivity; whether a zero score means 'not assessed' or 'no harm' is unresolved with the exporter.",
            interpretation_confidence="High that channel choice changes the retained score count; low that inferred scores verify realized harm severity.",
            caveats=SHARED_CAVEATS
            + [
                "The published rubric defines the original ten dimensions. Psychological, epistemic and CSEA dimensions are reported separately as a thirteen-dimension sensitivity.",
                "Direct/indirect denotes explicitly reported causal pathways in app definitions; inferred means model-imputed, not an additional independently documented harm count.",
                "Thresholds are ordinal. Level 1 includes none through minor harm; scores and counts are not summed into a burden-of-harm metric.",
            ],
            robustness=robust,
            proposed_website_text=f"Severity summaries depend on the evidence channel. In the original ten harm categories, {direct.numerator:,} of {direct.denominator:,} records ({percent_text(direct.percent)}) have a direct or indirect score of at least 4; {inferred.numerator:,} ({percent_text(inferred.percent)}) meet that threshold when model-inferred scores are included. Inferred scores require further investigation.",
            review_state=(
                "human_review_required" if eligibility["passed"] else "withheld"
            ),
        )
    )
    if len(candidates) > engine.config.max_shortlisted_candidates:
        raise ValueError("Shortlist exceeds configured cap")
    for candidate in candidates:
        if not set(candidate.evidence_ids).issubset(engine.measures):
            raise ValueError(f"Missing evidence for {candidate.candidate_id}")
        decisions.append(
            {
                "candidate_id": candidate.candidate_id,
                "decision": candidate.review_state,
                "selection_stage": "session_template",
                "eligibility": candidate.eligibility,
                "selection_reason": (
                    "Same-population measurement-definition contrast selected editorially in the first session; not a cell of the v1 exploratory ledger (a channel_contrast family was added in v2); its 5-pp rule was clarified post hoc in definitions 2026-09-27.2."
                    if candidate.candidate_id == "IT-C005"
                    else "Complementary descriptive finding selected by the first session from the recorded exploratory universe; retained in v2 as an audited template alongside the data-driven discovery stage; not a statistical ranking."
                ),
            }
        )
    fraud_2021 = engine.measures.get(f"annual.sub4.3.primary.{start}")
    decisions.extend(
        [
            {
                "analysis": "primary fraud-share endpoint trend",
                "decision": "not separately shortlisted",
                "reason": "Retained in the fixed-window published-claim audit and duplicates the domain concentration narrative. The baseline endpoint sample-size issue must be rechecked for each new export.",
                "first_endpoint_count": fraud_2021.numerator if fraud_2021 else None,
            },
            {
                "analysis": "cross-domain harm contrasts",
                "decision": "not shortlisted",
                "reason": "Full exploratory ledger retained; contrasts are heavily entangled with taxonomy assignment, and the current multi-label harm percentages are assignment shares. No causal contrast is warranted.",
            },
            {
                "analysis": "national-security ≥4 annual trends",
                "decision": "not shortlisted",
                "reason": "The initial export's qualified cohort and annual counts fail the stability requirements. Future exports require rechecking this editorial decision; C07 remains an individual-record radar.",
            },
            {
                "analysis": "estimated harmed/exposed people totals",
                "decision": "not shortlisted",
                "reason": "Unknown/default/overlap semantics, extreme estimates and missing report provenance prevent a defensible distinct-people denominator.",
            },
        ]
    )
    return candidates, decisions


def chart_outcomes(
    inventory: dict[str, Any], candidates: list[Candidate], engine: Engine
) -> list[dict[str, Any]]:
    outcomes = []
    table_only = [c.candidate_id for c in candidates if not c.chart_ids]
    if table_only:
        outcomes.append(
            {
                "chart_id": "TABLE",
                "name": "Supporting table (no faithful current chart)",
                "source_url": None,
                "publication_status": "current_tracker",
                "surface_type": "supporting_table",
                "candidate_ids": table_only,
                "decision": "Findings whose definition no current aggregate chart can display faithfully; publish, if at all, with the supporting table.",
            }
        )
    for chart in inventory["entries"]:
        chart_id = chart["id"]
        related = [c.candidate_id for c in candidates if chart_id in c.chart_ids]
        if chart["publication_status"] != "current_tracker":
            decision = (
                "Reference/historical inventory; no new current-chart candidate sought."
            )
        elif related:
            decision = "Candidate(s) supplied; consult per-candidate compatibility (a supporting table may be required)."
        elif chart_id == "C06":
            decision = "No defensible aggregate insight: the Ishikawa diagram lists LLM-proposed potential causes, without independently verified causal effects or a consistent incidence denominator."
        elif chart_id == "C07":
            qualified = len(
                engine.select(Selection(numeric_min={"natsec_overall_score": 4}))
            )
            sample_note = (
                "below"
                if qualified < engine.config.min_comparison_denominator
                else "at or above"
            )
            decision = f"No aggregate candidate for this individual-record radar. NatSec ≥4 selects {qualified} records in this export, {sample_note} the {engine.config.min_comparison_denominator}-record subgroup criterion. Annual stability and publication usefulness require separate review."
        elif chart["surface_type"].startswith("framework_reference"):
            decision = "Framework definition, not an empirical chart; no incident finding applies."
        else:
            decision = "Listing/reference surface, not an aggregate chart. Use for incident-level evidence review; see inventory for its controls and scope."
        outcomes.append(
            {
                "chart_id": chart_id,
                "name": chart["name"],
                "source_url": chart["source_url"],
                "publication_status": chart["publication_status"],
                "surface_type": chart["surface_type"],
                "candidate_ids": related,
                "decision": decision,
            }
        )
    return outcomes
