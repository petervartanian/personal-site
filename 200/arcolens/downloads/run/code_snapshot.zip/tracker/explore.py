"""Explicit exploratory search universe and stable, executable evidence families."""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from datetime import date
from itertools import combinations
from pathlib import Path
from typing import Any

from .calc import Engine, matches, proportion, trend
from .data import HARM10, HARM13, SCALARS, load_incidents, write_csv, write_json
from .models import AnalysisConfig, Selection, SeveritySpec


def safe_key(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()[:12]


def build_facts(engine: Engine) -> dict[str, Any]:
    """Fixed evidence universe; published windows remain fixed in audit.py."""
    year_end = engine.analysis_date.year - 1
    year_start = year_end - engine.config.complete_year_window + 1
    facts: dict[str, Any] = {"start_year": year_start, "end_year": year_end}
    facts["all_records"] = engine.fraction("all.records").model_dump()
    facts["complete_records"] = engine.fraction(
        "complete.records", population=Selection(max_year=year_end)
    ).model_dump()
    windows = {
        "all": Selection(),
        "complete": Selection(max_year=year_end),
        "recent": Selection(min_year=year_start, max_year=year_end),
        "bar_complete": Selection(min_year=2016, max_year=year_end),
        "bar_default": Selection(min_year=2016),
    }
    facts["distributions"] = {}
    for window, population in windows.items():
        facts["distributions"][window] = {}
        for field in ("domain_code", "subdomain_code", *SCALARS):
            values = engine.distribution(field, population)
            facts["distributions"][window][field] = values
            for item in values:
                result = engine.fraction(
                    f"dist.{window}.{field}.{safe_key(item['category'])}",
                    Selection(equals={field: [item["category"]]}),
                    population,
                    description=f"{field}={item['category']!r} in {window} window",
                )
                item["calculation_id"] = result.calculation_id
    facts["series"] = {}
    fact_targets: dict[str, Selection] = {
        "records": Selection(),
        "intentional": Selection(equals={"causal_intent": ["Intentional"]}),
        "human": Selection(equals={"causal_entity": ["Human"]}),
        "pre_deployment": Selection(equals={"causal_timing": ["Pre-deployment"]}),
        "post_deployment": Selection(equals={"causal_timing": ["Post-deployment"]}),
        "eu1": Selection(equals={"eu_ai_act_risk_level": ["1"]}),
        "eu2": Selection(equals={"eu_ai_act_risk_level": ["2"]}),
        "generation_strict": Selection(
            purposes=engine.config.strict_generation_purposes
        ),
        "generation_expanded": Selection(
            purposes=engine.config.expanded_generation_purposes
        ),
        "generation_primary_secondary": Selection(
            purposes=engine.config.strict_generation_purposes,
            purpose_scope="primary_or_secondary",
        ),
        "natsec4": Selection(numeric_min={"natsec_overall_score": 4}),
        "natsec_full_autonomy": Selection(
            equals={"natsec_autonomy_level": ["Full autonomy"]}
        ),
    }
    for subdomain in ("7.3", "4.3", "3.1"):
        for scope in ("primary", "any"):
            fact_targets[f"sub{subdomain}.{scope}"] = Selection(
                subdomains=[subdomain], classification=scope
            )
    for name, target in fact_targets.items():
        # 2016 includes older context; no current-year trend.
        facts["series"][name] = engine.series(
            f"annual.{name}", target, min(2016, year_start), year_end
        )
        facts[name] = engine.fraction(f"all.{name}", target).model_dump()
    for subdomain in ("7.3", "4.3", "3.1"):
        name = f"sub{subdomain}.assignment"
        facts["series"][name] = engine.series(
            f"annual.{name}",
            Selection(subdomains=[subdomain], classification="any"),
            min(2016, year_start),
            year_end,
            denominator="subdomain_assignments",
        )
    facts["severity"] = []
    for dimensions in (10, 13):
        for channels in (
            ["direct"],
            ["direct", "indirect"],
            ["direct", "indirect", "inferred"],
        ):
            channel_name = "+".join(channels)
            for threshold in (2, 3, 4, 5):
                for policy in ("lower_bound", "upper_bound"):
                    key = f"severity.{dimensions}.{channel_name}.ge{threshold}.{policy}"
                    measure = engine.fraction(
                        key,
                        Selection(
                            severity=SeveritySpec(
                                dimensions=dimensions,
                                channels=channels,
                                threshold=threshold,
                                missing_policy=policy,
                            )
                        ),
                    )
                    facts["severity"].append(
                        {
                            "dimensions": dimensions,
                            "channels": channel_name,
                            "threshold": threshold,
                            "policy": policy,
                            "calculation_id": key,
                            "numerator": measure.numerator,
                            "denominator": measure.denominator,
                            "percent": measure.percent,
                        }
                    )
    facts["harm_categories"] = []
    for category in HARM13:
        result = engine.fraction(
            f"harm.{category}.reported.ge2",
            Selection(severity=SeveritySpec(categories=[category], threshold=2)),
        )
        facts["harm_categories"].append({"category": category, **result.model_dump()})
    return facts


def explore(engine: Engine) -> list[dict[str, Any]]:
    """Record each screened comparison, eligibility reasons, and exact definitions."""
    config = engine.config
    end = engine.analysis_date.year - 1
    start = end - config.complete_year_window + 1
    ledger: list[dict[str, Any]] = []

    def comparison(
        family: str,
        name: str,
        target: Selection,
        group_a: Selection,
        group_b: Selection,
        threshold: float,
    ) -> None:
        points = []
        for population in (group_a, group_b):
            rows = engine.select(population)
            count = sum(matches(row, target, config) for row in rows)
            points.append(
                {
                    "numerator": count,
                    "denominator": len(rows),
                    "percent": proportion(count, len(rows)),
                }
            )
        a, b = points
        difference = (
            b["percent"] - a["percent"]
            if a["percent"] is not None and b["percent"] is not None
            else None
        )
        reasons = []
        if min(a["denominator"], b["denominator"]) < config.min_comparison_denominator:
            reasons.append("comparison denominator below minimum")
        if min(a["numerator"], b["numerator"]) < config.min_category_count:
            reasons.append("category count below minimum")
        if difference is None or abs(difference) < threshold:
            reasons.append("share difference below materiality")
        # v2: a cell excluded only because the category was too small at one endpoint, while
        # both denominators meet the minimum and the larger count reaches it, is flagged for the
        # discovery stage's emergence rule (docs/methodology.md, version 2026-09-27.3).
        emergence = (
            reasons == ["category count below minimum"]
            and min(a["denominator"], b["denominator"])
            >= config.min_comparison_denominator
            and max(a["numerator"], b["numerator"]) >= config.min_comparison_denominator
        )
        ledger.append(
            {
                "search_id": f"SEARCH-{safe_key(family+name)}",
                "family": family,
                "name": name,
                "a": a,
                "b": b,
                "delta_pp": difference,
                "eligible": not reasons,
                "exclusion_reasons": reasons,
                "emergence_candidate": emergence,
                "target": target.model_dump(),
                "population_a": group_a.model_dump(),
                "population_b": group_b.model_dump(),
            }
        )

    def definition_contrast(
        family: str,
        name: str,
        target_a: Selection,
        target_b: Selection,
        population: Selection,
        threshold: float,
    ) -> None:
        """Same-population measurement-definition contrast (v2 addition; 5-pp rule)."""
        rows = engine.select(population)
        points = []
        for target in (target_a, target_b):
            count = sum(matches(row, target, config) for row in rows)
            points.append(
                {
                    "numerator": count,
                    "denominator": len(rows),
                    "percent": proportion(count, len(rows)),
                }
            )
        a, b = points
        difference = (
            b["percent"] - a["percent"]
            if a["percent"] is not None and b["percent"] is not None
            else None
        )
        reasons = []
        if len(rows) < config.min_comparison_denominator:
            reasons.append("comparison denominator below minimum")
        if min(a["numerator"], b["numerator"]) < config.min_category_count:
            reasons.append("category count below minimum")
        if difference is None or abs(difference) < threshold:
            reasons.append("share difference below materiality")
        ledger.append(
            {
                "search_id": f"SEARCH-{safe_key(family+name)}",
                "family": family,
                "name": name,
                "a": a,
                "b": b,
                "delta_pp": difference,
                "eligible": not reasons,
                "exclusion_reasons": reasons,
                "emergence_candidate": False,
                "target_a": target_a.model_dump(),
                "target_b": target_b.model_dump(),
                "population": population.model_dump(),
                "rule": "same-population measurement-definition contrast (5 pp); added to the ledger in v2",
            }
        )

    # Candidate universe is fixed by the exported labels, not chosen after viewing changes.
    for scope in ("primary", "any"):
        for subdomain in sorted(set.union(*(row.subdomains for row in engine.rows))):
            comparison(
                "subdomain_endpoint",
                f"{scope}:{subdomain}",
                Selection(subdomains=[subdomain], classification=scope),
                Selection(years=[start]),
                Selection(years=[end]),
                config.share_change_materiality_pp,
            )
    for field in SCALARS:
        for label in sorted({row.raw[field] for row in engine.rows}):
            comparison(
                "scalar_endpoint",
                f"{field}:{label}",
                Selection(equals={field: [label]}),
                Selection(years=[start]),
                Selection(years=[end]),
                config.share_change_materiality_pp,
            )
    for domain_a, domain_b in combinations(
        sorted({row.domain for row in engine.rows if row.domain}), 2
    ):
        for category in HARM10:
            comparison(
                "domain_harm_intersection",
                f"{domain_a}:{domain_b}:{category}",
                Selection(severity=SeveritySpec(categories=[category], threshold=2)),
                Selection(domains=[domain_a], max_year=end),
                Selection(domains=[domain_b], max_year=end),
                config.group_contrast_materiality_pp,
            )
    for dimensions in (10, 13):
        for channels in (
            ["direct"],
            ["direct", "indirect"],
            ["direct", "indirect", "inferred"],
        ):
            for threshold in (2, 3, 4):
                comparison(
                    "severity_endpoint",
                    f"{dimensions}:{'+'.join(channels)}:{threshold}",
                    Selection(
                        severity=SeveritySpec(
                            dimensions=dimensions,
                            channels=channels,
                            threshold=threshold,
                        )
                    ),
                    Selection(years=[start]),
                    Selection(years=[end]),
                    config.share_change_materiality_pp,
                )
    # v2: same-population channel contrasts, so measurement-definition findings such as the
    # retained template IT-C005 are screened cells rather than ad hoc computations.
    channel_sets = (
        ["direct"],
        ["direct", "indirect"],
        ["direct", "indirect", "inferred"],
    )
    for dimensions in (10, 13):
        for left, right in zip(channel_sets, channel_sets[1:]):
            for threshold in (2, 3, 4, 5):
                definition_contrast(
                    "channel_contrast",
                    f"{dimensions}:{'+'.join(left)}->{'+'.join(right)}:{threshold}",
                    Selection(
                        severity=SeveritySpec(
                            dimensions=dimensions, channels=left, threshold=threshold
                        )
                    ),
                    Selection(
                        severity=SeveritySpec(
                            dimensions=dimensions, channels=right, threshold=threshold
                        )
                    ),
                    Selection(),
                    config.share_change_materiality_pp,
                )
    for field in (
        "domain_code",
        "subdomain_code",
        "ai_goal_primary",
        "causal_intent",
        "causal_timing",
    ):
        distribution = engine.distribution(field, Selection(max_year=end))
        if not distribution:
            continue
        first = distribution[0]
        second = distribution[1] if len(distribution) > 1 else {"percent": 0}
        lead = first["percent"] - second["percent"]
        reasons = []
        if first["count"] < config.min_comparison_denominator:
            reasons.append("winner count below minimum")
        if lead < config.share_change_materiality_pp:
            reasons.append("ranking lead below materiality")
        ledger.append(
            {
                "search_id": f"SEARCH-{safe_key('ranking'+field)}",
                "family": "ranking",
                "name": field,
                "a": first,
                "b": second,
                "delta_pp": lead,
                "eligible": not reasons,
                "exclusion_reasons": reasons,
                "population": {"max_year": end},
            }
        )
    years = Counter(row.year for row in engine.rows)
    a, b = years[start], years[end]
    rel = 100 * (b - a) / a if a else None
    eligible = (
        min(a, b) >= config.min_comparison_denominator
        and abs(b - a) >= config.count_change_materiality_absolute
        and rel is not None
        and abs(rel) >= config.count_change_materiality_relative_pct
    )
    ledger.append(
        {
            "search_id": "SEARCH-record-counts",
            "family": "record_counts",
            "name": f"{start}-{end}",
            "a": a,
            "b": b,
            "absolute_count_change": b - a,
            "relative_count_change_pct": rel,
            "eligible": eligible,
            "exclusion_reasons": [] if eligible else ["count thresholds not met"],
        }
    )
    # Concentrations and national-security intersections use the same N rules.
    for domain in sorted({row.domain for row in engine.rows if row.domain}):
        rows = engine.select(Selection(domains=[domain], max_year=end))
        counts = Counter(
            row.primary for row in rows if row.primary
        )  # blank primaries never win
        if not counts:
            continue
        winner, count = counts.most_common(1)[0]
        percent = proportion(count, len(rows))
        eligible = (
            len(rows) >= config.min_comparison_denominator
            and count >= config.min_category_count
            and percent >= config.concentration_min_share_pct
        )
        ledger.append(
            {
                "search_id": f"SEARCH-concentration-{domain}",
                "family": "within_domain_concentration",
                "name": f"{domain}:{winner}",
                "numerator": count,
                "denominator": len(rows),
                "percent": percent,
                "eligible": eligible,
                "exclusion_reasons": (
                    [] if eligible else ["concentration/sample thresholds not met"]
                ),
                "population": {
                    "max_year": end,
                    "unclassified_primary_excluded_from_winner": True,
                },
            }
        )
    comparison(
        "natsec_intersection",
        "human-controlled:autonomous:impact>=4",
        Selection(numeric_min={"natsec_overall_score": 4}),
        Selection(equals={"natsec_autonomy_level": ["Human-controlled"]}, max_year=end),
        Selection(equals={"natsec_autonomy_level": ["Full autonomy"]}, max_year=end),
        config.group_contrast_materiality_pp,
    )
    return ledger


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--analysis-date", type=date.fromisoformat, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--config", type=Path, default=Path("config/analysis.json"))
    args = parser.parse_args()
    config = AnalysisConfig.model_validate_json(args.config.read_text())
    engine = Engine(
        load_incidents(args.input, args.analysis_date), config, args.analysis_date
    )
    facts = build_facts(engine)
    ledger = explore(engine)
    write_json(args.output / "facts.json", facts)
    write_json(args.output / "search_ledger.json", ledger)
    write_csv(args.output / "search_ledger.csv", ledger)
    engine.export(args.output)
    print(
        json.dumps(
            {
                "records": len(engine.rows),
                "comparisons": len(ledger),
                "eligible": sum(item["eligible"] for item in ledger),
                "annual": {
                    key: [
                        point
                        for point in value["points"]
                        if 2021 <= point["year"] <= 2025
                    ]
                    for key, value in facts["series"].items()
                },
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
