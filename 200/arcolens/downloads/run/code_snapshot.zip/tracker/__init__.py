"""Deterministic incident-tracker evidence pipeline."""

__version__ = "0.4.1"
