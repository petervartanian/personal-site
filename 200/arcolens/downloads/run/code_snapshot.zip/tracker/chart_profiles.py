"""Descriptive chart coverage; no trend inference or population-risk estimate."""

from __future__ import annotations

import json
from typing import Any

from .calc import Engine
from .models import Candidate, Selection

CATEGORIES = (
    "Technology",
    "Data Inputs",
    "Human Factors",
    "Process and Methods",
    "Regulatory Environment",
    "Management",
)
AXES = {
    "physical": "Physical security and critical infrastructure",
    "information": "Information warfare and intelligence security",
    "sovereignty": "Sovereignty and government functions",
    "economic": "Economic and technological security",
    "societal": "Societal stability and human rights",
}
EMPTY = {
    "",
    "n/a",
    "na",
    "none",
    "null",
    "unknown",
    "not applicable",
    "not specified",
    "not identified",
}


def cause_map(raw: str) -> dict[str, list[str]]:
    """Match documented payload wrappers; exclude explicit placeholders, fail closed."""
    root = json.loads(raw)
    if not isinstance(root, dict):
        raise ValueError("Ishikawa must be an object")
    for key in ("Ishikawa", "ishikawa", "ishikawa_diagram", "ishikawaDiagram"):
        if key in root:
            root = root[key]
            break
    if not isinstance(root, dict):
        raise ValueError("Ishikawa wrapper must be an object")
    if not any(k in root for k in CATEGORIES):
        nested = [
            v
            for v in root.values()
            if isinstance(v, dict) and any(k in v for k in CATEGORIES)
        ]
        if len(nested) != 1:
            raise ValueError("Unrecognized or ambiguous Ishikawa categories")
        root = nested[0]
    out: dict[str, list[str]] = {}
    for category in CATEGORIES:
        items = root.get(category)
        if not isinstance(items, list):
            raise ValueError(f"Missing or invalid category: {category}")
        labels = []
        for item in items:
            if isinstance(item, str):
                label = item.strip()
            elif isinstance(item, dict):
                label = next(
                    (
                        item[k].strip()
                        for k in ("Cause", "cause", "name", "title", "issue")
                        if isinstance(item.get(k), str) and item[k].strip()
                    ),
                    "",
                )
                if not label:
                    label = next(
                        (
                            item[k].strip()
                            for k in (
                                "Explanation",
                                "explanation",
                                "description",
                                "desc",
                                "detail",
                            )
                            if isinstance(item.get(k), str) and item[k].strip()
                        ),
                        "",
                    )
            else:
                raise ValueError("Unrecognized cause entry")
            if label.casefold() not in EMPTY:
                labels.append(label)
        out[category] = labels
    return out


def chart_profiles(engine: Engine) -> tuple[list[Candidate], dict[str, Any]]:
    """Rerun two declared descriptive profiles; retain exclusions and full evidence."""
    from .candidates import SHARED_CAVEATS, CHART_CAVEAT

    parsed = {}
    errors = {}
    for row in engine.rows:
        try:
            parsed[row.incident_id] = cause_map(row.raw.get("ishikawa", ""))
        except (ValueError, TypeError) as error:
            errors[row.incident_id] = str(error)
    evidence = []
    coverage = []
    for index, category in enumerate(CATEGORIES):
        ids = [key for key, value in parsed.items() if value[category]]
        measure = engine.fraction(
            f"profile.causes.category{index}", Selection(ids=ids), Selection()
        )
        coverage.append({"category": category, **measure.model_dump()})
        evidence.append(measure.calculation_id)
    complete = [
        key for key, value in parsed.items() if all(value[c] for c in CATEGORIES)
    ]
    all_six = engine.fraction(
        "profile.causes.all_six", Selection(ids=complete), Selection()
    )
    evidence.append(all_six.calculation_id)
    valid = engine.fraction(
        "profile.causes.parseable", Selection(ids=list(parsed)), Selection()
    )
    evidence.append(valid.calculation_id)
    exemplar = min(complete, key=int) if complete else None
    tech = coverage[0]
    management = coverage[-1]
    text = (
        (
            f"In the {engine.analysis_date.isoformat()} export, {all_six.numerator:,} of {all_six.denominator:,} records ({all_six.percent:.1f}%) have at least one non-placeholder potential-cause annotation in each of the six diagram categories. These are model-proposed explanations in a prompted framework, not six independently established causes per incident."
        )
        if all_six.denominator
        else "No records are available for this profile."
    )
    robustness = []
    for label, excluded in [
        ("Drop probable duplicate #353", ["353"]),
        ("Drop source-contaminated record #1607", ["1607"]),
    ]:
        result = engine.fraction(
            f"profile.causes.sensitivity{len(robustness)}",
            Selection(ids=complete),
            Selection(exclude_ids=excluded),
        )
        evidence.append(result.calculation_id)
        robustness.append({"alternative": label, **result.model_dump()})
    cause_candidate = Candidate(
        candidate_id="IT-P001",
        title="Potential-cause annotations span six categories",
        finding=text,
        chart_ids=["C06"],
        evidence_ids=evidence,
        chart_configuration={
            "primary_chart": "C06",
            "stacking_category": "None; six qualitative branches",
            "filters": {"incident_id": exemplar},
            "date_range": "All dates in the supplied export; no time comparison",
            "setting": "Potential Causes in the incident detail; counts and proportions do not apply to the diagram",
            "compatibility": f"The diagram can illustrate record #{exemplar}; the aggregate six-category coverage requires the attached table. Ignore N/A placeholders. The live mirror may contain different annotations.",
            "verification": CHART_CAVEAT,
            "supporting_table": coverage,
            "example_annotations": parsed.get(exemplar, {}),
        },
        eligibility={
            "passed": bool(exemplar) and not errors,
            "rule": "Declared descriptive annotation coverage, separate from comparative trend discovery",
            "parseable_records": len(parsed),
            "unparseable_records": len(errors),
            "denominator": "All export records; unparseable records are not silently removed",
            "example_selection": "Lowest incident ID with a non-placeholder annotation in every category; illustration, not representative sampling",
        },
        calculation_confidence="High for counts of non-placeholder annotations in the supplied structured field; schema failures withhold the candidate.",
        interpretation_confidence="Low for real causes. This measures annotation coverage within a model-prompted six-category structure.",
        caveats=SHARED_CAVEATS
        + [
            "The historical RCA prompt asks for six categories, up to three causes each, and N/A placeholders. That structure can produce widespread multi-category coverage without independently verifying the explanations.",
            "The parser excludes explicit empty and N/A labels, but does not independently establish that each remaining explanation is valid.",
            "A record can contribute to all six categories. Category percentages overlap and must not be added.",
            "The diagram is qualitative; category frequency is not a ranking of causal importance.",
        ],
        robustness=robustness,
        proposed_website_text=text,
        review_state="human_review_required" if exemplar and not errors else "withheld",
        selection_stage="chart_profile",
    )
    natsec_rows = []
    natsec_evidence = []
    for threshold in (3, 4, 5):
        pop = Selection(numeric_min={"natsec_overall_score": threshold})
        for axis, label in AXES.items():
            result = engine.fraction(
                f"profile.natsec.threshold{threshold}.{axis}",
                Selection(numeric_min={f"natsec_{axis}_score": threshold}),
                pop,
            )
            natsec_rows.append(
                {
                    "threshold": threshold,
                    "axis": axis,
                    "label": label,
                    **result.model_dump(),
                }
            )
            natsec_evidence.append(result.calculation_id)
    base = [r for r in natsec_rows if r["threshold"] == 4]
    ranked = sorted(base, key=lambda r: (-r["numerator"], r["axis"]))
    leader = ranked[0]
    runner = ranked[1]
    field = f"natsec_{leader['axis']}_score"
    cohort = [
        r for r in engine.rows if int(r.raw.get("natsec_overall_score") or 0) >= 4
    ]
    illustrative = [
        r
        for r in cohort
        if int(r.raw[field] or 0) == 4 and int(r.raw["natsec_overall_score"]) == 4
    ]
    ex = min(illustrative, key=lambda r: int(r.incident_id)) if illustrative else None
    text = f"Among the {leader['denominator']} records assigned an overall national-security score of at least 4 in the {engine.analysis_date.isoformat()} export, {leader['numerator']} have a score of at least 4 for {leader['label'].lower()}, compared with {runner['numerator']} for {runner['label'].lower()}. These are overlapping model-assigned categories within a small selected group, not estimates of national-security risk."
    robustness = []
    for threshold in (3, 5):
        points = [r for r in natsec_rows if r["threshold"] == threshold]
        robustness.append(
            {
                "alternative": f"Change both overall and axis threshold to {threshold}",
                "points": points,
                "display_unit": "counts",
            }
        )
    for label, pop in [
        (
            "Exclude partial current year",
            Selection(
                numeric_min={"natsec_overall_score": 4},
                max_year=engine.analysis_date.year - 1,
            ),
        ),
        (
            "Exclude probable duplicate and source-contaminated record",
            Selection(
                numeric_min={"natsec_overall_score": 4}, exclude_ids=["353", "1607"]
            ),
        ),
    ]:
        points = []
        for axis, label_axis in AXES.items():
            result = engine.fraction(
                f"profile.natsec.sensitivity{len(robustness)}.{axis}",
                Selection(numeric_min={f"natsec_{axis}_score": 4}),
                pop,
            )
            points.append({"label": label_axis, **result.model_dump()})
            natsec_evidence.append(result.calculation_id)
        robustness.append(
            {"alternative": label, "points": points, "display_unit": "counts"}
        )
    inconsistent = [
        r.incident_id
        for r in engine.rows
        if int(r.raw.get("natsec_overall_score") or 0)
        != max(int(r.raw.get(f"natsec_{axis}_score") or 0) for axis in AXES)
    ]
    strict_rows = [r for r in natsec_rows if r["threshold"] == 5]
    strict_max = max(r["numerator"] for r in strict_rows)
    strict_leaders = [r["label"] for r in strict_rows if r["numerator"] == strict_max]
    strict_note = f"At threshold 5, {strict_rows[0]['denominator']} records qualify; the leading category or categories are {', '.join(strict_leaders)}. Category ordering is threshold-dependent and must be reviewed for this export."
    ns_candidate = Candidate(
        candidate_id="IT-P002",
        title=(
            "Information-security scores within the high-score group"
            if leader["axis"] == "information"
            else f"{leader['label']} in the high-score group"
        ),
        finding=text,
        chart_ids=["C07"],
        evidence_ids=natsec_evidence,
        chart_configuration={
            "primary_chart": "C07",
            "stacking_category": "None; five separate impact ratings",
            "filters": {
                "overall_national_security_score_min": 4,
                "incident_id": ex.incident_id if ex else None,
            },
            "date_range": "All dates in the supplied export; partial-year records included only in this snapshot description",
            "setting": "Choose an incident in the national-security listing and open its five-axis radar; ordinal scores 1–5, no counts/proportions toggle",
            "compatibility": "The radar illustrates one record, not the aggregate count comparison. Use the attached five-category table for that comparison. The live mirror can differ from this export.",
            "verification": CHART_CAVEAT,
            "supporting_table": base,
            "example_profile": (
                {axis: ex.raw[f"natsec_{axis}_score"] for axis in AXES} if ex else {}
            ),
        },
        eligibility={
            "passed": bool(ex) and not inconsistent,
            "rule": "Descriptive small-cohort profile; not eligible for inferential claims or annual trend discovery",
            "cohort_records": len(cohort),
            "original_comparison_minimum_unchanged": engine.config.min_comparison_denominator,
            "overall_max_mismatch_ids": inconsistent,
            "example_selection": "Lowest ID whose overall score and leading-axis score both equal 4; illustrative only",
        },
        calculation_confidence="High for recorded scores, distinct IDs and threshold membership; missing scores never count as reaching a threshold.",
        interpretation_confidence="Limited to the supplied model labels. Small, selectively reported cohort. "
        + strict_note,
        caveats=SHARED_CAVEATS
        + [
            "Categories overlap: the same record can reach the threshold on multiple axes.",
            strict_note,
            "Ratings are ordinal, and radar area is not a quantitative measure of risk. The overall score is the maximum axis score.",
            "Prior small-sample validation does not establish current national-security label accuracy. No annual trend is inferred from this profile.",
        ],
        robustness=robustness,
        proposed_website_text=text,
        review_state="human_review_required" if ex and not inconsistent else "withheld",
        selection_stage="chart_profile",
    )
    return [cause_candidate, ns_candidate], {
        "method_version": "chart-profiles.v1",
        "source": "Supplied export only",
        "causes_parse_errors": errors,
        "cause_coverage": coverage,
        "all_six": all_six.model_dump(),
        "national_security_thresholds": natsec_rows,
        "overall_max_mismatch_ids": inconsistent,
        "note": "Added to cover qualitative and individual-profile charts; separate from discovery ranking, no lowered trend thresholds.",
    }
