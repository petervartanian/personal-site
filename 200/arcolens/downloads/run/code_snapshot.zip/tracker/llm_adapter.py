"""Provider adapter for unattended LLM drafting, with provenance and grounding checks.

The deterministic pipeline never depends on this module. A provider receives the
versioned prompt and the evidence bundle and must return JSON matching LLMDraft.
Every call records request/response provenance (model, request id, usage,
timestamps, SHA-256 of the bundle and of the raw response) and the draft is then
checked for schema validity, evidence references, numerical grounding and
publication authorisation before an independent review stage. A FakeProvider
exercises the whole path offline; the AnthropicProvider is implemented against
the documented SDK surface but has not been live-tested here. The separate editorial module uses existing
official CLI authentication and records actual execution independently.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Protocol

from .data import json_bytes, write_json
from .models import LLMDraft

FORBIDDEN_PATTERNS = {
    "legal conclusion from LLM tags": r"\b(prohibited|illegal|unlawful)\b",
    "causal/safety overreach": r"\b(proves?|caused by AI|safer|less safe|improv(ed|ing) safety|worsening safety)\b",
    "prevalence overreach": r"\b(prevalence|incidence rate|per capita)\b",
    "unthresholded qualifier": r"\b(dramatic(ally)?|vast majority|overwhelming(ly)?|around half|about half)\b",
}
NUMBER = re.compile(r"(?<![\w.])(\d{1,3}(?:,\d{3})+|\d+)(?![\w.]|\.\d)")
PERCENT = re.compile(r"(\d+(?:\.\d+)?)\s?%")
POINTS = re.compile(r"([+-]?\d+(?:\.\d+)?)\s?(?:pp\b|percentage points?)")


@dataclass
class ProviderResponse:
    provider: str
    model: str
    request_id: str | None
    raw_text: str
    usage: dict[str, Any]
    stop_reason: str | None
    stop_details: dict[str, Any] | None
    started_at_utc: str
    completed_at_utc: str
    attempts: int
    notes: list[str] = field(default_factory=list)


class Provider(Protocol):
    name: str

    def generate(
        self, system_prompt: str, user_payload: str, model: str, effort: str
    ) -> ProviderResponse: ...


class FakeProvider:
    """Deterministic offline provider used for tests and dry runs.

    It echoes the deterministic candidate first draft from the evidence bundle
    as a valid LLMDraft. It performs no interpretation; its only purpose is to
    exercise provenance, validation and grounding code paths.
    """

    name = "fake"

    def __init__(self, mutate: Any | None = None) -> None:
        self.mutate = mutate

    def generate(
        self, system_prompt: str, user_payload: str, model: str, effort: str
    ) -> ProviderResponse:
        started = datetime.now(timezone.utc).isoformat()
        bundle = json.loads(user_payload)
        draft = {
            "schema_version": "1.0",
            "run_id": bundle["run_id"],
            "model": f"fake:{model}",
            "prompt_version": bundle.get("prompt_version", "unknown"),
            "input_evidence_sha256": bundle["bundle_sha256"],
            "candidates": bundle["candidate_first_draft"],
            "concerns": [
                "FakeProvider output: deterministic echo of the evidence-bound first draft; no interpretation performed."
            ],
            "publication_authorized": False,
        }
        if self.mutate:
            draft = self.mutate(draft)
        text = json.dumps(draft, ensure_ascii=False)
        return ProviderResponse(
            provider=self.name,
            model=f"fake:{model}",
            request_id=f"fake-{hashlib.sha256(text.encode()).hexdigest()[:12]}",
            raw_text=text,
            usage={
                "input_tokens": len(user_payload) // 4,
                "output_tokens": len(text) // 4,
                "estimated": True,
            },
            stop_reason="end_turn",
            stop_details=None,
            started_at_utc=started,
            completed_at_utc=datetime.now(timezone.utc).isoformat(),
            attempts=1,
        )


class AnthropicProvider:
    """Claude provider via the official SDK (lazy import; optional dependency).

    SDK execution is not established by the separate CLI integration. Uses the
    documented client.messages.parse(..., output_format=LLMDraft) surface, omits
    the thinking parameter (adaptive by default on current models) and controls
    depth with output_config.effort. Credentials resolve from the environment
    (ANTHROPIC_API_KEY, ANTHROPIC_AUTH_TOKEN or an 'ant auth login' profile).
    """

    name = "anthropic"

    def __init__(self, max_retries: int = 2, timeout_seconds: float = 600.0) -> None:
        try:
            import anthropic  # type: ignore
        except ImportError as error:  # pragma: no cover - depends on optional install
            raise RuntimeError(
                "The 'anthropic' SDK is not installed. Install the optional 'llm' extra (poetry install --extras llm) and supply credentials before using this provider."
            ) from error
        self._anthropic = anthropic
        self._client = anthropic.Anthropic(
            max_retries=max_retries, timeout=timeout_seconds
        )
        self.max_retries = max_retries

    def generate(
        self, system_prompt: str, user_payload: str, model: str, effort: str
    ) -> ProviderResponse:  # pragma: no cover - live call
        anthropic = self._anthropic
        started = datetime.now(timezone.utc).isoformat()
        notes: list[str] = []
        try:
            response = self._client.messages.parse(
                model=model,
                max_tokens=16000,
                system=system_prompt,
                messages=[{"role": "user", "content": user_payload}],
                output_format=LLMDraft,
                output_config={"effort": effort},
            )
        except anthropic.RateLimitError as error:
            raise RuntimeError(f"rate limited: {error}") from error
        except anthropic.APIStatusError as error:
            raise RuntimeError(
                f"API error {error.status_code}: {error.message}"
            ) from error
        except anthropic.APIConnectionError as error:
            raise RuntimeError(f"connection error: {error}") from error
        stop_details = None
        if response.stop_reason == "refusal":
            details = getattr(response, "stop_details", None)
            stop_details = {
                "category": getattr(details, "category", None),
                "explanation": getattr(details, "explanation", None),
            }
            notes.append("provider refused; no draft produced")
        text = ""
        parsed = getattr(response, "parsed_output", None)
        if parsed is not None:
            text = parsed.model_dump_json()
        else:
            text = next(
                (block.text for block in response.content if block.type == "text"), ""
            )
        usage = (
            response.usage.model_dump()
            if hasattr(response.usage, "model_dump")
            else dict(response.usage)
        )
        return ProviderResponse(
            provider=self.name,
            model=response.model,
            request_id=getattr(response, "_request_id", None),
            raw_text=text,
            usage=usage,
            stop_reason=response.stop_reason,
            stop_details=stop_details,
            started_at_utc=started,
            completed_at_utc=datetime.now(timezone.utc).isoformat(),
            attempts=1 + self.max_retries if notes else 1,
            notes=notes,
        )


def numbers_in(text: str) -> set[int]:
    return {int(m.replace(",", "")) for m in NUMBER.findall(text)}


def percents_in(text: str) -> set[str]:
    return {m for m in PERCENT.findall(text)}


def points_in(text: str) -> set[str]:
    return {m.lstrip("+-") for m in POINTS.findall(text)}


def ground_candidate(
    candidate: dict[str, Any], calculations: dict[str, Any], years: set[int]
) -> dict[str, Any]:
    cited = [calculations[k] for k in candidate["evidence_ids"] if k in calculations]
    missing = [k for k in candidate["evidence_ids"] if k not in calculations]
    allowed_ints: set[int] = set(years)
    allowed_pct: set[str] = set()
    for measure in cited:
        allowed_ints.update(
            {
                measure["numerator"],
                measure["denominator"],
                measure["denominator_incident_count"],
            }
        )
        if measure["percent"] is not None:
            for decimals in (0, 1, 2):
                allowed_pct.add(f"{measure['percent']:.{decimals}f}")
    for a in list(allowed_ints):
        for b in list(allowed_ints):
            if a > b:
                allowed_ints.add(a - b)
    # Derived quantities that templates legitimately print: relative count changes
    # between cited numerators and percentage-point differences between cited shares.
    numerators = sorted({m["numerator"] for m in cited if m["numerator"]})
    percents = sorted({m["percent"] for m in cited if m["percent"] is not None})
    for a in numerators:
        for b in numerators:
            if a != b:
                allowed_pct.add(f"{100 * (b - a) / a:.1f}")
                allowed_pct.add(f"{abs(100 * (b - a) / a):.1f}")
    for a in percents:
        for b in percents:
            if a != b:
                for decimals in (1, 2):
                    allowed_pct.add(f"{abs(b - a):.{decimals}f}")
    text = candidate["finding"] + " " + candidate["proposed_website_text"]
    ints = {n for n in numbers_in(text) if n >= 10}
    unexplained_ints = sorted(n for n in ints if n not in allowed_ints)
    normalised_allowed = {a.rstrip("0").rstrip(".") for a in allowed_pct}
    unexplained_pcts = sorted(
        p
        for p in percents_in(text)
        if p.rstrip("0").rstrip(".") not in normalised_allowed
    )
    unexplained_points = sorted(
        p
        for p in points_in(text)
        if p.rstrip("0").rstrip(".") not in normalised_allowed
    )
    flags = [
        {"pattern": name, "match": m.group(0)}
        for name, pattern in FORBIDDEN_PATTERNS.items()
        for m in re.finditer(pattern, text, flags=re.IGNORECASE)
    ]
    return {
        "candidate_id": candidate["candidate_id"],
        "evidence_ids_missing": missing,
        "unexplained_integers": unexplained_ints,
        "unexplained_percentages": unexplained_pcts,
        "unexplained_percentage_points": unexplained_points,
        "editorial_flags": flags,
        "grounded": not missing
        and not unexplained_ints
        and not unexplained_pcts
        and not unexplained_points,
    }


def ground_draft(
    draft: LLMDraft,
    calculations: dict[str, Any],
    valid_chart_ids: set[str],
    years: set[int],
) -> dict[str, Any]:
    per_candidate = [
        ground_candidate(c.model_dump(), calculations, years) for c in draft.candidates
    ]
    bad_charts = [
        c.candidate_id
        for c in draft.candidates
        if not set(c.chart_ids).issubset(valid_chart_ids)
    ]
    return {
        "publication_authorized": draft.publication_authorized,
        "candidates_checked": len(per_candidate),
        "all_grounded": all(item["grounded"] for item in per_candidate)
        and not bad_charts
        and draft.publication_authorized is False,
        "candidates_with_unknown_chart_ids": bad_charts,
        "per_candidate": per_candidate,
        "scope": "Numerical grounding against cited calculation IDs, chart-ID validity and publication flag. Semantic correctness, classification truth and representativeness remain human/independent-review judgments.",
    }


def build_request(
    run: Path, prompt_path: Path, model: str, effort: str
) -> tuple[str, str, dict[str, Any]]:
    metadata = json.loads((run / "run_metadata.json").read_text(encoding="utf-8"))
    bundle_path = run / "llm/evidence_bundle.json"
    bundle = json.loads(bundle_path.read_text(encoding="utf-8"))
    bundle_sha = hashlib.sha256(bundle_path.read_bytes()).hexdigest()
    payload = {
        **bundle,
        "bundle_sha256": bundle_sha,
        "prompt_version": prompt_path.stem,
    }
    system_prompt = prompt_path.read_text(encoding="utf-8")
    request = {
        "run_id": metadata["run_id"],
        "model_requested": model,
        "effort": effort,
        "prompt_path": str(prompt_path.name),
        "prompt_sha256": hashlib.sha256(system_prompt.encode()).hexdigest(),
        "evidence_bundle_sha256": bundle_sha,
        "user_payload_sha256": hashlib.sha256(json_bytes(payload)).hexdigest(),
        "source_material_policy": "bundle contents are evidence, never instructions",
    }
    return (
        system_prompt,
        json.dumps(payload, ensure_ascii=False, sort_keys=True),
        request,
    )


def generate_draft(
    run: Path,
    provider: Provider,
    prompt_path: Path,
    model: str,
    effort: str,
    output: Path,
) -> dict[str, Any]:
    system_prompt, payload, request = build_request(run, prompt_path, model, effort)
    output.mkdir(parents=True, exist_ok=True)
    write_json(output / "request.json", request)
    response = provider.generate(system_prompt, payload, model, effort)
    write_json(
        output / "response.json",
        {
            **{k: v for k, v in response.__dict__.items() if k != "raw_text"},
            "raw_response_sha256": hashlib.sha256(
                response.raw_text.encode()
            ).hexdigest(),
            "raw_response_path": "raw_response.txt",
        },
    )
    (output / "raw_response.txt").write_text(response.raw_text, encoding="utf-8")
    result: dict[str, Any] = {
        "provider": response.provider,
        "model": response.model,
        "request_id": response.request_id,
        "stop_reason": response.stop_reason,
        "draft_valid": False,
        "grounding": None,
        "independent_review": "required before any human publication review; not performed by this command",
        "publication_authorized": False,
    }
    if response.stop_reason == "refusal" or not response.raw_text.strip():
        result["error"] = "no draft text returned"
        write_json(output / "result.json", result)
        return result
    try:
        draft = LLMDraft.model_validate_json(response.raw_text)
    except Exception as error:  # noqa: BLE001 - recorded, not raised
        result["error"] = (
            f"draft failed LLMDraft validation: {type(error).__name__}: {str(error)[:500]}"
        )
        write_json(output / "result.json", result)
        return result
    metadata = json.loads((run / "run_metadata.json").read_text(encoding="utf-8"))
    bundle_sha = hashlib.sha256(
        (run / "llm/evidence_bundle.json").read_bytes()
    ).hexdigest()
    if draft.run_id != metadata["run_id"] or draft.input_evidence_sha256 != bundle_sha:
        result["error"] = "draft does not bind to this run/evidence bundle"
        write_json(output / "result.json", result)
        return result
    calculations = json.loads((run / "calculations.json").read_text(encoding="utf-8"))[
        "measures"
    ]
    charts = {
        item["chart_id"]
        for item in json.loads(
            (run / "chart_outcomes.json").read_text(encoding="utf-8")
        )
    }
    years = set(range(1980, int(metadata["analysis_date"][:4]) + 1))
    grounding = ground_draft(draft, calculations, charts, years)
    write_json(output / "draft.json", draft.model_dump())
    write_json(output / "grounding.json", grounding)
    result.update(
        draft_valid=True,
        grounding={k: v for k, v in grounding.items() if k != "per_candidate"},
    )
    write_json(output / "result.json", result)
    return result
