"""Compare a genuine legacy tracker export on explicitly mapped common fields.

The old file is not padded into the modern ingestion schema. Snapshot differences
combine additions, source revisions, dating, taxonomy and classifier changes.
"""

from __future__ import annotations

import argparse
import ast
import csv
import hashlib
import json
import re
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from pydantic import BaseModel, ConfigDict

BASE_MAP = {
    "Date": "date",
    "Domain": "domain_code",
    "Subdomain": "subdomain_code",
    "Entity": "causal_entity",
    "Intent": "causal_intent",
    "Timing": "causal_timing",
    "EU AI Act Risk Classification": "eu_ai_act_risk_level",
    "AI_Goal_Primary": "ai_goal_primary",
    "AI_Goal_Secondary": "ai_goal_secondary",
    "Behaviour Type": "behaviour_type",
    "NatSec_Overall_Score": "natsec_overall_score",
    "NatSec_Autonomy_Level": "natsec_autonomy_level",
    "NatSec_Imminence_Level": "natsec_imminence_level",
    "NatSec_Novelty_Level": "natsec_novelty_level",
}
HARM_MAP = {
    "Physical": "physical_harm",
    "Infrastructure": "infrastructure_damage",
    "Property": "property_damage",
    "Financial": "financial_loss",
    "Environmental": "environmental_damage",
    "Malicious_Content": "toxic_or_malicious_content",
    "Differential_Treatment": "differential_treatment",
    "Civil_Rights": "human_and_civil_rights",
    "Democracy": "democratic_norms",
    "Privacy": "privacy",
}
FIELD_MAP = {
    **BASE_MAP,
    **{
        f"{a}_Severity_{ch.title()}": f"{b}_severity_{ch}"
        for a, b in HARM_MAP.items()
        for ch in ("direct", "indirect", "inferred")
    },
    **{
        f"NatSec_{a.title()}_Score": f"natsec_{a}_score"
        for a in ("physical", "information", "sovereignty", "economic", "societal")
    },
}
CODE_FIELDS = {"domain_code", "subdomain_code", "eu_ai_act_risk_level"}


class Comparison(BaseModel):
    model_config = ConfigDict(extra="forbid")
    schema_version: str = "legacy-comparison.v1"
    sources: dict[str, Any]
    counts: dict[str, int]
    fields: dict[str, Any]
    candidate_replays: dict[str, Any]
    added_ids: list[str]
    removed_ids: list[str]
    limits: list[str]


def load(path: Path, id_field: str) -> dict[str, dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    result = {}
    for row in rows:
        identifier = row[id_field].strip()
        if not re.fullmatch(r"[0-9]+", identifier):
            raise ValueError(f"Invalid ID {identifier!r}")
        identifier = str(int(identifier))
        if identifier in result:
            raise ValueError(f"Duplicate ID {identifier}")
        result[identifier] = row
    return result


def normalize(value: str, field: str, legacy: bool = False) -> str:
    value = value.strip()
    if field == "date" and value:
        parsed = (
            datetime.strptime(value, "%d/%m/%Y")
            if legacy
            else datetime.fromisoformat(value.replace("Z", "+00:00"))
        )
        return parsed.date().isoformat()
    if field in CODE_FIELDS and value:
        match = re.match(r"^([0-9]+(?:\.[0-9]+)?)(?:\s|$)", value)
        if not match:
            raise ValueError(f"Invalid code {field}: {value}")
        return match[1]
    return value


def fingerprint(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def compare(old_path: Path, new_path: Path) -> tuple[Comparison, list[dict[str, str]]]:
    old = load(old_path, "incident_id")
    new = load(new_path, "aiid_id")
    common = sorted(old.keys() & new.keys(), key=int)
    changes = []
    fields = {}
    for a, b in FIELD_MAP.items():
        if any(a not in r for r in old.values()) or any(
            b not in r for r in new.values()
        ):
            raise ValueError(f"Missing mapped field {a} or {b}")
        changed = []
        for identifier in common:
            x = normalize(old[identifier][a], b, True)
            y = normalize(new[identifier][b], b)
            if x != y:
                changed.append(identifier)
                changes.append(
                    {"incident_id": identifier, "field": b, "before": x, "after": y}
                )
        fields[b] = {
            "legacy_field": a,
            "common_records": len(common),
            "changed": len(changed),
            "changed_ids": changed,
        }

    def stats(
        rows: dict[str, dict[str, str]], legacy: bool, ids: list[str] | None = None
    ) -> dict:
        reverse = {v: k for k, v in FIELD_MAP.items()}
        selected = [rows[i] for i in ids] if ids is not None else list(rows.values())

        def cell(row, field):
            return normalize(row[reverse[field] if legacy else field], field, legacy)

        annual = []
        for year in range(2021, 2026):
            cohort = [r for r in selected if cell(r, "date").startswith(str(year))]
            numerator = sum(cell(r, "subdomain_code") == "7.3" for r in cohort)
            annual.append(
                {
                    "year": year,
                    "numerator": numerator,
                    "denominator": len(cohort),
                    "percent": 100 * numerator / len(cohort) if cohort else None,
                }
            )
        return {
            "records": len(selected),
            "capability_by_incident_year": annual,
            "primary_purposes": dict(
                Counter(cell(r, "ai_goal_primary") for r in selected)
            ),
            "eu_tiers": dict(
                Counter(cell(r, "eu_ai_act_risk_level") for r in selected)
            ),
            "natsec_at_least_4": sum(
                int(cell(r, "natsec_overall_score") or 0) >= 4 for r in selected
            ),
        }

    classifier_models = Counter()
    for row in old.values():
        try:
            classifier_models[
                ast.literal_eval(row["API_Info"]).get("model", "unknown")
            ] += 1
        except (ValueError, SyntaxError, AttributeError):
            classifier_models["unparseable"] += 1
    result = Comparison(
        sources={
            "legacy": {
                "filename": old_path.name,
                "sha256": fingerprint(old_path),
                "drive_file_id": "1wi942r9oFVL2RKdP1OCZ2pyehHH13AWQ",
                "drive_modified_time": "2025-10-07T10:35:20Z",
                "snapshot_date": "Not independently authenticated; original filename preserved",
                "classifier_models_from_API_Info": dict(classifier_models),
            },
            "current": {"filename": new_path.name, "sha256": fingerprint(new_path)},
            "created_at_utc": datetime.now(timezone.utc).isoformat(),
        },
        counts={
            "legacy": len(old),
            "current": len(new),
            "common": len(common),
            "added": len(new.keys() - old.keys()),
            "removed": len(old.keys() - new.keys()),
            "mapped_fields": len(FIELD_MAP),
        },
        fields=fields,
        candidate_replays={
            "legacy_all": stats(old, True),
            "current_all": stats(new, False),
            "legacy_common": stats(old, True, common),
            "current_common": stats(new, False, common),
        },
        added_ids=sorted(new.keys() - old.keys(), key=int),
        removed_ids=sorted(old.keys() - new.keys(), key=int),
        limits=[
            "This is a genuine older shared tracker export, not verified as an export from the current Arcola classification pipeline. It tests real historical differences, not same-version month-to-month stability.",
            "A common-field projection is used. Ishikawa, additional subdomains, added harm dimensions and current classifier metadata are unavailable in the legacy schema; none are invented.",
            "Model Name in the legacy file names the incident system, not the classifier. Classifier provenance comes from API_Info.",
            "Changes to shared-record tags do not establish errors or improvements; source text, prompts, models and taxonomy can all differ.",
            "The historic filename date is not treated as authenticated collection time. Do not interpret newly present records as newly occurred incidents, or compare incomplete incident-year cohorts as full-year trends.",
        ],
    )
    return result, changes


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--old", type=Path, required=True)
    parser.add_argument("--new", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result, changes = compare(args.old, args.new)
    args.output.mkdir(parents=True, exist_ok=False)
    (args.output / "comparison.json").write_text(
        result.model_dump_json(indent=2) + "\n"
    )
    with (args.output / "changed_fields.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(
            handle, fieldnames=["incident_id", "field", "before", "after"]
        )
        writer.writeheader()
        writer.writerows(changes)
    lines = [
        "# Historical export comparison",
        "",
        f"{result.counts['legacy']:,} legacy records and {result.counts['current']:,} current records; {result.counts['common']:,} shared IDs, {result.counts['added']} added IDs, {result.counts['removed']} removed IDs.",
        "",
        "| Common field | Changed shared records |",
        "|---|---:|",
    ]
    lines += [
        f'| {k} | {v["changed"]}/{v["common_records"]} |'
        for k, v in result.fields.items()
    ]
    lines += ["", "## Interpretation", ""] + ["- " + s for s in result.limits]
    (args.output / "COMPARISON.md").write_text("\n".join(lines) + "\n")
    print(json.dumps(result.counts))


if __name__ == "__main__":
    main()
