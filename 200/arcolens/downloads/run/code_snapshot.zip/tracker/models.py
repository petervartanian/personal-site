"""Validated contracts shared by deterministic analysis and editorial review."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)


class AnalysisConfig(StrictModel):
    schema_version: str
    analysis_version: str
    definitions_version: str
    cadence: Literal["monthly", "fortnightly"]
    complete_year_window: int = Field(ge=2)
    min_comparison_denominator: int = Field(ge=1)
    min_category_count: int = Field(ge=1)
    share_change_materiality_pp: float = Field(gt=0)
    group_contrast_materiality_pp: float = Field(gt=0)
    count_change_materiality_absolute: int = Field(ge=1)
    count_change_materiality_relative_pct: float = Field(gt=0)
    concentration_min_share_pct: float = Field(ge=0, le=100)
    max_shortlisted_candidates: int = Field(ge=1)
    unknown_values: list[str]
    other_is_unknown_for_sensitivity_only: list[str]
    strict_generation_purposes: list[str]
    expanded_generation_purposes: list[str]
    probable_duplicate_sensitivity_drop_ids: list[str]
    llm_mode: str
    llm_model: str
    generation_prompt_version: str
    review_prompt_version: str
    report_style_version: str

    @model_validator(mode="after")
    def llm_identity_is_current(self) -> AnalysisConfig:
        major, minor = (int(part) for part in self.analysis_version.split(".")[:2])
        if (major, minor) >= (0, 2) and "gpt-6-astra" in self.llm_model:
            raise ValueError(
                "analysis_version >= 0.2 must not attribute wording to the first-session model string"
            )
        return self


class SeveritySpec(StrictModel):
    dimensions: Literal[10, 13] = 10
    channels: list[Literal["direct", "indirect", "inferred"]] = Field(
        default_factory=lambda: ["direct", "indirect"], min_length=1
    )
    threshold: int = Field(default=4, ge=1, le=5)
    categories: list[str] | None = None
    minimum_categories: int = Field(default=1, ge=1)
    missing_policy: Literal["lower_bound", "upper_bound", "complete_only"] = (
        "lower_bound"
    )

    @model_validator(mode="after")
    def categories_are_distinct(self) -> SeveritySpec:
        if self.categories is not None and len(set(self.categories)) != len(
            self.categories
        ):
            raise ValueError(
                "Duplicate harm categories would double-count toward minimum_categories"
            )
        return self


class Selection(StrictModel):
    """All conditions are conjoined; values within one field are ORed."""

    years: list[int] | None = None
    min_year: int | None = None
    max_year: int | None = None
    equals: dict[str, list[str]] = Field(default_factory=dict)
    subdomains: list[str] | None = None
    domains: list[str] | None = None
    classification: Literal["primary", "any"] = "primary"
    purposes: list[str] | None = None
    purpose_scope: Literal["primary", "primary_or_secondary"] = "primary"
    known_fields: list[str] = Field(default_factory=list)
    exclude_other: bool = False
    exclude_ids: list[str] = Field(default_factory=list)
    ids: list[str] | None = None
    severity: SeveritySpec | None = None
    numeric_min: dict[str, float] = Field(default_factory=dict)
    numeric_gt: dict[str, float] = Field(default_factory=dict)
    identity_contains: dict[str, list[str]] = Field(default_factory=dict)


class Calculation(StrictModel):
    population: Selection = Field(default_factory=Selection)
    target: Selection = Field(default_factory=Selection)
    denominator: Literal["incidents", "subdomain_assignments"] = "incidents"
    description: str

    @model_validator(mode="after")
    def assignment_target_is_singleton(self) -> Calculation:
        if self.denominator == "subdomain_assignments":
            if (
                self.target.classification != "any"
                or len(self.target.subdomains or []) != 1
            ):
                raise ValueError(
                    "Assignment shares require exactly one any-label subdomain; composite assignment numerators are not implemented"
                )
        return self


class Measure(StrictModel):
    calculation_id: str
    definition: Calculation
    numerator: int = Field(ge=0)
    denominator: int = Field(ge=0)
    percent: float | None
    numerator_ids_ref: str
    denominator_ids_ref: str
    denominator_incident_count: int = Field(ge=0)
    numerator_incident_count: int = Field(ge=0)
    window: dict[str, Any]

    @model_validator(mode="after")
    def coherent_fraction(self) -> Measure:
        if self.numerator > self.denominator:
            raise ValueError("Numerator exceeds denominator")
        expected = 100 * self.numerator / self.denominator if self.denominator else None
        if self.percent != expected:
            raise ValueError("Percentage is not the executable fraction")
        if self.numerator != self.numerator_incident_count:
            raise ValueError("This measure's numerator must count distinct incidents")
        if self.definition.denominator == "incidents":
            if self.denominator != self.denominator_incident_count:
                raise ValueError("Incident denominator incorrectly counts assignments")
        return self


AuditStatus = Literal[
    "Supported",
    "Needs a numerical or wording update",
    "Unsupported under the stated interpretation",
    "Not verifiable with the available data or an ambiguous definition",
]


class AuditRecord(StrictModel):
    claim_id: str
    exact_wording: str
    source_url: str
    retrieval_date_utc: str
    retrieved_at_utc: str
    quote_sha256: str
    source_snapshot: dict[str, Any]
    publication_status: str
    empirical: bool
    interpretation: str
    original_time_window: str
    status: AuditStatus
    evidence_ids: list[str]
    component_checks: list[dict[str, Any]]
    reason: str
    proposed_revision: str | None
    editorial_flags: list[str]
    calculation_definition: dict[str, Any]
    discrepancy_explanation: str | None = None


class Candidate(StrictModel):
    candidate_id: str
    title: str
    finding: str
    chart_ids: list[str]
    evidence_ids: list[str]
    chart_configuration: dict[str, Any]
    eligibility: dict[str, Any]
    calculation_confidence: str
    interpretation_confidence: str
    caveats: list[str]
    robustness: list[dict[str, Any]]
    proposed_website_text: str
    review_state: Literal["human_review_required", "withheld"]
    selection_stage: Literal[
        "session_template", "data_driven_discovery", "chart_profile"
    ] = "session_template"


class LLMDraft(StrictModel):
    """Provider-independent review artifact; an LLM cannot change calculations."""

    schema_version: Literal["1.0"]
    run_id: str
    model: str
    prompt_version: str
    input_evidence_sha256: str
    candidates: list[Candidate]
    concerns: list[str]
    publication_authorized: Literal[False] = False
