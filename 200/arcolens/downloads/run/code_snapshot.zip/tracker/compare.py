"""Cross-export comparison: what changed between two incident exports.

The comparison is descriptive bookkeeping over incident records: which IDs were
added or removed, which shared records changed classification or date, and how
annual cohorts changed (added records dated in earlier years indicate backfill
or delayed reporting; they are not new events). It never infers why a value
changed, and synthetic inputs used for testing must never be presented as
historical observations.
"""

from __future__ import annotations

import json
from collections import Counter
from datetime import date
from pathlib import Path
from typing import Any

from .data import Incident, load_incidents, sha256_file, sorted_ids, write_json

SYNTHETIC_MODEL_NAMES = {"synthetic-model", "test-model"}
SYNTHETIC_TITLE_PREFIXES = (
    "SYNTHETIC",
    "Incident ",
)  # tests/test_analysis.raw_row titles


def classify_input(path: Path, root: Path, rows: list[Incident]) -> dict[str, Any]:
    """Provenance derived from content, never from a caller-supplied label.

    registered_snapshot: the file's SHA-256 exists under <root>/snapshots/**;
    synthetic markers: classifier model names or titles used only by test fixtures.
    """
    digest = sha256_file(path)
    registered = any(
        candidate.name == f"{digest}.csv"
        for candidate in (root / "snapshots").rglob("*.csv")
    )
    markers = {
        "model_name_marker": sum(
            row.raw.get("model_name", "") in SYNTHETIC_MODEL_NAMES for row in rows
        ),
        "title_marker": sum(
            row.raw.get("title", "").startswith(SYNTHETIC_TITLE_PREFIXES)
            for row in rows
        ),
        "high_id_marker": sum(int(row.incident_id) >= 900000 for row in rows),
    }
    synthetic = any(markers.values())
    return {
        "path": str(path),
        "sha256": digest,
        "records": len(rows),
        "provenance": "registered_snapshot" if registered else "unregistered_input",
        "synthetic_markers": markers,
        "synthetic": synthetic,
    }


COMPARED_FIELDS = (
    "date",
    "domain_code",
    "subdomain_code",
    "additional_subdomains",
    "ai_goal_primary",
    "ai_goal_secondary",
    "causal_entity",
    "causal_intent",
    "causal_timing",
    "eu_ai_act_risk_level",
    "highest_severity",
    "highest_severity_10",
    "natsec_overall_score",
    "model_name",
    "prompt_version",
    "title",
)
TRANSITION_FIELDS = (
    "subdomain_code",
    "domain_code",
    "eu_ai_act_risk_level",
    "causal_intent",
)
EXAMPLE_LIMIT = 25


def index(rows: list[Incident]) -> dict[str, Incident]:
    return {row.incident_id: row for row in rows}


def year_counter(rows: list[Incident]) -> Counter[str]:
    return Counter(str(row.year) if row.year is not None else "undated" for row in rows)


def compare_exports(
    previous: list[Incident],
    current: list[Incident],
    labels: dict[str, str] | None = None,
) -> dict[str, Any]:
    labels = labels or {"previous": "previous", "current": "current"}
    before, after = index(previous), index(current)
    added = sorted_ids(set(after) - set(before))
    removed = sorted_ids(set(before) - set(after))
    shared = sorted_ids(set(before) & set(after))
    field_changes: dict[str, dict[str, Any]] = {}
    changed_records: set[str] = set()
    for field in COMPARED_FIELDS:
        examples: list[dict[str, str]] = []
        count = 0
        for identifier in shared:
            old, new = before[identifier].raw.get(field, ""), after[identifier].raw.get(
                field, ""
            )
            if old != new:
                count += 1
                changed_records.add(identifier)
                if len(examples) < EXAMPLE_LIMIT:
                    examples.append(
                        {
                            "aiid_id": identifier,
                            "previous": old[:200],
                            "current": new[:200],
                        }
                    )
        field_changes[field] = {"changed_records": count, "examples": examples}
    transitions: dict[str, list[dict[str, Any]]] = {}
    for field in TRANSITION_FIELDS:
        counter: Counter[tuple[str, str]] = Counter()
        for identifier in shared:
            old, new = before[identifier].raw[field], after[identifier].raw[field]
            if old != new:
                counter[(old, new)] += 1
        transitions[field] = [
            {"previous": old, "current": new, "records": n}
            for (old, new), n in sorted(counter.items(), key=lambda kv: (-kv[1], kv[0]))
        ]
    added_years = year_counter([after[i] for i in added])
    removed_years = year_counter([before[i] for i in removed])
    previous_years, current_years = year_counter(previous), year_counter(current)
    all_years = sorted(
        set(previous_years) | set(current_years), key=lambda y: (y == "undated", y)
    )
    annual = [
        {
            "year": year,
            labels["previous"]: previous_years.get(year, 0),
            labels["current"]: current_years.get(year, 0),
            "net_change": current_years.get(year, 0) - previous_years.get(year, 0),
            "added_records_dated_this_year": added_years.get(year, 0),
            "removed_records_dated_this_year": removed_years.get(year, 0),
        }
        for year in all_years
    ]
    cohorts = {
        label: [
            {"model": key[0], "prompt_version": key[1], "records": n}
            for key, n in Counter(
                (row.raw["model_name"], row.raw["prompt_version"]) for row in rows
            ).most_common()
        ]
        for label, rows in (
            (labels["previous"], previous),
            (labels["current"], current),
        )
    }
    date_shift = [
        {
            "aiid_id": i,
            "previous": before[i].raw["date"],
            "current": after[i].raw["date"],
            "year_changed": before[i].year != after[i].year,
        }
        for i in shared
        if before[i].raw["date"] != after[i].raw["date"]
    ]
    return {
        "schema_version": "1.0",
        "unit": "distinct incident records; a changed value is a changed export cell, not an explained event",
        "labels": labels,
        "counts": {
            labels["previous"]: len(previous),
            labels["current"]: len(current),
            "added": len(added),
            "removed": len(removed),
            "shared": len(shared),
            "shared_with_any_compared_field_change": len(changed_records),
        },
        "added_ids": added,
        "removed_ids": removed,
        "field_changes": field_changes,
        "transitions": transitions,
        "date_changes": date_shift[:200],
        "date_changes_total": len(date_shift),
        "annual_cohorts": annual,
        "classifier_cohorts": cohorts,
        "interpretation_limits": [
            "Added records dated in earlier years indicate backfill or delayed reporting, not new events in those years.",
            "Reclassifications may reflect prompt/model changes, human corrections or source updates; the export does not say which.",
            "Removed records may be merges, deletions or export filtering; no merge is inferred.",
        ],
    }


def render_markdown(result: dict[str, Any]) -> str:
    labels = result["labels"]
    lines = [
        "# Export-to-export comparison",
        "",
        f"**{labels['previous']}** → **{labels['current']}**. Unit: {result['unit']}.",
        "",
        "| Quantity | Value |",
        "| --- | --- |",
    ]
    for key, value in result["counts"].items():
        lines.append(f"| {key} | {value:,} |")
    lines += [
        "",
        "## Changed cells among shared records",
        "",
        "| Field | Records changed |",
        "| --- | --- |",
    ]
    for field, info in result["field_changes"].items():
        lines.append(f"| {field} | {info['changed_records']:,} |")
    lines += [
        "",
        "## Annual cohorts",
        "",
        f"| Year | {labels['previous']} | {labels['current']} | Net | Added dated this year | Removed dated this year |",
        "| --- | --- | --- | --- | --- | --- |",
    ]
    for row in result["annual_cohorts"]:
        lines.append(
            f"| {row['year']} | {row[labels['previous']]} | {row[labels['current']]} | {row['net_change']:+d} | {row['added_records_dated_this_year']} | {row['removed_records_dated_this_year']} |"
        )
    for field, items in result["transitions"].items():
        if items:
            lines += [
                "",
                f"## {field} transitions (top 15)",
                "",
                "| Previous | Current | Records |",
                "| --- | --- | --- |",
            ]
            for item in items[:15]:
                lines.append(
                    f"| {item['previous']} | {item['current']} | {item['records']} |"
                )
    lines += (
        ["", "## Interpretation limits", ""]
        + [f"- {t}" for t in result["interpretation_limits"]]
        + [""]
    )
    return "\n".join(lines)


def load_export(path: Path, analysis_date: date) -> list[Incident]:
    return load_incidents(path, analysis_date)


def run_comparison(
    previous_path: Path,
    previous_date: date,
    current_path: Path,
    current_date: date,
    output: Path,
    root: Path,
    synthetic: bool = False,
) -> dict[str, Any]:
    previous = load_export(previous_path, previous_date)
    current = load_export(current_path, current_date)
    result = compare_exports(
        previous,
        current,
        {
            "previous": f"previous ({previous_date})",
            "current": f"current ({current_date})",
        },
    )
    inputs = {
        "previous": classify_input(previous_path, root, previous),
        "current": classify_input(current_path, root, current),
        "previous_analysis_date": str(previous_date),
        "current_analysis_date": str(current_date),
        "caller_declared_synthetic": synthetic,
    }
    synthetic_detected = (
        synthetic or inputs["previous"]["synthetic"] or inputs["current"]["synthetic"]
    )
    both_registered = (
        inputs["previous"]["provenance"] == "registered_snapshot"
        and inputs["current"]["provenance"] == "registered_snapshot"
        and not synthetic_detected
    )
    inputs["synthetic"] = synthetic_detected
    inputs["historical_observation"] = (
        both_registered and inputs["previous"]["sha256"] != inputs["current"]["sha256"]
    )
    inputs["self_comparison"] = (
        inputs["previous"]["sha256"] == inputs["current"]["sha256"]
    )
    result["inputs"] = inputs
    if synthetic_detected:
        result["WARNING"] = (
            "SYNTHETIC TEST INPUTS (detected from content and/or declared): this comparison is a code test, not a historical observation."
        )
    elif inputs["self_comparison"]:
        result["WARNING"] = (
            "SELF-COMPARISON: both inputs have the same SHA-256; this is a null test of the comparison code, not a historical observation."
        )
    elif not both_registered:
        result["WARNING"] = (
            "UNREGISTERED INPUT: at least one file is not a content-addressed snapshot under snapshots/; do not present as a historical observation."
        )
    output.mkdir(parents=True, exist_ok=True)
    write_json(output / "export_comparison.json", result)
    banner = f"> **{result['WARNING']}**\n\n" if result.get("WARNING") else ""
    (output / "export_comparison.md").write_text(
        banner + render_markdown(result), encoding="utf-8"
    )
    return result
