"""Explicit session adjudication of rejected replacement wording.

The original model cycle stays immutable, including its rejected status. This
module calls no model and authorizes no publication. It permits edits only to
failed suggested_revision fields and re-runs the unchanged numerical gate.
"""

from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal

from pydantic import Field

from . import editorial
from .data import json_bytes, sha256_file
from .editorial_adoption import (
    _load,
    _manifest,
    _Mismatch,
    _recorded_attempt,
    _require_equal,
    differences,
)
from .models import StrictModel

RESOLVED = "adjudicated_requires_human_review"
AUTHOR = "Codex session editorial adjudication"


class SourceReference(StrictModel):
    path: str = Field(min_length=1)
    sha256: str = Field(pattern=r"^[a-f0-9]{64}$")
    locator: str = Field(min_length=1)


class Replacement(StrictModel):
    item_id: str = Field(min_length=1)
    replacement_text: str = Field(min_length=1)
    rationale: str = Field(min_length=1)
    evidence_ids: list[str]
    source_references: list[SourceReference] = Field(min_length=1)
    source_urls: list[str] = Field(default_factory=list)


class ReplacementSet(StrictModel):
    input_sha256: str = Field(pattern=r"^[a-f0-9]{64}$")
    publication_authorized: Literal[False]
    replacements: list[Replacement] = Field(min_length=1)


class ResolutionPaths(StrictModel):
    cycle: str
    source_run: str
    current_run: str
    context: str
    replacements: str


class ResolutionChange(StrictModel):
    item_type: Literal["candidate", "published_claim"]
    item_id: str
    original_suggested_revision: str
    resolved_suggested_revision: str
    rationale: str
    evidence_ids: list[str]
    source_references: list[SourceReference]
    source_urls: list[str]


class ResolutionRecord(StrictModel):
    schema_version: Literal[1]
    status: Literal["adjudicated_requires_human_review"]
    author: Literal["Codex session editorial adjudication"]
    created_at_utc: str
    publication_authorized: Literal[False]
    model_calls_performed: Literal[False]
    original_cycle_status: Literal["completed_review_suggestions_rejected"]
    paths: ResolutionPaths
    original_review_run_id: str
    current_run_id: str
    input_sha256: str
    analysis_date: str
    original_evidence_sha256: str
    original_draft_sha256: str
    original_review_sha256: str
    context_sha256: str
    replacements_sha256: str
    equivalent_evidence_sha256: str
    resolved_review_sha256: str
    resolved_screening_sha256: str
    artifact_manifests: dict[str, Any]
    original_model_calls: dict[str, Any]
    checks: dict[str, Any]
    changes: list[ResolutionChange]
    change_count: int
    resolved_review: editorial.EditorialReview
    original_review_screening: dict[str, Any]
    resolved_review_screening: dict[str, Any]
    meaning: str


def _hash_json(value: Any) -> str:
    return hashlib.sha256(json_bytes(value)).hexdigest()


def _proofs(entry: Replacement, replacement_path: Path) -> list[SourceReference]:
    checked = []
    for reference in entry.source_references:
        path = Path(reference.path)
        if not path.is_absolute():
            path = replacement_path.parent / path
        path = path.resolve(strict=True)
        _require_equal(reference.sha256, sha256_file(path), "replacement source proof")
        checked.append(reference.model_copy(update={"path": str(path)}))
    return checked


def create_resolution(
    cycle: Path,
    source_run: Path,
    current_run: Path,
    context: Path,
    replacements: Path,
) -> dict[str, Any]:
    """Return a complete receipt or not_resolved; never mutate any input.

    Save a receipt outside the immutable cycle/runs. Its resolved_review is
    explicitly session-authored. Original model identities and run_id remain
    unchanged; current_run_id records exact-evidence equivalence separately.
    """
    paths = ResolutionPaths(
        **{
            name: str(Path(value).resolve())
            for name, value in {
                "cycle": cycle,
                "source_run": source_run,
                "current_run": current_run,
                "context": context,
                "replacements": replacements,
            }.items()
        }
    )
    cycle, source_run, current_run, context, replacements = (
        Path(getattr(paths, name)) for name in ResolutionPaths.model_fields
    )
    stage = "artifact integrity"
    try:
        manifests = {
            "cycle": _manifest(cycle, cycle / "manifest.json"),
            "source_run": _manifest(source_run, source_run / "artifact_manifest.json"),
            "current_run": _manifest(
                current_run, current_run / "artifact_manifest.json"
            ),
        }
        from .__main__ import verify_run

        checks = {
            "source_run": verify_run(source_run, root=source_run.parent.parent),
            "current_run": verify_run(current_run, root=current_run.parent.parent),
        }
        context_hash, replacements_hash = sha256_file(context), sha256_file(
            replacements
        )
        stage = "original cycle"
        status = _load(cycle / "status.json")
        if (
            status.get("status") != "completed_review_suggestions_rejected"
            or status.get("publication_authorized") is not False
            or status.get("review_suggestions_grounded") is not False
        ):
            raise ValueError(
                "Resolution requires an unchanged completed cycle with rejected suggestions and no publication authorization"
            )
        evidence = _load(cycle / "evidence.json")
        evidence_hash = sha256_file(cycle / "evidence.json")
        _require_equal(
            evidence_hash, status.get("evidence_sha256"), "original evidence hash"
        )
        _require_equal(evidence["run_id"], status.get("run_id"), "original run binding")
        _require_equal(
            context_hash,
            evidence.get("additional_context_sha256"),
            "exact context bytes",
        )
        _require_equal(
            _load(context),
            evidence.get("additional_verified_context"),
            "exact context content",
        )
        stage = "exact evidence equivalence"
        source_evidence = editorial.evidence_payload(source_run, context)
        current_evidence = editorial.evidence_payload(current_run, context)
        _require_equal(
            evidence, source_evidence, "recorded versus reconstructed source evidence"
        )
        comparable = {k: v for k, v in source_evidence.items() if k != "run_id"}
        _require_equal(
            comparable,
            {k: v for k, v in current_evidence.items() if k != "run_id"},
            "source versus current evidence (only top-level run_id may differ)",
        )
        draft = editorial.EditorialDraft.model_validate(_load(cycle / "draft.json"))
        review = editorial.EditorialReview.model_validate(_load(cycle / "review.json"))
        draft_hash = sha256_file(cycle / "draft.json")
        original_review_hash = sha256_file(cycle / "review.json")
        _require_equal(draft_hash, status.get("draft_sha256"), "original draft hash")
        stage = "original screening"
        grounding = editorial.validate_draft(draft, evidence, evidence_hash)
        _require_equal(
            grounding, _load(cycle / "grounding.json"), "original draft screening"
        )
        if grounding["all_grounded"] is not True:
            raise ValueError(
                "Original draft failed grounding; replacement adjudication cannot repair it"
            )
        screening = editorial.validate_review(
            review, evidence, evidence_hash, draft_hash
        )
        _require_equal(
            screening,
            _load(cycle / "review_screening.json"),
            "original review screening",
        )
        if screening["all_grounded"] is not False:
            raise ValueError("Original review has no rejected suggestions to resolve")
        stage = "original request and response provenance"
        payload = {**evidence, "evidence_sha256": evidence_hash}
        calls = {
            "generation": _recorded_attempt(cycle, "generation", payload, draft),
            "review": _recorded_attempt(
                cycle,
                "review",
                {
                    **payload,
                    "draft": draft.model_dump(),
                    "draft_sha256": draft_hash,
                    "numerical_screening": grounding,
                },
                review,
            ),
        }
        stage = "replacement scope and proof"
        selected = ReplacementSet.model_validate(_load(replacements))
        _require_equal(
            evidence["input_sha256"], selected.input_sha256, "replacement CSV binding"
        )
        # validate_review guarantees all expected typed items. Item IDs must also
        # be globally unique because its screening artifact indexes IDs alone.
        ids = [item.item_id for item in review.reviews]
        if len(ids) != len(set(ids)):
            raise ValueError("Ambiguous review item IDs across item types")
        failed = {
            item["item_id"] for item in screening["items"] if item["grounded"] is False
        }
        replacement_ids = [item.item_id for item in selected.replacements]
        if (
            len(replacement_ids) != len(set(replacement_ids))
            or set(replacement_ids) != failed
        ):
            raise ValueError(
                f"Replacements must cover exactly failed item IDs: {sorted(failed)}"
            )
        by_id = {item.item_id: item for item in selected.replacements}
        resolved = review.model_copy(deep=True)
        changes = []
        for original, edited in zip(review.reviews, resolved.reviews):
            if original.item_id not in failed:
                continue
            replacement = by_id[original.item_id]
            _require_equal(
                original.evidence_ids,
                replacement.evidence_ids,
                "replacement evidence IDs must remain unchanged",
            )
            if (
                not replacement.replacement_text.strip()
                or not replacement.rationale.strip()
            ):
                raise ValueError("Replacement text and rationale must be substantive")
            if replacement.replacement_text == original.suggested_revision:
                raise ValueError("Rejected text was not replaced")
            proofs = _proofs(replacement, replacements)
            edited.suggested_revision = replacement.replacement_text
            changes.append(
                ResolutionChange(
                    item_type=original.item_type,
                    item_id=original.item_id,
                    original_suggested_revision=original.suggested_revision,
                    resolved_suggested_revision=edited.suggested_revision,
                    rationale=replacement.rationale,
                    evidence_ids=original.evidence_ids,
                    source_references=proofs,
                    source_urls=replacement.source_urls,
                )
            )
        expected_paths = {
            f"/reviews/{index}/suggested_revision"
            for index, item in enumerate(review.reviews)
            if item.item_id in failed
        }
        actual_paths = {
            item["path"]
            for item in differences(review.model_dump(), resolved.model_dump())
        }
        _require_equal(
            sorted(expected_paths),
            sorted(actual_paths),
            "only failed suggestions may change",
        )
        stage = "resolved numerical gate"
        resolved_screening = editorial.validate_review(
            resolved, evidence, evidence_hash, draft_hash
        )
        if resolved_screening["all_grounded"] is not True:
            raise _Mismatch(
                stage,
                [item for item in resolved_screening["items"] if not item["grounded"]],
            )
        stage = "final integrity recheck"
        for name, directory, filename in (
            ("cycle", cycle, "manifest.json"),
            ("source_run", source_run, "artifact_manifest.json"),
            ("current_run", current_run, "artifact_manifest.json"),
        ):
            _require_equal(
                manifests[name],
                _manifest(directory, directory / filename),
                stage + " " + name,
            )
        _require_equal(context_hash, sha256_file(context), stage + " context")
        _require_equal(
            replacements_hash, sha256_file(replacements), stage + " replacements"
        )
        for replacement in selected.replacements:
            _proofs(replacement, replacements)
        checks.update(
            original_draft_screening=True,
            original_rejected_review_reproduced=True,
            resolved_review_screening=True,
            untouched_review_fields=True,
        )
        return ResolutionRecord(
            schema_version=1,
            status=RESOLVED,
            author=AUTHOR,
            created_at_utc=datetime.now(timezone.utc).isoformat(),
            publication_authorized=False,
            model_calls_performed=False,
            original_cycle_status=status["status"],
            paths=paths,
            original_review_run_id=evidence["run_id"],
            current_run_id=current_evidence["run_id"],
            input_sha256=evidence["input_sha256"],
            analysis_date=evidence["analysis_date"],
            original_evidence_sha256=evidence_hash,
            original_draft_sha256=draft_hash,
            original_review_sha256=original_review_hash,
            context_sha256=context_hash,
            replacements_sha256=replacements_hash,
            equivalent_evidence_sha256=_hash_json(comparable),
            resolved_review_sha256=_hash_json(resolved.model_dump()),
            resolved_screening_sha256=_hash_json(resolved_screening),
            artifact_manifests=manifests,
            original_model_calls=calls,
            checks=checks,
            changes=changes,
            change_count=len(changes),
            resolved_review=resolved,
            original_review_screening=screening,
            resolved_review_screening=resolved_screening,
            meaning="The original model cycle remains rejected and immutable. A Codex session substituted only the failed suggested replacement text using the cited source artifacts; the unchanged numerical gate now passes. Original model assessments and evidence IDs remain intact. No model reviewed the substituted text. The current run has exactly the same evidence except its top-level run_id. Human review and publication approval remain required.",
        ).model_dump(mode="json")
    except _Mismatch as error:
        return {
            "status": "not_resolved",
            "publication_authorized": False,
            "stage": error.stage,
            "differences": error.found,
        }
    except (
        OSError,
        ValueError,
        TypeError,
        KeyError,
        AttributeError,
        SystemExit,
    ) as error:
        return {
            "status": "not_resolved",
            "publication_authorized": False,
            "stage": stage,
            "differences": [{"path": "/", "reason": str(error)}],
        }


def verify_resolution_record(
    record: dict[str, Any], current_run: Path
) -> dict[str, Any]:
    """Recheck a stored receipt, exact run, every source hash, and allowed edits."""
    try:
        saved = ResolutionRecord.model_validate(record)
        _require_equal(
            str(Path(current_run).resolve()),
            str(Path(saved.paths.current_run).resolve()),
            "receipt current run path",
        )
        fresh = create_resolution(
            **{key: Path(value) for key, value in saved.paths.model_dump().items()}
        )
        if fresh["status"] != RESOLVED:
            return fresh
        # These fresh checks are mandatory; only the current optional LATEST_RUN
        # anchor state and validation timestamp are excluded from receipt equality.
        old_value = {
            k: v
            for k, v in saved.model_dump(mode="json").items()
            if k not in ("created_at_utc", "checks")
        }
        new_value = {
            k: v for k, v in fresh.items() if k not in ("created_at_utc", "checks")
        }
        _require_equal(old_value, new_value, "saved resolution binding")
        return fresh
    except _Mismatch as error:
        return {
            "status": "not_resolved",
            "publication_authorized": False,
            "stage": error.stage,
            "differences": error.found,
        }
    except (OSError, ValueError, TypeError, KeyError, AttributeError) as error:
        return {
            "status": "not_resolved",
            "publication_authorized": False,
            "differences": [{"path": "/", "reason": str(error)}],
        }
