"""Reviewed website-claim refresh.

Fetches the current public pages behind the pinned claim registry (bounded GET
requests, raw bytes preserved with SHA-256 and UTC timestamps), converts HTML to
text without executing anything, and reports for each current claim whether its
exact registered wording is still present, partially present, or absent.

It never edits the registry or the check definitions: a changed or absent quote
is a signal for a human-reviewed registry update, not an automatic one.

Scope: prose quotes taken from static HTML (publication_status current_tracker and
current_reference) are matched in the fetched text; tabular transcriptions of published
Sheets/Docs are checked by source-byte hash only. Deployed-app text quotes
(current_app_text, extracted from the source-mapped TypeScript) cannot be matched
in minified embed.js; for those the fetched embed.js SHA-256 is compared with the
registered capture and reported as app_source_unchanged / app_source_changed /
page_unavailable. JavaScript-rendered text is not checked (no browser).
"""

from __future__ import annotations

import hashlib
import html
import json
import re
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Callable

QUOTE_MAP = str.maketrans(
    {"’": "'", "‘": "'", "“": '"', "”": '"', "–": "-", "—": "-", "\xa0": " "}
)
Fetcher = Callable[[str], tuple[int | None, bytes, str | None]]


class TextExtractor(HTMLParser):
    SKIP = {"script", "style", "noscript", "template"}

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self.skip_depth = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in self.SKIP:
            self.skip_depth += 1
        elif tag in {
            "p",
            "div",
            "li",
            "br",
            "h1",
            "h2",
            "h3",
            "h4",
            "h5",
            "h6",
            "tr",
            "section",
            "article",
        }:
            self.parts.append("\n")

    def handle_endtag(self, tag: str) -> None:
        if tag in self.SKIP and self.skip_depth:
            self.skip_depth -= 1

    def handle_data(self, data: str) -> None:
        if not self.skip_depth:
            self.parts.append(data)


def html_to_text(raw: bytes) -> str:
    parser = TextExtractor()
    parser.feed(raw.decode("utf-8", errors="replace"))
    return "".join(parser.parts)


class CellExtractor(HTMLParser):
    """Ordered table-cell texts, for quotes transcribed from published Sheets."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.cells: list[str] = []
        self.current: list[str] | None = None

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in {"td", "th"}:
            self.current = []
        elif tag == "br" and self.current is not None:
            self.current.append("\n")

    def handle_endtag(self, tag: str) -> None:
        if tag in {"td", "th"} and self.current is not None:
            self.cells.append("".join(self.current))
            self.current = None

    def handle_data(self, data: str) -> None:
        if self.current is not None:
            self.current.append(data)


def table_cells(raw: bytes) -> list[str]:
    parser = CellExtractor()
    parser.feed(raw.decode("utf-8", errors="replace"))
    return [normalize(cell) for cell in parser.cells if normalize(cell)]


def table_quote_present(quote: str, raw: bytes) -> bool:
    """True when the quote's lines, read in order, appear in the ordered table-cell text.

    Cells and quote lines may split differently (a cell can hold a line break), so both sides are
    flattened to one whitespace-normalised string before the ordered containment test.
    """
    lines = [normalize(line) for line in quote.split("\n") if normalize(line)]
    cells = table_cells(raw)
    if not lines or not cells:
        return False
    return " ".join(lines) in " ".join(cells)


def normalize(text: str) -> str:
    text = html.unescape(text).translate(QUOTE_MAP)
    return re.sub(r"\s+", " ", text).strip().lower()


def word_ngrams(text: str, n: int = 8) -> set[tuple[str, ...]]:
    words = normalize(text).split()
    if len(words) < n:
        return {tuple(words)} if words else set()
    return {tuple(words[i : i + n]) for i in range(len(words) - n + 1)}


def quote_status(quote: str, page_text: str) -> tuple[str, float]:
    page = normalize(page_text)
    if normalize(quote) in page:
        return "present", 1.0
    grams = word_ngrams(quote)
    if not grams:
        return "absent", 0.0
    page_grams = word_ngrams(page_text)
    overlap = len(grams & page_grams) / len(grams)
    if overlap >= 0.5:
        return "changed", round(overlap, 3)
    return "absent", round(overlap, 3)


def fetch_url_for(claim: dict[str, Any]) -> str:
    """Deployed-app quotes were extracted from the source map; that is the artefact to compare."""
    raw_path = claim.get("source_snapshot", {}).get("raw_path", "")
    if claim["publication_status"] == "current_app_text" and ".map" in raw_path:
        return claim["source_url"] + ".map"
    return claim["source_url"]


def live_fetcher(timeout: float = 20.0, max_bytes: int = 8 * 1024 * 1024) -> Fetcher:
    import httpx

    def fetch(url: str) -> tuple[int | None, bytes, str | None]:
        try:
            with httpx.Client(
                follow_redirects=True,
                timeout=timeout,
                headers={
                    "User-Agent": "incident-tracker-claim-refresh/0.2 (read-only)"
                },
            ) as client:
                response = client.get(url)
                body = response.content[:max_bytes]
                return response.status_code, body, str(response.url)
        except Exception as error:  # noqa: BLE001 - recorded, not raised
            return None, f"FETCH ERROR: {type(error).__name__}: {error}".encode(), None

    return fetch


def capture_fetcher(root: Path, registry: dict[str, Any]) -> Fetcher:
    """Offline mode for tests: serve the pinned raw captures recorded in the registry."""
    paths: dict[str, Path] = {}
    for claim in registry["claims"]:
        snapshot = claim.get("source_snapshot", {})
        if snapshot.get("raw_path"):
            paths[fetch_url_for(claim)] = root / snapshot["raw_path"]

    def fetch(url: str) -> tuple[int | None, bytes, str | None]:
        path = paths.get(url)
        if path is None or not path.exists():
            return None, b"", None
        return 200, path.read_bytes(), f"capture://{path.name}"

    return fetch


def refresh_claims(
    registry: dict[str, Any],
    fetcher: Fetcher,
    output: Path,
    publication_statuses: tuple[str, ...] = (
        "current_tracker",
        "current_reference",
        "current_app_text",
    ),
    mode: str = "live",
) -> dict[str, Any]:
    output.mkdir(parents=True, exist_ok=True)
    (output / "raw").mkdir(exist_ok=True)
    claims = [
        c for c in registry["claims"] if c["publication_status"] in publication_statuses
    ]

    fetch_url = fetch_url_for
    urls = sorted({fetch_url(c) for c in claims})
    pages: dict[str, dict[str, Any]] = {}
    for url in urls:
        fetched_at = datetime.now(timezone.utc).isoformat()
        status, body, final_url = fetcher(url)
        digest = hashlib.sha256(body).hexdigest()
        slug = re.sub(r"[^A-Za-z0-9._-]+", "_", url.split("//", 1)[-1])[:120]
        raw_path = output / "raw" / f"{slug}--{digest[:16]}.html"
        raw_path.write_bytes(body)
        pages[url] = {
            "requested_url": url,
            "final_url": final_url,
            "http_status": status,
            "fetched_at_utc": fetched_at,
            "bytes": len(body),
            "sha256": digest,
            "raw_path": str(raw_path.relative_to(output)),
            "text": html_to_text(body) if status == 200 else "",
            "raw_bytes": body if status == 200 else b"",
        }
    results = []
    for claim in claims:
        page = pages[fetch_url(claim)]
        registered_hash = claim.get("source_snapshot", {}).get("raw_sha256")
        if page["http_status"] != 200:
            status, score = "page_unavailable", 0.0
        elif claim["publication_status"] == "current_app_text":
            # Source-mapped app text cannot be located in minified JS; compare bytes instead.
            status = (
                "app_source_unchanged"
                if registered_hash == page["sha256"]
                else "app_source_changed_quote_unverifiable"
            )
            score = 1.0 if status == "app_source_unchanged" else 0.0
        elif claim["publication_status"] == "current_reference":
            # Published Sheets/Docs re-render with volatile bytes, so byte identity is not a change
            # signal. Prose is matched in the text; tabular transcriptions are matched cell by cell
            # in order; only if neither matches is the byte comparison reported.
            status, score = quote_status(claim["exact_wording"], page["text"])
            if status != "present" and table_quote_present(
                claim["exact_wording"], page.get("raw_bytes", b"")
            ):
                status, score = "present", 1.0
            if status != "present":
                status = (
                    "reference_source_unchanged"
                    if registered_hash == page["sha256"]
                    else "reference_source_changed_quote_unverifiable"
                )
                score = 1.0 if status == "reference_source_unchanged" else 0.0
        else:
            status, score = quote_status(claim["exact_wording"], page["text"])
        results.append(
            {
                "claim_id": claim["claim_id"],
                "source_url": claim["source_url"],
                "fetched_url": fetch_url(claim),
                "quote_status": status,
                "ngram_overlap": score,
                "page_sha256_now": page["sha256"],
                "page_sha256_registered": registered_hash,
                "page_changed_since_registry": bool(registered_hash)
                and registered_hash != page["sha256"],
                "registered_retrieval": claim.get("retrieved_at_utc"),
            }
        )
    summary = {
        "mode": mode,
        "pages_fetched": len(urls),
        "pages_ok": sum(p["http_status"] == 200 for p in pages.values()),
        "claims_checked": len(results),
        "present": sum(r["quote_status"] == "present" for r in results),
        "changed": sum(r["quote_status"] == "changed" for r in results),
        "absent": sum(r["quote_status"] == "absent" for r in results),
        "app_source_unchanged": sum(
            r["quote_status"] == "app_source_unchanged" for r in results
        ),
        "app_source_changed_quote_unverifiable": sum(
            r["quote_status"] == "app_source_changed_quote_unverifiable"
            for r in results
        ),
        "reference_source_unchanged": sum(
            r["quote_status"] == "reference_source_unchanged" for r in results
        ),
        "reference_source_changed_quote_unverifiable": sum(
            r["quote_status"] == "reference_source_changed_quote_unverifiable"
            for r in results
        ),
        "page_unavailable": sum(
            r["quote_status"] == "page_unavailable" for r in results
        ),
        "pages_with_changed_bytes": len(
            {r["source_url"] for r in results if r["page_changed_since_registry"]}
        ),
        "javascript_rendered_text_checked": False,
        "registry_edited": False,
        "next_step": "Human review: for any 'changed' or 'absent' quote, compare the raw capture with the registered text, then version the registry and check definitions deliberately. Nothing was edited automatically.",
    }
    report = {
        "schema_version": "1.0",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "summary": summary,
        "pages": {
            url: {k: v for k, v in page.items() if k not in {"text", "raw_bytes"}}
            for url, page in pages.items()
        },
        "claims": results,
    }
    (output / "claim_refresh_report.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    lines = [
        "# Claim refresh report",
        "",
        f"Mode: **{mode}**. Generated {report['generated_at_utc']}. Registry was **not** edited.",
        "",
        "| Metric | Value |",
        "| --- | --- |",
        *[
            f"| {k} | {v} |"
            for k, v in summary.items()
            if k not in {"next_step", "mode"}
        ],
        "",
        "| Claim | Quote status | 8-gram overlap | Page bytes changed since registry |",
        "| --- | --- | --- | --- |",
        *[
            f"| {r['claim_id']} | {r['quote_status']} | {r['ngram_overlap']} | {r['page_changed_since_registry']} |"
            for r in results
        ],
        "",
        summary["next_step"],
        "",
    ]
    (output / "claim_refresh_report.md").write_text("\n".join(lines), encoding="utf-8")
    return report
