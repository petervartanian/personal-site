"""Compare current labels with a small pre-existing human consensus reference.

This is a ten-incident diagnostic, not a held-out estimate of current accuracy.
"""

from __future__ import annotations
import argparse
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path
from .legacy_compare import load, normalize, fingerprint

ITEM_MAP = {
    "Democratic Norms Direct": "democratic_norms",
    "Differential Treatment Direct": "differential_treatment",
    "Environmental Damage Direct": "environmental_damage",
    "Financial Loss Direct": "financial_loss",
    "Human/Civil Rights Direct": "human_and_civil_rights",
    "Infrastructure Damage Direct": "infrastructure_damage",
    "Privacy Direct": "privacy",
    "Property Damage Direct": "property_damage",
    "Pyhsical Harm Direct": "physical_harm",
    "Toxic or Malicious Content Direct": "toxic_or_malicious_content",
}


def agreement(pairs: list[tuple[str, str]], ordinal: bool = False) -> dict:
    n = len(pairs)
    if not n:
        return {"n": 0, "exact_agreement": None, "kappa": None}
    exact = sum(a == b for a, b in pairs)
    ca = Counter(a for a, b in pairs)
    cb = Counter(b for a, b in pairs)
    if ordinal:
        if any(v not in {"1", "2", "3", "4", "5"} for pair in pairs for v in pair):
            raise ValueError("Ordinal score outside 1–5")
        observed = sum((int(a) - int(b)) ** 2 for a, b in pairs) / n
        expected = (
            sum(
                na * nb * (int(a) - int(b)) ** 2
                for a, na in ca.items()
                for b, nb in cb.items()
            )
            / n**2
        )
        kappa = 1 - observed / expected if expected else None
    else:
        expected = sum(ca[k] * cb[k] for k in ca.keys() | cb.keys()) / n**2
        kappa = (exact / n - expected) / (1 - expected) if expected != 1 else None
    return {
        "n": n,
        "exact_matches": exact,
        "exact_agreement": exact / n,
        "kappa": kappa,
        "kappa_type": (
            "quadratic weighted, fixed 1–5 scale" if ordinal else "unweighted nominal"
        ),
    }


def evaluate(reference: Path, export: Path) -> dict:
    current = load(export, "aiid_id")
    with reference.open(encoding="utf-8-sig") as handle:
        rows = list(csv.DictReader(handle))
    details = []
    grouped = defaultdict(list)
    human = defaultdict(list)
    for row in rows:
        section, item, identifier = row["Section"], row["Item"], row["Incident_ID"]
        if section == "Harm Severity":
            field = ITEM_MAP[item] + "_severity_direct"
        elif section == "Causal Taxonomy":
            field = {
                "Entity": "causal_entity",
                "Intent": "causal_intent",
                "Timing": "causal_timing",
            }[item]
        else:
            field = {
                "EU AI Act": "eu_ai_act_risk_level",
                "Domain (Top-level)": "domain_code",
                "Subdomain": "subdomain_code",
            }[section]
        if identifier not in current:
            raise ValueError(f"Missing pilot incident #{identifier}")
        predicted = normalize(current[identifier][field], field)
        consensus = row["Consensus"].strip()
        if not consensus:
            raise ValueError("Missing consensus")
        group = section if section != "Causal Taxonomy" else section + ": " + item
        grouped[group].append((predicted, consensus))
        human[group].append((row["H1"].strip(), row["H2"].strip()))
        details.append(
            {
                "incident_id": identifier,
                "section": section,
                "item": item,
                "field": field,
                "current": predicted,
                "consensus": consensus,
                "match": predicted == consensus,
            }
        )
    return {
        "source_reference": {
            "file": reference.name,
            "sha256": fingerprint(reference),
            "drive_file_id": "1VdiSfMoqm--D7laK4-ymZsLIciWJyWM6",
        },
        "source_export_sha256": fingerprint(export),
        "incidents": sorted(set(r["Incident_ID"] for r in rows), key=int),
        "rows": len(rows),
        "by_section": {
            s: {
                "current_vs_consensus": agreement(p, s == "Harm Severity"),
                "human_vs_human": agreement(human[s], s == "Harm Severity"),
            }
            for s, p in grouped.items()
        },
        "details": details,
        "limits": [
            "Ten deliberately selected incidents; not a representative random sample or confirmed holdout. References were used during prompt development and may overlap development data.",
            "Multiple ratings within an incident are correlated. A 100-rating harm table is still only ten incidents. No confidence intervals or population accuracy estimates are claimed.",
            "Historical human labels and current export classifications may use different report text or rubrics. Disagreement is a review signal, not proof the current model is wrong.",
            "This reference file contains no national-security ratings or potential-cause labels. A separate preliminary methodology document reports earlier national-security review; its paired labels are not present in this file.",
            "Kappa is undefined when expected disagreement is zero; no value is substituted. EU tier codes are assessed nominally, not interpreted as legal determinations.",
        ],
    }


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--reference", type=Path, required=True)
    p.add_argument("--export", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    result = evaluate(args.reference, args.export)
    args.output.mkdir(parents=True, exist_ok=False)
    (args.output / "pilot_reference_check.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )
    with (args.output / "paired_labels.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(result["details"][0]))
        writer.writeheader()
        writer.writerows(result["details"])
    lines = [
        "# Current labels against the pilot reference",
        "",
        "This diagnostic compares 160 ratings across ten previously selected incidents. It is not a current-pipeline accuracy estimate.",
        "",
        "| Section | Exact matches | Kappa |",
        "|---|---:|---:|",
    ]
    for s, v in result["by_section"].items():
        a = v["current_vs_consensus"]
        lines.append(
            f'| {s} | {a["exact_matches"]}/{a["n"]} | {a["kappa"]:.3f} |'
            if a["kappa"] is not None
            else f'| {s} | {a["exact_matches"]}/{a["n"]} | Undefined |'
        )
    lines += ["", "## Limits", ""] + ["- " + s for s in result["limits"]]
    (args.output / "PILOT_REFERENCE_CHECK.md").write_text("\n".join(lines) + "\n")
    print(json.dumps(result["by_section"], indent=2))


if __name__ == "__main__":
    main()
