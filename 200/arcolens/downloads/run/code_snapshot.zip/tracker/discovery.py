"""Data-driven candidate discovery over the exploratory ledger.

Stages are kept separate and each is recorded in the discovery ledger:
1. statistical screening (the eligibility flags computed in explore.py, plus the
   v2 'emergence' relaxation for categories that were too small at the first
   endpoint but are well populated at the last);
2. deduplication of cells that describe the same comparison (primary/any-label,
   same-field complements, severity ladders);
3. declared withholding rules (published- and archived-claim routing, complement
   labels of audited fields, taxonomy-entangled contrasts, unknown/Other winners,
   near-tautological concentrations, low-information rankings, unstable directions);
4. explainable scoring with stored components and weights;
5. chart-coverage-aware selection with a score floor and per-family, per-chart
   and total caps.

Nothing here is a statistical test. Scores rank descriptive stability and
usefulness for the existing charts; interpretation and publication remain
LLM-assisted/editorial stages that are not automated in this module.
"""

from __future__ import annotations

import hashlib
import re
from collections import Counter, defaultdict
from typing import Any

from pydantic import Field

from tracker.audit import fraction_text, percent_text
from tracker.calc import Engine, matches, proportion
from tracker.candidates import CHART_CAVEAT, SHARED_CAVEATS, common_cohort, number_text
from tracker.models import Candidate, Selection, SeveritySpec, StrictModel

SCALAR_LABELS = {
    "causal_entity": "causal entity",
    "causal_intent": "causal intent",
    "causal_timing": "causal timing",
    "eu_ai_act_risk_level": "EU AI Act risk tier",
    "ai_goal_primary": "primary AI purpose",
    "behaviour_type": "behavior type",
    "natsec_autonomy_level": "national-security autonomy level",
    "natsec_imminence_level": "national-security imminence level",
    "natsec_novelty_level": "national-security novelty level",
}
EU_TIER_NAMES = {
    "1": "1 Unacceptable",
    "2": "2 High Risk",
    "3": "3 Limited Risk",
    "4": "4 Minimal or No Risk",
}
CHART_GROUPING = {
    "causal_entity": ("C02", "Entity", "entity"),
    "causal_intent": ("C02", "Intent", "intent"),
    "causal_timing": ("C02", "Timing", "timing"),
    "eu_ai_act_risk_level": ("C02", "EU AI Act Risk Tier", "euRisk"),
    "ai_goal_primary": ("C02", "AI Purpose", "aiGoal"),
}


class PublishedSignature(StrictModel):
    claim_ids: list[str]
    family: str
    name_pattern: str


class DiscoveryConfig(StrictModel):
    schema_version: str
    discovery_version: str
    max_discovered_candidates: int = Field(ge=1)
    per_chart_cap: int = Field(ge=1)
    per_family_cap: int = Field(ge=1)
    concentration_near_tautology_pct: float | None = Field(default=None, ge=50, le=100)
    coverage_minimum_score: float = Field(default=0.0, ge=0, le=1)
    emergence_minimum_end_count: int = Field(default=50, ge=1)
    minimum_stability: float = Field(ge=0, le=1)
    weights: dict[str, float]
    effect_saturation_pp: float = Field(gt=0)
    count_relative_saturation_pct: float = Field(gt=0)
    support_saturation: int = Field(ge=1)
    chart_fit: dict[str, float]
    withheld_families: dict[str, str]
    low_cardinality_max_labels: int = Field(ge=2)
    high_cardinality_cap_per_field: int = Field(ge=1)
    published_signatures: list[PublishedSignature]


def key_text(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()[:10]


def clip(value: float) -> float:
    return max(0.0, min(1.0, value))


def subdomain_labels(engine: Engine) -> dict[str, str]:
    labels: dict[str, str] = {}
    for row in engine.rows:
        value = row.raw["subdomain_code"].strip()
        if value and row.primary and row.primary not in labels:
            labels[row.primary] = value
    return labels


def domain_labels(engine: Engine) -> dict[str, str]:
    labels: dict[str, str] = {}
    for row in engine.rows:
        value = row.raw["domain_code"].strip()
        if value and row.domain and row.domain not in labels:
            labels[row.domain] = value
    return labels


def direction_word(delta: float | None) -> str:
    if delta is None:
        return "undefined"
    return "up" if delta > 0 else "down" if delta < 0 else "flat"


def steps_text(series: dict[str, Any]) -> str:
    return ", ".join(
        f"{s['from_year']}→{s['to_year']} {s['share_direction']}"
        for s in series["trend"]["steps"]
    )


class Discovery:
    def __init__(
        self,
        engine: Engine,
        facts: dict[str, Any],
        ledger: list[dict[str, Any]],
        config: DiscoveryConfig,
    ) -> None:
        self.engine = engine
        self.facts = facts
        self.ledger = ledger
        self.config = config
        self.start = facts["start_year"]
        self.end = facts["end_year"]
        self.sub_labels = subdomain_labels(engine)
        self.dom_labels = domain_labels(engine)
        self.cohort = common_cohort(engine)
        self.drop_ids = engine.config.probable_duplicate_sensitivity_drop_ids
        sentinels = set(engine.config.unknown_values) | {"Other"}
        self.scalar_cardinality = {
            field: len({row.raw[field] for row in engine.rows} - sentinels)
            for field in (*SCALAR_LABELS, "domain_code", "subdomain_code")
        }

    # ---- stage helpers -------------------------------------------------
    def published_match(self, item: dict[str, Any]) -> list[str]:
        hits: list[str] = []
        for signature in self.config.published_signatures:
            if signature.family == item["family"] and re.fullmatch(
                signature.name_pattern, item["name"]
            ):
                hits.extend(signature.claim_ids)
        return sorted(set(hits))

    def emergence_candidate(self, item: dict[str, Any]) -> bool:
        """v2 relaxation: a category too small at the first endpoint (< min_category_count)
        but with at least emergence_minimum_end_count records at the last endpoint, both
        denominators meeting the comparison minimum, and no other screen failure."""
        if item["family"] not in {"subdomain_endpoint", "scalar_endpoint"}:
            return False
        if item.get("exclusion_reasons") != ["category count below minimum"]:
            return False
        a, b = item["a"], item["b"]
        minimum = self.engine.config.min_comparison_denominator
        return (
            a["denominator"] >= minimum
            and b["denominator"] >= minimum
            and b["numerator"] >= self.config.emergence_minimum_end_count
            and a["numerator"] < self.engine.config.min_category_count
        )

    def complement_of_audited(self, item: dict[str, Any]) -> list[str]:
        """Labels of a low-cardinality field whose other labels match a published claim."""
        field = item["name"].split(":", 1)[0]
        if (
            self.scalar_cardinality.get(field, 99)
            > self.config.low_cardinality_max_labels
        ):
            return []
        hits: list[str] = []
        for signature in self.config.published_signatures:
            if (
                signature.family == "scalar_endpoint"
                and signature.name_pattern.startswith(field + ":")
            ):
                hits.extend(signature.claim_ids)
        return sorted(set(hits))

    def target_for(self, item: dict[str, Any]) -> Selection | None:
        if "target" in item:
            return Selection(**item["target"])
        return None

    def endpoint_stability(
        self, key: str, target: Selection, threshold: float
    ) -> tuple[float, list[dict[str, Any]], list[str], dict[str, Any]]:
        """Return stability score, robustness rows, evidence IDs and the base series."""
        engine = self.engine
        base = engine.series(f"discovery.{key}.annual", target, self.start, self.end)
        evidence = [p["calculation_id"] for p in base["points"]]
        delta = base["trend"]["endpoint_delta_pp"]
        sign = direction_word(delta)
        checks: list[dict[str, Any]] = []
        variants = [
            ("start one year later", Selection(), self.start + 1, self.end),
            ("exclude latest complete year", Selection(), self.start, self.end - 1),
            (
                "drop probable duplicate #353",
                Selection(exclude_ids=self.drop_ids),
                self.start,
                self.end,
            ),
            ("common classifier/prompt cohort", self.cohort, self.start, self.end),
        ]
        passes = 0
        for name, population, a, b in variants:
            series = engine.series(
                f"discovery.{key}.{key_text(name)}", target, a, b, population
            )
            evidence.extend(p["calculation_id"] for p in series["points"])
            alt = series["trend"]["endpoint_delta_pp"]
            ok = (
                alt is not None
                and direction_word(alt) == sign
                and sign != "flat"
                and abs(alt) >= threshold
            )
            passes += ok
            checks.append(
                {
                    "alternative": name,
                    "series_id": series["series_id"],
                    "points": series["points"],
                    "trend": series["trend"],
                    "same_direction_and_material": ok,
                }
            )
        monotonic = (
            base["trend"]["strictly_increasing_share"]
            if sign == "up"
            else base["trend"]["strictly_decreasing_share"] if sign == "down" else False
        )
        checks.append(
            {
                "alternative": "every annual step in the same direction",
                "series_id": base["series_id"],
                "points": base["points"],
                "trend": base["trend"],
                "same_direction_and_material": bool(monotonic),
            }
        )
        stability = (passes + bool(monotonic)) / (len(variants) + 1)
        return stability, checks, evidence, base

    # ---- scoring -------------------------------------------------------
    def score(self, components: dict[str, float]) -> float:
        weights = self.config.weights
        total_weight = sum(weights.values())
        return sum(weights[k] * components[k] for k in weights) / total_weight

    # ---- main ----------------------------------------------------------
    def run(self) -> tuple[list[Candidate], dict[str, Any]]:
        config = self.config
        entries: list[dict[str, Any]] = []
        for item in self.ledger:
            entry = {
                "search_id": item["search_id"],
                "family": item["family"],
                "ledger_family": item["family"],
                "name": item["name"],
                "stage1_screen_eligible": bool(item["eligible"]),
                "screen_exclusion_reasons": item.get("exclusion_reasons", []),
                "decision": None,
                "reason": None,
                "published_claim_ids": self.published_match(item),
                "components": None,
                "score": None,
                "chart": None,
            }
            entry["emergence_candidate"] = self.emergence_candidate(item)
            if entry["emergence_candidate"]:
                entry["family"] = "emergence"
                entry["stage1_screen_eligible"] = True
                entry["screen_note"] = (
                    "admitted by the v2 emergence relaxation: first-endpoint count below the "
                    f"{self.engine.config.min_category_count}-record minimum, last-endpoint count at least "
                    f"{config.emergence_minimum_end_count}; stability requires the preceding year to agree and no final-step reversal"
                )
            elif not item["eligible"]:
                entry["decision"] = "screened_out"
                entry["reason"] = "failed the frozen numerical screen in explore.py"
            entries.append(entry)
        eligible = [e for e in entries if e["stage1_screen_eligible"]]
        by_id = {e["search_id"]: e for e in entries}
        items = {i["search_id"]: i for i in self.ledger}

        # Stage 3a: declared withholding before expensive scoring.
        for entry in eligible:
            item = items[entry["search_id"]]
            if entry["published_claim_ids"] and all(
                claim.startswith("ARCH-") for claim in entry["published_claim_ids"]
            ):
                entry["decision"] = "route_to_archived_replay"
                entry["reason"] = (
                    "matches an archived insight replayed under "
                    + ", ".join(entry["published_claim_ids"])
                    + "; not re-proposed as new"
                )
            elif entry["published_claim_ids"]:
                entry["decision"] = "route_to_claim_audit"
                entry["reason"] = (
                    "matches a currently published claim; audited under "
                    + ", ".join(entry["published_claim_ids"])
                    + " rather than proposed as new"
                )
            elif item["family"] == "scalar_endpoint" and self.complement_of_audited(
                item
            ):
                audited = self.complement_of_audited(item)
                a, b = item["a"], item["b"]
                entry["decision"] = "complement_of_audited_claim"
                entry["reason"] = (
                    f"label of a field whose other labels are audited under {', '.join(audited)}; "
                    f"this label moved {a['numerator']}/{a['denominator']} ({(a['percent'] or 0):.1f}%) -> "
                    f"{b['numerator']}/{b['denominator']} ({(b['percent'] or 0):.1f}%), {item['delta_pp']:+.1f} pp; "
                    "shown as composition context in those claims' reasons, not proposed as a separate finding"
                )
            elif item["family"] in config.withheld_families:
                entry["decision"] = "withheld_family"
                entry["reason"] = config.withheld_families[item["family"]]
            elif (
                item["family"] == "ranking"
                and self.scalar_cardinality.get(item["name"], 99)
                <= config.low_cardinality_max_labels
            ):
                entry["decision"] = "withheld_low_information_ranking"
                entry["reason"] = (
                    f"ranking over {item['name']} ({self.scalar_cardinality[item['name']]} categories) "
                    "adds nothing beyond the field's distribution"
                )
            elif (
                item["family"] == "within_domain_concentration"
                and config.concentration_near_tautology_pct is not None
                and (item.get("percent") or 0)
                >= config.concentration_near_tautology_pct
            ):
                entry["decision"] = "withheld_near_tautology"
                entry["reason"] = (
                    f"{item['percent']:.1f}% concentration at or above the declared {config.concentration_near_tautology_pct}% threshold: "
                    "the domain is effectively one subdomain in this export; record as a taxonomy-usage note, not an insight"
                )
            elif item["family"] == "scalar_endpoint" and (
                item["name"].split(":", 1)[1] in self.engine.config.unknown_values
                or item["name"].split(":", 1)[1] == "Other"
            ):
                entry["decision"] = "withheld_unknown_or_other"
                entry["reason"] = "the moving category is an unknown/Other bucket"
        remaining = [e for e in eligible if e["decision"] is None]

        # Stage 2: deduplication groups.
        groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for entry in remaining:
            item = items[entry["search_id"]]
            family = item["family"]
            if entry.get("emergence_candidate"):
                groups[f"emergence:{item['name'].split(':', 1)[-1]}"].append(entry)
                continue
            if family == "subdomain_endpoint":
                groups[f"subdomain:{item['name'].split(':', 1)[1]}"].append(entry)
            elif family == "scalar_endpoint":
                field = item["name"].split(":", 1)[0]
                if (
                    self.scalar_cardinality.get(field, 99)
                    <= config.low_cardinality_max_labels
                ):
                    groups[f"field:{field}"].append(entry)
                else:
                    groups[f"cell:{entry['search_id']}"].append(entry)
            elif family == "severity_endpoint":
                groups["severity"].append(entry)
            else:
                groups[f"cell:{entry['search_id']}"].append(entry)

        # Stage 4: score every remaining entry (so losers are explainable too).
        built: dict[str, dict[str, Any]] = {}
        for entry in remaining:
            built[entry["search_id"]] = self.build(items[entry["search_id"]], entry)

        # Resolve groups: keep the best-scoring member; record the rest as merged.
        survivors: list[dict[str, Any]] = []
        for group_key, members in groups.items():
            ordered = sorted(
                members,
                key=lambda e: (
                    -(e["score"] or 0),
                    self.tie_break(items[e["search_id"]]),
                    e["search_id"],
                ),
            )
            keep = ordered[0]
            if group_key.startswith(("subdomain:", "emergence:")):
                # Prefer the primary scope: the public chart shows primary shares.
                primaries = [
                    e
                    for e in ordered
                    if items[e["search_id"]]["name"].startswith("primary:")
                ]
                if primaries:
                    keep = primaries[0]
            survivors.append(keep)
            for other in ordered:
                if other is keep:
                    continue
                other["decision"] = "merged_as_sensitivity"
                other["reason"] = (
                    f"same comparison as {keep['search_id']} ({group_key})"
                )
                built[keep["search_id"]]["merged"].append(
                    {
                        "search_id": other["search_id"],
                        "name": items[other["search_id"]]["name"],
                        "delta_pp": items[other["search_id"]].get("delta_pp"),
                        "score": other["score"],
                    }
                )
        # High-cardinality fields: cap per field.
        per_field: Counter[str] = Counter()
        survivors.sort(key=lambda e: (-(e["score"] or 0), e["search_id"]))
        filtered: list[dict[str, Any]] = []
        for entry in survivors:
            item = items[entry["search_id"]]
            if item["family"] == "scalar_endpoint":
                field = item["name"].split(":", 1)[0]
                if (
                    self.scalar_cardinality.get(field, 99)
                    > config.low_cardinality_max_labels
                ):
                    per_field[field] += 1
                    if per_field[field] > config.high_cardinality_cap_per_field:
                        entry["decision"] = "withheld_field_cap"
                        entry["reason"] = (
                            f"more than {config.high_cardinality_cap_per_field} findings for field {field}"
                        )
                        continue
            filtered.append(entry)

        # Stage 3b: stability floor.
        stable: list[dict[str, Any]] = []
        for entry in filtered:
            if entry["components"]["stability"] < config.minimum_stability:
                entry["decision"] = "withheld_unstable"
                entry["reason"] = (
                    f"stability {entry['components']['stability']:.2f} below the declared minimum {config.minimum_stability}"
                )
            else:
                stable.append(entry)

        # Stage 5: coverage-aware selection.
        selected: list[dict[str, Any]] = []
        chart_counts: Counter[str] = Counter()
        family_counts: Counter[str] = Counter()
        # First pass: best item per chart for coverage (still subject to the family cap).
        seen_charts: set[str] = set()
        for entry in stable:
            chart, family = entry["chart"], entry["family"]
            if (
                chart not in seen_charts
                and len(selected) < config.max_discovered_candidates
                and family_counts[family] < config.per_family_cap
                and (entry["score"] or 0) >= config.coverage_minimum_score
            ):
                seen_charts.add(chart)
                selected.append(entry)
                chart_counts[chart] += 1
                family_counts[family] += 1
        # Second pass: fill by score within caps.
        for entry in stable:
            if entry in selected:
                continue
            if len(selected) >= config.max_discovered_candidates:
                entry["decision"] = "ranked_below_total_cap"
                entry["reason"] = (
                    f"total cap {config.max_discovered_candidates} reached"
                )
                continue
            if family_counts[entry["family"]] >= config.per_family_cap:
                entry["decision"] = "ranked_below_family_cap"
                entry["reason"] = (
                    f"per-family cap {config.per_family_cap} reached for {entry['family']}"
                )
                continue
            if chart_counts[entry["chart"]] >= config.per_chart_cap:
                entry["decision"] = "ranked_below_chart_cap"
                entry["reason"] = (
                    f"per-chart cap {config.per_chart_cap} reached for {entry['chart']}"
                )
                continue
            selected.append(entry)
            chart_counts[entry["chart"]] += 1
            family_counts[entry["family"]] += 1
        selected.sort(key=lambda e: (-(e["score"] or 0), e["search_id"]))
        candidates: list[Candidate] = []
        for rank, entry in enumerate(selected, 1):
            entry["decision"] = "selected"
            entry["reason"] = f"rank {rank} by declared score; chart coverage pass"
            entry["rank"] = rank
            spec = built[entry["search_id"]]
            candidates.append(self.candidate(f"IT-D{rank:03d}", spec, entry))
        ledger_out = {
            "schema_version": "1.0",
            "discovery_version": config.discovery_version,
            "stages": [
                "1 statistical screen (explore.py eligibility flags; v2 emergence relaxation admits first-endpoint-small categories that reach the end-count minimum)",
                "2 deduplication (primary/any-label, same-field complements, severity ladder)",
                "3 declared withholding (published/archived-claim routing, complements of audited fields, withheld families, unknown/Other, near-tautology, low-information rankings, stability floor, field cap)",
                "4 explainable scoring (weighted components below; no novelty weight: published matches are routed before scoring)",
                "5 chart-coverage selection (score floor, per-family, per-chart and total caps)",
                "6 LLM interpretation and editorial choice: NOT automated; human review required",
            ],
            "notes": [
                "Ranking and concentration cells in the ledger use records dated through the last complete year; the retained session templates IT-C003 (all dates) and IT-C004 (2016 to the last complete year) use different windows, stated in each candidate.",
                "Reviewer 3's alternative weighting (effect 0.35, stability 0.25, robustness 0.15, monotonicity 0.10, chart 0.15; per-chart cap 2) and its 'domain-dominant duplicate' and 'per-harm-category domain profile' rules were considered and recorded in V2_CHANGELOG.md; the declared rules here are the ones in force.",
            ],
            "weights": config.weights,
            "counts": Counter(e["decision"] for e in entries),
            "entries": sorted(
                entries,
                key=lambda e: (
                    e["decision"] != "selected",
                    -(e["score"] or -1),
                    e["search_id"],
                ),
            ),
        }
        ledger_out["counts"] = dict(ledger_out["counts"])
        return candidates, ledger_out

    def tie_break(self, item: dict[str, Any]) -> tuple[Any, ...]:
        """Deterministic order among equal scores: public-rubric severity definition first,
        then the larger absolute shift, then the rising category (reads more naturally than
        its falling complement), then the search ID."""
        if item["family"] == "severity_endpoint":
            dims, channels, threshold = item["name"].split(":")
            return (
                dims != "10",
                channels != "direct+indirect",
                abs(int(threshold) - 4),
            )
        delta = item.get("delta_pp") or 0.0
        return (0, -abs(delta), 0 if delta > 0 else 1)

    # ---- per-family construction ---------------------------------------
    def build(self, item: dict[str, Any], entry: dict[str, Any]) -> dict[str, Any]:
        family = item["family"]
        config = self.config
        spec: dict[str, Any] = {
            "item": item,
            "merged": [],
            "robustness": [],
            "evidence": [],
            "base": None,
            "label": None,
            "chart": None,
        }
        if family in {"subdomain_endpoint", "scalar_endpoint", "severity_endpoint"}:
            target = self.target_for(item)
            assert target is not None
            threshold = self.engine.config.share_change_materiality_pp
            stability, checks, evidence, base = self.endpoint_stability(
                key_text(item["search_id"]), target, threshold
            )
            if entry.get("emergence_candidate"):
                # Emergence rule: the preceding year must already show the shift, and the
                # final annual step must not reverse it (v3-monthly-operator correction).
                points = base["points"]
                sign = direction_word(base["trend"]["endpoint_delta_pp"])
                prev = points[-2] if len(points) >= 2 else None
                prev_ok = (
                    prev is not None
                    and prev["percent"] is not None
                    and points[0]["percent"] is not None
                    and direction_word(prev["percent"] - points[0]["percent"]) == sign
                    and abs(prev["percent"] - points[0]["percent"]) >= threshold
                )
                last_step = (
                    base["trend"]["steps"][-1]["share_direction"]
                    if base["trend"]["steps"]
                    else None
                )
                no_reversal = last_step in (sign, "flat")
                checks.append(
                    {
                        "alternative": "emergence rule: preceding year already shows the shift and the final annual step does not reverse it",
                        "series_id": base["series_id"],
                        "points": points,
                        "trend": base["trend"],
                        "same_direction_and_material": bool(prev_ok and no_reversal),
                    }
                )
                stability = stability if (prev_ok and no_reversal) else 0.0
                spec["emergence"] = {
                    "first_endpoint_count": points[0]["numerator"],
                    "last_step_direction": last_step,
                }
            spec.update(robustness=checks, evidence=evidence, base=base)
            first, last = base["points"][0], base["points"][-1]
            delta = base["trend"]["endpoint_delta_pp"] or 0.0
            support = first["numerator"] + last["numerator"]
            current_year = self.engine.analysis_date.year
            partial = self.engine.fraction(
                f"discovery.{key_text(item['search_id'])}.partial_current_year",
                target,
                Selection(years=[current_year]),
            )
            spec["evidence"].append(partial.calculation_id)
            spec["robustness"].append(
                {
                    "alternative": f"partial {current_year} to date (context only; not a full-year comparison)",
                    **partial.model_dump(),
                }
            )
            if family == "subdomain_endpoint":
                scope, code = item["name"].split(":", 1)
                spec["label"] = self.sub_labels.get(code, code)
                spec["scope"] = scope
                chart = "C02" if scope == "primary" else "TABLE"
                fit = config.chart_fit[
                    "C02_primary_subdomain" if scope == "primary" else "table_only"
                ]
                # Any-label incident shares are not what the All Subdomains toggle shows.
                if scope == "any":
                    assignment = self.engine.series(
                        f"discovery.{key_text(item['search_id'])}.assignment",
                        target,
                        self.start,
                        self.end,
                        denominator="subdomain_assignments",
                    )
                    spec["evidence"].extend(
                        p["calculation_id"] for p in assignment["points"]
                    )
                    spec["robustness"].append(
                        {
                            "alternative": "assignment-share denominator (what the All Subdomains toggle displays; different estimand)",
                            "series_id": assignment["series_id"],
                            "points": assignment["points"],
                            "trend": assignment["trend"],
                        }
                    )
            elif family == "scalar_endpoint":
                field, label = item["name"].split(":", 1)
                spec["field"], spec["value"] = field, label
                display = (
                    EU_TIER_NAMES.get(label, label)
                    if field == "eu_ai_act_risk_level"
                    else label
                )
                spec["label"] = f"{SCALAR_LABELS.get(field, field)} = {display}"
                if field in CHART_GROUPING:
                    chart = CHART_GROUPING[field][0]
                    fit = config.chart_fit["C02_scalar_grouping"]
                else:
                    chart, fit = "TABLE", config.chart_fit["table_only"]
                if (
                    self.scalar_cardinality.get(field, 99)
                    <= config.low_cardinality_max_labels
                ):
                    for year in (self.start, self.end):
                        top = []
                        for dist_item in self.engine.distribution(
                            field, Selection(years=[year])
                        ):
                            result = self.engine.fraction(
                                f"discovery.{key_text(item['search_id'])}.dist.{year}.{key_text(dist_item['category'])}",
                                Selection(equals={field: [dist_item["category"]]}),
                                Selection(years=[year]),
                            )
                            spec["evidence"].append(result.calculation_id)
                            top.append(
                                {
                                    "category": dist_item["category"] or "(blank)",
                                    **result.model_dump(),
                                }
                            )
                        spec["robustness"].append(
                            {
                                "alternative": f"full {SCALAR_LABELS.get(field, field)} distribution, {year} (complements move together)",
                                "top_categories": top,
                            }
                        )
                known = self.engine.series(
                    f"discovery.{key_text(item['search_id'])}.known",
                    target,
                    self.start,
                    self.end,
                    Selection(known_fields=[field], exclude_other=True),
                )
                spec["evidence"].extend(p["calculation_id"] for p in known["points"])
                spec["robustness"].append(
                    {
                        "alternative": "known values only, Other excluded (different denominator)",
                        "series_id": known["series_id"],
                        "points": known["points"],
                        "trend": known["trend"],
                    }
                )
            else:
                dims, channels, threshold_text = item["name"].split(":")
                spec["label"] = (
                    f"reported {channels.replace('+', '/')} severity score ≥{threshold_text} in any of the "
                    + ("original ten" if dims == "10" else "thirteen exported")
                    + " harm categories"
                )
                chart, fit = "TABLE", config.chart_fit["severity_table"]
            components = {
                "effect": clip(abs(delta) / config.effect_saturation_pp),
                "support": clip(support / config.support_saturation),
                "stability": stability,
                "chart_fit": fit,
            }
        elif family == "record_counts":
            a, b = item["a"], item["b"]
            rel = item["relative_count_change_pct"]
            annual = self.engine.series(
                f"discovery.{key_text(item['search_id'])}.counts",
                Selection(),
                self.start,
                self.end,
            )
            spec["evidence"] = [p["calculation_id"] for p in annual["points"]]
            spec["base"] = annual
            passes = 0
            variants = [
                ("start one year later", self.start + 1, self.end, Selection()),
                ("exclude latest complete year", self.start, self.end - 1, Selection()),
                ("include prior year", self.start - 1, self.end, Selection()),
                ("common classifier/prompt cohort", self.start, self.end, self.cohort),
            ]
            for name, s, e, population in variants:
                series = self.engine.series(
                    f"discovery.{key_text(item['search_id'])}.{key_text(name)}",
                    Selection(),
                    s,
                    e,
                    population,
                )
                spec["evidence"].extend(p["calculation_id"] for p in series["points"])
                ok = bool(
                    series["trend"]["strictly_increasing_count"]
                    or series["trend"]["strictly_decreasing_count"]
                )
                passes += ok
                spec["robustness"].append(
                    {
                        "alternative": name,
                        "series_id": series["series_id"],
                        "points": series["points"],
                        "trend": series["trend"],
                        "display_unit": "counts",
                        "same_direction_and_material": ok,
                    }
                )
            spec["label"] = "complete-year incident record counts"
            chart, fit = "C01", config.chart_fit["C01_counts"]
            components = {
                "effect": clip(abs(rel or 0) / config.count_relative_saturation_pct),
                "support": clip(min(a, b) / config.support_saturation),
                "stability": passes / len(variants),
                "chart_fit": fit,
            }
        elif family == "within_domain_concentration":
            domain, winner = item["name"].split(":", 1)
            target = Selection(subdomains=[winner])
            base_pop = Selection(domains=[domain], max_year=self.end)
            base = self.engine.fraction(
                f"discovery.{key_text(item['search_id'])}.base", target, base_pop
            )
            spec["evidence"] = [base.calculation_id]
            spec["base"] = base
            passes = 0
            variants = [
                (
                    "all dates (includes incomplete current year)",
                    Selection(domains=[domain]),
                ),
                (
                    "2016 floor to latest complete year (bar-chart window)",
                    Selection(domains=[domain], min_year=2016, max_year=self.end),
                ),
                (
                    "recent complete years",
                    Selection(domains=[domain], min_year=self.start, max_year=self.end),
                ),
                (
                    "drop probable duplicate #353",
                    base_pop.model_copy(update={"exclude_ids": self.drop_ids}),
                ),
                (
                    "common classifier/prompt cohort",
                    base_pop.model_copy(update={"equals": self.cohort.equals}),
                ),
                (
                    f"any {winner} membership (primary or additional) within primary domain",
                    None,
                ),
                (
                    f"partial {self.engine.analysis_date.year} to date (context only; not comparable)",
                    Selection(domains=[domain], years=[self.engine.analysis_date.year]),
                ),
            ]
            for name, population in variants:
                if population is None:
                    result = self.engine.fraction(
                        f"discovery.{key_text(item['search_id'])}.{key_text(name)}",
                        Selection(subdomains=[winner], classification="any"),
                        base_pop,
                    )
                else:
                    result = self.engine.fraction(
                        f"discovery.{key_text(item['search_id'])}.{key_text(name)}",
                        target,
                        population,
                    )
                spec["evidence"].append(result.calculation_id)
                ok = (
                    result.percent is not None
                    and result.percent >= self.engine.config.concentration_min_share_pct
                )
                passes += ok
                spec["robustness"].append(
                    {"alternative": name, **result.model_dump(), "still_a_majority": ok}
                )
            passes -= (
                1 if spec["robustness"][-1]["still_a_majority"] else 0
            )  # partial-year row is context, not a stability vote
            spec["label"] = (
                f"{self.sub_labels.get(winner, winner)} within {self.dom_labels.get(domain, domain)}"
            )
            spec["domain"], spec["winner"] = domain, winner
            chart, fit = "C04", config.chart_fit["C04_within_domain"]
            components = {
                "effect": clip(((base.percent or 0) - 50) / 50),
                "support": clip(base.numerator / config.support_saturation),
                "stability": passes / (len(variants) - 1),
                "chart_fit": fit,
            }
        elif family == "ranking":
            field = item["name"]
            first, second = item["a"], item["b"]
            lead = item["delta_pp"]
            spec["field"] = field
            windows = [
                ("complete years only", Selection(max_year=self.end)),
                ("all dates (includes incomplete current year)", Selection()),
                (
                    "recent complete years",
                    Selection(min_year=self.start, max_year=self.end),
                ),
                (
                    "common classifier/prompt cohort",
                    Selection(max_year=self.end, equals=self.cohort.equals),
                ),
                (
                    "drop probable duplicate #353",
                    Selection(max_year=self.end, exclude_ids=self.drop_ids),
                ),
            ]
            passes = 0
            for name, population in windows:
                distribution = self.engine.distribution(field, population)
                top = []
                for rank, dist_item in enumerate(distribution[:3], 1):
                    result = self.engine.fraction(
                        f"discovery.{key_text(item['search_id'])}.{key_text(name)}.rank{rank}",
                        Selection(equals={field: [dist_item["category"]]}),
                        population,
                    )
                    spec["evidence"].append(result.calculation_id)
                    top.append(
                        {"category": dist_item["category"], **result.model_dump()}
                    )
                same_winner = bool(top) and top[0]["category"] == first["category"]
                passes += same_winner
                spec["robustness"].append(
                    {
                        "alternative": name,
                        "top_categories": top,
                        "same_winner": same_winner,
                    }
                )
            spec["base"] = spec["robustness"][0]
            spec["label"] = (
                f"largest {SCALAR_LABELS.get(field, field.replace('_', ' '))} category"
            )
            chart = "C03"
            fit = config.chart_fit["C03_ranking"]
            components = {
                "effect": clip((lead or 0) / config.effect_saturation_pp),
                "support": clip(first["count"] / config.support_saturation),
                "stability": passes / len(windows),
                "chart_fit": fit,
            }
        else:
            # domain_harm_intersection / natsec_intersection: group contrasts are
            # withheld by declared rule before reaching this point; if a new family
            # appears, it is scored conservatively as table-only with no stability
            # evidence rather than silently promoted.
            spec["label"] = item["name"]
            chart, fit = "TABLE", config.chart_fit["table_only"]
            components = {
                "effect": clip(
                    abs(item.get("delta_pp") or 0) / config.effect_saturation_pp
                ),
                "support": (
                    clip(
                        min(item["a"]["numerator"], item["b"]["numerator"])
                        / config.support_saturation
                    )
                    if isinstance(item.get("a"), dict)
                    else 0.0
                ),
                "stability": 0.0,
                "chart_fit": fit,
            }
        entry["components"] = components
        entry["score"] = round(self.score(components), 4)
        entry["chart"] = chart
        spec["chart"] = chart
        return spec

    # ---- candidate rendering -------------------------------------------
    def candidate(
        self, identifier: str, spec: dict[str, Any], entry: dict[str, Any]
    ) -> Candidate:
        item = spec["item"]
        family = item["family"]
        start, end = self.start, self.end
        window = f"{start}-01-01 to {end}-12-31"
        selection_note = (
            f"Selected by the data-driven discovery stage (score {entry['score']:.3f}: "
            + ", ".join(f"{k} {v:.2f}" for k, v in entry["components"].items())
            + "). Scores rank descriptive stability and chart usefulness; they are not significance tests."
        )
        caveats = SHARED_CAVEATS + [selection_note]
        if family in {"subdomain_endpoint", "scalar_endpoint", "severity_endpoint"}:
            base = spec["base"]
            first, last = base["points"][0], base["points"][-1]
            delta = base["trend"]["endpoint_delta_pp"]
            monotonic = (
                base["trend"]["strictly_increasing_share"]
                or base["trend"]["strictly_decreasing_share"]
            )
            verb = (
                "rose"
                if (delta or 0) > 0
                else "fell" if (delta or 0) < 0 else "was unchanged"
            )
            emergence_text = (
                f" This category had fewer than {self.engine.config.min_category_count} records in {start} ({first['numerator']}); the finding is admitted under the v2 emergence rule and describes where it stands in {end}, not a per-year rate."
                if spec.get("emergence")
                else ""
            )
            step_text = (
                " Every annual step moved in the same direction."
                if monotonic
                else f" Annual steps: {steps_text(base)}."
            )
            count_text = (
                f" Counts changed from {first['numerator']} to {last['numerator']}"
                f" ({number_text(base['trend']['relative_count_change_pct'], 1)}%)."
            )
            if family == "subdomain_endpoint":
                scope_text = (
                    "primarily classified as"
                    if spec["scope"] == "primary"
                    else "carrying (primary or additional)"
                )
                subject = f"the share of records {scope_text} ‘{spec['label']}’"
                title = f"{spec['label']}: {spec['scope']} share {verb} {start}→{end}"
                chart_configuration = {
                    "primary_chart": spec["chart"],
                    "stacking_category": (
                        "Primary Subdomain"
                        if spec["scope"] == "primary"
                        else "All Subdomains (assignment shares; not this incident share)"
                    ),
                    "filters": {},
                    "date_range": window,
                    "setting": "Proportions with all legend series visible; Counts for the companion count view",
                    "programmatic_preset": {
                        "year": [str(y) for y in range(start, end + 1)],
                        "stackBy": "subdomain",
                        "viewMode": "proportion",
                    },
                    "compatibility": (
                        "Representable as a primary-subdomain share with an exact-year host preset; do not filter to the subdomain or hide other series."
                        if spec["scope"] == "primary"
                        else "Not directly representable: the All Subdomains toggle shows assignment shares (see robustness row), not any-label incident shares. Use the supporting table."
                    ),
                    "verification": CHART_CAVEAT,
                    "container_id": "main-chart",
                    "dataset": "incidents-arcola",
                }
            elif family == "scalar_endpoint":
                subject = f"the share of records tagged {spec['label']}"
                title = f"{spec['label']}: share {verb} {start}→{end}"
                grouping = CHART_GROUPING.get(spec["field"])
                chart_configuration = {
                    "primary_chart": spec["chart"],
                    "stacking_category": (
                        grouping[1]
                        if grouping
                        else "No current grouping dimension for this field"
                    ),
                    "filters": {},
                    "date_range": window,
                    "setting": "Proportions with all legend series visible",
                    "programmatic_preset": (
                        {
                            "year": [str(y) for y in range(start, end + 1)],
                            "stackBy": grouping[2],
                            "viewMode": "proportion",
                        }
                        if grouping
                        else {}
                    ),
                    "compatibility": (
                        "Representable with an exact-year host preset and all categories visible."
                        if grouping
                        else "Table only: the field is not a chart grouping dimension."
                    ),
                    "verification": CHART_CAVEAT,
                    "container_id": "main-chart" if grouping else None,
                    "dataset": "incidents-arcola",
                }
            else:
                subject = f"the share of records with a {spec['label']}"
                title = f"Severity-threshold share {verb} {start}→{end}"
                chart_configuration = {
                    "primary_chart": "Supporting table (no faithful aggregate chart)",
                    "stacking_category": "No aggregate grouping matches direct/indirect scores across the original ten harm dimensions",
                    "filters": {},
                    "date_range": window,
                    "setting": "Counts and proportions in the supporting table",
                    "compatibility": "Use a supporting table: this calculation uses direct/indirect scores in ten dimensions; the public headline includes inferred scores across thirteen dimensions.",
                    "verification": CHART_CAVEAT,
                }
            finding = (
                f"Among records dated {start}, {subject} was {fraction_text(first)}; among records dated {end} it was "
                f"{fraction_text(last)}: {number_text(delta)} percentage points.{count_text}{step_text}{emergence_text}"
                " These are shares of database records, not measures of underlying risk or of AI safety."
            )
            website = (
                f"In this export, {subject} {verb} from {fraction_text(first)} in {start} to {fraction_text(last)} in {end}."
                + (
                    " It moved in the same direction in every intervening year."
                    if monotonic
                    else ""
                )
                + " The figures describe recorded incident classifications and may reflect changes in reporting and coverage."
            )
            eligibility = {
                "passed": True,
                "rule": "comparative share shift (explore.py screen) + discovery stability floor",
                "endpoint_delta_pp": delta,
                "stability": entry["components"]["stability"],
                "minimum_stability": self.config.minimum_stability,
            }
            calc_conf = "High for the exported classifications and exact annual comparisons in this export."
            interp_conf = "Moderate as a description of database composition; low for any claim about real-world incidence, risk or safety."
            caveats = caveats + [
                "Shares are compositional: a category's share can fall while its count rises when other categories grow faster.",
                "Additional (non-primary) tags answer a different question from the primary tag; assignment shares are a third quantity.",
                "The partial current year is shown as context only; recently dated records may still be added or reclassified, so it is not a trend point.",
            ]
            if family == "severity_endpoint":
                caveats = caveats + [
                    "Severity scores are ordinal LLM annotations under the published ten-category rubric; level 1 spans none to minor harm, and zero/missing components are unknown, not proof of no harm.",
                    "Inferred (model-imputed) scores are excluded from this direct/indirect definition; the thirteen-dimension and inferred-inclusive variants are listed as merged sensitivities.",
                ]
        elif family == "record_counts":
            base = spec["base"]
            first, last = base["points"][0], base["points"][-1]
            change = last["numerator"] - first["numerator"]
            rel = base["trend"]["relative_count_change_pct"]
            title = "Complete-year incident record counts"
            finding = (
                f"The export contains {first['numerator']:,} incident records dated {start} and {last['numerator']:,} dated {end}: "
                f"{change:+,} records ({number_text(rel, 1)}% relative change). Strict annual count increase over the window: "
                f"{base['trend']['strictly_increasing_count']}. These are database records, not events, reports or people."
            )
            website = (
                f"In the {self.engine.analysis_date} export, incident records dated {start}–{end} "
                f"{'rose' if change > 0 else 'fell' if change < 0 else 'were unchanged'} from {first['numerator']:,} to {last['numerator']:,}. "
                "These counts describe the database's recorded incidents and may reflect changes in reporting and coverage."
            )
            chart_configuration = {
                "primary_chart": "C01",
                "stacking_category": "Domain (all seven domains visible)",
                "filters": {},
                "date_range": window,
                "setting": "Counts; sum stacked domains for yearly record totals",
                "programmatic_preset": {
                    "year": [str(y) for y in range(start, end + 1)],
                    "stackBy": "domain",
                    "viewMode": "counts",
                },
                "compatibility": "Counts and stacks are supported; an exact-year host preset is needed to suppress the partial current year.",
                "verification": CHART_CAVEAT,
                "container_id": "incident-domain-chart",
                "dataset": "incidents-arcola",
            }
            eligibility = {
                "passed": True,
                "rule": "complete-year counts (explore.py screen)",
                "stability": entry["components"]["stability"],
            }
            calc_conf = "High for distinct-record counts and date parsing; not an estimate of new submissions or events."
            interp_conf = "Low for actual incident incidence or safety changes; moderate as a description of this snapshot."
        elif family == "within_domain_concentration":
            base = spec["base"]
            title = f"{self.sub_labels.get(spec['winner'], spec['winner'])} within primary {self.dom_labels.get(spec['domain'], spec['domain'])}"
            finding = (
                f"Among records dated through {end} with primary domain ‘{self.dom_labels.get(spec['domain'], spec['domain'])}’, "
                f"{fraction_text(base)} have primary subdomain ‘{self.sub_labels.get(spec['winner'], spec['winner'])}’. "
                "This conditional share is within the domain, not across all incidents."
            )
            website = (
                f"Of the records dated through {end} primarily classified as ‘{self.dom_labels.get(spec['domain'], spec['domain'])}’, "
                f"{fraction_text(base)} have primary subdomain ‘{self.sub_labels.get(spec['winner'], spec['winner'])}’."
            )
            chart_configuration = {
                "primary_chart": "C04",
                "stacking_category": "Primary Subdomain",
                "filters": {
                    "domain": [self.dom_labels.get(spec["domain"], spec["domain"])],
                    "year": [str(y) for y in range(2016, end + 1)],
                },
                "date_range": f"2016-01-01 to {end}-12-31 on the bar chart (2016 floor); the headline uses all complete years",
                "setting": "Counts (visible default); percentage derived from the domain total",
                "programmatic_preset": {
                    "year": [str(y) for y in range(2016, end + 1)],
                    "domain": self.dom_labels.get(spec["domain"], spec["domain"]),
                    "stackBy": "subdomain",
                    "viewMode": "counts",
                },
                "compatibility": "The bar chart cannot show pre-2016 records; see the '2016 floor' robustness row for the chart-window value.",
                "verification": CHART_CAVEAT,
                "container_id": "main-chart-2",
                "dataset": "incidents-arcola",
            }
            eligibility = {
                "passed": True,
                "rule": "within-domain concentration (explore.py screen)",
                "stability": entry["components"]["stability"],
            }
            caveats = caveats + [
                "A high within-domain concentration can reflect how the classifier uses the taxonomy's subdomains (some subdomains are rarely assigned), not only what happened.",
            ]
            calc_conf = "High for the explicitly primary numerator and denominator."
            interp_conf = "Moderate for category composition; low for the prevalence of real-world events."
        elif family == "ranking":
            top = spec["base"]["top_categories"]
            first = top[0]
            second = top[1] if len(top) > 1 else None
            title = f"{first['category']} is the {spec['label']} (complete years)"
            finding = (
                f"Among records dated through {end}, {first['category']} has {fraction_text(first)}"
                + (
                    f" versus {second['category']} with {fraction_text(second)}; lead {first['percent'] - second['percent']:.2f} percentage points."
                    if second
                    else "."
                )
                + (
                    " This is a plurality, not a majority."
                    if first["percent"] <= 50
                    else " This is a majority."
                )
            )
            website = (
                f"In this export, ‘{first['category']}’ is the most frequent {SCALAR_LABELS.get(spec['field'], spec['field'])} tag among records dated through {end}, "
                f"at {fraction_text(first)}"
                + (
                    f", followed by ‘{second['category']}’ at {fraction_text(second)}."
                    if second
                    else "."
                )
            )
            chart_configuration = {
                "primary_chart": "C03",
                "stacking_category": SCALAR_LABELS.get(spec["field"], spec["field"]),
                "filters": {
                    "year": (
                        [str(y) for y in range(2016, end + 1)]
                        if spec["field"] != "domain_code"
                        else []
                    )
                },
                "date_range": f"through {end}; the live pie is all-time and includes the partial current year (see the all-dates robustness row)",
                "setting": "Pie proportions; keep all slices, including Other, visible",
                "programmatic_preset": {
                    "stackBy": {
                        "ai_goal_primary": "aiGoal",
                        "domain_code": "domain",
                        "subdomain_code": "subdomain",
                        "causal_intent": "intent",
                        "causal_timing": "timing",
                    }.get(spec["field"], spec["field"])
                },
                "compatibility": "Representable; Other is an aggregation of the tail, not a competing category.",
                "verification": CHART_CAVEAT,
                "container_id": "main-chart",
                "dataset": "incidents-arcola",
            }
            eligibility = {
                "passed": True,
                "rule": "ranking winner ≥50 and lead ≥5 pp (explore.py screen)",
                "stability": entry["components"]["stability"],
            }
            calc_conf = "High for the primary-tag ranking in this export."
            interp_conf = "Moderate for the retained tag ranking; low for which applications are intrinsically riskiest."
        else:
            raise ValueError(f"Unsupported discovery family: {family}")
        return Candidate(
            candidate_id=identifier,
            title=title,
            finding=finding,
            chart_ids=[] if spec["chart"] == "TABLE" else [spec["chart"]],
            evidence_ids=list(dict.fromkeys(spec["evidence"])),
            chart_configuration=chart_configuration,
            eligibility={
                **eligibility,
                "search_id": item["search_id"],
                "merged_sensitivities": spec["merged"],
            },
            calculation_confidence=calc_conf,
            interpretation_confidence=interp_conf,
            caveats=caveats,
            robustness=spec["robustness"],
            proposed_website_text=website,
            review_state="human_review_required",
            selection_stage="data_driven_discovery",
        )


def discover(
    engine: Engine,
    facts: dict[str, Any],
    ledger: list[dict[str, Any]],
    config: DiscoveryConfig,
) -> tuple[list[Candidate], dict[str, Any]]:
    return Discovery(engine, facts, ledger, config).run()
