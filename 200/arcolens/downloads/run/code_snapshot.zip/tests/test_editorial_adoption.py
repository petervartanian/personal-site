"""Offline provenance and exact-equivalence regressions; no model calls."""

from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
import unittest

from tracker import editorial
from tracker.data import json_bytes, sha256_file, write_json
from tracker.editorial_adoption import (
    ADOPTED,
    validate_editorial_adoption,
    verify_adoption_record,
)


def seal(folder: Path, filename: str) -> None:
    write_json(
        folder / filename,
        {
            "files": {
                p.relative_to(folder).as_posix(): sha256_file(p)
                for p in folder.rglob("*")
                if p.is_file() and p != folder / filename
            }
        },
    )


class AdoptionTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.source = self.root / "runs/source"
        self.current = self.root / "runs/current"
        self.cycle = self.root / "cycle"
        self.context = self.root / "context.json"
        self.cycle.mkdir()
        snapshot = self.root / "snapshot.csv"
        snapshot.write_text("id\na\nb\n")
        self.input_hash = sha256_file(snapshot)
        write_json(
            self.context,
            {"input_sha256": self.input_hash, "verified": "Scope is limited."},
        )
        candidate = {
            "candidate_id": "c1",
            "title": "A finding",
            "finding": "One of two records.",
            "proposed_website_text": "One of two records.",
            "chart_ids": ["chart"],
            "chart_configuration": {
                "filters": {"year": 2025},
                "verification": "Historical.",
            },
            "calculation_confidence": "High",
            "interpretation_confidence": "Limited",
            "caveats": ["Selected records."],
            "evidence_ids": ["m1"],
        }
        claim = {
            "claim_id": "p1",
            "publication_status": "current_tracker",
            "empirical": True,
            "exact_wording": "One of two records.",
            "source_url": "https://example.org/claim",
            "status": "Supported",
            "reason": "Reproduced.",
            "proposed_revision": "One of two records.",
            "original_time_window": "2025",
            "editorial_flags": [],
            "evidence_ids": ["m1"],
        }
        for run in (self.source, self.current):
            run.mkdir(parents=True)
            refs = []
            for ids in (["a"], ["a", "b"]):
                ref = "ids/" + hashlib.sha256(json_bytes(ids)).hexdigest() + ".json"
                write_json(run / ref, ids)
                refs.append(ref)
            write_json(
                run / "run_metadata.json",
                {
                    "run_id": run.name,
                    "analysis_date": "2026-09-27",
                    "input": {
                        "sha256": self.input_hash,
                        "snapshot_path": "snapshot.csv",
                    },
                },
            )
            write_json(run / "candidates.json", [candidate])
            write_json(run / "claim_audit.json", [claim])
            write_json(
                run / "calculations.json",
                {
                    "measures": {
                        "m1": {
                            "calculation_id": "m1",
                            "definition": {"description": "Selected records"},
                            "numerator": 1,
                            "denominator": 2,
                            "percent": 50.0,
                            "numerator_ids_ref": refs[0],
                            "denominator_ids_ref": refs[1],
                            "numerator_incident_count": 1,
                            "denominator_incident_count": 2,
                            "window": {"years": [2025]},
                        }
                    }
                },
            )
            seal(run, "artifact_manifest.json")
        evidence = editorial.evidence_payload(self.source, self.context)
        write_json(self.cycle / "evidence.json", evidence)
        evidence_hash = sha256_file(self.cycle / "evidence.json")
        draft = editorial.EditorialDraft.model_validate(
            {
                "run_id": "source",
                "evidence_sha256": evidence_hash,
                "publication_authorized": False,
                "concerns": [],
                "candidates": [
                    {
                        "candidate_id": "c1",
                        "suggested_wording": "1 of 2 records (50%).",
                        "chart": {
                            key: "Selected records"
                            for key in editorial.ChartText.model_fields
                        },
                        "calculation_confidence": "High",
                        "interpretation_confidence": "Limited",
                        "caveats": ["Selected records."],
                        "evidence_ids": ["m1"],
                    }
                ],
            }
        )
        write_json(self.cycle / "draft.json", draft.model_dump())
        draft_hash = sha256_file(self.cycle / "draft.json")
        grounding = editorial.validate_draft(draft, evidence, evidence_hash)
        write_json(self.cycle / "grounding.json", grounding)
        review = editorial.EditorialReview.model_validate(
            {
                "run_id": "source",
                "evidence_sha256": evidence_hash,
                "draft_sha256": draft_hash,
                "publication_authorized": False,
                "overall_concerns": [],
                "reviews": [
                    {
                        "item_type": kind,
                        "item_id": name,
                        "disposition": "pass",
                        "numerical_review": "Reproduced",
                        "chart_review": "Suitable",
                        "wording_review": "Scoped",
                        "issues": [],
                        "suggested_revision": "1 of 2 records (50%).",
                        "evidence_ids": ["m1"],
                    }
                    for kind, name in (("candidate", "c1"), ("published_claim", "p1"))
                ],
            }
        )
        write_json(self.cycle / "review.json", review.model_dump())
        write_json(
            self.cycle / "review_screening.json",
            editorial.validate_review(review, evidence, evidence_hash, draft_hash),
        )
        for name, response, payload in (
            ("generation", draft, {**evidence, "evidence_sha256": evidence_hash}),
            (
                "review",
                review,
                {
                    **evidence,
                    "evidence_sha256": evidence_hash,
                    "draft": draft.model_dump(),
                    "draft_sha256": draft_hash,
                    "numerical_screening": grounding,
                },
            ),
        ):
            directory = self.cycle / name
            write_json(
                directory / "request.json",
                {"system_instructions": "Original prompt", "evidence": payload},
            )
            write_json(
                directory / "schema.json", editorial.strict_schema(type(response))
            )
            write_json(directory / "structured_response.json", response.model_dump())
            write_json(
                directory / "call.json",
                {
                    "status": "response_received",
                    "provider": name,
                    "requested_model": "offline-test",
                    "requested_effort": "max",
                    "request_sha256": sha256_file(directory / "request.json"),
                    "schema_sha256": sha256_file(directory / "schema.json"),
                },
            )
        write_json(
            self.cycle / "status.json",
            {
                "status": "completed_requires_human_review",
                "publication_authorized": False,
                "review_suggestions_grounded": True,
                "run_id": "source",
                "evidence_sha256": evidence_hash,
                "draft_sha256": draft_hash,
            },
        )
        seal(self.cycle, "manifest.json")

    def tearDown(self) -> None:
        self.temp.cleanup()

    def check(self) -> dict:
        return validate_editorial_adoption(
            self.cycle,
            self.cycle / "manifest.json",
            self.source,
            self.current,
            self.context,
        )

    def mutate(self, path: Path, update, seal_folder: Path | None = None) -> None:
        value = json.loads(path.read_text())
        update(value)
        write_json(path, value)
        if seal_folder:
            seal(
                seal_folder,
                (
                    "manifest.json"
                    if seal_folder == self.cycle
                    else "artifact_manifest.json"
                ),
            )

    def test_identical_except_run_id_adopts_and_rechecks_without_mutation(self) -> None:
        before = {str(p): sha256_file(p) for p in self.root.rglob("*") if p.is_file()}
        result = self.check()
        self.assertEqual(result["status"], ADOPTED, result)
        self.assertFalse(result["publication_authorized"])
        self.assertFalse(result["model_calls_performed"])
        self.assertEqual(result["original_review_run_id"], "source")
        self.assertEqual(result["current_run_id"], "current")
        self.assertEqual(
            verify_adoption_record(result, self.current)["status"], ADOPTED
        )
        self.assertEqual(
            before,
            {str(p): sha256_file(p) for p in self.root.rglob("*") if p.is_file()},
        )

    def test_any_wording_difference_rejected(self) -> None:
        self.mutate(
            self.current / "candidates.json",
            lambda v: v[0].update(proposed_website_text="Different wording."),
            self.current,
        )
        result = self.check()
        self.assertEqual(result["status"], "not_adopted")
        self.assertIn(
            "/candidates/0/proposed_website_text",
            [d["path"] for d in result["differences"]],
        )

    def test_chart_filter_difference_rejected(self) -> None:
        self.mutate(
            self.current / "candidates.json",
            lambda v: v[0]["chart_configuration"]["filters"].update(year=2024),
            self.current,
        )
        self.assertEqual(self.check()["status"], "not_adopted")

    def test_exact_context_override_can_equalize_only_historical_verification(
        self,
    ) -> None:
        self.mutate(
            self.current / "candidates.json",
            lambda v: v[0]["chart_configuration"].update(
                verification="New historical note."
            ),
            self.current,
        )
        self.assertEqual(self.check()["status"], ADOPTED)

    def test_analysis_date_difference_rejected(self) -> None:
        self.mutate(
            self.current / "run_metadata.json",
            lambda v: v.update(analysis_date="2026-09-28"),
            self.current,
        )
        self.assertEqual(self.check()["status"], "not_adopted")

    def test_claim_status_difference_rejected(self) -> None:
        self.mutate(
            self.current / "claim_audit.json",
            lambda v: v[0].update(status="Unsupported"),
            self.current,
        )
        self.assertEqual(self.check()["status"], "not_adopted")

    def test_definition_difference_rejected(self) -> None:
        self.mutate(
            self.current / "calculations.json",
            lambda v: v["measures"]["m1"]["definition"].update(
                description="Changed definition"
            ),
            self.current,
        )
        self.assertEqual(self.check()["status"], "not_adopted")

    def test_modified_source_no_longer_matches_recording(self) -> None:
        self.mutate(
            self.source / "candidates.json",
            lambda v: v[0].update(title="Changed title"),
            self.source,
        )
        result = self.check()
        self.assertEqual(
            result["stage"], "recorded versus reconstructed source evidence"
        )

    def test_same_json_different_context_bytes_rejected(self) -> None:
        self.context.write_text(json.dumps(json.loads(self.context.read_text())))
        self.assertEqual(self.check()["stage"], "exact context file")

    def test_changed_context_content_rejected(self) -> None:
        self.mutate(self.context, lambda v: v.update(verified="Changed context."))
        self.assertEqual(self.check()["status"], "not_adopted")

    def test_cycle_hash_mismatch_rejected(self) -> None:
        (self.cycle / "draft.json").write_text("{}")
        self.assertEqual(self.check()["status"], "not_adopted")

    def test_extra_cycle_file_rejected(self) -> None:
        (self.cycle / "unmanifested.txt").write_text("Extra")
        self.assertEqual(self.check()["status"], "not_adopted")

    def test_current_hash_mismatch_rejected(self) -> None:
        (self.current / "candidates.json").write_text("[]")
        self.assertEqual(self.check()["status"], "not_adopted")

    def test_corrupted_snapshot_rejected(self) -> None:
        (self.root / "snapshot.csv").write_text("changed")
        self.assertEqual(self.check()["status"], "not_adopted")

    def test_unfinished_cycle_rejected_even_with_valid_manifest(self) -> None:
        self.mutate(
            self.cycle / "status.json",
            lambda v: v.update(status="reviewing"),
            self.cycle,
        )
        self.assertEqual(self.check()["status"], "not_adopted")

    def test_rejected_suggestions_not_adopted(self) -> None:
        self.mutate(
            self.cycle / "status.json",
            lambda v: v.update(status="completed_review_suggestions_rejected"),
            self.cycle,
        )
        self.assertEqual(self.check()["status"], "not_adopted")

    def test_request_provenance_mismatch_rejected_after_resealing(self) -> None:
        self.mutate(
            self.cycle / "generation/request.json",
            lambda v: v["evidence"].update(run_id="other"),
        )
        self.mutate(
            self.cycle / "generation/call.json",
            lambda v: v.update(
                request_sha256=sha256_file(self.cycle / "generation/request.json")
            ),
            self.cycle,
        )
        self.assertEqual(self.check()["stage"], "generation request evidence")

    def test_original_response_not_replaced_by_edited_draft(self) -> None:
        self.mutate(
            self.cycle / "generation/structured_response.json",
            lambda v: v["candidates"][0].update(suggested_wording="Other text."),
            self.cycle,
        )
        self.assertEqual(self.check()["stage"], "generation original response")

    def test_saved_adoption_rejects_different_current_run(self) -> None:
        self.assertEqual(
            verify_adoption_record(self.check(), self.source)["status"], "not_adopted"
        )

    def test_saved_adoption_rejects_later_artifact_change(self) -> None:
        result = self.check()
        self.mutate(
            self.current / "candidates.json",
            lambda v: v[0].update(title="New title"),
            self.current,
        )
        self.assertEqual(
            verify_adoption_record(result, self.current)["status"], "not_adopted"
        )

    def test_saved_adoption_rejects_forged_binding(self) -> None:
        result = self.check()
        result["current_run_id"] = "forged"
        self.assertEqual(
            verify_adoption_record(result, self.current)["status"], "not_adopted"
        )

    def test_nested_run_id_is_not_ignored(self) -> None:
        self.mutate(
            self.current / "candidates.json",
            lambda v: v[0]["chart_configuration"].update(run_id="nested"),
            self.current,
        )
        self.assertEqual(self.check()["status"], "not_adopted")

    def test_boolean_is_not_equal_to_integer(self) -> None:
        self.mutate(
            self.source / "candidates.json",
            lambda v: v[0]["chart_configuration"]["filters"].update(flag=True),
            self.source,
        )
        # The source already differs from the recorded request, which must reject.
        self.mutate(
            self.current / "candidates.json",
            lambda v: v[0]["chart_configuration"]["filters"].update(flag=1),
            self.current,
        )
        self.assertEqual(self.check()["status"], "not_adopted")

    def make_review_retry(self, number: int = 1) -> None:
        shutil.copytree(self.cycle / "review", self.cycle / f"review-retry-{number}")
        self.mutate(
            self.cycle / "review/call.json", lambda v: v.update(status="failed")
        )
        (self.cycle / "review/structured_response.json").unlink()
        seal(self.cycle, "manifest.json")

    def test_successful_retry_adopted_with_failed_attempt_preserved(self) -> None:
        self.make_review_retry()
        result = self.check()
        self.assertEqual(result["status"], ADOPTED, result)
        call = result["original_model_calls"]["review"]
        self.assertEqual(call["attempt_directory"], "review-retry-1")
        self.assertEqual(call["preserved_prior_attempts"][0]["status"], "failed")
        self.assertEqual(
            verify_adoption_record(result, self.current)["status"], ADOPTED
        )

    def test_retry_with_different_model_settings_rejected(self) -> None:
        self.make_review_retry()
        self.mutate(
            self.cycle / "review-retry-1/call.json",
            lambda v: v.update(requested_model="other-model"),
            self.cycle,
        )
        self.assertEqual(self.check()["status"], "not_adopted")

    def test_retry_with_changed_prompt_rejected(self) -> None:
        self.make_review_retry()
        self.mutate(
            self.cycle / "review-retry-1/request.json",
            lambda v: v.update(system_instructions="Changed prompt"),
        )
        self.mutate(
            self.cycle / "review-retry-1/call.json",
            lambda v: v.update(
                request_sha256=sha256_file(self.cycle / "review-retry-1/request.json")
            ),
            self.cycle,
        )
        self.assertEqual(self.check()["status"], "not_adopted")

    def test_retry_chain_cannot_skip_attempts(self) -> None:
        self.make_review_retry(number=2)
        self.assertEqual(self.check()["status"], "not_adopted")

    def test_retry_after_success_is_ambiguous(self) -> None:
        shutil.copytree(self.cycle / "review", self.cycle / "review-retry-1")
        seal(self.cycle, "manifest.json")
        self.assertEqual(self.check()["status"], "not_adopted")


if __name__ == "__main__":
    unittest.main()
