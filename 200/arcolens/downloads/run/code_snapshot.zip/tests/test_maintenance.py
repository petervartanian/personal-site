"""Counterexamples for maintenance fixes; fixtures are synthetic."""

from __future__ import annotations

import argparse
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from tests.test_analysis import DAY, raw_row
from tracker.data import parse_row
from tracker.provenance import late_entry_table, prefixes_matching
from tracker.__main__ import refresh_command, generate_draft_command


class MaintenanceTests(unittest.TestCase):
    def test_prefix_match_does_not_establish_historical_origin(self) -> None:
        result = prefixes_matching(
            [
                {
                    "max_id": 100,
                    "n": 100,
                    "latest_incident_date": "2025-04-01",
                    "tier": 5,
                }
            ],
            {"tier": (5.0, 1)},
        )
        self.assertEqual(result["joint_matching_prefixes"], 1)
        self.assertIn("does not establish", result["interpretation"])
        self.assertIn("original snapshot", result["interpretation"])

    def test_no_prefix_match_does_not_rule_out_history(self) -> None:
        result = prefixes_matching(
            [
                {
                    "max_id": 100,
                    "n": 100,
                    "latest_incident_date": "2025-04-01",
                    "tier": 5,
                }
            ],
            {"tier": (25.0, 1)},
        )
        self.assertEqual(result["joint_matching_prefixes"], 0)
        self.assertIn("does not rule out", result["interpretation"])

    def test_id_order_is_not_entry_timestamp(self) -> None:
        rows = [
            parse_row(raw_row(100, year=2021), DAY),
            parse_row(raw_row(10, year=2022), DAY),
        ]
        result = late_entry_table(rows, [2021])[0]
        self.assertEqual(result["records_above_following_year_minimum_id"], 1)
        self.assertNotIn("records_entered_after_following_year_started", result)
        self.assertIn("not database-entry timestamps", result["interpretation"])

    def test_unavailable_page_is_failure_not_success(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            args = argparse.Namespace(output=directory, offline_from_captures=True)
            with (
                patch("tracker.__main__.read_json", return_value={}),
                patch("tracker.refresh.capture_fetcher"),
                patch(
                    "tracker.refresh.refresh_claims",
                    return_value={"summary": {"page_unavailable": 1}},
                ),
                patch("tracker.__main__.refresh_manifest_if_inside_run"),
            ):
                with self.assertRaises(SystemExit) as caught:
                    refresh_command(args)
            self.assertEqual(caught.exception.code, 3)

    def test_rejected_draft_is_failure_not_success(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            args = argparse.Namespace(
                run=Path(directory),
                provider="fake",
                prompt_version="candidate-generation.v1",
                model="fake",
                effort="high",
            )
            with (
                patch("tracker.__main__.resolve_run", return_value=Path(directory)),
                patch(
                    "tracker.llm_adapter.generate_draft",
                    return_value={"draft_valid": False, "grounding": None},
                ),
                patch("tracker.__main__.refresh_manifest_if_inside_run"),
            ):
                with self.assertRaises(SystemExit) as caught:
                    generate_draft_command(args)
            self.assertEqual(caught.exception.code, 4)

    def test_grounded_draft_succeeds(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            args = argparse.Namespace(
                run=Path(directory),
                provider="fake",
                prompt_version="candidate-generation.v1",
                model="fake",
                effort="high",
            )
            with (
                patch("tracker.__main__.resolve_run", return_value=Path(directory)),
                patch(
                    "tracker.llm_adapter.generate_draft",
                    return_value={
                        "draft_valid": True,
                        "grounding": {"all_grounded": True},
                    },
                ),
                patch("tracker.__main__.refresh_manifest_if_inside_run"),
            ):
                generate_draft_command(args)
