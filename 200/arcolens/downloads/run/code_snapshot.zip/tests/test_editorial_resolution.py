"""Offline resolution receipts: exact scope, provenance, and no gate weakening."""

from __future__ import annotations

import copy
import json
from pathlib import Path
import unittest

from tracker import editorial
from tracker.data import sha256_file, write_json
from tracker.editorial_adoption import differences
from tracker.editorial_resolution import (
    RESOLVED,
    create_resolution,
    verify_resolution_record,
)
from tests import test_editorial_adoption as adoption_fixture
from tests.test_editorial_adoption import seal


class ResolutionTests(unittest.TestCase):
    """Reusable real fixture: call setUp(), create(), then tearDown()."""

    def setUp(self) -> None:
        self.fixture = adoption_fixture.AdoptionTests()
        self.fixture.setUp()
        for name in ("root", "source", "current", "cycle", "context", "input_hash"):
            setattr(self, name, getattr(self.fixture, name))
        self.replacements = self.root / "replacements.json"
        self.proof = self.root / "checked-copy.txt"
        self.proof.write_text("1 of 2 records (50%).")
        review = self.read(self.cycle / "review.json")
        review["reviews"][1]["suggested_revision"] = "9999 records."
        self.store_review(review)
        status = self.read(self.cycle / "status.json")
        status.update(
            status="completed_review_suggestions_rejected",
            review_suggestions_grounded=False,
        )
        write_json(self.cycle / "status.json", status)
        write_json(
            self.replacements,
            {
                "input_sha256": self.input_hash,
                "publication_authorized": False,
                "replacements": [
                    {
                        "item_id": "p1",
                        "replacement_text": self.proof.read_text(),
                        "rationale": "Use the separately checked source copy with an explicit denominator.",
                        "evidence_ids": ["m1"],
                        "source_references": [
                            {
                                "path": self.proof.name,
                                "sha256": sha256_file(self.proof),
                                "locator": "complete checked replacement sentence",
                            }
                        ],
                        "source_urls": ["https://example.org/claim"],
                    }
                ],
            },
        )
        seal(self.cycle, "manifest.json")

    def tearDown(self) -> None:
        self.fixture.tearDown()

    def read(self, path: Path):
        return json.loads(path.read_text())

    def store_review(self, value: dict) -> None:
        write_json(self.cycle / "review.json", value)
        write_json(self.cycle / "review/structured_response.json", value)
        screening = editorial.validate_review(
            editorial.EditorialReview.model_validate(value),
            self.read(self.cycle / "evidence.json"),
            sha256_file(self.cycle / "evidence.json"),
            sha256_file(self.cycle / "draft.json"),
        )
        write_json(self.cycle / "review_screening.json", screening)

    def create(self) -> dict:
        return create_resolution(
            self.cycle, self.source, self.current, self.context, self.replacements
        )

    def change_replacements(self, change) -> None:
        value = self.read(self.replacements)
        change(value)
        write_json(self.replacements, value)

    def test_exact_resolution_passes_and_inputs_are_unchanged(self) -> None:
        before = {str(p): sha256_file(p) for p in self.root.rglob("*") if p.is_file()}
        result = self.create()
        self.assertEqual(result["status"], RESOLVED, result)
        self.assertEqual(result["change_count"], 1)
        self.assertEqual(result["author"], "Codex session editorial adjudication")
        self.assertFalse(result["publication_authorized"])
        self.assertFalse(result["model_calls_performed"])
        self.assertEqual(
            result["original_cycle_status"], "completed_review_suggestions_rejected"
        )
        self.assertFalse(result["original_review_screening"]["all_grounded"])
        self.assertTrue(result["resolved_review_screening"]["all_grounded"])
        self.assertEqual(result["resolved_review"]["run_id"], "source")
        self.assertEqual(result["current_run_id"], "current")
        changed = differences(
            self.read(self.cycle / "review.json"), result["resolved_review"]
        )
        self.assertEqual(
            [x["path"] for x in changed], ["/reviews/1/suggested_revision"]
        )
        self.assertEqual(
            verify_resolution_record(result, self.current)["status"], RESOLVED
        )
        self.assertEqual(
            before,
            {str(p): sha256_file(p) for p in self.root.rglob("*") if p.is_file()},
        )

    def test_missing_replacement_rejected(self) -> None:
        self.change_replacements(lambda v: v.update(replacements=[]))
        self.assertEqual(self.create()["status"], "not_resolved")

    def test_extra_replacement_for_passing_item_rejected(self) -> None:
        def change(v):
            item = copy.deepcopy(v["replacements"][0])
            item["item_id"] = "c1"
            v["replacements"].append(item)

        self.change_replacements(change)
        self.assertEqual(self.create()["status"], "not_resolved")

    def test_duplicate_replacement_rejected(self) -> None:
        self.change_replacements(
            lambda v: v["replacements"].append(copy.deepcopy(v["replacements"][0]))
        )
        self.assertEqual(self.create()["status"], "not_resolved")

    def test_ungrounded_replacement_rejected(self) -> None:
        self.change_replacements(
            lambda v: v["replacements"][0].update(replacement_text="827 records.")
        )
        self.assertEqual(self.create()["stage"], "resolved numerical gate")

    def test_changed_evidence_ids_rejected(self) -> None:
        self.change_replacements(lambda v: v["replacements"][0].update(evidence_ids=[]))
        self.assertEqual(self.create()["status"], "not_resolved")

    def test_attempted_other_field_edit_rejected(self) -> None:
        self.change_replacements(
            lambda v: v["replacements"][0].update(disposition="withhold")
        )
        self.assertEqual(self.create()["status"], "not_resolved")

    def test_unchanged_rejected_copy_rejected(self) -> None:
        self.change_replacements(
            lambda v: v["replacements"][0].update(replacement_text="9999 records.")
        )
        self.assertEqual(self.create()["status"], "not_resolved")

    def test_wrong_replacement_csv_rejected(self) -> None:
        self.change_replacements(lambda v: v.update(input_sha256="0" * 64))
        self.assertEqual(self.create()["status"], "not_resolved")

    def test_source_proof_tampering_rejected(self) -> None:
        self.proof.write_text("changed proof")
        self.assertEqual(self.create()["status"], "not_resolved")

    def test_missing_source_proof_rejected(self) -> None:
        self.proof.unlink()
        self.assertEqual(self.create()["status"], "not_resolved")

    def test_blank_rationale_rejected(self) -> None:
        self.change_replacements(lambda v: v["replacements"][0].update(rationale=" "))
        self.assertEqual(self.create()["status"], "not_resolved")

    def test_blank_copy_rejected(self) -> None:
        self.change_replacements(
            lambda v: v["replacements"][0].update(replacement_text=" ")
        )
        self.assertEqual(self.create()["status"], "not_resolved")

    def test_no_source_proof_rejected(self) -> None:
        self.change_replacements(
            lambda v: v["replacements"][0].update(source_references=[])
        )
        self.assertEqual(self.create()["status"], "not_resolved")

    def test_publication_true_in_input_rejected(self) -> None:
        self.change_replacements(lambda v: v.update(publication_authorized=True))
        self.assertEqual(self.create()["status"], "not_resolved")

    def test_publication_true_in_original_status_rejected(self) -> None:
        self.fixture.mutate(
            self.cycle / "status.json",
            lambda v: v.update(publication_authorized=True),
            self.cycle,
        )
        self.assertEqual(self.create()["status"], "not_resolved")

    def test_original_manifest_tampering_rejected(self) -> None:
        (self.cycle / "review.json").write_text("{}")
        self.assertEqual(self.create()["status"], "not_resolved")

    def test_unmanifested_original_artifact_rejected(self) -> None:
        (self.cycle / "extra.txt").write_text("extra")
        self.assertEqual(self.create()["status"], "not_resolved")

    def test_wrong_current_evidence_rejected_even_after_resealing(self) -> None:
        self.fixture.mutate(
            self.current / "candidates.json",
            lambda v: v[0].update(title="changed"),
            self.current,
        )
        self.assertEqual(self.create()["status"], "not_resolved")

    def test_changed_analysis_date_rejected(self) -> None:
        self.fixture.mutate(
            self.current / "run_metadata.json",
            lambda v: v.update(analysis_date="2026-09-28"),
            self.current,
        )
        self.assertEqual(self.create()["status"], "not_resolved")

    def test_context_same_json_different_bytes_rejected(self) -> None:
        self.context.write_text(json.dumps(self.read(self.context)))
        self.assertEqual(self.create()["status"], "not_resolved")

    def test_original_failed_grounding_cannot_be_resolved(self) -> None:
        draft = self.read(self.cycle / "draft.json")
        draft["candidates"][0]["suggested_wording"] = "9999 records."
        write_json(self.cycle / "draft.json", draft)
        status = self.read(self.cycle / "status.json")
        status["draft_sha256"] = sha256_file(self.cycle / "draft.json")
        write_json(self.cycle / "status.json", status)
        ground = editorial.validate_draft(
            editorial.EditorialDraft.model_validate(draft),
            self.read(self.cycle / "evidence.json"),
            sha256_file(self.cycle / "evidence.json"),
        )
        write_json(self.cycle / "grounding.json", ground)
        seal(self.cycle, "manifest.json")
        result = self.create()
        self.assertEqual(result["status"], "not_resolved")
        self.assertIn("Original draft failed", str(result))

    def test_original_screening_record_must_match_recomputation(self) -> None:
        self.fixture.mutate(
            self.cycle / "review_screening.json",
            lambda v: v.update(all_grounded=True),
            self.cycle,
        )
        self.assertEqual(self.create()["status"], "not_resolved")

    def test_original_raw_response_must_match(self) -> None:
        self.fixture.mutate(
            self.cycle / "review/structured_response.json",
            lambda v: v["reviews"][0].update(wording_review="changed"),
            self.cycle,
        )
        self.assertEqual(self.create()["status"], "not_resolved")

    def test_no_failed_review_items_rejected(self) -> None:
        value = self.read(self.cycle / "review.json")
        value["reviews"][1]["suggested_revision"] = "1 of 2 records (50%)."
        self.store_review(value)
        seal(self.cycle, "manifest.json")
        self.assertEqual(self.create()["status"], "not_resolved")

    def test_receipt_wrong_target_run_rejected(self) -> None:
        self.assertEqual(
            verify_resolution_record(self.create(), self.source)["status"],
            "not_resolved",
        )

    def test_receipt_changed_current_id_rejected(self) -> None:
        value = self.create()
        value["current_run_id"] = "other"
        self.assertEqual(
            verify_resolution_record(value, self.current)["status"], "not_resolved"
        )

    def test_receipt_changes_outside_failed_text_rejected(self) -> None:
        value = self.create()
        value["resolved_review"]["reviews"][0]["disposition"] = "withhold"
        self.assertEqual(
            verify_resolution_record(value, self.current)["status"], "not_resolved"
        )

    def test_receipt_publication_true_rejected(self) -> None:
        value = self.create()
        value["publication_authorized"] = True
        self.assertEqual(
            verify_resolution_record(value, self.current)["status"], "not_resolved"
        )

    def test_receipt_nested_publication_true_rejected(self) -> None:
        value = self.create()
        value["resolved_review"]["publication_authorized"] = True
        self.assertEqual(
            verify_resolution_record(value, self.current)["status"], "not_resolved"
        )

    def test_receipt_changed_resolution_hash_rejected(self) -> None:
        value = self.create()
        value["resolved_review_sha256"] = "0" * 64
        self.assertEqual(
            verify_resolution_record(value, self.current)["status"], "not_resolved"
        )

    def test_receipt_changed_proof_rejected(self) -> None:
        value = self.create()
        self.proof.write_text("changed")
        self.assertEqual(
            verify_resolution_record(value, self.current)["status"], "not_resolved"
        )

    def test_receipt_changed_replacement_file_rejected(self) -> None:
        value = self.create()
        self.change_replacements(
            lambda v: v["replacements"][0].update(rationale="Changed rationale.")
        )
        self.assertEqual(
            verify_resolution_record(value, self.current)["status"], "not_resolved"
        )

    def test_receipt_fake_author_rejected(self) -> None:
        value = self.create()
        value["author"] = "Fable independently reviewed this text"
        self.assertEqual(
            verify_resolution_record(value, self.current)["status"], "not_resolved"
        )


if __name__ == "__main__":
    unittest.main()
