"""Small offline regressions for adapter binding, rejection, and CLI failure handling."""

from __future__ import annotations
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

from tracker import editorial as adapter


class AdapterRegressionTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.run = self.root / "synthetic-run"
        self.run.mkdir()
        fixtures = {
            "run_metadata.json": {
                "run_id": "synthetic-run",
                "analysis_date": "2026-09-27",
                "input": {"sha256": "a" * 64},
            },
            "candidates.json": [],
            "claim_audit.json": [],
            "calculations.json": {"measures": {}},
        }
        for name, value in fixtures.items():
            (self.run / name).write_text(json.dumps(value))

    def tearDown(self):
        self.tmp.cleanup()

    def test_reject_wrong_csv_context(self):
        context = self.root / "context.json"
        context.write_text(json.dumps({"input_sha256": "0" * 64}))
        with self.assertRaisesRegex(ValueError, "source CSV hash"):
            adapter.evidence_payload(self.run, context)

    def test_record_bad_context_preflight(self):
        context = self.root / "context.json"
        context.write_text("{bad-json")
        output = self.root / "editorial"
        with self.assertRaises(json.JSONDecodeError):
            adapter.run_editorial_cycle(self.run, output, context=context)
        status = json.loads((output / "status.json").read_text())
        self.assertEqual(status["status"], "failed_preflight")
        manifest = json.loads((output / "manifest.json").read_text())
        self.assertIn("status.json", manifest["files"])

    def test_failed_resume_keeps_full_manifest(self):
        output = self.root / "resume"
        output.mkdir()
        (output / "status.json").write_text('{"status":"failed"}')
        (output / "preserved.json").write_text('{"previous":"evidence"}')
        adapter.write_editorial_manifest(output)
        bad_context = self.root / "bad-context.json"
        bad_context.write_text('{"input_sha256":"wrong"}')
        for _ in range(2):
            with self.assertRaisesRegex(ValueError, "source CSV hash"):
                adapter.run_editorial_cycle(
                    self.run, output, context=bad_context, resume=True
                )
            manifest = json.loads((output / "manifest.json").read_text())["files"]
            self.assertIn("preserved.json", manifest)
            self.assertTrue(any(name.startswith("history/") for name in manifest))

    def test_quantitative_revisions_screened(self):
        evidence = adapter.evidence_payload(self.run)
        evidence["candidates"] = [{"candidate_id": "synthetic-C1"}]
        reviews = []
        for item_type, key, items in [
            ("candidate", "candidate_id", evidence["candidates"]),
            ("published_claim", "claim_id", evidence["published_claims"]),
        ]:
            for item in items:
                reviews.append(
                    adapter.ReviewItem(
                        item_type=item_type,
                        item_id=item[key],
                        disposition="pass",
                        numerical_review="Checked.",
                        chart_review="Checked.",
                        wording_review="Checked.",
                        issues=[],
                        suggested_revision="999999 incidents (99.999%).",
                        evidence_ids=[],
                    )
                )
        review = adapter.EditorialReview(
            run_id=evidence["run_id"],
            evidence_sha256="e",
            draft_sha256="d",
            reviews=reviews,
            overall_concerns=[],
            publication_authorized=False,
        )
        result = adapter.validate_review(review, evidence, "e", "d")
        self.assertFalse(result["all_grounded"])

    def _invoke_fake_codex(self, events: list[dict]):
        def run(args, **kwargs):
            if args[-1] == "--version":
                return subprocess.CompletedProcess(args, 0, "test-cli", "")
            last = Path(args[args.index("--output-last-message") + 1])
            last.write_text('{"ok":true}')
            return subprocess.CompletedProcess(
                args, 0, "\n".join(json.dumps(x) for x in events), ""
            )

        with (
            patch.object(adapter.shutil, "which", return_value="/fake/codex"),
            patch.object(adapter.subprocess, "run", side_effect=run),
        ):
            return adapter.invoke_cli(
                "codex",
                "No tools",
                {},
                {"type": "object"},
                self.root / "call",
                "test-model",
                "high",
            )

    def test_codex_failed_event_rejected(self):
        with self.assertRaisesRegex(RuntimeError, "failed turn"):
            self._invoke_fake_codex(
                [{"type": "turn.failed", "error": {"message": "failed"}}]
            )
        self.assertEqual(
            json.loads((self.root / "call/call.json").read_text())["status"], "failed"
        )

    def test_codex_tool_execution_rejected(self):
        with self.assertRaisesRegex(RuntimeError, "used tools"):
            self._invoke_fake_codex(
                [
                    {"type": "item.completed", "item": {"type": "command_execution"}},
                    {"type": "turn.completed", "usage": {}},
                ]
            )

    def test_valid_codex_completed_response(self):
        response = self._invoke_fake_codex(
            [
                {"type": "thread.started", "thread_id": "test"},
                {
                    "type": "turn.completed",
                    "usage": {"input_tokens": 10, "output_tokens": 5},
                },
            ]
        )
        self.assertEqual(response, {"ok": True})
        record = json.loads((self.root / "call/call.json").read_text())
        self.assertEqual(record["session_id"], "test")
        self.assertEqual(record["usage"]["output_tokens"], 5)

    def test_claude_error_envelope_rejected(self):
        def run(args, **kwargs):
            if args[-1] == "--version":
                return subprocess.CompletedProcess(args, 0, "test-cli", "")
            return subprocess.CompletedProcess(
                args, 0, json.dumps({"is_error": True, "result": "API error"}), ""
            )

        with (
            patch.object(adapter.shutil, "which", return_value="/fake/claude"),
            patch.object(adapter.subprocess, "run", side_effect=run),
        ):
            with self.assertRaisesRegex(RuntimeError, "reported an error"):
                adapter.invoke_cli(
                    "claude",
                    "No tools",
                    {},
                    {"type": "object"},
                    self.root / "call",
                    "test-model",
                    "high",
                )


if __name__ == "__main__":
    unittest.main()
