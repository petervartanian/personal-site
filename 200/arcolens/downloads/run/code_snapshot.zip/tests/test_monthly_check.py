"""Exercise orchestration and failure reporting while mocking only subprocesses."""

from __future__ import annotations

from datetime import date
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

from scripts.check_monthly import check_monthly, digest_file, previous_editorial_status
from tracker.data import json_bytes


class MonthlyCheckTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.downloads = self.root / "Downloads"
        self.project = self.root / "project"
        self.downloads.mkdir()
        self.project.mkdir()
        self.csv = self.downloads / "incident_tracker_export_2026-09-26.csv"
        self.csv.write_text(
            "Synthetic orchestration fixture; schema validation is owned by the intake tests.\n"
        )
        self.sha = digest_file(self.csv)
        self.today = date(2026, 9, 27)
        baseline = self.project / "runs/old-run"
        baseline.mkdir(parents=True)
        (baseline / "run_metadata.json").write_text(
            json.dumps(
                {
                    "code": {
                        "fingerprint_sha256": hashlib.sha256(json_bytes({})).hexdigest()
                    },
                    "input_artifact_hashes": {},
                }
            )
        )
        (self.project / "LATEST_RUN.json").write_text(
            json.dumps({"path": "runs/old-run", "run_id": "old-run"})
        )
        reviewed = self.project / "logs/editorial/default-current-review"
        reviewed.mkdir(parents=True)
        (reviewed / "status.json").write_text(
            json.dumps(
                {
                    "run_id": "old-run",
                    "status": "completed_requires_human_review",
                    "publication_authorized": False,
                    "completed_at_utc": "2026-09-24T12:00:00+00:00",
                }
            )
        )

    def intake(self, status: str = "different_export") -> dict:
        return {
            "status": status,
            "ready_for_analysis": status == "different_export",
            "selected": {
                "path": str(self.csv),
                "filename_date": "2026-09-26",
                "sha256": self.sha,
            },
            "baseline": {
                "run_id": "old-run",
                "input_sha256": self.sha if status == "unchanged_export" else "0" * 64,
            },
        }

    def record_run(self, digest: str | None = None) -> None:
        run = self.project / "runs/new-run"
        run.mkdir(parents=True, exist_ok=True)
        sha = digest or self.sha
        (run / "run_metadata.json").write_text(
            json.dumps({"analysis_date": "2026-09-26", "input": {"sha256": sha}})
        )
        (self.project / "LATEST_RUN.json").write_text(
            json.dumps(
                {"path": "runs/new-run", "input_sha256": sha, "run_id": "new-run"}
            )
        )

    def fake_process(
        self,
        intake_status: str = "different_export",
        intake_code: int = 0,
        refresh_code: int = 0,
        analysis_code: int = 0,
        editorial_code: int = 0,
        editorial_status: str = "completed_requires_human_review",
        wrong_binding: bool = False,
    ):
        def invoke(command, **kwargs):
            if "tracker.intake" in command:
                return subprocess.CompletedProcess(
                    command, intake_code, json.dumps(self.intake(intake_status)), ""
                )
            if "refresh-claims" in command:
                return subprocess.CompletedProcess(
                    command,
                    refresh_code,
                    json.dumps(
                        {
                            "summary": {
                                "changed": int(refresh_code == 2),
                                "page_unavailable": int(refresh_code == 3),
                            }
                        }
                    ),
                    "",
                )
            if command[0] == "sh":
                if analysis_code == 0:
                    self.record_run("0" * 64 if wrong_binding else None)
                return subprocess.CompletedProcess(
                    command,
                    analysis_code,
                    "analysis output\n",
                    "failure\n" if analysis_code else "",
                )
            if "editorial-cycle" in command:
                result = {
                    "status": editorial_status,
                    "run_id": "new-run",
                    "publication_authorized": False,
                }
                return subprocess.CompletedProcess(
                    command,
                    editorial_code,
                    json.dumps(result),
                    "authentication failed\n" if editorial_code else "",
                )
            raise AssertionError(command)

        return invoke

    def check(self, context: Path | None = None):
        return check_monthly(
            self.project, self.downloads, today=self.today, context=context
        )

    def test_unchanged_refreshes_without_analysis_or_paid_model(self) -> None:
        with patch(
            "scripts.check_monthly.subprocess.run",
            side_effect=self.fake_process("unchanged_export"),
        ) as runner:
            report = self.check()
        self.assertEqual(runner.call_count, 2)
        self.assertEqual(report["status"], "unchanged_export")
        self.assertFalse(report["analysis_invoked"])
        self.assertFalse(report["model_cycle_invoked"])
        self.assertEqual(report["exit_code"], 0)
        self.assertTrue((Path(report["output"]) / "summary.json").is_file())
        self.assertTrue((Path(report["output"]) / "manifest.json").is_file())

    def test_changed_export_uses_filename_date_and_authenticated_cycle(self) -> None:
        with patch(
            "scripts.check_monthly.subprocess.run", side_effect=self.fake_process()
        ) as runner:
            report = self.check()
        self.assertEqual(runner.call_count, 4)
        analysis_call = runner.call_args_list[2]
        self.assertEqual(
            analysis_call.args[0][-3:], ["2026-09-26", "monthly", "latest"]
        )
        self.assertEqual(analysis_call.kwargs["env"]["TRACKER_LLM_PROVIDER"], "none")
        editorial_call = runner.call_args_list[3].args[0]
        self.assertIn("editorial-cycle", editorial_call)
        self.assertIn("latest", editorial_call)
        self.assertNotIn("--provider", editorial_call)
        self.assertNotIn("fake", editorial_call)
        self.assertEqual(report["status"], "completed_requires_human_review")
        self.assertFalse(report["publication_authorized"])

    def test_no_export_still_refreshes(self) -> None:
        with patch(
            "scripts.check_monthly.subprocess.run",
            side_effect=self.fake_process("no_export_found"),
        ) as runner:
            report = self.check()
        self.assertEqual(runner.call_count, 2)
        self.assertEqual(report["status"], "no_export_found")

    def test_intake_failure_does_not_skip_refresh(self) -> None:
        with patch(
            "scripts.check_monthly.subprocess.run",
            side_effect=self.fake_process("invalid_export", intake_code=2),
        ) as runner:
            report = self.check()
        self.assertEqual(runner.call_count, 2)
        self.assertEqual(report["status"], "intake_failed")
        self.assertEqual(report["exit_code"], 2)

    def test_unchanged_website_failure_is_not_reported_as_success(self) -> None:
        with patch(
            "scripts.check_monthly.subprocess.run",
            side_effect=self.fake_process("unchanged_export", refresh_code=3),
        ):
            report = self.check()
        self.assertEqual(report["status"], "unchanged_export_website_needs_attention")
        self.assertEqual(report["exit_code"], 2)

    def test_analysis_failure_prevents_paid_model(self) -> None:
        with patch(
            "scripts.check_monthly.subprocess.run",
            side_effect=self.fake_process(analysis_code=1),
        ) as runner:
            report = self.check()
        self.assertEqual(runner.call_count, 3)
        self.assertFalse(report["model_cycle_invoked"])
        self.assertEqual(report["status"], "analysis_or_website_check_failed")

    def test_editorial_authentication_failure_has_recorded_outputs(self) -> None:
        with patch(
            "scripts.check_monthly.subprocess.run",
            side_effect=self.fake_process(editorial_code=1),
        ):
            report = self.check()
        self.assertEqual(report["status"], "editorial_failed")
        self.assertEqual(report["exit_code"], 2)
        stderr = Path(report["steps"]["editorial"]["stderr_path"]).read_text()
        self.assertIn("authentication failed", stderr)

    def test_editorial_rejected_suggestions_require_attention_even_with_zero_exit(
        self,
    ) -> None:
        with patch(
            "scripts.check_monthly.subprocess.run",
            side_effect=self.fake_process(
                editorial_status="completed_review_suggestions_rejected"
            ),
        ):
            report = self.check()
        self.assertEqual(report["status"], "editorial_needs_attention")
        self.assertEqual(report["exit_code"], 2)

    def test_old_context_is_omitted_for_fresh_export(self) -> None:
        context = self.root / "old-context.json"
        context.write_text(
            json.dumps({"input_sha256": "0" * 64, "diagnostic": "old snapshot"})
        )
        with patch(
            "scripts.check_monthly.subprocess.run", side_effect=self.fake_process()
        ) as runner:
            report = self.check(context)
        self.assertNotIn("--context", runner.call_args_list[-1].args[0])
        self.assertEqual(report["context"]["status"], "omitted")

    def test_hash_matched_context_is_forwarded(self) -> None:
        context = self.root / "context.json"
        context.write_text(
            json.dumps({"input_sha256": self.sha, "diagnostic": "current input"})
        )
        with patch(
            "scripts.check_monthly.subprocess.run", side_effect=self.fake_process()
        ) as runner:
            report = self.check(context)
        self.assertIn("--context", runner.call_args_list[-1].args[0])
        self.assertEqual(report["context"]["status"], "matched")

    def test_wrong_new_run_hash_prevents_model_call(self) -> None:
        with patch(
            "scripts.check_monthly.subprocess.run",
            side_effect=self.fake_process(wrong_binding=True),
        ) as runner:
            report = self.check()
        self.assertEqual(runner.call_count, 3)
        self.assertEqual(report["status"], "analysis_binding_failed")

    def test_changed_input_after_intake_prevents_analysis(self) -> None:
        base = self.fake_process()

        def changing(command, **kwargs):
            result = base(command, **kwargs)
            if "refresh-claims" in command:
                self.csv.write_text("changed after intake\n")
            return result

        with patch(
            "scripts.check_monthly.subprocess.run", side_effect=changing
        ) as runner:
            report = self.check()
        self.assertEqual(runner.call_count, 2)
        self.assertEqual(report["status"], "selected_input_invalid")

    def test_initial_refresh_failure_remains_visible_if_later_stages_complete(
        self,
    ) -> None:
        with patch(
            "scripts.check_monthly.subprocess.run",
            side_effect=self.fake_process(refresh_code=2),
        ):
            report = self.check()
        self.assertEqual(report["status"], "completed_with_website_attention")
        self.assertEqual(report["exit_code"], 2)
        self.assertTrue(report["model_cycle_invoked"])

    def test_malformed_intake_json_still_refreshes(self) -> None:
        base = self.fake_process()

        def malformed(command, **kwargs):
            if "tracker.intake" in command:
                return subprocess.CompletedProcess(command, 0, "not JSON", "")
            return base(command, **kwargs)

        with patch(
            "scripts.check_monthly.subprocess.run", side_effect=malformed
        ) as runner:
            report = self.check()
        self.assertEqual(runner.call_count, 2)
        self.assertEqual(report["status"], "intake_failed")

    def test_process_timeout_is_recorded_and_refresh_still_runs(self) -> None:
        base = self.fake_process()

        def timeout(command, **kwargs):
            if "tracker.intake" in command:
                raise subprocess.TimeoutExpired(command, 180, output=b"partial\n")
            return base(command, **kwargs)

        with patch(
            "scripts.check_monthly.subprocess.run", side_effect=timeout
        ) as runner:
            report = self.check()
        self.assertEqual(runner.call_count, 2)
        self.assertEqual(report["steps"]["intake"]["returncode"], 124)
        self.assertEqual(report["status"], "intake_failed")

    def test_failed_model_attempt_remains_visible_when_input_is_unchanged(self) -> None:
        history = self.project / "logs/editorial/previous"
        history.mkdir(parents=True)
        (history / "status.json").write_text(
            json.dumps(
                {
                    "run_id": "old-run",
                    "status": "failed",
                    "publication_authorized": False,
                    "completed_at_utc": "2026-09-25T12:00:00+00:00",
                }
            )
        )
        with patch(
            "scripts.check_monthly.subprocess.run",
            side_effect=self.fake_process("unchanged_export"),
        ) as runner:
            report = self.check()
        self.assertEqual(runner.call_count, 2)
        self.assertEqual(report["status"], "unchanged_export_editorial_needs_attention")
        self.assertEqual(report["exit_code"], 2)
        self.assertFalse(report["model_cycle_invoked"])

    def test_later_successful_model_attempt_resolves_earlier_failure(self) -> None:
        for name, state, stamp in [
            ("failed", "failed", "2026-09-25T12:00:00+00:00"),
            (
                "complete",
                "completed_requires_human_review",
                "2026-09-26T12:00:00+00:00",
            ),
        ]:
            history = self.project / "logs/editorial" / name
            history.mkdir(parents=True)
            (history / "status.json").write_text(
                json.dumps(
                    {
                        "run_id": "old-run",
                        "status": state,
                        "publication_authorized": False,
                        "completed_at_utc": stamp,
                    }
                )
            )
        with patch(
            "scripts.check_monthly.subprocess.run",
            side_effect=self.fake_process("unchanged_export"),
        ):
            report = self.check()
        self.assertEqual(report["status"], "unchanged_export")
        self.assertEqual(report["previous_editorial"]["status"], "completed")

    def test_interrupted_monthly_model_attempt_remains_visible(self) -> None:
        history = self.project / "logs/monthly-checks/interrupted"
        history.mkdir(parents=True)
        (history / "state.json").write_text(
            json.dumps(
                {
                    "model_cycle_invoked": True,
                    "selected_input": {"sha256": self.sha},
                    "started_at_utc": "2026-09-25T12:00:00+00:00",
                    "steps": {},
                }
            )
        )
        with patch(
            "scripts.check_monthly.subprocess.run",
            side_effect=self.fake_process("unchanged_export"),
        ):
            report = self.check()
        self.assertEqual(report["status"], "unchanged_export_editorial_needs_attention")

    def test_prior_failure_on_another_snapshot_does_not_block_unchanged_check(
        self,
    ) -> None:
        history = self.project / "logs/editorial/another-input"
        history.mkdir(parents=True)
        (history / "status.json").write_text(
            json.dumps(
                {
                    "run_id": "another-run",
                    "status": "failed",
                    "publication_authorized": False,
                }
            )
        )
        (history / "evidence.json").write_text(json.dumps({"input_sha256": "f" * 64}))
        with patch(
            "scripts.check_monthly.subprocess.run",
            side_effect=self.fake_process("unchanged_export"),
        ):
            report = self.check()
        self.assertEqual(report["status"], "unchanged_export")

    def test_zero_exit_without_valid_refresh_summary_is_not_success(self) -> None:
        base = self.fake_process("unchanged_export")

        def malformed(command, **kwargs):
            if "refresh-claims" in command:
                return subprocess.CompletedProcess(command, 0, "not a report", "")
            return base(command, **kwargs)

        with patch("scripts.check_monthly.subprocess.run", side_effect=malformed):
            report = self.check()
        self.assertEqual(report["status"], "unchanged_export_website_needs_attention")
        self.assertEqual(report["exit_code"], 2)

    def test_baseline_without_review_remains_pending(self) -> None:
        (self.project / "logs/editorial/default-current-review/status.json").unlink()
        with patch(
            "scripts.check_monthly.subprocess.run",
            side_effect=self.fake_process("unchanged_export"),
        ):
            report = self.check()
        self.assertEqual(report["status"], "unchanged_export_editorial_needs_attention")
        self.assertEqual(report["previous_editorial"]["status"], "no_record")
        self.assertEqual(report["exit_code"], 2)

    def test_same_csv_success_for_other_run_cannot_certify_current_run(self) -> None:
        history = self.project / "logs/editorial/default-current-review"
        (history / "status.json").write_text(
            json.dumps(
                {
                    "run_id": "different-calculations",
                    "status": "completed_requires_human_review",
                    "publication_authorized": False,
                }
            )
        )
        (history / "evidence.json").write_text(json.dumps({"input_sha256": self.sha}))
        with patch(
            "scripts.check_monthly.subprocess.run",
            side_effect=self.fake_process("unchanged_export"),
        ):
            report = self.check()
        self.assertEqual(report["status"], "unchanged_export_editorial_needs_attention")

    def test_claimed_adoption_is_not_trusted_without_verification(self) -> None:
        (self.project / "LATEST_EDITORIAL_ADOPTION.json").write_text(
            json.dumps({"status": "adopted_equivalent_evidence_requires_human_review"})
        )
        with patch(
            "scripts.check_monthly.subprocess.run",
            side_effect=self.fake_process("unchanged_export"),
        ):
            report = self.check()
        self.assertEqual(report["status"], "unchanged_export_editorial_needs_attention")
        self.assertEqual(
            report["previous_editorial"]["adoption_verification"]["status"],
            "not_adopted",
        )

    def test_changed_code_is_not_skipped_for_unchanged_csv(self) -> None:
        code = self.project / "tracker"
        code.mkdir()
        (code / "changed.py").write_text("# changed implementation\n")
        with patch(
            "scripts.check_monthly.subprocess.run",
            side_effect=self.fake_process("unchanged_export"),
        ) as runner:
            report = self.check()
        self.assertEqual(
            report["status"], "code_or_definitions_changed_needs_attention"
        )
        self.assertFalse(report["model_cycle_invoked"])
        self.assertEqual(runner.call_count, 2)

    def test_changed_pinned_chart_definition_is_not_skipped(self) -> None:
        research = self.project / "research"
        research.mkdir()
        chart = research / "chart_inventory.json"
        chart.write_text("{}\n")
        meta_path = self.project / "runs/old-run/run_metadata.json"
        meta = json.loads(meta_path.read_text())
        meta["input_artifact_hashes"] = {"chart_inventory.json": "0" * 64}
        meta_path.write_text(json.dumps(meta))
        with patch(
            "scripts.check_monthly.subprocess.run",
            side_effect=self.fake_process("unchanged_export"),
        ):
            report = self.check()
        self.assertEqual(
            report["status"], "code_or_definitions_changed_needs_attention"
        )
        self.assertIn(
            "research/chart_inventory.json", report["baseline_definitions"]["changed"]
        )

    def test_stale_adoption_does_not_override_successful_current_review(self) -> None:
        (self.project / "LATEST_EDITORIAL_ADOPTION.json").write_text(
            json.dumps(
                {
                    "status": "not_adopted",
                    "paths": {"current_run": str(self.project / "runs/older-run")},
                }
            )
        )
        with patch(
            "scripts.check_monthly.subprocess.run",
            side_effect=self.fake_process("unchanged_export"),
        ):
            report = self.check()
        self.assertEqual(report["status"], "unchanged_export")
        self.assertEqual(report["previous_editorial"]["status"], "completed")
        self.assertEqual(
            report["previous_editorial"]["adoption_verification"]["status"],
            "ignored_other_run",
        )

    def test_stale_resolution_does_not_clear_failed_current_review(self) -> None:
        current = self.project / "logs/editorial/default-current-review/status.json"
        current.write_text(
            json.dumps(
                {
                    "run_id": "old-run",
                    "status": "completed_review_suggestions_rejected",
                    "publication_authorized": False,
                }
            )
        )
        (self.project / "LATEST_EDITORIAL_RESOLUTION.json").write_text(
            json.dumps(
                {
                    "status": "adjudicated_requires_human_review",
                    "current_run_id": "older-run",
                    "paths": {"current_run": str(self.project / "runs/older-run")},
                }
            )
        )
        with patch(
            "scripts.check_monthly.subprocess.run",
            side_effect=self.fake_process("unchanged_export"),
        ):
            report = self.check()
        self.assertEqual(report["status"], "unchanged_export_editorial_needs_attention")
        self.assertEqual(
            report["previous_editorial"]["resolution_verification"]["status"],
            "ignored_other_run",
        )
        self.assertEqual(
            report["previous_editorial"]["latest_attempt"]["status"],
            "completed_review_suggestions_rejected",
        )

    def test_stale_resolution_cannot_certify_missing_current_review(self) -> None:
        (self.project / "logs/editorial/default-current-review/status.json").unlink()
        (self.project / "LATEST_EDITORIAL_RESOLUTION.json").write_text(
            json.dumps(
                {
                    "status": "adjudicated_requires_human_review",
                    "current_run_id": "older-run",
                    "paths": {"current_run": str(self.project / "runs/older-run")},
                }
            )
        )
        with patch(
            "scripts.check_monthly.subprocess.run",
            side_effect=self.fake_process("unchanged_export"),
        ):
            report = self.check()
        self.assertEqual(report["status"], "unchanged_export_editorial_needs_attention")
        self.assertEqual(report["previous_editorial"]["status"], "no_record")

    def test_successful_current_cycle_ignores_stale_resolution(self) -> None:
        (self.project / "LATEST_EDITORIAL_RESOLUTION.json").write_text(
            json.dumps(
                {
                    "status": "adjudicated_requires_human_review",
                    "current_run_id": "older-run",
                    "paths": {"current_run": str(self.project / "runs/older-run")},
                }
            )
        )
        with patch(
            "scripts.check_monthly.subprocess.run",
            side_effect=self.fake_process("unchanged_export"),
        ):
            report = self.check()
        self.assertEqual(report["status"], "unchanged_export")
        self.assertEqual(report["previous_editorial"]["status"], "completed")
        self.assertNotIn("model_review_passed", report["previous_editorial"])

    def test_claimed_current_resolution_must_pass_real_verifier(self) -> None:
        (self.project / "LATEST_EDITORIAL_RESOLUTION.json").write_text(
            json.dumps(
                {
                    "status": "adjudicated_requires_human_review",
                    "current_run_id": "old-run",
                    "paths": {"current_run": str(self.project / "runs/old-run")},
                }
            )
        )
        with patch(
            "scripts.check_monthly.subprocess.run",
            side_effect=self.fake_process("unchanged_export"),
        ):
            report = self.check()
        self.assertEqual(report["status"], "unchanged_export_editorial_needs_attention")
        self.assertEqual(
            report["previous_editorial"]["resolution_verification"]["status"],
            "not_resolved",
        )

    def test_conflicting_resolution_binding_is_reverified_not_ignored(self) -> None:
        (self.project / "LATEST_EDITORIAL_RESOLUTION.json").write_text(
            json.dumps(
                {
                    "status": "adjudicated_requires_human_review",
                    "current_run_id": "older-run",
                    "paths": {"current_run": str(self.project / "runs/old-run")},
                }
            )
        )
        with patch(
            "scripts.check_monthly.subprocess.run",
            side_effect=self.fake_process("unchanged_export"),
        ):
            report = self.check()
        self.assertEqual(report["status"], "unchanged_export_editorial_needs_attention")
        self.assertEqual(
            report["previous_editorial"]["resolution_verification"]["status"],
            "not_resolved",
        )


class MonthlyResolutionIntegrationTests(unittest.TestCase):
    """Use real hashed resolution artifacts, not a mocked successful verifier."""

    def setUp(self) -> None:
        from tests import test_editorial_resolution as fixtures

        self.fixture = fixtures.ResolutionTests()
        self.fixture.setUp()
        self.addCleanup(self.fixture.tearDown)
        self.project = self.fixture.root
        cycle = self.project / "logs/editorial/original-rejected"
        cycle.parent.mkdir(parents=True)
        self.fixture.cycle.rename(cycle)
        self.fixture.cycle = cycle
        self.baseline = {
            "run_id": self.fixture.current.name,
            "input_sha256": self.fixture.input_hash,
        }
        (self.project / "LATEST_RUN.json").write_text(
            json.dumps(
                {
                    "run_id": self.fixture.current.name,
                    "path": str(self.fixture.current.relative_to(self.project)),
                }
            )
        )
        self.record = self.fixture.create()
        self.assertEqual(
            self.record["status"], "adjudicated_requires_human_review", self.record
        )
        self.record_path = self.project / "LATEST_EDITORIAL_RESOLUTION.json"
        self.record_path.write_text(json.dumps(self.record))

    def test_verified_resolution_preserves_raw_rejected_model_status(self) -> None:
        before = (self.fixture.cycle / "status.json").read_bytes()
        result = previous_editorial_status(self.project, self.baseline)
        self.assertEqual(result["status"], "adjudicated_requires_human_review")
        self.assertFalse(result["needs_attention"])
        self.assertFalse(result["model_review_passed"])
        self.assertFalse(result["publication_authorized"])
        self.assertEqual(
            result["original_cycle_status"], "completed_review_suggestions_rejected"
        )
        self.assertEqual(
            result["latest_attempt"]["status"], "completed_review_suggestions_rejected"
        )
        self.assertEqual(before, (self.fixture.cycle / "status.json").read_bytes())

    def test_tampered_resolution_record_cannot_clear_rejected_review(self) -> None:
        self.record["resolved_review"]["reviews"][1][
            "suggested_revision"
        ] = "Publication is approved."
        self.record_path.write_text(json.dumps(self.record))
        result = previous_editorial_status(self.project, self.baseline)
        self.assertEqual(result["status"], "resolution_needs_attention")
        self.assertTrue(result["needs_attention"])
        self.assertEqual(result["resolution_verification"]["status"], "not_resolved")
        self.assertNotIn("model_review_passed", result)

    def test_changed_source_proof_invalidates_saved_resolution(self) -> None:
        self.fixture.proof.write_text("Unverified replacement copy.")
        result = previous_editorial_status(self.project, self.baseline)
        self.assertTrue(result["needs_attention"])
        self.assertEqual(result["resolution_verification"]["status"], "not_resolved")
        self.assertEqual(
            result["latest_attempt"]["status"], "completed_review_suggestions_rejected"
        )


if __name__ == "__main__":
    unittest.main()
