"""Semantic guards for qualitative profiles, missingness and legacy comparison."""

import json
import unittest
from tracker.chart_profiles import cause_map, CATEGORIES
from tracker.legacy_compare import normalize, FIELD_MAP


class ProfileGuards(unittest.TestCase):
    def test_placeholder_is_not_a_cause(self):
        data = {k: [{"Cause": "N/A", "Explanation": "N/A"}] for k in CATEGORIES}
        data["Technology"].append(
            {"Cause": "Classifier error", "Explanation": "Example"}
        )
        parsed = cause_map(json.dumps({"Ishikawa": data}))
        self.assertEqual(parsed["Technology"], ["Classifier error"])
        self.assertEqual(parsed["Management"], [])

    def test_missing_category_fails_instead_of_becoming_zero(self):
        with self.assertRaises(ValueError):
            cause_map('{"Technology":[]}')

    def test_invalid_payload_fails(self):
        for payload in ("[]", "null", "", '{"Ishikawa":null}'):
            with self.assertRaises(ValueError):
                cause_map(payload)

    def test_legacy_classifier_not_mapped_from_incident_model(self):
        self.assertNotIn("Model Name", FIELD_MAP)

    def test_legacy_date_and_code_normalize(self):
        self.assertEqual(normalize("02/10/2025", "date", True), "2025-10-02")
        self.assertEqual(
            normalize("7.3 Lack of capability", "subdomain_code", True), "7.3"
        )
        self.assertEqual(normalize("3 Limited Risk", "eu_ai_act_risk_level", True), "3")

    def test_invalid_date_is_not_silently_inferred(self):
        with self.assertRaises(ValueError):
            normalize("10/30/2025", "date", True)
