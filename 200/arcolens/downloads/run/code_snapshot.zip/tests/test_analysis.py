"""Small counterexamples for the methodological errors most likely to matter."""

from __future__ import annotations

import csv
import json
import tempfile
import unittest
from datetime import date
from pathlib import Path

from tracker.__main__ import next_due
from tracker.audit import SUPPORTED, UNSUPPORTED, current_check
from tracker.calc import Engine, severity_state, trend
from tracker.candidates import comparison_eligibility
from tracker.data import CHANNELS, HARM13, REQUIRED, load_incidents, parse_row
from tracker.models import AnalysisConfig, Measure, Selection, SeveritySpec

ROOT = Path(__file__).resolve().parents[1]
DAY = date(2026, 9, 27)


def raw_row(
    identifier: int, year: int = 2024, primary: str = "1.1", **updates: str
) -> dict[str, str]:
    raw = {field: "" for field in REQUIRED}
    raw.update(
        {
            "aiid_id": str(identifier),
            "title": f"Incident {identifier}",
            "date": f"{year}-03-01 00:00:00+00",
            "classified_at": "2026-07-18 00:00:00+00",
            "domain_code": primary.split(".")[0] + " Test domain",
            "subdomain_code": primary + " Test subdomain",
            "additional_subdomains": "[]",
            "ai_models": "[]",
            "ai_developers": "[]",
            "causal_entity": "AI",
            "causal_intent": "Unintentional",
            "causal_timing": "Post-deployment",
            "eu_ai_act_risk_level": "3",
            "ai_goal_primary": "Chatbot",
            "highest_severity": "1",
            "highest_severity_10": "1",
            "natsec_overall_score": "1",
            "model_name": "test-model",
            "prompt_version": "test.v1",
        }
    )
    for harm in HARM13:
        for channel in CHANNELS:
            raw[f"{harm}_severity_{channel}"] = "1"
    raw.update(updates)
    return raw


class CountingTests(unittest.TestCase):
    def setUp(self) -> None:
        self.config = AnalysisConfig.model_validate_json(
            (ROOT / "config/analysis.json").read_text()
        )

    def engine(self, *rows: dict[str, str]) -> Engine:
        return Engine([parse_row(row, DAY) for row in rows], self.config, DAY)

    def test_unknown_and_other_remain_in_base_denominator(self) -> None:
        engine = self.engine(
            raw_row(1, causal_entity="Human"),
            raw_row(2, causal_entity="Other"),
            raw_row(3, causal_entity=""),
        )
        target = Selection(equals={"causal_entity": ["Human"]})
        all_records = engine.fraction("all", target)
        known = engine.fraction(
            "known", target, Selection(known_fields=["causal_entity"])
        )
        known_without_other = engine.fraction(
            "noother",
            target,
            Selection(known_fields=["causal_entity"], exclude_other=True),
        )
        self.assertEqual((all_records.numerator, all_records.denominator), (1, 3))
        self.assertEqual(known.denominator, 2)
        self.assertEqual(known_without_other.denominator, 1)

    def test_primary_is_not_any_label_and_duplicates_do_not_inflate(self) -> None:
        additional = json.dumps(
            [
                {"code": "4.3 Fraud"},
                {"code": "4.3 Fraud"},
                {"code": "1.1 Same as primary"},
            ]
        )
        engine = self.engine(
            raw_row(1, additional_subdomains=additional), raw_row(2, primary="4.3")
        )
        primary = engine.fraction("primary", Selection(subdomains=["4.3"]))
        any_label = engine.fraction(
            "any", Selection(subdomains=["4.3"], classification="any")
        )
        assignment = engine.fraction(
            "assignments",
            Selection(subdomains=["4.3"], classification="any"),
            denominator="subdomain_assignments",
        )
        self.assertEqual((primary.numerator, any_label.numerator), (1, 2))
        self.assertEqual((any_label.denominator, assignment.denominator), (2, 3))
        self.assertEqual(assignment.percent, 200 / 3)

    def test_parent_any_domain_deduplicates_subdomains(self) -> None:
        engine = self.engine(
            raw_row(1, additional_subdomains=json.dumps([{"code": "1.2 Toxic"}]))
        )
        result = engine.fraction(
            "domain", Selection(domains=["1"], classification="any")
        )
        self.assertEqual(result.numerator, 1)

    def test_zero_denominator_is_undefined_not_zero(self) -> None:
        engine = self.engine(raw_row(1))
        result = engine.fraction("empty", population=Selection(years=[2025]))
        self.assertEqual(
            (result.numerator, result.denominator, result.percent), (0, 0, None)
        )

    def test_same_dimension_or_cross_dimension_and(self) -> None:
        engine = self.engine(
            raw_row(1, causal_entity="AI"),
            raw_row(2, causal_entity="Human"),
            raw_row(3, causal_entity="Human", causal_intent="Intentional"),
        )
        selected = engine.fraction(
            "orand",
            Selection(
                equals={
                    "causal_entity": ["AI", "Human"],
                    "causal_intent": ["Unintentional"],
                }
            ),
        )
        self.assertEqual(selected.numerator, 2)

    def test_primary_secondary_purpose_count_once(self) -> None:
        engine = self.engine(
            raw_row(1, ai_goal_primary="Chatbot", ai_goal_secondary="Chatbot"),
            raw_row(
                2, ai_goal_primary="Writing Assistant", ai_goal_secondary="Chatbot"
            ),
        )
        result = engine.fraction(
            "purpose",
            Selection(purposes=["Chatbot"], purpose_scope="primary_or_secondary"),
        )
        self.assertEqual((result.numerator, result.denominator), (2, 2))

    def test_identifier_duplicates_fail_and_paths_with_spaces_work(self) -> None:
        with tempfile.TemporaryDirectory(prefix="tracker test ") as directory:
            path = Path(directory) / "input with spaces.csv"
            first = raw_row(1)
            with path.open("w", newline="", encoding="utf-8") as handle:
                writer = csv.DictWriter(handle, fieldnames=list(first))
                writer.writeheader()
                writer.writerows([first, first])
            with self.assertRaisesRegex(ValueError, "Duplicate incident IDs"):
                load_incidents(path, DAY)
            with path.open("w", newline="", encoding="utf-8") as handle:
                writer = csv.DictWriter(handle, fieldnames=list(first))
                writer.writeheader()
                writer.writerow({**first, "title": 'Comma, quote " and\nnewline'})
            rows = load_incidents(path, DAY)
            self.assertEqual(len(rows), 1)
            self.assertIn("\n", rows[0].raw["title"])

    def test_denominator_contract_rejects_assignment_as_incident(self) -> None:
        engine = self.engine(raw_row(1))
        value = engine.fraction("one").model_dump()
        value.update(denominator=2, percent=50)
        with self.assertRaises(ValueError):
            Measure.model_validate(value)


class TimeLogicTests(unittest.TestCase):
    def test_endpoint_decline_does_not_imply_annual_decline(self) -> None:
        points = [
            {"year": 2021 + i, "numerator": n, "denominator": 10}
            for i, n in enumerate([5, 3, 4, 2])
        ]
        result = trend(points)
        self.assertEqual(result["endpoint_delta_pp"], -30)
        self.assertFalse(result["strictly_decreasing_share"])
        self.assertEqual(result["steps"][1]["share_direction"], "up")

    def test_count_growth_can_coexist_with_share_decline(self) -> None:
        result = trend(
            [
                {"year": 2024, "numerator": 33, "denominator": 80},
                {"year": 2025, "numerator": 45, "denominator": 452},
            ]
        )
        self.assertTrue(result["strictly_increasing_count"])
        self.assertTrue(result["strictly_decreasing_share"])
        self.assertGreater(result["relative_count_change_pct"], 0)

    def test_missing_year_does_not_pass_trend(self) -> None:
        result = trend(
            [
                {"year": 2021, "numerator": 1, "denominator": 10},
                {"year": 2023, "numerator": 3, "denominator": 10},
            ]
        )
        self.assertFalse(result["evaluable"])
        self.assertFalse(result["strictly_increasing_share"])

    def test_zero_denominator_and_flat_do_not_pass_strict_trend(self) -> None:
        result = trend(
            [
                {"year": 2021, "numerator": 0, "denominator": 0},
                {"year": 2022, "numerator": 3, "denominator": 10},
            ]
        )
        self.assertFalse(result["strictly_increasing_share"])
        flat = trend(
            [
                {"year": 2021, "numerator": 3, "denominator": 10},
                {"year": 2022, "numerator": 6, "denominator": 20},
            ]
        )
        self.assertFalse(flat["strictly_increasing_share"])
        self.assertEqual(flat["steps"][0]["share_direction"], "flat")

    def test_current_year_excluded_from_full_year_comparison(self) -> None:
        config = AnalysisConfig.model_validate_json(
            (ROOT / "config/analysis.json").read_text()
        )
        engine = Engine([parse_row(raw_row(1, year=2026), DAY)], config, DAY)
        with self.assertRaisesRegex(ValueError, "incomplete"):
            engine.series("bad", Selection(), 2025, 2026)

    def test_series_populates_missing_year_without_inventing_proportion(self) -> None:
        config = AnalysisConfig.model_validate_json(
            (ROOT / "config/analysis.json").read_text()
        )
        engine = Engine(
            [
                parse_row(raw_row(1, year=2023), DAY),
                parse_row(raw_row(2, year=2025), DAY),
            ],
            config,
            DAY,
        )
        result = engine.series("gap", Selection(), 2023, 2025)
        self.assertIsNone(result["points"][1]["percent"])
        self.assertFalse(result["trend"]["evaluable"])

    def test_classification_date_does_not_choose_incident_year(self) -> None:
        row = parse_row(raw_row(1, year=2019), DAY)
        self.assertEqual(row.year, 2019)

    def test_monthly_and_fortnightly_schedule(self) -> None:
        self.assertEqual(next_due(date(2026, 1, 31), "monthly"), date(2026, 2, 28))
        self.assertEqual(next_due(date(2026, 12, 31), "monthly"), date(2027, 1, 31))
        self.assertEqual(next_due(date(2026, 9, 27), "fortnightly"), date(2026, 10, 11))


class HarmLogicTests(unittest.TestCase):
    def test_level_one_is_not_above_negligible(self) -> None:
        row = parse_row(raw_row(1), DAY)
        self.assertEqual(severity_state(row, SeveritySpec(threshold=2)), (False, False))

    def test_zero_is_unknown_lower_upper_bounds(self) -> None:
        row = parse_row(raw_row(1, physical_harm_severity_direct="0"), DAY)
        self.assertEqual(severity_state(row, SeveritySpec(threshold=4)), (False, True))

    def test_inferred_score_does_not_enter_direct_indirect(self) -> None:
        row = parse_row(raw_row(1, financial_loss_severity_inferred="4"), DAY)
        self.assertEqual(severity_state(row, SeveritySpec(threshold=4)), (False, False))
        self.assertEqual(
            severity_state(
                row,
                SeveritySpec(channels=["direct", "indirect", "inferred"], threshold=4),
            ),
            (True, True),
        )

    def test_added_dimensions_do_not_enter_original_ten(self) -> None:
        row = parse_row(raw_row(1, psychological_harm_severity_direct="4"), DAY)
        self.assertFalse(
            severity_state(row, SeveritySpec(dimensions=10, threshold=4))[0]
        )
        self.assertTrue(
            severity_state(row, SeveritySpec(dimensions=13, threshold=4))[0]
        )

    def test_multiple_categories_count_dimensions_not_channels(self) -> None:
        row = parse_row(
            raw_row(
                1,
                financial_loss_severity_direct="4",
                financial_loss_severity_indirect="4",
            ),
            DAY,
        )
        self.assertFalse(
            severity_state(row, SeveritySpec(threshold=4, minimum_categories=2))[0]
        )

    def test_invalid_score_fails(self) -> None:
        with self.assertRaisesRegex(ValueError, "outside"):
            parse_row(raw_row(1, physical_harm_severity_direct="6"), DAY)


class ClaimAndSelectionTests(unittest.TestCase):
    def setUp(self) -> None:
        self.config = AnalysisConfig.model_validate_json(
            (ROOT / "config/analysis.json").read_text()
        )

    def test_small_baseline_cannot_become_candidate_despite_large_share_shift(
        self,
    ) -> None:
        engine = Engine([], self.config, DAY)
        result = comparison_eligibility(
            engine,
            {"numerator": 3, "denominator": 80, "percent": 3.75},
            {"numerator": 192, "denominator": 452, "percent": 19200 / 452},
        )
        self.assertFalse(result["passed"])
        self.assertIn("endpoint category count below minimum", result["reasons"])

    def test_historical_claim_does_not_roll_to_new_analysis_year(self) -> None:
        rows = []
        for i, year in enumerate(range(2022, 2026)):
            for j in range(10):
                rows.append(
                    parse_row(
                        raw_row(
                            i * 10 + j + 1,
                            year=year,
                            eu_ai_act_risk_level="1" if j <= i else "3",
                        ),
                        date(2027, 1, 2),
                    )
                )
        rows.append(
            parse_row(
                raw_row(100, year=2026, eu_ai_act_risk_level="3"), date(2027, 1, 2)
            )
        )
        engine = Engine(rows, self.config, date(2027, 1, 2))
        result = current_check(
            engine,
            {"claim_id": "TEST"},
            {
                "handler": "eu_annual",
                "years": [2022, 2025],
                "level": "1",
                "published_endpoint_percent": 40,
                "rounding_decimals": 0,
            },
        )
        self.assertEqual(result["status"], SUPPORTED)
        self.assertNotIn("claim.TEST.level1.2026", engine.measures)

    def test_rounding_endpoint_does_not_rescue_false_annual_trend(self) -> None:
        rows = []
        for i, count in enumerate([1, 3, 2, 4]):
            for j in range(10):
                rows.append(
                    parse_row(
                        raw_row(
                            i * 10 + j + 1,
                            year=2022 + i,
                            eu_ai_act_risk_level="1" if j < count else "3",
                        ),
                        DAY,
                    )
                )
        engine = Engine(rows, self.config, DAY)
        result = current_check(
            engine,
            {"claim_id": "TEST"},
            {
                "handler": "eu_annual",
                "years": [2022, 2025],
                "level": "1",
                "published_endpoint_percent": 40,
                "rounding_decimals": 0,
            },
        )
        self.assertEqual(result["status"], UNSUPPORTED)
        self.assertEqual(result["component_checks"][1]["status"], SUPPORTED)


if __name__ == "__main__":
    unittest.main()
