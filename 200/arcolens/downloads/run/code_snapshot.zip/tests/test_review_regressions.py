"""Regression counterexamples supplied by the independent in-session verifier."""

from __future__ import annotations

import json
import unittest
from datetime import date

from tests.test_analysis import DAY, ROOT, raw_row
from tracker.audit import archival_check, current_check
from tracker.calc import Engine, trend
from tracker.candidates import candidate_shortlist
from tracker.data import parse_row
from tracker.models import AnalysisConfig, Selection
from tracker.report import robustness_summary


class IndependentReviewRegressions(unittest.TestCase):
    def setUp(self) -> None:
        self.config = AnalysisConfig.model_validate_json(
            (ROOT / "config/analysis.json").read_text()
        )

    def engine(self, rows: list[dict[str, str]], day: date = DAY) -> Engine:
        return Engine([parse_row(row, day) for row in rows], self.config, day)

    def shortlist(self, rows: list[dict[str, str]]) -> tuple[Engine, dict[str, object]]:
        engine = self.engine(rows)
        candidates, _ = candidate_shortlist(
            engine, {"start_year": 2021, "end_year": 2025}
        )
        return engine, {item.candidate_id: item for item in candidates}

    def test_absent_baseline_cohort_is_withheld_not_a_crash(self) -> None:
        _, candidates = self.shortlist([raw_row(1, year=2025)])
        self.assertEqual(candidates["IT-C001"].review_state, "withheld")
        self.assertEqual(candidates["IT-C002"].review_state, "withheld")
        self.assertIn("undefined", candidates["IT-C001"].finding)

    def test_absent_robustness_category_is_withheld(self) -> None:
        _, candidates = self.shortlist([raw_row(1, year=2021), raw_row(2, year=2025)])
        self.assertEqual(candidates["IT-C002"].review_state, "withheld")
        self.assertIn("undefined", candidates["IT-C002"].finding)

    def test_single_purpose_has_no_invented_runner_up(self) -> None:
        _, candidates = self.shortlist([raw_row(1, year=2021), raw_row(2, year=2025)])
        self.assertIn(
            "no second primary-purpose category",
            candidates["IT-C003"].proposed_website_text,
        )

    def test_count_candidate_requires_both_endpoint_samples(self) -> None:
        rows = [raw_row(i + 1, year=2021) for i in range(80)] + [
            raw_row(100 + i, year=2025) for i in range(20)
        ]
        _, candidates = self.shortlist(rows)
        self.assertFalse(candidates["IT-C001"].eligibility["passed"])

    def test_count_and_share_direction_wording_is_derived(self) -> None:
        rows = [
            raw_row(i + 1, year=2021, primary="7.3" if i < 2 else "1.1")
            for i in range(10)
        ]
        rows += [
            raw_row(100 + i, year=2025, primary="7.3" if i < 8 else "1.1")
            for i in range(20)
        ]
        _, candidates = self.shortlist(rows)
        self.assertIn(
            "share direction is up; the count direction is up",
            candidates["IT-C002"].finding,
        )
        self.assertNotIn("directions differ", candidates["IT-C002"].finding)

    def test_majority_wording_and_undated_population(self) -> None:
        rows = [
            raw_row(
                i + 1,
                ai_goal_primary="Chatbot" if i < 8 else "Writing Assistant",
                date="",
            )
            for i in range(10)
        ]
        _, candidates = self.shortlist(rows)
        text = candidates["IT-C003"].finding
        self.assertIn("majority of incident records", text)
        self.assertNotIn("not a majority", text)
        self.assertIn("all export records", text)

    def test_zero_exclusion_is_recomputed_from_new_id(self) -> None:
        rows = [
            raw_row(1),
            raw_row(2),
            raw_row(900001, physical_harm_severity_direct="0"),
        ]
        _, candidates = self.shortlist(rows)
        variant = next(
            v
            for v in candidates["IT-C005"].robustness
            if v["alternative"].startswith("exclude records with any zero")
        )
        self.assertEqual(variant["points"][0]["denominator"], 2)
        self.assertEqual(
            variant["points"][0]["definition"]["population"]["exclude_ids"], ["900001"]
        )

    def test_nan_inf_negative_and_out_of_range_scores_fail_ingestion(self) -> None:
        for field, value in (
            ("natsec_overall_score", "NaN"),
            ("total_people_reported_harmed", "inf"),
            ("total_people_reported_exposed", "-1"),
            ("natsec_overall_score", "6"),
        ):
            with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                parse_row(raw_row(1, **{field: value}), DAY)

    def test_composite_assignment_share_is_rejected(self) -> None:
        engine = self.engine(
            [raw_row(1, additional_subdomains=json.dumps([{"code": "4.3 Fraud"}]))]
        )
        with self.assertRaisesRegex(ValueError, "exactly one"):
            engine.fraction(
                "bad",
                Selection(subdomains=["1.1", "4.3"], classification="any"),
                denominator="subdomain_assignments",
            )

    def test_archived_malicious_people_claim_restricts_subgroup(self) -> None:
        engine = self.engine(
            [
                raw_row(
                    1,
                    year=2023,
                    primary="7.3",
                    total_people_reported_harmed="2000",
                    financial_loss_severity_direct="3",
                ),
                raw_row(
                    2,
                    year=2023,
                    primary="4.3",
                    total_people_reported_harmed="2000",
                    financial_loss_severity_direct="3",
                ),
            ]
        )
        claim_id = "ARCH-TIMELINE-NUMBER-OF-PEOPLE-AFFECTED-02"
        archival_check(engine, {"claim_id": claim_id})
        self.assertEqual(
            engine.measures[
                f"claim.{claim_id}.reported_people_and_score3.2023"
            ].numerator,
            1,
        )

    def test_archived_page_scope_remains_fixed_with_2027_analysis(self) -> None:
        engine = self.engine(
            [
                raw_row(1, year=2024, primary="7.3"),
                raw_row(2, year=2014, primary="7.3"),
                raw_row(3, year=2026, primary="7.3"),
            ],
            date(2027, 1, 2),
        )
        identifier = "ARCH-TIMELINE-SUB-DOMAINS-03"
        archival_check(engine, {"claim_id": identifier})
        self.assertEqual(
            engine.measures[f"claim.{identifier}.robustness"].denominator, 1
        )
        archival_check(engine, {"claim_id": "ARCH-TIMELINE-SUB-DOMAINS-01"})
        self.assertNotIn("claim.ARCH-TIMELINE-SUB-DOMAINS-01.1.1.2026", engine.measures)

    def test_chart_presets_use_string_years_and_bound_container(self) -> None:
        _, candidates = self.shortlist([raw_row(1, year=2021), raw_row(2, year=2025)])
        for identifier in ("IT-C001", "IT-C002", "IT-C004"):
            config = candidates[identifier].chart_configuration
            self.assertTrue(
                all(
                    isinstance(year, str)
                    for year in config["programmatic_preset"]["year"]
                )
            )
            self.assertEqual(config["dataset"], "incidents-arcola")
            self.assertTrue(config["container_id"])

    def test_count_table_exposes_prior_year_reversal(self) -> None:
        points = [
            {"year": 2020, "numerator": 92, "denominator": 92, "percent": 100},
            {"year": 2021, "numerator": 80, "denominator": 80, "percent": 100},
        ]
        text = robustness_summary(
            {"display_unit": "counts", "points": points, "trend": trend(points)}
        )
        self.assertIn("92 records", text)
        self.assertIn("2020→2021 down", text)
        self.assertIn("-12 records", text)
        self.assertNotIn("100.0%", text)

    def test_paired_labels_and_delta_are_rendered(self) -> None:
        text = robustness_summary(
            {
                "points": [
                    {
                        "label": "direct+indirect",
                        "numerator": 1,
                        "denominator": 10,
                        "percent": 10,
                    },
                    {
                        "label": "all channels",
                        "numerator": 2,
                        "denominator": 10,
                        "percent": 20,
                    },
                ],
                "delta_pp": 10,
            }
        )
        self.assertIn("direct+indirect", text)
        self.assertIn("all channels", text)
        self.assertIn("+10.00 pp", text)

    def test_timing_claim_with_no_complete_year_records_is_unverifiable(self) -> None:
        engine = self.engine([raw_row(1, year=2026)])
        result = current_check(
            engine,
            {"claim_id": "TEST"},
            {
                "handler": "timing_any_year",
                "context_start": 2016,
                "vague_terms": ["few"],
            },
        )
        self.assertIn("Not verifiable", result["status"])


if __name__ == "__main__":
    unittest.main()
