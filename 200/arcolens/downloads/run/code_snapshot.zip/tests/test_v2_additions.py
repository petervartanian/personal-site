"""Regression tests for the second version's additions: data-driven discovery (including the
emergence rule and routing), export comparison with content-derived provenance, read-only claim
refresh, and the provider adapter's grounding checks.

Every dataset in this file is SYNTHETIC, built with tests/test_analysis.raw_row or tiny in-memory
fixtures. Nothing here is a real export or a historical observation.
"""

from __future__ import annotations

import csv
import json
import tempfile
import unittest
from pathlib import Path

from tests.test_analysis import DAY, ROOT, raw_row
from tracker.calc import Engine
from tracker.candidates import candidate_shortlist
from tracker.compare import compare_exports, run_comparison
from tracker.data import parse_row
from tracker.discovery import DiscoveryConfig, discover
from tracker.explore import build_facts, explore
from tracker.llm_adapter import FakeProvider, ground_candidate
from tracker.models import AnalysisConfig
from tracker.refresh import capture_fetcher, quote_status, refresh_claims

CONFIG = AnalysisConfig.model_validate_json(
    (ROOT / "config/analysis.json").read_text(encoding="utf-8")
)
DCONFIG = DiscoveryConfig.model_validate_json(
    (ROOT / "config/discovery.json").read_text(encoding="utf-8")
)


def two_cohort_export(
    rising: str, falling: str, first_share: float = 0.10
) -> list[dict[str, str]]:
    """'rising' grows from first_share to 60% of each year's records; 'falling' shrinks; 1.1 fills."""
    rows: list[dict[str, str]] = []
    n = 0
    for year, share in (
        (2021, first_share),
        (2022, 0.20),
        (2023, 0.35),
        (2024, 0.50),
        (2025, 0.60),
    ):
        total = 120
        k = int(total * share)
        for i in range(total):
            n += 1
            primary = (
                rising if i < k else (falling if i < k + (total - k) // 2 else "1.1")
            )
            rows.append(raw_row(n, year=year, primary=primary))
    return rows


def run_discovery(rows: list[dict[str, str]], dconfig: DiscoveryConfig = DCONFIG):
    engine = Engine([parse_row(r, DAY) for r in rows], CONFIG, DAY)
    facts = build_facts(engine)
    ledger = explore(engine)
    templates, _ = candidate_shortlist(engine, facts)
    discovered, dledger = discover(engine, facts, ledger, dconfig)
    return templates, discovered, dledger


def decisions(ledger: dict) -> dict[str, dict]:
    return {e["name"]: e for e in ledger["entries"]}


class DiscoveryTests(unittest.TestCase):
    def test_changed_input_changes_discovered_shortlist_but_not_templates(self) -> None:
        templates_a, _, ledger_a = run_discovery(two_cohort_export("2.1", "5.1"))
        templates_b, _, ledger_b = run_discovery(two_cohort_export("6.3", "3.2"))
        selected_a = {
            e["name"] for e in ledger_a["entries"] if e["decision"] == "selected"
        }
        selected_b = {
            e["name"] for e in ledger_b["entries"] if e["decision"] == "selected"
        }
        self.assertEqual(
            [c.candidate_id for c in templates_a], [c.candidate_id for c in templates_b]
        )
        self.assertNotEqual(selected_a, selected_b)
        self.assertIn("primary:2.1", selected_a)
        self.assertIn("primary:6.3", selected_b)

    def test_emergence_from_a_small_base_is_admitted_and_selected(self) -> None:
        # 2.1 has 2 of 120 records in 2021 (below the 10-record screen) and 72 of 120 in 2025.
        _, discovered, ledger = run_discovery(
            two_cohort_export("2.1", "5.1", first_share=0.02)
        )
        entry = decisions(ledger)["primary:2.1"]
        self.assertTrue(entry["emergence_candidate"])
        self.assertEqual(entry["family"], "emergence")
        self.assertEqual(entry["decision"], "selected")
        self.assertTrue(any("emergence rule" in c.finding for c in discovered))

    def test_emergence_with_final_step_reversal_is_not_stable(self) -> None:
        rows: list[dict[str, str]] = []
        n = 0
        for year, share in (
            (2021, 0.02),
            (2022, 0.30),
            (2023, 0.50),
            (2024, 0.70),
            (2025, 0.55),
        ):
            for i in range(120):
                n += 1
                rows.append(
                    raw_row(
                        n, year=year, primary="2.1" if i < int(120 * share) else "1.1"
                    )
                )
        _, _, ledger = run_discovery(rows)
        entry = decisions(ledger)["primary:2.1"]
        self.assertTrue(entry["emergence_candidate"])
        self.assertEqual(entry["decision"], "withheld_unstable")

    def test_published_topic_is_routed_and_eu_complement_is_explicit(self) -> None:
        rows = two_cohort_export("7.3", "5.1")
        for index, row in enumerate(rows):
            row["eu_ai_act_risk_level"] = (
                "3" if (index % 10 < 8 and int(row["date"][:4]) >= 2024) else "2"
            )
        _, discovered, ledger = run_discovery(rows)
        entries = decisions(ledger)
        self.assertEqual(entries["primary:7.3"]["decision"], "route_to_claim_audit")
        self.assertIn("TIME-02", entries["primary:7.3"]["published_claim_ids"])
        self.assertEqual(
            entries["eu_ai_act_risk_level:2"]["decision"], "route_to_claim_audit"
        )
        self.assertEqual(
            entries["eu_ai_act_risk_level:3"]["decision"], "complement_of_audited_claim"
        )
        self.assertIn("+", entries["eu_ai_act_risk_level:3"]["reason"])
        self.assertFalse(
            any("7.3" in c.title or "EU AI Act" in c.title for c in discovered)
        )

    def test_near_tautology_and_archived_matches_are_withheld(self) -> None:
        rows = [
            raw_row(i, year=2021 + (i % 5), primary="7.3" if i % 30 else "7.1")
            for i in range(1, 301)
        ]
        rows += [
            raw_row(400 + i, year=2021 + (i % 5), primary="3.1" if i % 4 else "3.2")
            for i in range(1, 121)
        ]
        _, discovered, ledger = run_discovery(rows)
        entries = decisions(ledger)
        self.assertIn(
            entries["7:7.3"]["decision"],
            {"route_to_archived_replay", "withheld_near_tautology"},
        )
        self.assertFalse(any(c.title.startswith("7.3") for c in discovered))
        strict = DCONFIG.model_copy(
            update={"published_signatures": [], "concentration_near_tautology_pct": 95}
        )
        _, _, ledger_strict = run_discovery(rows, strict)
        self.assertEqual(
            decisions(ledger_strict)["7:7.3"]["decision"], "withheld_near_tautology"
        )

    def test_every_eligible_cell_has_an_explained_decision_and_no_novelty_weight(
        self,
    ) -> None:
        _, discovered, ledger = run_discovery(two_cohort_export("2.1", "5.1"))
        self.assertNotIn("novelty", ledger["weights"])
        for entry in ledger["entries"]:
            self.assertIsNotNone(entry["decision"])
            self.assertTrue(entry["reason"])
            if entry["decision"] == "selected":
                self.assertEqual(set(entry["components"]), set(DCONFIG.weights))
        self.assertLessEqual(len(discovered), DCONFIG.max_discovered_candidates)
        for candidate in discovered:
            self.assertEqual(candidate.selection_stage, "data_driven_discovery")
            self.assertEqual(candidate.review_state, "human_review_required")

    def test_low_information_ranking_is_not_selected(self) -> None:
        rows = [
            raw_row(i + 1, year=2021 + (i % 5), causal_timing="Post-deployment")
            for i in range(300)
        ]
        _, _, ledger = run_discovery(rows)
        timing = [
            e
            for e in ledger["entries"]
            if e["ledger_family"] == "ranking" and e["name"] == "causal_timing"
        ]
        self.assertTrue(timing)
        self.assertNotEqual(timing[0]["decision"], "selected")

    def test_rise_from_small_base_is_not_penalised_relative_to_its_complement(
        self,
    ) -> None:
        _, _, ledger = run_discovery(two_cohort_export("2.1", "5.1"))
        by_name = {e["name"]: e for e in ledger["entries"] if e["score"] is not None}
        self.assertGreaterEqual(
            by_name["primary:2.1"]["score"], by_name["primary:5.1"]["score"]
        )


class CompareTests(unittest.TestCase):
    def test_added_removed_reclassified_and_backfill_are_reported(self) -> None:
        previous = [
            parse_row(r, DAY)
            for r in (
                raw_row(1, year=2023, primary="7.3"),
                raw_row(2, year=2024, primary="4.3"),
                raw_row(3, year=2024),
            )
        ]
        current = [
            parse_row(r, DAY)
            for r in (
                raw_row(1, year=2023, primary="7.1"),
                raw_row(2, year=2024, primary="4.3", eu_ai_act_risk_level="1"),
                raw_row(4, year=2022, primary="2.1"),
            )
        ]
        result = compare_exports(previous, current)
        self.assertEqual(result["counts"]["added"], 1)
        self.assertEqual(result["counts"]["removed"], 1)
        self.assertEqual(
            result["field_changes"]["subdomain_code"]["changed_records"], 1
        )
        self.assertEqual(result["transitions"]["eu_ai_act_risk_level"][0]["records"], 1)
        backfill = next(a for a in result["annual_cohorts"] if a["year"] == "2022")
        self.assertEqual(backfill["added_records_dated_this_year"], 1)

    def test_synthetic_inputs_are_detected_from_content_and_never_historical(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for name, rows in (
                ("prev.csv", [raw_row(1)]),
                ("cur.csv", [raw_row(1), raw_row(2)]),
            ):
                with (root / name).open("w", newline="", encoding="utf-8") as handle:
                    writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
                    writer.writeheader()
                    writer.writerows(rows)
            result = run_comparison(
                root / "prev.csv", DAY, root / "cur.csv", DAY, root / "out", ROOT
            )
            self.assertTrue(result["inputs"]["synthetic"])
            self.assertFalse(result["inputs"]["historical_observation"])
            self.assertEqual(
                result["inputs"]["previous"]["provenance"], "unregistered_input"
            )
            self.assertIn("SYNTHETIC", result["WARNING"])
            self.assertTrue(
                (root / "out/export_comparison.md")
                .read_text(encoding="utf-8")
                .startswith("> **SYNTHETIC")
            )


class RefreshTests(unittest.TestCase):
    def test_pinned_captures_reproduce_every_current_quote_and_app_source_hash(
        self,
    ) -> None:
        registry = json.loads(
            (ROOT / "research/published_claims_raw.json").read_text(encoding="utf-8")
        )
        with tempfile.TemporaryDirectory() as directory:
            report = refresh_claims(
                registry,
                capture_fetcher(ROOT, registry),
                Path(directory),
                mode="offline-captures",
            )
        self.assertEqual(report["summary"]["absent"], 0)
        self.assertEqual(report["summary"]["changed"], 0)
        self.assertEqual(report["summary"]["app_source_changed_quote_unverifiable"], 0)
        self.assertEqual(
            report["summary"]["reference_source_changed_quote_unverifiable"], 0
        )
        self.assertGreater(report["summary"]["app_source_unchanged"], 0)
        self.assertEqual(report["summary"]["page_unavailable"], 0)
        self.assertFalse(report["summary"]["registry_edited"])
        self.assertFalse(report["summary"]["javascript_rendered_text_checked"])

    def test_quote_status_distinguishes_present_changed_absent(self) -> None:
        page = "Intro. The proportion of incidents rose between 2021 and 2025 in every year. End."
        self.assertEqual(
            quote_status(
                "The proportion of incidents rose between 2021 and 2025 in every year",
                page,
            )[0],
            "present",
        )
        self.assertEqual(
            quote_status(
                "The proportion of incidents rose between 2021 and 2025 in every single year",
                page,
            )[0],
            "changed",
        )
        self.assertEqual(
            quote_status("Something entirely unrelated appears here", page)[0], "absent"
        )


class AdapterTests(unittest.TestCase):
    CALCULATIONS = {
        "c1": {
            "numerator": 33,
            "denominator": 80,
            "denominator_incident_count": 80,
            "percent": 41.25,
        },
        "c2": {
            "numerator": 45,
            "denominator": 452,
            "denominator_incident_count": 452,
            "percent": 9.955752212389381,
        },
    }

    def candidate(self, extra: str = "") -> dict:
        return {
            "candidate_id": "X",
            "evidence_ids": ["c1", "c2"],
            "finding": "33/80 (41.2%) in 2021 versus 45/452 (10.0%) in 2025: -31.29 percentage points; counts +36.4%."
            + extra,
            "proposed_website_text": "Shares fell from 41.2% to 10.0%.",
        }

    def test_grounded_text_passes(self) -> None:
        self.assertTrue(
            ground_candidate(self.candidate(), self.CALCULATIONS, {2021, 2025})[
                "grounded"
            ]
        )

    def test_ungrounded_integer_percent_and_points_are_flagged(self) -> None:
        report = ground_candidate(
            self.candidate(
                " Also 999 records, 77.7% agreed, a 12.5 percentage point gap."
            ),
            self.CALCULATIONS,
            {2021, 2025},
        )
        self.assertFalse(report["grounded"])
        self.assertIn(999, report["unexplained_integers"])
        self.assertIn("77.7", report["unexplained_percentages"])
        self.assertIn("12.5", report["unexplained_percentage_points"])

    def test_fake_provider_never_authorises_publication(self) -> None:
        bundle = {
            "run_id": "r",
            "bundle_sha256": "x",
            "candidate_first_draft": [],
            "prompt_version": "p",
        }
        response = FakeProvider().generate(
            "system", json.dumps(bundle), "claude-opus-5", "high"
        )
        self.assertFalse(json.loads(response.raw_text)["publication_authorized"])
        self.assertTrue(response.request_id)


if __name__ == "__main__":
    unittest.main()
