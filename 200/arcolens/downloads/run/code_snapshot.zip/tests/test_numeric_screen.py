from __future__ import annotations
import unittest
from copy import deepcopy

from tracker.numeric_screen import screen_text

EVIDENCE = {
    "analysis_date": "2026-09-27",
    "calculations": {
        "a": {
            "numerator": 33,
            "denominator": 80,
            "denominator_incident_count": 80,
            "percent": 41.25,
            "definition": {"target": {"subdomains": ["3.1"]}},
        },
        "b": {
            "numerator": 45,
            "denominator": 452,
            "denominator_incident_count": 452,
            "percent": 100 * 45 / 452,
            "definition": {},
        },
    },
}


class NumericScreenTests(unittest.TestCase):
    def test_short_snapshot_date_requires_matching_date_and_label(self):
        self.check("The September 27 export", True)
        self.check("The September 28 export", False)
        self.check("There were 27 incidents", False)

    def test_exact_high_precision_share_is_valid_but_nearby_value_is_not(self):
        evidence = deepcopy(EVIDENCE)
        evidence["calculations"]["a"].update(
            numerator=1, denominator=32, denominator_incident_count=32, percent=3.125
        )
        self.assertTrue(screen_text("1 of 32 (3.125%)", ["a"], evidence)["grounded"])
        self.assertFalse(screen_text("1 of 32 (3.126%)", ["a"], evidence)["grounded"])

    def test_chart_incident_reference_does_not_become_a_count_allowance(self):
        evidence = deepcopy(EVIDENCE)
        evidence["candidates"] = [
            {
                "evidence_ids": ["a"],
                "chart_configuration": {"filters": {"incident_id": "544"}},
            }
        ]
        self.assertTrue(screen_text("Open incident 544", ["a"], evidence)["grounded"])
        self.assertFalse(screen_text("544 records", ["a"], evidence)["grounded"])
        self.assertFalse(screen_text("Open incident 545", ["a"], evidence)["grounded"])
        self.assertFalse(screen_text("Open incident 544", ["b"], evidence)["grounded"])

    def test_half_up_display_rounding_is_valid(self):
        self.assertTrue(screen_text("33 of 80 (41.3%)", ["a"], EVIDENCE)["grounded"])

    def check(self, text: str, expected: bool) -> None:
        result = screen_text(text, ["a", "b"], EVIDENCE)
        self.assertEqual(result["grounded"], expected, (text, result))

    def test_calendar_dates(self):
        for text in (
            "September 27, 2026",
            "27 September 2026",
            "2026-09-27",
            "Sep. 27, 2026",
        ):
            with self.subTest(text=text):
                self.check(text, True)

    def test_day_is_not_a_global_count(self):
        self.check("There were 27 incidents.", False)

    def test_invalid_calendar_date(self):
        self.check("September 31, 2026", False)

    def test_future_calendar_date(self):
        self.check("September 27, 2099", False)

    def test_correct_counts_shares(self):
        self.check("45 of 452 records (9.96%)", True)

    def test_percent_word(self):
        self.check("41.25 percent", True)

    def test_bad_percent_word(self):
        self.check("999.99 percent", False)

    def test_bad_decimal_count(self):
        self.check("999999.5 incidents", False)

    def test_bad_scientific_count(self):
        self.check("9e9 incidents", False)

    def test_relative_change(self):
        self.check("33 to 45, up 12 records (36.4%).", True)

    def test_unsupported_relative_change(self):
        self.check("33 to 45, up 36.5%.", False)

    def test_percentage_points(self):
        self.check("Down 31.29 percentage points.", True)

    def test_grouped_number(self):
        self.check("999,999.5 incidents", False)

    def test_cited_taxonomy_code(self):
        self.check("Subdomain 3.1", True)

    def test_uncited_taxonomy_code(self):
        self.check("Subdomain 9.8", False)

    def test_no_year_difference_allowance(self):
        self.check("There were 1947 incidents.", False)

    def test_no_denominator_difference_allowance(self):
        self.check("There were 372 incidents.", False)

    def test_unknown_reference(self):
        self.assertFalse(screen_text("45", ["bad"], EVIDENCE)["grounded"])

    def test_sentence_final_number(self):
        self.check("There were 999999.", False)

    def test_known_number_at_sentence_end(self):
        self.check("The count was 45.", True)

    def test_negative_unobserved_count(self):
        self.check("There were -45 incidents.", False)

    def test_leading_decimal(self):
        self.check("There were .5 incidents.", False)


if __name__ == "__main__":
    unittest.main()
