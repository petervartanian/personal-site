"""Failures that must prevent a model response from being accepted."""

import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace

from pydantic import ValidationError
from tracker.editorial import (
    EditorialDraft,
    EditorialReview,
    invoke_cli,
    screen_text,
    strict_schema,
    validate_draft,
    validate_review,
)

EVIDENCE = {
    "run_id": "run-1",
    "analysis_date": "2026-09-27",
    "candidates": [{"candidate_id": "C1"}],
    "published_claims": [{"claim_id": "P1"}],
    "calculations": {
        "m1": {
            "numerator": 33,
            "denominator": 80,
            "denominator_incident_count": 80,
            "percent": 41.25,
        }
    },
}


def candidate():
    return {
        "candidate_id": "C1",
        "suggested_wording": "33 of 80 records (41.25%) in 2021.",
        "chart": dict.fromkeys(
            [
                "display",
                "stack_by",
                "filters",
                "time_window",
                "counts_or_proportions",
                "compatibility",
            ],
            "Test",
        ),
        "calculation_confidence": "Reproduced",
        "interpretation_confidence": "Limited",
        "caveats": [],
        "evidence_ids": ["m1"],
    }


class EditorialTests(unittest.TestCase):
    def draft(self, **changes):
        payload = {
            "run_id": "run-1",
            "evidence_sha256": "abc",
            "candidates": [candidate()],
            "concerns": [],
            "publication_authorized": False,
        }
        return EditorialDraft.model_validate({**payload, **changes})

    def test_draft_requires_exact_complete_unique_items(self):
        self.assertTrue(validate_draft(self.draft(), EVIDENCE, "abc")["all_grounded"])
        for rows in ([], [candidate(), candidate()]):
            with self.assertRaises(ValueError):
                validate_draft(self.draft(candidates=rows), EVIDENCE, "abc")
        with self.assertRaises(ValueError):
            validate_draft(self.draft(evidence_sha256="stale"), EVIDENCE, "abc")

    def test_numbers_are_not_just_arbitrary_year_differences(self):
        self.assertFalse(screen_text("47 records (41%)", ["m1"], EVIDENCE)["grounded"])
        self.assertFalse(
            screen_text("33 records (41.5%)", ["m1"], EVIDENCE)["grounded"]
        )
        self.assertFalse(screen_text("33 of 80", ["missing"], EVIDENCE)["grounded"])
        self.assertTrue(
            screen_text("33 of 80 (41.2%) in 2021; ten dimensions", ["m1"], EVIDENCE)[
                "grounded"
            ]
        )

    def test_publication_and_extra_fields_rejected(self):
        with self.assertRaises(ValidationError):
            self.draft(publication_authorized=True)
        with self.assertRaises(ValidationError):
            self.draft(secret="extra")
        self.assertFalse(strict_schema(EditorialDraft)["additionalProperties"])

    def test_review_requires_every_claim_and_candidate(self):
        def row(kind, name):
            return {
                "item_type": kind,
                "item_id": name,
                "disposition": "pass",
                "numerical_review": "checked",
                "chart_review": "checked",
                "wording_review": "checked",
                "issues": [],
                "suggested_revision": "",
                "evidence_ids": [],
            }

        raw = {
            "run_id": "run-1",
            "evidence_sha256": "abc",
            "draft_sha256": "def",
            "reviews": [row("candidate", "C1"), row("published_claim", "P1")],
            "overall_concerns": [],
            "publication_authorized": False,
        }
        review = EditorialReview.model_validate(raw)
        self.assertTrue(validate_review(review, EVIDENCE, "abc", "def")["all_grounded"])
        for key, value in [("draft_sha256", "wrong"), ("reviews", raw["reviews"][:1])]:
            with self.assertRaises(ValueError):
                validate_review(
                    EditorialReview.model_validate({**raw, key: value}),
                    EVIDENCE,
                    "abc",
                    "def",
                )
        review.reviews[0].suggested_revision = "999 records (99.9%)"
        self.assertFalse(
            validate_review(review, EVIDENCE, "abc", "def")["all_grounded"]
        )

    def test_tool_execution_and_provider_errors_rejected_and_recorded(self):
        with tempfile.TemporaryDirectory() as folder:
            for i, event in enumerate(
                [
                    {"type": "item.completed", "item": {"type": "command_execution"}},
                    {"type": "turn.failed", "error": {"message": "test"}},
                ]
            ):
                dest = Path(folder) / str(i)
                results = [
                    SimpleNamespace(stdout="test-cli"),
                    SimpleNamespace(returncode=0, stdout=json.dumps(event), stderr=""),
                ]
                with (
                    patch(
                        "tracker.editorial.shutil.which", return_value="/bin/provider"
                    ),
                    patch("tracker.editorial.subprocess.run", side_effect=results),
                ):
                    with self.assertRaises(RuntimeError):
                        invoke_cli("codex", "prompt", {}, {}, dest, "model", "ultra")
                self.assertEqual(
                    json.loads((dest / "call.json").read_text())["status"], "failed"
                )

    def test_claude_error_cannot_become_empty_success(self):
        with tempfile.TemporaryDirectory() as folder:
            results = [
                SimpleNamespace(stdout="test-cli"),
                SimpleNamespace(returncode=0, stdout='{"is_error":true}', stderr=""),
            ]
            with (
                patch("tracker.editorial.shutil.which", return_value="/bin/provider"),
                patch("tracker.editorial.subprocess.run", side_effect=results),
            ):
                with self.assertRaises(RuntimeError):
                    invoke_cli(
                        "claude",
                        "prompt",
                        {},
                        {},
                        Path(folder) / "call",
                        "fable",
                        "max",
                    )


if __name__ == "__main__":
    unittest.main()
