"""Counterexamples for stale, ambiguous, incomplete, or mislabeled deliveries."""

from __future__ import annotations

import csv
from datetime import date
import json
from pathlib import Path
import tempfile
import unittest

from tracker.data import REQUIRED, load_incidents

from tracker.intake import file_hash, inspect_exports, previous_input


class IntakeTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.project = self.root / "project"
        self.downloads = self.root / "Downloads"
        self.inbox = self.root / "inbox"
        for path in [self.project, self.downloads, self.inbox]:
            path.mkdir()
        self.today = date(2026, 9, 27)

    def write_export(
        self, day: str, identifier: int = 1, directory: Path | None = None
    ) -> Path:
        path = (directory or self.downloads) / f"incident_tracker_export_{day}.csv"
        raw = {key: "" for key in REQUIRED}
        raw.update(
            aiid_id=str(identifier),
            date="2024-01-01",
            classified_at="2026-09-01",
            domain_code="1 Test",
            subdomain_code="1.1 Test",
            additional_subdomains="[]",
            ai_models="[]",
            ai_developers="[]",
        )
        with path.open("w", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=sorted(REQUIRED))
            writer.writeheader()
            writer.writerow(raw)
        return path

    def baseline(self, path: Path) -> None:
        run = self.project / "runs" / "baseline"
        run.mkdir(parents=True)
        digest = file_hash(path)
        (run / "run_metadata.json").write_text(
            json.dumps(
                {
                    "analysis_date": "2026-09-27",
                    "input": {"sha256": digest, "original_path": str(path)},
                }
            )
        )
        (self.project / "LATEST_RUN.json").write_text(
            json.dumps(
                {"path": "runs/baseline", "input_sha256": digest, "run_id": "baseline"}
            )
        )

    def inspect(self):
        return inspect_exports(
            self.project, [self.downloads, self.inbox], self.today, load_incidents
        )

    def test_unchanged_export_is_not_ready_or_fresh(self) -> None:
        file = self.write_export("2026-09-26")
        self.baseline(file)
        result = self.inspect()
        self.assertEqual(result["status"], "unchanged_export")
        self.assertFalse(result["ready_for_analysis"])
        self.assertEqual(result["selected"]["days_since_filename_date"], 1)

    def test_renaming_identical_bytes_to_new_date_does_not_create_observation(
        self,
    ) -> None:
        old = self.write_export("2026-09-25")
        self.baseline(old)
        new = self.inbox / "incident_tracker_export_2026-09-27.csv"
        new.write_bytes(old.read_bytes())
        result = self.inspect()
        self.assertEqual(result["status"], "unchanged_export")
        self.assertEqual(result["selected"]["path"], str(new))

    def test_latest_different_content_is_selected_from_inbox(self) -> None:
        self.baseline(self.write_export("2026-09-25"))
        selected = self.write_export("2026-09-26", 2, self.inbox)
        result = self.inspect()
        self.assertTrue(result["ready_for_analysis"])
        self.assertEqual(result["selected"]["path"], str(selected))

    def test_same_date_conflict_blocks_arbitrary_selection(self) -> None:
        self.write_export("2026-09-26", 1)
        self.write_export("2026-09-26", 2, self.inbox)
        self.assertEqual(self.inspect()["status"], "conflicting_exports_for_same_date")

    def test_duplicate_same_date_same_bytes_is_unambiguous(self) -> None:
        file = self.write_export("2026-09-26")
        (self.inbox / file.name).write_bytes(file.read_bytes())
        self.assertEqual(self.inspect()["status"], "first_input")

    def test_invalid_newer_delivery_does_not_silently_fall_back(self) -> None:
        self.write_export("2026-09-25")
        (self.inbox / "incident_tracker_export_2026-09-26.csv").write_text(
            "aiid_id\n1\n"
        )
        result = self.inspect()
        self.assertEqual(result["status"], "invalid_newest_export")
        self.assertIsNone(result["selected"])

    def test_invalid_filename_date_is_recorded(self) -> None:
        self.write_export("2026-09-31")
        self.assertEqual(self.inspect()["status"], "invalid_export")

    def test_future_export_is_rejected(self) -> None:
        self.write_export("2026-09-28")
        self.assertEqual(self.inspect()["status"], "invalid_export")

    def test_classification_after_filename_date_is_rejected(self) -> None:
        path = self.write_export("2026-09-20")
        path.write_text(path.read_text().replace("2026-09-01", "2026-09-21"))
        result = self.inspect()
        self.assertEqual(result["status"], "invalid_export")
        self.assertIn("classified after", result["observations"][0]["error"])

    def test_copy_suffix_and_nonexact_names_are_ignored(self) -> None:
        file = self.write_export("2026-09-26")
        file.rename(file.with_name("incident_tracker_export_2026-09-26 (1).csv"))
        self.assertEqual(self.inspect()["status"], "no_export_found")

    def test_symlink_is_not_followed(self) -> None:
        target = self.write_export("2026-09-25")
        (self.inbox / "incident_tracker_export_2026-09-26.csv").symlink_to(target)
        self.assertEqual(self.inspect()["status"], "invalid_newest_export")

    def test_older_different_export_does_not_rewind_baseline(self) -> None:
        newer = self.write_export("2026-09-26")
        self.baseline(newer)
        newer.unlink()
        self.write_export("2026-09-25", 2)
        self.assertEqual(self.inspect()["status"], "older_than_latest_export")

    def test_same_date_revision_is_labeled(self) -> None:
        path = self.write_export("2026-09-26")
        self.baseline(path)
        self.write_export("2026-09-26", 2)
        result = self.inspect()
        self.assertEqual(result["status"], "different_export")
        self.assertIn("same declared export date", result["warnings"][0])

    def test_baseline_hash_disagreement_fails(self) -> None:
        self.baseline(self.write_export("2026-09-26"))
        pointer = self.project / "LATEST_RUN.json"
        obj = json.loads(pointer.read_text())
        obj["input_sha256"] = "0" * 64
        pointer.write_text(json.dumps(obj))
        with self.assertRaisesRegex(ValueError, "disagree"):
            self.inspect()

    def test_changed_during_validation_is_rejected(self) -> None:
        self.write_export("2026-09-26")

        def changing_loader(path: Path, day: date):
            rows = load_incidents(path, day)
            path.write_bytes(path.read_bytes() + b"\n")
            return rows

        result = inspect_exports(
            self.project, [self.downloads], self.today, changing_loader
        )
        self.assertEqual(result["status"], "invalid_export")
        self.assertIn("changed during validation", result["observations"][0]["error"])

    def test_missing_optional_inbox_does_not_block(self) -> None:
        self.write_export("2026-09-26")
        result = inspect_exports(
            self.project,
            [self.downloads, self.root / "absent"],
            self.today,
            load_incidents,
        )
        self.assertEqual(result["status"], "first_input")


if __name__ == "__main__":
    unittest.main()
