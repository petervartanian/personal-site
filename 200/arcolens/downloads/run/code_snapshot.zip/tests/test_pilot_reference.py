import unittest
from tracker.pilot_reference_check import agreement


class AgreementTests(unittest.TestCase):
    def test_perfect_agreement_with_two_classes(self):
        self.assertEqual(agreement([("1", "1"), ("2", "2")], True)["kappa"], 1)

    def test_constant_agreement_has_undefined_kappa(self):
        self.assertIsNone(agreement([("1", "1")] * 10)["kappa"])

    def test_complete_reversal_two_points(self):
        self.assertEqual(agreement([("1", "5"), ("5", "1")], True)["kappa"], -1)

    def test_invalid_score_rejected(self):
        with self.assertRaises(ValueError):
            agreement([("0", "1")], True)
