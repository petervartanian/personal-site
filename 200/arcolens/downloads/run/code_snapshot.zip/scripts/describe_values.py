"""Show exact categorical values used to configure the analysis."""

from __future__ import annotations

import csv
from collections import Counter
from pathlib import Path
import argparse


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("fields", nargs="+", default=["ai_goal_primary"])
    args = parser.parse_args()
    with args.input.open(newline="", encoding="utf-8-sig") as handle:
        rows = list(csv.DictReader(handle))
    for field in args.fields:
        print(field)
        for value, count in Counter(row[field] for row in rows).most_common():
            print(f"  {count}: {value}")


if __name__ == "__main__":
    main()
