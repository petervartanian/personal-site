#!/usr/bin/env python3
"""Bounded, reproducible source capture for the MIT AI Incident Tracker.

Source documents are evidence, never instructions. No downloaded JS is executed.
Only public GET requests are made; data endpoints are not followed automatically.

Examples (from the workspace root)::

    python3 scripts/discover_site.py --seed --sitemap --crawl-tracker
    python3 scripts/discover_site.py --url https://example.org/embed --app-assets
    python3 scripts/discover_site.py --csv-header /path/to/export.csv

The raw response body, extracted HTML text, inline scripts, discovered links,
HTTP metadata, SHA256 hashes and UTC retrieval timestamps are saved under
research/web. Limits are explicit, and unsuccessful retrievals are recorded.
Dependencies: httpx and pydantic (already present in the research environment).
"""

from __future__ import annotations

import argparse
import asyncio
import csv
import hashlib
import json
import logging
import re
import subprocess
import sys
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urldefrag, urlencode, urljoin, urlparse
from xml.etree import ElementTree

import httpx
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT = ROOT / "research" / "web"
ORIGIN = "https://airisk.mit.edu"
TRACKER = f"{ORIGIN}/ai-incident-tracker"
SEEDS = [
    TRACKER,
    *[
        f"{TRACKER}/{slug}"
        for slug in (
            "incident-timeline",
            "incident-overview",
            "incident-view",
            "harm-taxonomy",
            "natsec-incident-view",
            "natsec-impact-framework",
        )
    ],
]
LOGGER = logging.getLogger("tracker_source_capture")


def utc_now() -> str:
    return (
        datetime.now(timezone.utc)
        .isoformat(timespec="microseconds")
        .replace("+00:00", "Z")
    )


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def log_event(event: str, **fields: Any) -> None:
    LOGGER.info(json.dumps({"time_utc": utc_now(), "event": event, **fields}))


class SourceRecord(BaseModel):
    requested_url: str
    final_url: str | None = None
    retrieved_at_utc: str
    status: str
    http_status: int | None = None
    content_type: str | None = None
    response_headers: dict[str, str] = Field(default_factory=dict)
    byte_count: int = 0
    raw_sha256: str | None = None
    raw_path: str | None = None
    text_sha256: str | None = None
    text_path: str | None = None
    discovery_path: str | None = None
    metadata_path: str | None = None
    parent_url: str | None = None
    discovery_relation: str | None = None
    error: str | None = None
    verification: str = "HTTP source retrieval; not browser rendering"


class PageParser(HTMLParser):
    """Extract text and link/script provenance without running page content."""

    BLOCKS = {
        "address",
        "article",
        "aside",
        "blockquote",
        "br",
        "div",
        "dl",
        "dt",
        "dd",
        "fieldset",
        "figcaption",
        "figure",
        "footer",
        "form",
        "h1",
        "h2",
        "h3",
        "h4",
        "h5",
        "h6",
        "header",
        "hr",
        "li",
        "main",
        "nav",
        "ol",
        "p",
        "section",
        "table",
        "td",
        "th",
        "tr",
        "ul",
    }

    def __init__(self, url: str) -> None:
        super().__init__(convert_charrefs=True)
        self.url = url
        self.links: list[dict[str, Any]] = []
        self.frames: list[dict[str, Any]] = []
        self.scripts: list[dict[str, Any]] = []
        self.assets: list[dict[str, Any]] = []
        self.configurations: list[dict[str, Any]] = []
        self.images: list[dict[str, Any]] = []
        self.parts: list[str] = []
        self.hidden_tag: str | None = None
        self.current_script: dict[str, Any] | None = None

    def absolute(self, value: str) -> str:
        return urljoin(self.url, value)

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        data = dict(attrs)
        if (
            "data-chart-type" in data
            or data.get("id") == "main-chart-data"
            or "data-gc-filters" in data
            or "gc-incident-count" in str(data.get("class", ""))
        ):
            self.configurations.append({"tag": tag, "attributes": data})
        if tag == "img" and data.get("src"):
            self.images.append(
                {"url": self.absolute(str(data["src"])), "attributes": data}
            )
        if tag == "script":
            self.hidden_tag = "script"
            self.current_script = {"attributes": data, "text": ""}
            if data.get("src"):
                self.current_script["url"] = self.absolute(str(data["src"]))
            self.scripts.append(self.current_script)
        elif tag in {"style", "noscript"}:
            self.hidden_tag = tag
        if tag in self.BLOCKS and not self.hidden_tag:
            self.parts.append("\n")
        if tag == "a" and data.get("href"):
            self.links.append(
                {"url": self.absolute(str(data["href"])), "attributes": data}
            )
        if tag in {"iframe", "embed", "object"}:
            source = data.get("src") or data.get("data") or data.get("data-src")
            self.frames.append(
                {
                    "tag": tag,
                    "url": self.absolute(str(source)) if source else None,
                    "attributes": data,
                }
            )
        if tag == "link" and data.get("href"):
            self.assets.append(
                {
                    "tag": tag,
                    "url": self.absolute(str(data["href"])),
                    "attributes": data,
                }
            )

    def handle_endtag(self, tag: str) -> None:
        if tag == self.hidden_tag:
            self.hidden_tag = None
            self.current_script = None
        if tag in self.BLOCKS and not self.hidden_tag:
            self.parts.append("\n")

    def handle_data(self, data: str) -> None:
        if self.hidden_tag == "script" and self.current_script is not None:
            self.current_script["text"] += data
        elif not self.hidden_tag:
            self.parts.append(data)

    def text(self) -> str:
        lines = [
            re.sub(r"[\t\r \u00a0]+", " ", line).strip()
            for line in "".join(self.parts).split("\n")
        ]
        return "\n".join(line for line in lines if line) + "\n"


def store_bytes(output: Path, name: str, data: bytes) -> str:
    path = output / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_bytes() != data:
        raise RuntimeError(f"Refusing to overwrite distinct source bytes: {path}")
    path.write_bytes(data)
    return str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path)


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )


def source_slug(url: str) -> str:
    parsed = urlparse(url)
    value = parsed.netloc + "__" + (parsed.path.strip("/") or "index")
    return re.sub(r"[^a-zA-Z0-9_.-]", "_", value)[-180:]


async def capture(
    client: httpx.AsyncClient,
    url: str,
    output: Path,
    max_bytes: int,
    parent_url: str | None,
    relation: str | None,
) -> tuple[SourceRecord, dict[str, Any]]:
    record = SourceRecord(
        requested_url=url,
        retrieved_at_utc=utc_now(),
        status="pending",
        parent_url=parent_url,
        discovery_relation=relation,
    )
    discovery: dict[str, Any] = {}
    try:
        async with client.stream("GET", url) as response:
            record.final_url = str(response.url)
            record.http_status = response.status_code
            record.content_type = response.headers.get("content-type", "")
            record.response_headers = dict(response.headers)
            chunks: list[bytes] = []
            async for chunk in response.aiter_bytes():
                record.byte_count += len(chunk)
                if record.byte_count > max_bytes:
                    raise ValueError(
                        f"Response exceeded {max_bytes} decoded bytes; stopped"
                    )
                chunks.append(chunk)
            body = b"".join(chunks)
            record.raw_sha256 = sha256(body)
            content_type = record.content_type.lower()
            suffix = (
                ".html"
                if "html" in content_type
                else (
                    ".png"
                    if "image/png" in content_type
                    else (
                        ".jpg"
                        if "image/jpeg" in content_type
                        else (
                            ".webp"
                            if "image/webp" in content_type
                            else (
                                ".pdf"
                                if "application/pdf" in content_type
                                else (
                                    ".js"
                                    if "javascript" in content_type
                                    or urlparse(url).path.endswith(".js")
                                    else (
                                        ".json"
                                        if "json" in content_type
                                        else (
                                            ".xml"
                                            if "xml" in content_type
                                            else (
                                                ".txt"
                                                if "text" in content_type
                                                else ".bin"
                                            )
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            )
            stem = f"{source_slug(url)}--{record.raw_sha256[:16]}"
            record.raw_path = store_bytes(output, f"raw/{stem}{suffix}", body)
            record.status = (
                "retrieved" if response.is_success else "http_error_body_preserved"
            )
            text = body.decode(response.encoding or "utf-8", errors="replace")
            if suffix == ".html":
                parser = PageParser(str(response.url))
                parser.feed(text)
                extracted = parser.text().encode("utf-8")
                record.text_path = store_bytes(output, f"text/{stem}.txt", extracted)
                record.text_sha256 = sha256(extracted)
                inline_scripts: list[dict[str, Any]] = []
                for index, script in enumerate(parser.scripts):
                    entry = dict(script)
                    script_text = str(entry.pop("text"))
                    if script_text.strip():
                        raw_script = script_text.encode("utf-8")
                        entry["inline_script_sha256"] = sha256(raw_script)
                        entry["inline_script_path"] = store_bytes(
                            output, f"inline/{stem}--script-{index:02d}.js", raw_script
                        )
                    inline_scripts.append(entry)
                discovery = {
                    "url": str(response.url),
                    "links": parser.links,
                    "embeds": parser.frames,
                    "scripts": inline_scripts,
                    "assets": parser.assets,
                    "note": "HTML source extraction, including potentially hidden text; not rendered DOM",
                }
                discovery_path = output / "discovery" / f"{stem}.json"
                write_json(discovery_path, discovery)
                record.discovery_path = str(discovery_path.relative_to(ROOT))
            elif suffix == ".xml":
                try:
                    tree = ElementTree.fromstring(text)
                    discovery["sitemap_urls"] = [
                        str(node.text)
                        for node in tree.iter()
                        if node.tag.endswith("}loc") and node.text
                    ]
                except ElementTree.ParseError:
                    pass
    except (httpx.HTTPError, ValueError, OSError) as exc:
        record.status = "retrieval_failed_or_limited"
        record.error = f"{type(exc).__name__}: {exc}"
    timestamp = re.sub(r"[^0-9]", "", record.retrieved_at_utc)
    metadata_path = output / "metadata" / f"{source_slug(url)}--{timestamp}.json"
    record.metadata_path = str(metadata_path.relative_to(ROOT))
    write_json(metadata_path, record.model_dump())
    log_event(
        "capture",
        url=url,
        status=record.status,
        bytes=record.byte_count,
        raw_path=record.raw_path,
        embeds=discovery.get("embeds", []),
    )
    return record, discovery


def relevant_tracker_url(url: str) -> bool:
    parsed = urlparse(url)
    return parsed.netloc == "airisk.mit.edu" and (
        "ai-incident-tracker" in parsed.path
        or (parsed.path.startswith("/blog/") and "incident-tracker" in parsed.path)
    )


def summarize_saved(output: Path, manifest: dict[str, Any]) -> None:
    """Regenerate a concise discovery index from immutable saved HTML bodies."""
    pages = []
    chart_bindings = []
    json_index = []
    source_map_index = []
    seen: set[str] = set()
    for source in manifest["sources"]:
        raw_path = source.get("raw_path")
        if raw_path and raw_path.endswith(".json") and raw_path not in seen:
            seen.add(raw_path)
            try:
                payload = json.loads((ROOT / raw_path).read_text(encoding="utf-8"))
                if source["requested_url"].endswith(".map"):
                    for original_path, content in zip(
                        payload.get("sources", []), payload.get("sourcesContent", [])
                    ):
                        if content is None or "node_modules" in original_path:
                            continue
                        source_bytes = content.encode("utf-8")
                        digest = sha256(source_bytes)
                        safe_name = re.sub(
                            r"[^A-Za-z0-9_.-]", "_", original_path
                        ).lstrip("._")
                        extracted = store_bytes(
                            output, f"app_source/{safe_name}", source_bytes
                        )
                        source_map_index.append(
                            {
                                "source_map_url": source["requested_url"],
                                "source_map_raw_path": raw_path,
                                "source_map_sha256": source["raw_sha256"],
                                "retrieved_at_utc": source["retrieved_at_utc"],
                                "original_source_path": original_path,
                                "extracted_path": extracted,
                                "sha256": digest,
                                "verification": "Source-map embedded source; not server code unless identified",
                            }
                        )
                    continue
                derived = output / "derived" / f"{Path(raw_path).stem}.pretty.json"
                write_json(derived, payload)
                json_index.append(
                    {
                        "url": source["requested_url"],
                        "raw_path": raw_path,
                        "raw_sha256": source["raw_sha256"],
                        "retrieved_at_utc": source["retrieved_at_utc"],
                        "derived_path": str(derived.relative_to(ROOT)),
                        "derived_sha256": sha256(derived.read_bytes()),
                        "operation": "JSON parse/indent only",
                    }
                )
            except (json.JSONDecodeError, UnicodeDecodeError):
                pass
        if not raw_path or not raw_path.endswith(".html") or raw_path in seen:
            continue
        seen.add(raw_path)
        parser = PageParser(source.get("final_url") or source["requested_url"])
        parser.feed((ROOT / raw_path).read_text(encoding="utf-8"))
        images = []
        for image in parser.images:
            if image["url"].startswith("data:"):
                images.append(
                    {
                        "inline_data_sha256": sha256(image["url"].encode()),
                        "note": "Full inline image is preserved in raw HTML",
                    }
                )
            else:
                images.append(image)
        pages.append(
            {
                "url": source["requested_url"],
                "raw_path": raw_path,
                "text_path": source.get("text_path"),
                "metadata_path": source.get("metadata_path"),
                "configurations": parser.configurations,
                "embeds": parser.frames,
                "scripts": [entry for entry in parser.scripts if entry.get("url")],
                "images": images,
            }
        )
        chart_bindings.append(
            {
                "url": source["requested_url"],
                "configurations": parser.configurations,
                "initializers": [
                    entry["text"]
                    for entry in parser.scripts
                    if "GovCharts.init" in entry["text"]
                ],
                "embeds": parser.frames,
            }
        )
    write_json(output / "page_elements.json", pages)
    write_json(output / "chart_bindings.json", chart_bindings)
    write_json(output / "json_index.json", json_index)
    write_json(output / "source_map_index.json", source_map_index)
    api_probes: dict[str, dict[str, Any]] = {}
    for source in manifest["sources"]:
        url = source["requested_url"]
        raw_path = source.get("raw_path")
        if "/api/data/incidents?" not in url or not raw_path:
            continue
        payload = json.loads((ROOT / raw_path).read_text(encoding="utf-8"))
        pie = payload.get("data")
        series = payload.get("series")
        query = parse_qs(urlparse(url).query)
        api_probes[url] = {
            "url": url,
            "query": query,
            "raw_path": raw_path,
            "raw_sha256": source["raw_sha256"],
            "retrieved_at_utc": source["retrieved_at_utc"],
            "chartType": payload.get("chartType"),
            "stackBy": payload.get("stackBy"),
            "lastUpdated": payload.get("lastUpdated"),
            "totalIncidents": payload.get("totalIncidents"),
            "totalIncidentsAll": payload.get("totalIncidentsAll"),
            "pie_sum": sum(item["value"] for item in pie) if pie else None,
            "pie_data": pie,
            "series_count": len(series) if series else None,
            "series_sum": sum(sum(item["data"]) for item in series) if series else None,
            "series_names": [item["name"] for item in series] if series else None,
            "list_item_count": len(payload["items"]) if "items" in payload else None,
            "list_ids_unique": (
                len({str(item["incidentId"]) for item in payload["items"]})
                if "items" in payload
                else None
            ),
            "server_logic_caution": "Observed public API output; backend implementation not available in client source map",
        }
        if query == {"src": ["incidents-arcola"], "chartType": ["domain-pie"]}:
            keys = (
                "years",
                "domains",
                "subdomains",
                "allSubdomains",
                "harmCategories",
                "entities",
                "intents",
                "timings",
                "euRisks",
                "aiGoals",
                "aiModels",
                "aiDevelopers",
                "natSecImminenceLevels",
                "natSecAutonomyLevels",
                "natSecNoveltyLevels",
                "severityFields",
            )
            write_json(
                output / "controls_snapshot.json",
                {
                    "source_url": url,
                    "raw_path": raw_path,
                    "raw_sha256": source["raw_sha256"],
                    "retrieved_at_utc": source["retrieved_at_utc"],
                    "lastUpdated": payload.get("lastUpdated"),
                    "option_counts": {key: len(payload.get(key, [])) for key in keys},
                    "options": {key: payload.get(key, []) for key in keys},
                    "hasAdditionalSubdomains": payload.get("hasAdditionalSubdomains"),
                    "hasAiIdentity": payload.get("hasAiIdentity"),
                    "note": "These are actual API-delivered option values. UI availability depends on the chart component; see inventory.",
                },
            )
    write_json(output / "api_probe_summary.json", list(api_probes.values()))


def format_javascript(path: Path, output: Path) -> None:
    """Use Prettier as a parser/formatter; do not execute the captured source."""
    result = subprocess.run(
        [
            "npx",
            "--yes",
            "--package=prettier@3.8.3",
            "prettier",
            "--parser",
            "babel",
            str(path),
        ],
        capture_output=True,
        check=True,
        timeout=120,
    )
    original = path.read_bytes()
    derived_path = store_bytes(output, f"derived/{path.stem}.pretty.js", result.stdout)
    write_json(
        output / "derived" / f"{path.stem}.format_metadata.json",
        {
            "source_path": str(path),
            "source_sha256": sha256(original),
            "derived_path": derived_path,
            "derived_sha256": sha256(result.stdout),
            "operation": "prettier@3.8.3 --parser babel (format only; no source execution)",
            "generated_at_utc": utc_now(),
        },
    )
    log_event("formatted_js", path=derived_path)


async def run(args: argparse.Namespace) -> None:
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    manifest_path = output / "manifest.json"
    manifest = (
        json.loads(manifest_path.read_text())
        if manifest_path.exists()
        else {
            "description": "Public source snapshots; exact bytes hashed; source-only unless explicitly stated",
            "sources": [],
        }
    )
    queue = [(url, None, "explicit_seed") for url in args.url]
    if args.seed:
        queue += [(url, None, "starting_page") for url in SEEDS]
    if args.sitemap:
        queue.append((f"{ORIGIN}/sitemap.xml", None, "site_sitemap"))
    if args.archived_embeds:
        saved_bindings = output / "chart_bindings.json"
        if saved_bindings.exists():
            for page in json.loads(saved_bindings.read_text(encoding="utf-8")):
                if "/old-ai-incident-tracker/" not in page["url"]:
                    continue
                queue += [
                    (entry["url"], page["url"], "archived_public_embed")
                    for entry in page["embeds"]
                    if entry.get("url", "").startswith("https://airtable.com/")
                ]
    if args.publication_assets:
        elements_path = output / "page_elements.json"
        if elements_path.exists():
            for page in json.loads(elements_path.read_text(encoding="utf-8")):
                if "/blog/" not in page["url"] or "incident-tracker" not in page["url"]:
                    continue
                queue += [
                    (entry["url"], page["url"], "dated_publication_figure_or_table")
                    for entry in page["images"]
                    if entry.get("url", "").startswith("https://")
                    and not entry.get("attributes", {}).get("class")
                ]
    if args.probe_controls:
        base = "https://airi-echarts-visualizations.vercel.app/api/data/incidents"
        probes: list[list[tuple[str, str]]] = []
        for dimension in (
            "subdomain",
            "allSubdomains",
            "harmCategory",
            "entity",
            "intent",
            "timing",
            "aiGoal",
            "aiModel",
            "aiDeveloper",
            "euRisk",
            "highestSeverity",
            "natSecImpact",
        ):
            probes.append([("chartType", "domain-pie"), ("stackBy", dimension)])
        probes.extend(
            [
                [
                    ("chartType", "domain-by-year"),
                    ("stackBy", "domain"),
                    ("minYear", "2016"),
                ],
                [
                    ("chartType", "subdomain-by-year"),
                    ("stackBy", "subdomain"),
                    ("minYear", "2016"),
                ],
                [
                    ("chartType", "domain-subdomain"),
                    ("stackBy", "subdomain"),
                    ("minYear", "2016"),
                ],
                [("chartType", "domain-pie"), ("minSeverity", "4")],
                [("chartType", "domain-pie"), ("minSeverityHighest", "4")],
                [("chartType", "domain-pie"), ("minSeverityPhysical", "4")],
                [("chartType", "domain-pie"), ("entity", "Human")],
                [("chartType", "domain-pie"), ("entity", "AI")],
                [("chartType", "domain-pie"), ("entity", "Human"), ("entity", "AI")],
                [
                    ("chartType", "domain-pie"),
                    ("entity", "Human"),
                    ("intent", "Intentional"),
                ],
                [("chartType", "domain-pie"), ("minNatSecOverall", "4")],
                [("chartType", "natsec-incident-list"), ("minNatSecOverall", "4")],
            ]
        )
        queue += [
            (
                f"{base}?{urlencode([('src', 'incidents-arcola'), *probe])}",
                "https://airi-echarts-visualizations.vercel.app/embed.js",
                "bounded_control_api_probe",
            )
            for probe in probes
        ]
    seen: set[str] = set()
    async with httpx.AsyncClient(
        follow_redirects=True,
        timeout=httpx.Timeout(60.0),
        headers={
            "User-Agent": "MIT-Incident-Tracker-Source-Research/1.0 (bounded public source capture)"
        },
    ) as client:
        while queue:
            batch = []
            while queue and len(batch) < args.concurrency:
                url, parent, relation = queue.pop(0)
                url = urldefrag(url)[0]
                if url in seen or urlparse(url).scheme not in {"http", "https"}:
                    continue
                seen.add(url)
                batch.append((url, parent, relation))
            results = await asyncio.gather(
                *[
                    capture(client, url, output, args.max_bytes, parent, relation)
                    for url, parent, relation in batch
                ]
            )
            for record, discovery in results:
                manifest["sources"].append(record.model_dump())
                if args.crawl_tracker:
                    linked = [entry["url"] for entry in discovery.get("links", [])]
                    linked += discovery.get("sitemap_urls", [])
                    queue += [
                        (url, record.requested_url, "tracker_link_or_sitemap")
                        for url in linked
                        if relevant_tracker_url(url)
                    ]
                if args.embeds:
                    queue += [
                        (entry["url"], record.requested_url, "iframe_or_embed")
                        for entry in discovery.get("embeds", [])
                        if entry.get("url")
                    ]
                if (
                    args.app_assets
                    and urlparse(record.requested_url).netloc != "airisk.mit.edu"
                ):
                    queue += [
                        (
                            entry["url"],
                            record.requested_url,
                            "app_script_or_modulepreload",
                        )
                        for entry in discovery.get("scripts", [])
                        + discovery.get("assets", [])
                        if entry.get("url")
                        and (
                            entry.get("attributes", {}).get("type") == "module"
                            or entry.get("attributes", {}).get("rel") == "modulepreload"
                            or urlparse(entry["url"]).netloc
                            == urlparse(record.requested_url).netloc
                            and urlparse(entry["url"]).path.endswith(".js")
                        )
                    ]
            manifest["updated_at_utc"] = utc_now()
            write_json(manifest_path, manifest)
    if args.csv_header:
        with Path(args.csv_header).open(newline="", encoding="utf-8-sig") as handle:
            header = next(csv.reader(handle))
        write_json(
            output / "input_csv_header.json",
            {
                "input_path": str(Path(args.csv_header).resolve()),
                "read_at_utc": utc_now(),
                "scope": "header only; row audit belongs to agent 1",
                "column_count": len(header),
                "columns": header,
            },
        )
    summarize_saved(output, manifest)
    for path in args.format_js:
        format_javascript(Path(path).resolve(), output)
    log_event("done", captures_this_run=len(seen), manifest=str(manifest_path))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--url", action="append", default=[])
    parser.add_argument("--seed", action="store_true")
    parser.add_argument("--sitemap", action="store_true")
    parser.add_argument("--crawl-tracker", action="store_true")
    parser.add_argument("--embeds", action="store_true")
    parser.add_argument("--app-assets", action="store_true")
    parser.add_argument("--output", default=str(DEFAULT_OUTPUT))
    parser.add_argument("--max-bytes", type=int, default=8 * 1024 * 1024)
    parser.add_argument("--concurrency", type=int, default=4)
    parser.add_argument("--csv-header")
    parser.add_argument("--format-js", action="append", default=[])
    parser.add_argument("--probe-controls", action="store_true")
    parser.add_argument("--archived-embeds", action="store_true")
    parser.add_argument("--publication-assets", action="store_true")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(message)s", stream=sys.stderr)
    logging.getLogger("httpx").setLevel(logging.WARNING)
    asyncio.run(run(args))


if __name__ == "__main__":
    main()
