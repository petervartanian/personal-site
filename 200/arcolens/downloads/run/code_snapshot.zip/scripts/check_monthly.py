"""Check local export intake and live claims; analyze and review new content only."""

from __future__ import annotations

import argparse
from datetime import date, datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from typing import Any
import uuid

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
EXPORT_NAME = re.compile(r"incident_tracker_export_(\d{4}-\d{2}-\d{2})\.csv\Z")


def digest_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def run_step(
    name: str,
    command: list[str],
    project: Path,
    output: Path,
    timeout: int,
    overrides: dict[str, str] | None = None,
) -> dict[str, Any]:
    started = datetime.now(timezone.utc).isoformat()
    environment = os.environ.copy()
    environment.update(overrides or {})
    error = None
    try:
        process = subprocess.run(
            command,
            cwd=project,
            env=environment,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
            check=False,
        )
        code, stdout, stderr = process.returncode, process.stdout, process.stderr
    except subprocess.TimeoutExpired as caught:
        code, error = 124, f"{name} exceeded {timeout} seconds"
        stdout = caught.stdout or ""
        stderr = caught.stderr or ""
        if isinstance(stdout, bytes):
            stdout = stdout.decode("utf-8", errors="replace")
        if isinstance(stderr, bytes):
            stderr = stderr.decode("utf-8", errors="replace")
    except OSError as caught:
        code, stdout, stderr, error = 127, "", str(caught), str(caught)
    stdout_path, stderr_path = (
        output / f"{name}.stdout.txt",
        output / f"{name}.stderr.txt",
    )
    stdout_path.write_text(stdout, encoding="utf-8")
    stderr_path.write_text(stderr, encoding="utf-8")
    record = {
        "command": command,
        "started_at_utc": started,
        "finished_at_utc": datetime.now(timezone.utc).isoformat(),
        "returncode": code,
        "stdout_path": str(stdout_path),
        "stderr_path": str(stderr_path),
        "environment_overrides": overrides or {},
    }
    if error:
        record["error"] = error
    try:
        record["result"] = json.loads(stdout)
    except (ValueError, TypeError):
        pass
    write_json(output / f"{name}.execution.json", record)
    return record


def finish(
    output: Path, report: dict[str, Any], status: str, exit_code: int
) -> dict[str, Any]:
    report.update(
        status=status,
        exit_code=exit_code,
        finished_at_utc=datetime.now(timezone.utc).isoformat(),
    )
    write_json(output / "summary.json", report)
    files = {
        str(path.relative_to(output)): digest_file(path)
        for path in sorted(output.rglob("*"))
        if path.is_file() and path.name != "manifest.json"
    }
    write_json(output / "manifest.json", {"files": files})
    return report


def record_targets_another_run(
    record: dict[str, Any], current_run: Path, current_run_id: str
) -> bool:
    """Ignore a clearly stale pointer without treating it as a verified review.

    Conflicting bindings are not stale: the full verifier must reject them.
    Missing bindings also go to the verifier rather than being trusted.
    """
    recorded_id = record.get("current_run_id")
    paths = record.get("paths")
    recorded_path = paths.get("current_run") if isinstance(paths, dict) else None
    path = Path(recorded_path).resolve() if isinstance(recorded_path, str) else None
    if recorded_id == current_run_id or path == current_run.resolve():
        return False
    return bool(recorded_id or path)


def previous_editorial_status(
    project: Path, baseline: dict[str, Any] | None
) -> dict[str, Any]:
    """Keep a failed/unfinished model attempt visible without paying for a retry."""
    if not baseline:
        return {"status": "no_baseline", "needs_attention": False}
    attempts: list[dict[str, Any]] = []
    unknown: list[str] = []
    for path in sorted((project / "logs/editorial").glob("*/status.json")):
        try:
            status = json.loads(path.read_text())
            evidence_path = path.parent / "evidence.json"
            exact_run = status.get("run_id") == baseline.get("run_id")
            matched = exact_run
            if not matched and evidence_path.exists():
                evidence = json.loads(evidence_path.read_text())
                matched = (
                    bool(baseline.get("input_sha256"))
                    and evidence.get("input_sha256") == baseline["input_sha256"]
                )
            if not matched:
                # A failed preflight may have produced no evidence or run ID.
                if (
                    not status.get("run_id")
                    and status.get("status") != "completed_requires_human_review"
                ):
                    unknown.append(str(path))
                continue
            if (
                status.get("status") == "completed_requires_human_review"
                and not exact_run
            ):
                continue
            stamp = status.get("completed_at_utc")
            timestamp = (
                datetime.fromisoformat(stamp).timestamp()
                if stamp
                else path.stat().st_mtime
            )
            attempts.append(
                {
                    "path": str(path),
                    "status": status.get("status"),
                    "timestamp": timestamp,
                    "publication_authorized": status.get("publication_authorized"),
                }
            )
        except (OSError, ValueError, TypeError, AttributeError):
            unknown.append(str(path))
    for directory in sorted((project / "logs/monthly-checks").glob("*")):
        path = directory / "summary.json"
        if not path.exists():
            path = directory / "state.json"
        if not path.exists():
            continue
        try:
            summary = json.loads(path.read_text())
            if not summary.get("model_cycle_invoked"):
                continue
            if summary.get("selected_input", {}).get("sha256") != baseline.get(
                "input_sha256"
            ):
                continue
            step = summary.get("steps", {}).get("editorial", {})
            result = step.get("result", {})
            state = (
                result.get("status")
                if step.get("returncode") == 0
                else "failed_or_unfinished"
            )
            if state == "completed_requires_human_review" and result.get(
                "run_id"
            ) != baseline.get("run_id"):
                continue
            stamp = summary.get("finished_at_utc") or summary.get("started_at_utc")
            timestamp = (
                datetime.fromisoformat(stamp).timestamp()
                if stamp
                else path.stat().st_mtime
            )
            attempts.append(
                {
                    "path": str(path),
                    "status": state,
                    "timestamp": timestamp,
                    "publication_authorized": result.get("publication_authorized"),
                }
            )
        except (OSError, ValueError, TypeError, AttributeError):
            unknown.append(str(path))
    latest = max(attempts, key=lambda item: item["timestamp"]) if attempts else None
    incomplete = latest is None or (
        latest["status"] != "completed_requires_human_review"
        or latest["publication_authorized"] is not False
    )
    result = {
        "status": (
            "no_record"
            if latest is None and not unknown
            else ("needs_attention" if incomplete or unknown else "completed")
        ),
        "needs_attention": bool(incomplete or unknown),
        "latest_attempt": latest,
        "unresolved_records": unknown,
        "automatic_retry_performed": False,
    }
    adoption_path = project / "LATEST_EDITORIAL_ADOPTION.json"
    if adoption_path.exists():
        try:
            from tracker.editorial_adoption import verify_adoption_record

            pointer = json.loads((project / "LATEST_RUN.json").read_text())
            current_run = (project / pointer["path"]).resolve()
            if not current_run.is_relative_to(project.resolve()) or pointer.get(
                "run_id"
            ) != baseline.get("run_id"):
                raise ValueError("Adoption pointer is not the current baseline")
            record = json.loads(adoption_path.read_text())
            if record_targets_another_run(record, current_run, baseline["run_id"]):
                result["adoption_verification"] = {
                    "status": "ignored_other_run",
                    "path": str(adoption_path),
                    "reason": "The saved adoption does not target the current run.",
                }
            else:
                adoption = verify_adoption_record(record, current_run)
                result["adoption_verification"] = adoption
                if (
                    adoption.get("status")
                    == "adopted_equivalent_evidence_requires_human_review"
                ):
                    result.update(
                        status="adopted_equivalent_evidence_requires_human_review",
                        needs_attention=False,
                    )
                else:
                    result.update(
                        status="adoption_needs_attention", needs_attention=True
                    )
        except (
            ImportError,
            OSError,
            ValueError,
            TypeError,
            KeyError,
            AttributeError,
        ) as error:
            result.update(
                status="adoption_needs_attention",
                needs_attention=True,
                adoption_error=str(error),
            )
    resolution_path = project / "LATEST_EDITORIAL_RESOLUTION.json"
    if resolution_path.exists():
        try:
            from tracker.editorial_resolution import RESOLVED, verify_resolution_record

            pointer = json.loads((project / "LATEST_RUN.json").read_text())
            current_run = (project / pointer["path"]).resolve()
            if not current_run.is_relative_to(project.resolve()) or pointer.get(
                "run_id"
            ) != baseline.get("run_id"):
                raise ValueError("Resolution pointer is not the current baseline")
            record = json.loads(resolution_path.read_text())
            if record_targets_another_run(record, current_run, baseline["run_id"]):
                result["resolution_verification"] = {
                    "status": "ignored_other_run",
                    "path": str(resolution_path),
                    "reason": "The saved resolution does not target the current run.",
                }
            else:
                resolution = verify_resolution_record(record, current_run)
                result["resolution_verification"] = resolution
                if (
                    resolution.get("status") == RESOLVED
                    and resolution.get("current_run_id") == baseline["run_id"]
                    and resolution.get("publication_authorized") is False
                ):
                    result.update(
                        status=RESOLVED,
                        needs_attention=False,
                        original_cycle_status=resolution.get("original_cycle_status"),
                        model_review_passed=False,
                        publication_authorized=False,
                        resolution_method="explicit_assistant_adjudication",
                    )
                else:
                    result.update(
                        status="resolution_needs_attention", needs_attention=True
                    )
        except (
            ImportError,
            OSError,
            ValueError,
            TypeError,
            KeyError,
            AttributeError,
        ) as error:
            result.update(
                status="resolution_needs_attention",
                needs_attention=True,
                resolution_error=str(error),
            )
    return result


def baseline_definitions_status(project: Path) -> dict[str, Any]:
    """Unchanged bytes cannot conceal changed code or pinned analytical inputs."""
    from tracker.__main__ import code_files
    from tracker.data import json_bytes

    try:
        pointer = json.loads((project / "LATEST_RUN.json").read_text())
        run = (project / pointer["path"]).resolve()
        if not run.is_relative_to(project.resolve()):
            raise ValueError("Baseline pointer escapes the project")
        metadata = json.loads((run / "run_metadata.json").read_text())
        hashes = {
            p.relative_to(project).as_posix(): digest_file(p)
            for p in code_files(project)
        }
        current = hashlib.sha256(json_bytes(hashes)).hexdigest()
        changed = []
        if metadata.get("code", {}).get("fingerprint_sha256") != current:
            changed.append("code fingerprint")
        sources = {
            "chart_inventory.json": "research/chart_inventory.json",
            "published_claims_raw.json": "research/published_claims_raw.json",
            "web_manifest.json": "research/web/manifest.json",
            "claim_checks.json": "config/claim_checks.json",
            "discovery.json": "config/discovery.json",
            "report_text.json": "config/report_text.json",
            "methodology.md": "docs/methodology.md",
            "change_log.md": "docs/change_log.md",
        }
        pinned = metadata.get("input_artifact_hashes", {})
        for name, expected in pinned.items():
            relative = sources.get(name)
            if relative is None and (project / "prompts" / name).exists():
                relative = "prompts/" + name
            if relative is not None and (
                not (project / relative).is_file()
                or digest_file(project / relative) != expected
            ):
                changed.append(relative)
        return {
            "needs_attention": bool(changed),
            "changed": changed,
            "current_code_fingerprint": current,
        }
    except (OSError, ValueError, TypeError, KeyError) as error:
        return {"needs_attention": True, "error": str(error)}


def check_monthly(
    project: Path = ROOT,
    downloads: Path | None = None,
    inboxes: list[Path] | None = None,
    today: date | None = None,
    context: Path | None = None,
) -> dict[str, Any]:
    """Record every stage and fail honestly without performing publication."""
    project = project.resolve()
    today = today or date.today()
    downloads = (downloads or Path.home() / "Downloads").resolve()
    job_id = (
        datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        + "-"
        + uuid.uuid4().hex[:8]
    )
    output = project / "logs/monthly-checks" / job_id
    output.mkdir(parents=True, exist_ok=False)
    python = sys.executable
    report: dict[str, Any] = {
        "schema_version": 1,
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "checked_date": today.isoformat(),
        "output": str(output),
        "publication_authorized": False,
        "analysis_invoked": False,
        "model_cycle_invoked": False,
        "steps": {},
        "warnings": [],
    }
    intake_command = [
        python,
        "-B",
        "-m",
        "tracker.intake",
        "--project",
        str(project),
        "--downloads",
        str(downloads),
        "--today",
        today.isoformat(),
    ]
    for inbox in inboxes or []:
        intake_command.extend(["--inbox", str(inbox.resolve())])
    intake = run_step("intake", intake_command, project, output, 180)
    report["steps"]["intake"] = intake
    # Refresh is independent of intake and runs even if there is no new input or intake failed.
    refresh = run_step(
        "refresh",
        [
            python,
            "-B",
            "-m",
            "tracker",
            "refresh-claims",
            "--output",
            str(output / "claim_refresh"),
        ],
        project,
        output,
        600,
    )
    report["steps"]["refresh"] = refresh
    refresh_result = refresh.get("result")
    refresh_summary = (
        refresh_result.get("summary") if isinstance(refresh_result, dict) else None
    )
    refresh_ok = (
        refresh["returncode"] == 0
        and isinstance(refresh_summary, dict)
        and not any(
            refresh_summary.get(key, 0)
            for key in (
                "changed",
                "absent",
                "page_unavailable",
                "app_source_changed_quote_unverifiable",
                "reference_source_changed_quote_unverifiable",
            )
        )
    )
    report["website_refresh_ok"] = refresh_ok
    intake_result = intake.get("result")
    if intake["returncode"] or not isinstance(intake_result, dict):
        return finish(output, report, "intake_failed", 2)
    ready = intake_result.get("ready_for_analysis") is True
    report["intake_status"] = intake_result.get("status")
    report["previous_editorial"] = previous_editorial_status(
        project, intake_result.get("baseline")
    )
    if not ready:
        if intake_result.get("status") not in {"unchanged_export", "no_export_found"}:
            return finish(output, report, "intake_needs_attention", 2)
        status = (
            "unchanged_export"
            if intake_result["status"] == "unchanged_export"
            else "no_export_found"
        )
        if intake_result.get("baseline"):
            report["baseline_definitions"] = baseline_definitions_status(project)
            if report["baseline_definitions"]["needs_attention"]:
                return finish(
                    output, report, "code_or_definitions_changed_needs_attention", 2
                )
        if report["previous_editorial"]["needs_attention"]:
            report["warnings"].append(
                "A previous model cycle is failed, unfinished, or unverified. No paid retry was run because there is no new export; the outstanding editorial work still needs attention."
            )
            return finish(output, report, status + "_editorial_needs_attention", 2)
        if not refresh_ok:
            return finish(output, report, status + "_website_needs_attention", 2)
        return finish(output, report, status, 0)

    if intake_result.get("status") not in {"different_export", "first_input"}:
        return finish(output, report, "inconsistent_intake_status", 2)

    # A changed delivery can be analyzed even when the independent website refresh failed.
    # The existing rerun wrapper checks the website again and returns any failure honestly.
    try:
        selected = intake_result["selected"]
        selected_path = Path(selected["path"])
        export_date = date.fromisoformat(selected["filename_date"])
        name_match = EXPORT_NAME.fullmatch(selected_path.name)
        if (
            not name_match
            or name_match[1] != export_date.isoformat()
            or export_date > today
        ):
            raise ValueError("Selected filename/date is not a valid dated export")
        if selected_path.is_symlink() or not selected_path.is_file():
            raise ValueError("Selected input is no longer a regular local file")
        if digest_file(selected_path) != selected["sha256"]:
            raise ValueError("Selected input changed after intake")
    except (KeyError, TypeError, ValueError, OSError) as error:
        report["error"] = str(error)
        return finish(output, report, "selected_input_invalid", 2)
    report["selected_input"] = selected
    report["analysis_invoked"] = True
    previous = "latest" if intake_result.get("baseline") else "none"
    analysis = run_step(
        "analysis",
        [
            "sh",
            str(project / "scripts/monthly_rerun.sh"),
            str(selected_path),
            export_date.isoformat(),
            "monthly",
            previous,
        ],
        project,
        output,
        3600,
        {"TRACKER_PYTHON": python, "TRACKER_LLM_PROVIDER": "none"},
    )
    report["steps"]["analysis"] = analysis
    if analysis["returncode"]:
        return finish(output, report, "analysis_or_website_check_failed", 2)
    try:
        pointer = json.loads((project / "LATEST_RUN.json").read_text())
        run = (project / pointer["path"]).resolve()
        if not run.is_relative_to(project):
            raise ValueError("Latest pointer escapes the project")
        metadata = json.loads((run / "run_metadata.json").read_text())
        if (
            metadata["input"]["sha256"] != selected["sha256"]
            or pointer.get("input_sha256") != selected["sha256"]
        ):
            raise ValueError("New run is not bound to the selected export")
        if metadata["analysis_date"] != export_date.isoformat():
            raise ValueError("New run date differs from the export filename date")
        report["analysis_run"] = str(run)
        expected_run_id = pointer["run_id"]
    except (KeyError, ValueError, TypeError, OSError) as error:
        report["error"] = str(error)
        return finish(output, report, "analysis_binding_failed", 2)

    editorial_output = project / "logs/editorial" / job_id
    editorial_command = [
        python,
        "-B",
        "-m",
        "tracker",
        "editorial-cycle",
        "--run",
        "latest",
        "--output",
        str(editorial_output),
    ]
    report["context"] = {
        "status": "omitted",
        "reason": "No context supplied for this export.",
    }
    if context is not None:
        try:
            context_data = json.loads(context.read_text())
            if (
                isinstance(context_data, dict)
                and context_data.get("input_sha256") == selected["sha256"]
            ):
                editorial_command.extend(["--context", str(context.resolve())])
                report["context"] = {
                    "status": "matched",
                    "path": str(context.resolve()),
                    "sha256": digest_file(context),
                }
            else:
                report["context"][
                    "reason"
                ] = "Supplied context is not bound to this export's hash; historical diagnostics were omitted."
        except (OSError, ValueError) as error:
            report["context"][
                "reason"
            ] = f"Context unavailable or invalid; omitted: {error}"
    report["model_cycle_invoked"] = True
    report["editorial_output"] = str(editorial_output)
    # If this process is interrupted, the next monthly check can still see the attempt.
    write_json(output / "state.json", report)
    editorial = run_step("editorial", editorial_command, project, output, 3600)
    report["steps"]["editorial"] = editorial
    result = editorial.get("result")
    if editorial["returncode"]:
        return finish(output, report, "editorial_failed", 2)
    if (
        not isinstance(result, dict)
        or result.get("status") != "completed_requires_human_review"
        or result.get("publication_authorized") is not False
        or result.get("run_id") != expected_run_id
    ):
        return finish(output, report, "editorial_needs_attention", 2)
    if not refresh_ok:
        report["warnings"].append(
            "The initial live refresh failed or detected changes; later stages completed, but the initial failure remains recorded."
        )
        return finish(output, report, "completed_with_website_attention", 2)
    return finish(output, report, "completed_requires_human_review", 0)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", type=Path, default=ROOT)
    parser.add_argument("--downloads", type=Path, default=Path.home() / "Downloads")
    parser.add_argument("--inbox", action="append", type=Path, default=[])
    parser.add_argument("--today", type=date.fromisoformat, default=date.today())
    parser.add_argument("--context", type=Path)
    args = parser.parse_args()
    try:
        result = check_monthly(
            args.project, args.downloads, args.inbox, args.today, args.context
        )
    except Exception as error:
        result = {
            "status": "check_failed",
            "exit_code": 2,
            "publication_authorized": False,
            "error": str(error),
        }
    print(json.dumps(result, indent=2))
    return result["exit_code"]


if __name__ == "__main__":
    raise SystemExit(main())
