#!/bin/sh
# Rerun analysis when its input, definitions, date, or cadence changes.
# Website wording is checked on every invocation, including unchanged exports.
# TRACKER_PYTHON is one executable path, not a shell command.
# TRACKER_LLM_PROVIDER=none (default), fake (test only), or anthropic.
set -eu
CSV="${1:?CSV path required}"
DAY="${2:?analysis date YYYY-MM-DD (or 'today') required}"
CADENCE="${3:-monthly}"
PREVIOUS="${4:-latest}"
CALLER_DIR="$PWD"
case "$CSV" in /*) ;; *) CSV="$CALLER_DIR/$CSV" ;; esac
cd "$(dirname "$0")/.."
run_python() {
  if [ -n "${TRACKER_PYTHON:-}" ]; then "$TRACKER_PYTHON" "$@"
  elif command -v poetry >/dev/null 2>&1; then poetry run python "$@"
  else python3 "$@"; fi
}
if [ "$DAY" = today ]; then DAY=$(date -u +%Y-%m-%d); fi
case "$CADENCE" in monthly|fortnightly) ;; *) echo 'Cadence must be monthly or fortnightly' >&2; exit 1 ;; esac
PROVIDER="${TRACKER_LLM_PROVIDER:-none}"
case "$PROVIDER" in none|fake|anthropic) ;; *) echo 'Unknown provider' >&2; exit 1 ;; esac
CSV=$(run_python -c 'import pathlib,sys; p=pathlib.Path(sys.argv[1]).resolve(strict=True); print(p)' "$CSV")
JOB=$(run_python -c 'import pathlib,tempfile; p=pathlib.Path("logs/recurring"); p.mkdir(parents=True,exist_ok=True); print(pathlib.Path(tempfile.mkdtemp(prefix="check-",dir=p)).resolve())')
PREVIOUS_PATH=""
REUSE=no
if [ "$PREVIOUS" != none ]; then
  PREVIOUS_PATH=$(run_python - "$PREVIOUS" <<'PY'
import json,sys
from pathlib import Path
value=sys.argv[1]
p=Path(json.loads(Path('LATEST_RUN.json').read_text())['path']) if value=='latest' else Path(value)
if not p.exists(): p=Path('runs')/value
print(p.resolve(strict=True))
PY
)
  run_python -B -m tracker verify --run "$PREVIOUS_PATH" > "$JOB/previous-verification.json"
  REUSE=$(run_python - "$CSV" "$DAY" "$CADENCE" "$PREVIOUS_PATH" <<'PY'
import hashlib,json,sys
from pathlib import Path
from tracker.__main__ import code_files,ROOT
from tracker.data import json_bytes,sha256_file
csv,day,cadence,previous=sys.argv[1:]
meta=json.loads((Path(previous)/'run_metadata.json').read_text())
hashes={p.relative_to(ROOT).as_posix():sha256_file(p) for p in code_files(ROOT)}
unchanged=(meta['input']['sha256']==sha256_file(Path(csv)) and meta['analysis_date']==day and meta['cadence']==cadence and meta['code']['fingerprint_sha256']==hashlib.sha256(json_bytes(hashes)).hexdigest())
print('yes' if unchanged else 'no')
PY
)
fi
if [ "$REUSE" = yes ]; then
  NEW="$PREVIOUS_PATH"
  echo 'Analysis unchanged and verified; checking website wording again.'
else
  if [ -n "$PREVIOUS_PATH" ]; then
    run_python -B -m tracker run --input "$CSV" --analysis-date "$DAY" --cadence "$CADENCE" --previous-run "$PREVIOUS_PATH" > "$JOB/analysis.json"
  else
    run_python -B -m tracker run --input "$CSV" --analysis-date "$DAY" --cadence "$CADENCE" > "$JOB/analysis.json"
  fi
  NEW=$(run_python -c 'import json,pathlib; print(pathlib.Path(json.load(open("LATEST_RUN.json"))["path"]).resolve())')
fi
REFRESH_STATUS=0
run_python -B -m tracker refresh-claims --output "$JOB/claim_refresh" > "$JOB/claim-refresh.json" || REFRESH_STATUS=$?
# Keep outputs outside old runs when reusing an analysis; never silently rewrite them.
if [ "$REUSE" = no ] && [ "$PROVIDER" != none ]; then
  if [ "$PROVIDER" = fake ]; then echo 'TEST ONLY: the fake provider echoes existing drafts; no LLM is called.'; fi
  run_python -B -m tracker generate-draft --run "$NEW" --provider "$PROVIDER" > "$JOB/draft.json"
elif [ "$PROVIDER" = none ]; then
  echo 'LLM drafting and independent model review were not run; provider is not configured.'
fi
run_python -B -m tracker verify --run "$NEW" > "$JOB/final-verification.json"
echo "Analysis: $NEW"
echo "Website check and execution records: $JOB"
if [ "$REFRESH_STATUS" -ne 0 ]; then
  echo "Website check needs attention (exit $REFRESH_STATUS). Read $JOB/claim_refresh/claim_refresh_report.md." >&2
  exit "$REFRESH_STATUS"
fi
echo 'Analysis and website check completed. Independent review and human publication approval remain required.'
