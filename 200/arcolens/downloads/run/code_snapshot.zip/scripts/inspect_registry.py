"""Display source quotations without repeating their full provenance envelopes."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--status", default="current_tracker")
    parser.add_argument("--all-types", action="store_true")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    data = json.loads((root / "research/published_claims_raw.json").read_text())
    for claim in data["claims"]:
        if claim["publication_status"] != args.status:
            continue
        if not args.all_types and not claim["empirical"]:
            continue
        print(f"{claim['claim_id']} [{claim['claim_type']}]")
        print(claim["exact_wording"])
        print()


if __name__ == "__main__":
    main()
