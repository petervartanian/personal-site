# CSV ↔ calculation ↔ chart mapping

The detailed source/API inventory is [`research/chart_inventory.json`](../research/chart_inventory.json); readable evidence and exact controls are in [`research/site_research.md`](../research/site_research.md). This summary connects it to the executable pipeline. Source-code verification is not browser rendering or recovery of server-side transforms.

| Export | Calculation and treatment | Public chart/control |
|---|---|---|
| `aiid_id` | Unique string ID; each distinct record counts once. `report_count`, occurrence counts and people fields do not weight it. | API `incidentId`; segment → list → incident detail |
| `date` | Recorded incident calendar date; complete years stop before analysis year. Missing dates remain in all-record composition but not annual cohorts. AIID permits uncertain event/legal/report/publication proxies. | `date`/year; C01/C02 year axis. Ordinary timeline supports lower bound only; exact closed year arrays require host preset. C03/C04 expose Year selection. |
| `classified_at` | Classification time/cohort only; never replaces `date`. | Detail `classifiedAt`; distinct from mirror sync time |
| `domain_code` / `subdomain_code` | Leading numeric code plus preserved label; mutually exclusive primary tags. | Domain / Primary Subdomain; one contribution per record |
| `additional_subdomains` | JSON objects `{code, justification}`; set union with primary for any-label sensitivity, deduplicate per incident/category. | All Subdomains; chart proportions divide by **assignments**, not incidents |
| `causal_entity`, `causal_intent`, `causal_timing` | One tag each per incident. Other remains in base denominator; separate known-only sensitivity can exclude it. | Entity / Intent / Timing. Same-field multi-select OR; tested cross-field combination AND. |
| `ai_goal_primary` | Primary-purpose ranking, one tag per record. | AI Purpose; API groups a named leading set plus Other; retain Other in denominator |
| `ai_goal_secondary` | Separate secondary-purpose sensitivity; duplicate purpose per incident counts once. | Not the primary-purpose aggregate grouping |
| `eu_ai_act_risk_level` | 1 Unacceptable, 2 High Risk, 3 Limited Risk, 4 Minimal/No Risk. Automated tags, not adjudicated legality. | EU AI Act Risk Tier |
| `model_name`, `prompt_version` | Classifier provenance; used for cohort sensitivity. | Detail classifier model; **not** the AI Model Family grouping |
| `ai_models`, `ai_developers` | Registry-derived implicated-system arrays; missing, empty and unknown are distinct. Never positionally zip unrelated identity arrays. | AI Model Family / AI Developer; multi-assignment percentages, top named set + Other + identity-state buckets |
| `alleged_developer` / `subject_model_name` | Legacy/free-text labels; cannot safely split commas or silently substitute for identity arrays. | Historical/legacy field semantics; not assumed equivalent to current registry grouping |
| `<harm>_severity_direct` | Explicitly reported direct pathway, ordinal score; 0/blank unknown. | Ten per-category direct-score minimum controls; inclusive ≥, parameter names in inventory |
| `<harm>_severity_indirect` | Explicitly reported indirect pathway; keep separate from inference. | C05 direct/indirect radar and detail |
| `<harm>_severity_inferred` | Model-inferred severity, not an independently reported additional event. | No inferred numerical series in C05; no aggregate channel-comparison control |
| `<harm>_harm_caused` | JSON Reported/Directly caused/Indirectly caused/Inferred additional harm prose; Reported is not a boolean. | Detail evidence text; not an executable instruction or binary harm truth label |
| `highest_severity` | Export baseline equals max over 13 dimensions × 3 channels including model-inferred scores; the core never treats it as direct severity. | `highestSeverityScore` read by the client and labeled “Highest Direct Severity Score”; the v2 review established empirically (1,698/1,698 rows plus live detail probes of five incidents on 2026-09-27) that the headline equals this field, so the label is wrong for records that reach their maximum through indirect or inferred scores |
| `highest_severity_10` | Max over original 10 dimensions × 3 channels. | Separate API scalar; not the retrieved headline field |
| `severity_sum_direct`, `*_10` sums | Export arithmetic reconciled; sums of ordinal baselines are not a harm-burden measure. | Preserve versions; not used as new insight burden metric |
| `natsec_overall_score` | Max of five separate national-security axes in baseline. Grade 5 is Critical. | NatSec Overall Impact; C07 radar is individual-record only. V02 listing defaults/resets to ≥4. |
| `natsec_*_score`, `*_level` | Separate scores/descriptor fields; numeric ranges checked, unknown kept explicit. | NatSec category minima and novelty/imminence/autonomy filters in V02 |
| `total_people_*` | Reported/inferred harmed/exposed kept distinct. No assumption of unique people, exactness, unknown-zero semantics or overlap. Do not add as population totals. | Record detail; archived threshold replays use named reported-only proxies |
| `confidence`, `ai_goal_confidence`, `natsec_confidence` | Model annotations, not statistical confidence. | Record detail confidence labels |
| `ishikawa` | Model-proposed causes, unverified narrative data. | C06 potential-causes diagram; no aggregate causal-effect candidate |
| `source_url` | Blank throughout the baseline; report dates/IDs/URLs are absent. | Constructed AIID cite links in evidence index are lookup aids, not recovered source URLs |

## Denominator formulas

For population `P`, target `T`, and incident membership set `L_i`:

- Primary/any-label **incident share**: `100 × |{i in P : i matches T}| / |P|`.
- Singleton any-subdomain **assignment share**: `100 × |{i in P : code in L_i}| / sum_i |L_i|`. Composite assignment numerators are explicitly rejected by the prototype.
- Live timeline proportion: category count / **sum of visible series in that year**.
- Live domain-bar proportion: category count / **sum of visible series in that domain**.
- Live pie proportion: category value / **sum of visible slices**.

Thus hiding a legend category changes percentages. A filtered singleton subdomain cannot show its share of the original database. Unknown/Other values remain unless explicitly excluded in a named sensitivity. `None identified` is a real harm-category assignment bucket in the live API.

## Severity and version boundaries

The current linked v2 rubric has ten categories, 1 Negligible through 5 Catastrophic. Level 1 includes none to minor harm. The export adds psychological, epistemic and CSEA scores; their threshold definitions are absent from that linked tab. Current detail source can conditionally show further categories absent from this CSV. Prompt `aiid.v2`, rubric v2 and `_10` aggregates are distinct version concepts.

`tracker/calc.py:severity_state` counts categories reaching a threshold, with separate lower/upper bounds when components are unknown. Those bounds are measurement-availability bounds, **not confidence intervals**. Multiple high channels within one harm category do not become multiple categories. New-candidate harm comparisons avoid ordinal averages and sums.

## Verified incompatibilities and discrepancies

- Homepage/timeline/domain bars impose a 2016 floor; overview pie is all-time.
- Timeline severe-harm preset uses ineffective `minSeverity=4`; the captured API responds to `minSeverityHighest=4`. Correcting the parameter does not resolve its underlying channel/version semantics.
- The live mirror differs from the CSV even when both contain 1,698 records: record 1 has different classification dates, models, and severity values. Do not substitute this mirror for a second same-pipeline export. See review/site/delivery_evidence.json.
- All exact-year presets emitted by the corrected prototype use string values and identify the container and `incidents-arcola` dataset binding. They are host configurations; the tracker has not been modified.
- Archived Airtable internals were not recovered; current controls are not projected backwards onto those archives.

Every inventoried surface, including individual-record charts, listings, frameworks and archives, receives an explicit outcome in each run's `chart_outcomes.json`; candidates that no current chart can display faithfully are listed under a `TABLE` pseudo-surface.

## Second-version additions

| Artifact | Purpose |
|---|---|
| `discovery_ledger.json`, `tables/discovery_ledger.csv` | Every eligible or emergence-admitted ledger cell with its stage decision, reason, score components and (when selected) rank |
| `selection_decisions.json` | Retained template decisions plus one decision per discovery-stage cell |
| `quality.json` additions | zero-coded vs blank severity IDs, first id per year, late-entry table, current-year monthly counts, entry-order composition, dominant classifier cohort |
| `export_comparison/` (when `--previous-run` is given) | Added/removed IDs, reclassifications, date changes, backfill by year, with content-derived provenance |
| `claim_refresh/` (rerun script) | Read-only check that registered quotes are still live; app-source hashes for deployed-app text |
| `llm/provider_runs/` | Provider drafts with request/response provenance and numerical grounding |
