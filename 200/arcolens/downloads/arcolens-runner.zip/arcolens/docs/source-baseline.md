# Canonical source baseline

This private source starts from the complete portable package of the current
canonical source at `/Users/petervartanian/Downloads/incident-tracker-prototype/v2`. The selected delivery is
`arcolens-guide-20261001`, presentation version `arcolens-delivery-27`.

- Delivery manifest SHA-256: `73f9b6d3d79a2166dab2402cadaee61439cdbc76a97338ce1bf936f4438e6049`.
- Runner ZIP SHA-256: `71120c61c6a7e65bc50abc0b21628b8760e7e2583f867753a9b8b3445b8fc15c`.
- Pinned run: `20260928T153240558526Z-fbdc9a5f21b9`, code version `0.4.1`.
- Run artifact-manifest SHA-256: `bb3db6951073a92a1dedd7fb48e149e14c98a933a1f64f3b5ff45e9097fabdea`.
- Snapshot SHA-256: `fbdc9a5f21b9db1bf2eacdea60763e8795650bc121c631923c4856537353d4f0`.

All 1,493 package-manifest entries passed their hashes before extraction. Every
packaged delivery, tracker, test, script, and configuration file was byte-identical
to the corresponding canonical source. The package admits only the selected run,
one snapshot, and research files declared by the public capture registry. Private
source-account, publisher-password, and installed-schedule bindings are excluded.

The ten selected candidates, their calculation IDs, and the full candidate,
calculation, and claim-audit files were compared with the newer run. Those evidence
files match the previous review exactly. Later presentation corrections and
caveats are retained from the current frozen baseline and current render pipeline.

## Retained completed review and source check

The current installed presentation includes evidence that was adopted after the
portable source's frozen archive. `delivery/resources/current-baseline` retains
those exact records privately, including the original adoption record, model
requests and responses, and curated chart settings. Its manifest SHA-256 is
`6f66bd35c5dbd28bcfcbd99bffdec554de75886ca3bb516f49743b0e1c2eaf0d`.

- The completed September 28 review contains all 13 candidates and 19 published
  claims: 15 passed and 17 required revision. Human selection remains required.
  Its original manifest and numeric grounding are verified before use. The only
  adopted evidence difference is the recorded run ID; the evidence payload itself
  must match. Different analysis artifacts do not inherit this review.
- The historical October 1 source check is retained with all ten raw public-source
  captures. All capture hashes match its report, whose SHA-256 is
  `e737f7ed164500f6066db5c99270925bd3575e97a7fb6b905c39ab3363ad95f1`.
  It records 52 present quotations and seven unchanged application-source checks,
  with no changed or absent quotations. It did not check JavaScript-rendered text.
  The original October 1 timestamp remains visible; this is not a fresh check.
- Copied and exported chart settings retain the installed exact-year verification
  caveats, filter instructions, and table-only denominator instructions. The
  selected IT-D005 wording intentionally uses its narrower, matching chart window.

## Preserved behavior

- Review is light grayscale; Monitor is dark grayscale. Monitor is the former
  Premium concept, not a third mode.
- Overview headings remain “What does the data show?” and “What needs attention
  this month?” The five-step floating guide remains available.
- All thirteen candidates, seven chart views, and nineteen published-claim audits
  remain. Current-year observations, daily curves, forecast fans, source evidence,
  chart filters, and exports use the current modules.
- Intentional cyan increase and magenta decrease accents, black All records
  button, and assessment colors remain.
- The canonical source resources include the backfill and historical-completion
  evidence. The September archive remains unchanged.
- This portable review has no configured schedule. A build does not activate
  recurring work or publish. The user's installed schedule was paused separately.

## Scoped changes

`focused_review.py` adds ten priorities, concise wording, exact tracker-page
attribution, and collapsed supporting sections to the existing presentation.
`highlights.py` uses the established panel for those priorities. Guide and anchor
navigation open collapsed target sections. Existing charts, claim quotations,
raw calculations, and archived evidence are preserved. IT-D005's visible figure
and settings use the verified 2016–2025 measure of 52/56; its broader result remains
in the supporting comparison and original evidence.

Portability changes remove machine-specific defaults and use the pinned run in
regression checks. The following packaged paths differ from the baseline at this
review stage:

- `README.md`
- `START_HERE.md`
- `delivery/HOSTING.md`
- `delivery/START_HERE.md`
- `delivery/assets/guide.js`
- `delivery/highlights.py`
- `delivery/render.py`
- `delivery/tests/test_delivery.py`
- `delivery/workbench.py`
- `scripts/audit_schema.py`
- `scripts/launchd_template.plist`
- `tests/test_v2_regressions.py`

New files add the focused review layer, strict retained-evidence loader, regression
checks, browser checks, and their supporting resources. The unchanged canonical
modules still control the palette, Review/Monitor modes, charts, and guide.
