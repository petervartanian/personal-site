# Review presentation

The current Review and Monitor dashboard prioritizes ten findings from the September 27, 2026 Arcola
export. All thirteen baseline candidates remain available. The presentation does
not change the input CSV, calculations, contributing-record sets, or archived run.

The established grayscale theme, question headings, daily charts, Monitor view, and
five-step guide remain in place. The source baseline is documented in
`source-baseline.md`.

The priorities and wording live in `delivery/resources/review-selection.json`.
The input hash, analysis date, candidate-file hash, and calculation-file hash must
all match before any fixed wording, numeric summary, or directional title applies.
Each proposed passage has `wording_evidence_ids` that resolve to the saved measures.

Future runs use their own candidate wording. Discovery IDs can move between runs,
so priority matching uses the source finding title. An ambiguous or missing match
is omitted from the shortlist rather than assigned to a different finding.

## Top findings

| Candidate | Focus | Tracker placement |
| --- | --- | --- |
| IT-C003 | Single primary-purpose categories | Incident Overview, C03 |
| IT-C004 | Fraud within primary malicious-actor records | Incident Overview, C04, with C03 as an alternative |
| IT-C002 | Capability/robustness counts and shares | Incident Timeline, C02 |
| IT-C005 | Severity with and without inferred scores | Related C05/C03 views, with a separate supporting table |
| IT-C001 | Complete-year record counts | Tracker home, C01, and Incident Timeline, C02 |
| IT-D005 | Overreliance within human-computer interaction | Incident Overview, C04 |
| IT-D001 | False or misleading information within primary misinformation | Incident Overview, C04, with both date windows stated |
| IT-D002 | Direct/indirect severity threshold: share and count | Supporting annual table; no faithful aggregate chart |
| IT-D004 | Human-controlled, supervised, and autonomous tags | Supporting annual table; no matching public grouping |
| IT-D006 | False-or-misleading primary tags in 2025 | Incident Timeline, C02, with its exact-year verification caveat |

IT-D005 uses `discovery.0b6342a068.7c4bf965f2`: 52 of 56 records for 2016–2025,
which matches the chart controls. Its original all-complete-years result, 53 of 60,
and original chart configuration remain in the review data and audit details.
The primary source candidate and calculation files remain unchanged.

The four additions were checked against the current calculation records and the
retained independent review. IT-D001 uses `discovery.d5642ae3bc.base` (128/141)
and its chart-window comparison `discovery.d5642ae3bc.7c4bf965f2` (127/140), so
its chart-window warning remains. IT-D002 uses the five
`discovery.a9dfb24f8c.annual.2021` through `.2025` measures, retaining the original
ten harm dimensions, direct/indirect channels, threshold 3, and lower-bound
missing-score policy. It does not imply that a lower share means greater safety.
IT-D004 uses the six `discovery.637e47bb95.dist.2021.*` and `.dist.2025.*`
category measures so that the complementary categories and full-record denominator
remain explicit. These two findings require supporting tables.

IT-D006 uses `discovery.87a856248f.annual.2021` through `.2025`. Its headline
emphasizes the 2025 level, 63/452 (13.9%), rather than a growth rate from a
one-record baseline. The uneven annual series, 2024 dip, and unverified exact-year
preset remain explicit. Its defined subdomain and chart mapping make it a more
useful priority than an interpretation of the undefined Tool behavior tag.

Three candidates remain outside the top ten: IT-D003 has unresolved Tool-tag
semantics and a late plateau; IT-P001 primarily measures coverage induced by the
six-category prompt; and IT-P002 uses a small overlapping group whose ordering
reverses at threshold 5. All three remain available with their full evidence.
The priorities describe records and model classifications. They do not establish
population prevalence or changes in underlying AI safety. No more than ten items
can be promoted by the selection configuration.

## Rebuild and verify

From this directory:

```sh
python3 -B -m tracker verify --run latest
python3 -B -m unittest discover -s tests
python3 -B -m unittest discover -s delivery/tests
python3 -B -m delivery.runner build --output deliveries/review
```

Choose a new output directory for each build. The presentation pass updates the
current pages after either the frozen-baseline or new-run renderer, through
`delivery/focused_review.py`. The September
archive remains byte-identical to its supplied ZIP. The build verifies local links
and produces a complete runnable package without publishing or calling a model.

The source, snapshot, and plaintext review belong in this private repository.
Generated deliveries, logs, and packages are ignored by Git. Optional publication
is a separate encrypted handoff described in `delivery/HOSTING.md`.
