# Monitor

Review and Monitor use the same results and pages. Monitor adds the recorded
operating status and the existing analysis controls in a dark theme. It does not
start, stop, or reschedule the automatic job.

The hosted installation uses the existing monthly Codex automation. No additional
job is created. Its schedule is read at build time; source policy and scheduler
cadences must agree or the build stops. Recent check summaries are included only
when their hashes match their adjacent manifests. Only display fields are copied
to the website. Prompts, local paths, private receipts, and account details are not.

The private binding is `intake/schedule_display.json`, containing the absolute
`automation_path`, IANA `timezone`, and ISO-date `fortnightly_anchor`. It is excluded
from the downloadable package, along with the source policy and credentials.
The portable package reports recurring updates as unconfigured. The operator must
install an actual scheduler and source delivery before binding its status.

Status is captured at each website build. The site is not a live scheduler console.
Unchanged exports avoid recalculation and model calls and retain the published
review. Failures also retain the last successful website; the automation reports
actionable failures directly to the operator. A later successful new-data build
includes the earlier recorded checks. The in-progress check is finalized after
publication and therefore appears in a subsequent build.

Changing cadence requires updating the installed automation through Codex and
the source policy together. A browser choice or analysis command alone cannot
change an operating schedule. The current installation remains monthly.
