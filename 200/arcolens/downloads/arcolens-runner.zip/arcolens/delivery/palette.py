"""Apply neutral presentation colors without rewriting evidence or archived reports."""

from __future__ import annotations

from html.parser import HTMLParser
from pathlib import Path
import math
import re

ASSESSMENTS = {
    "Supported": "supported",
    "Unresolved": "unresolved",
    "Update needed": "updates",
    "Unsupported": "unsupported",
}
RING_COLORS = {
    "#46818a": "supported",
    "#a37960": "updates",
    "#985b72": "unsupported",
    "#82758f": "unresolved",
}
HEX_COLOR = re.compile(
    r"#(?:[0-9a-fA-F]{8}|[0-9a-fA-F]{6}|[0-9a-fA-F]{3})(?![0-9a-fA-F])"
)
COLOR_ATTRIBUTE = re.compile(
    r"""\b(style|fill|stroke|color|stop-color)=(['"])(.*?)\2""", re.DOTALL
)


def neutral_colors(text: str) -> str:
    def convert(match: re.Match[str]) -> str:
        value = match[0][1:]
        if len(value) == 3:
            value = "".join(c * 2 for c in value)
        red, green, blue = (int(value[i : i + 2], 16) for i in (0, 2, 4))
        gray = round(0.2126 * red + 0.7152 * green + 0.0722 * blue)
        return "#" + f"{gray:02x}" * 3 + value[6:]

    return HEX_COLOR.sub(convert, text)


def badge(label: str) -> str:
    return f'<span class="badge" data-assessment="{ASSESSMENTS[label]}">{label}</span>'


def order_assessments(text: str) -> str:
    """Use green, yellow, orange, red in the ring, legend, and audit sections."""
    order = {key: i for i, key in enumerate(ASSESSMENTS.values())}

    def rank(fragment: str) -> int:
        match = re.search(r'data-assessment="([^"]+)"', fragment)
        return order.get(match[1], 99) if match else 99

    def legend(match: re.Match[str]) -> str:
        links = re.findall(r"<a\b.*?</a>", match[2], re.S)
        return match[1] + "".join(sorted(links, key=rank)) + match[3]

    text = re.sub(
        r'(<div class="audit-legend">)(.*?)(</div>)', legend, text, flags=re.S
    )

    def ring(match: re.Match[str]) -> str:
        body = match[2]
        group = re.search(r"(<g\b[^>]*>)(.*?)(</g>)", body, re.S)
        if not group:
            return match[0]
        circles = re.findall(r"<circle\b[^>]*?(?:/>|>\s*</circle>)", group[2])
        offset = 0.0
        updated = []
        dividers = []
        for circle in sorted(circles, key=rank):
            width = float(re.search(r'stroke-dasharray="([\d.]+)', circle)[1])
            cx = float(re.search(r'cx="([\d.]+)', circle)[1])
            cy = float(re.search(r'cy="([\d.]+)', circle)[1])
            radius = float(re.search(r'\br="([\d.]+)', circle)[1])
            angle = offset * math.tau / 100
            inner, outer = radius - 9.5, radius + 9.5
            dividers.append(
                f'<path class="audit-divider" aria-hidden="true" d="M{cx+inner*math.cos(angle):.4f},{cy+inner*math.sin(angle):.4f}L{cx+outer*math.cos(angle):.4f},{cy+outer*math.sin(angle):.4f}"/>'
            )
            updated.append(
                re.sub(
                    r'stroke-dashoffset="[^"]+"',
                    f'stroke-dashoffset="{-offset:.8f}"',
                    circle,
                )
            )
            offset += width
        body = (
            body[: group.start(2)] + "".join(updated + dividers) + body[group.end(2) :]
        )
        opening = match[1]
        total_match = re.search(
            r'<text[^>]*class="ring-number"[^>]*>(\d+)</text>', body
        )
        if total_match:
            total = int(total_match[1])
            labels = []
            for circle in sorted(circles, key=rank):
                key = re.search(r'data-assessment="([^"]+)"', circle)[1]
                count = round(
                    float(re.search(r'stroke-dasharray="([\d.]+)', circle)[1])
                    * total
                    / 100
                )
                labels.append(
                    str(count)
                    + " "
                    + {
                        "supported": "supported",
                        "unresolved": "unresolved",
                        "updates": "need updates",
                        "unsupported": "unsupported",
                    }[key]
                )
            opening = re.sub(
                r'aria-label="[^"]*"',
                'aria-label="' + str(total) + " statements: " + ", ".join(labels) + '"',
                opening,
            )
        return opening + body + match[3]

    text = re.sub(
        r'(<svg\b[^>]*class="audit-ring"[^>]*>)(.*?)(</svg>)', ring, text, flags=re.S
    )

    def section_links(match: re.Match[str]) -> str:
        links = re.findall(r"<li>.*?</li>", match[2], re.S)
        if len(links) == 4 and all(rank(item) < 99 for item in links):
            return match[1] + "".join(sorted(links, key=rank)) + match[3]
        return match[0]

    text = re.sub(
        r'(<nav class="section-links"[^>]*><ul>)(.*?)(</ul></nav>)',
        section_links,
        text,
        flags=re.S,
    )
    groups = list(
        re.finditer(
            r'<h2\b[^>]*data-assessment="[^"]+"[^>]*>.*?(?=<h2\b|</article>)',
            text,
            re.S,
        )
    )
    if len(groups) == 4 and all(rank(item[0]) < 99 for item in groups):
        text = (
            text[: groups[0].start()]
            + "".join(sorted((item[0] for item in groups), key=rank))
            + text[groups[-1].end() :]
        )
    return text


class Presentation(HTMLParser):
    """Patch only presentation attributes, preserving all other source bytes."""

    def __init__(self, text: str) -> None:
        super().__init__(convert_charrefs=False)
        self.text = text
        self.line_offsets = [0]
        for match in re.finditer("\n", text):
            self.line_offsets.append(match.end())
        self.edits: list[tuple[int, int, str]] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        original = self.get_starttag_text()
        attributes = dict(attrs)
        line, column = self.getpos()
        offset = self.line_offsets[line - 1] + column
        changed = COLOR_ATTRIBUTE.sub(
            lambda m: m[1] + "=" + m[2] + neutral_colors(m[3]) + m[2], original
        )
        status = attributes.get("data-assessment")
        if tag == "h2" and attributes.get("id") in ASSESSMENTS.values():
            status = attributes["id"]
        if tag == "a":
            href = attributes.get("href", "") or ""
            if href.startswith("#") or "published.html#" in href:
                fragment = href.rsplit("#", 1)[-1]
                if fragment in ASSESSMENTS.values():
                    status = fragment
        if tag == "circle" and "stroke-dashoffset" in attributes:
            status = RING_COLORS.get(attributes.get("stroke", ""), status)
        if tag == "span" and "badge" in (attributes.get("class", "") or "").split():
            following = self.text[offset + len(original) :].split("<", 1)[0].strip()
            status = ASSESSMENTS.get(following, status)
        if status and "data-assessment" not in attributes:
            end = "/>" if changed.endswith("/>") else ">"
            changed = changed[: -len(end)] + f' data-assessment="{status}"' + end
        if changed != original:
            self.edits.append((offset, offset + len(original), changed))

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self.handle_starttag(tag, attrs)

    def result(self) -> str:
        self.feed(self.text)
        result = self.text
        for start, end, replacement in reversed(self.edits):
            result = result[:start] + replacement + result[end:]
        return result


def install(site: Path) -> None:
    # Frozen September pages have inline SVG colors. Archived source evidence stays
    # intact; these replacements apply only to the current presentation.
    for path in site.glob("*.css"):
        if path.name != "palette.css":
            path.write_text(neutral_colors(path.read_text()))
    for path in [*site.glob("*.html"), *site.glob("brand-*.svg")]:
        text = order_assessments(Presentation(path.read_text()).result())
        if path.suffix == ".html" and 'href="palette.css"' not in text:
            text = text.replace(
                "</head>", '<link rel="stylesheet" href="palette.css"></head>', 1
            )
        path.write_text(text)
