"""Build a self-contained, credential-free distribution with pinned evidence."""

from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path
from typing import Any

from .core import ROOT, check_run, digest, latest, read


def create(output: Path, root: Path = ROOT) -> dict[str, Any]:
    from tracker.__main__ import code_files

    root = root.resolve()
    run = latest(root)
    check_run(run, root)
    selected = set(code_files(root))
    selected.update(p for p in (root / "docs").glob("*.md"))
    selected.update(
        p
        for p in (root / "delivery").rglob("*")
        if p.is_file()
        and "__pycache__" not in p.parts
        and p.suffix not in {".pyc", ".log"}
        and "receipts" not in p.parts
    )
    selected.update(run.rglob("*"))
    selected = {p for p in selected if p.is_file()}
    selected.update(
        root / rel
        for rel in [
            "research/chart_inventory.json",
            "research/published_claims_raw.json",
            "research/web/manifest.json",
        ]
    )

    # Only paths declared by the public capture registry are admitted; shared private sources are excluded.
    def references(value: Any) -> None:
        if isinstance(value, dict):
            for k, v in value.items():
                if (
                    k.endswith("_path")
                    and isinstance(v, str)
                    and v.startswith("research/web/")
                ):
                    if ".." in Path(v).parts or "\\" in v:
                        raise ValueError("Unsafe captured-source path")
                    path = root / v
                    if path.is_file():
                        selected.add(path)
                references(v)
        elif isinstance(value, list):
            for v in value:
                references(v)

    references(read(root / "research/published_claims_raw.json"))
    references(read(root / "research/chart_inventory.json"))
    meta = read(run / "run_metadata.json")
    selected.add(root / meta["input"]["snapshot_path"])
    if any(p.is_symlink() or not p.resolve().is_relative_to(root) for p in selected):
        raise ValueError("Package input escapes the project or is a symlink")
    content = {p.relative_to(root).as_posix(): p.read_bytes() for p in selected}
    pointer = read(root / "LATEST_RUN.json")
    pointer.pop("absolute_path", None)
    content["LATEST_RUN.json"] = (json.dumps(pointer, indent=2) + "\n").encode()
    content["START_HERE.md"] = (root / "delivery/START_HERE.md").read_bytes()
    content["README.md"] = content["START_HERE.md"]
    content["requirements.txt"] = (root / "delivery/requirements.txt").read_bytes()
    content["PACKAGE_MANIFEST.json"] = (
        json.dumps(
            {
                "schema_version": 1,
                "baseline_run": run.name,
                "files": {
                    n: hashlib.sha256(b).hexdigest() for n, b in sorted(content.items())
                },
            },
            indent=2,
        )
        + "\n"
    ).encode()
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
        for name, data in sorted(content.items()):
            if Path(name).is_absolute() or ".." in Path(name).parts:
                raise ValueError("Unsafe package path")
            info = zipfile.ZipInfo("arcolens/" + name, (1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, data)
    return {
        "path": str(output),
        "sha256": digest(output),
        "files": len(content),
        "bytes": output.stat().st_size,
        "baseline_run": run.name,
    }
