"""Retain verified review evidence for its exact recorded analysis, without model calls."""

from pathlib import Path

from .core import digest, read


def load(run: Path, resources: Path) -> Path | None:
    folder = resources / "current-baseline"
    manifest = read(folder / "manifest.json")
    meta = read(run / "run_metadata.json")
    binding = {
        "input_sha256": meta["input"]["sha256"],
        "analysis_date": meta["analysis_date"],
        "files": {name: digest(run / name) for name in manifest["binding"]["files"]},
    }
    if binding != manifest["binding"]:
        return None
    for name, expected in manifest["files"].items():
        path = (folder / name).resolve()
        if not path.is_relative_to(folder.resolve()) or digest(path) != expected:
            raise ValueError("Recorded review evidence changed: " + name)
    from tracker.editorial import (
        EditorialDraft,
        EditorialReview,
        evidence_payload,
        validate_draft,
        validate_review,
    )
    from tracker.editorial_adoption import _manifest

    cycle = folder / "editorial"
    _manifest(cycle, cycle / "manifest.json")
    evidence = read(cycle / "evidence.json")
    current = evidence_payload(run, folder / "editorial-context.json")
    # This is the sole difference allowed by the preserved adoption record.
    current["run_id"] = evidence["run_id"]
    if current != evidence:
        raise ValueError("Recorded editorial evidence differs from this analysis")
    draft = EditorialDraft.model_validate(read(cycle / "draft.json"))
    review = EditorialReview.model_validate(read(cycle / "review.json"))
    if not validate_draft(draft, evidence, digest(cycle / "evidence.json"))[
        "all_grounded"
    ]:
        raise ValueError("Recorded draft failed numeric validation")
    if not validate_review(
        review, evidence, digest(cycle / "evidence.json"), digest(cycle / "draft.json")
    )["all_grounded"]:
        raise ValueError("Recorded independent review failed numeric validation")
    if read(cycle / "status.json")["status"] != "completed_requires_human_review":
        raise ValueError("Recorded review did not complete")
    return folder
