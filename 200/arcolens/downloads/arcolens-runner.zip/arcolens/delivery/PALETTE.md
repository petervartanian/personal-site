# Presentation palette

The interface uses neutral grays. Review is light; Monitor is dark. The existing
layout, lens mark, lettering, chart interactions, and underlying results are retained.

Color indicates the assessment of published statements:

| Assessment | Color | Meaning |
| --- | --- | --- |
| Supported | Green | Supported under the recorded calculation and interpretation |
| Update needed | Orange | A numerical or wording correction is required |
| Unsupported | Red | The stated interpretation is not supported |
| Unresolved | Yellow | The claim is ambiguous or cannot be verified with this export |

Visible status labels accompany every color. Orange distinguishes a required correction from an unresolved claim. Neutral gray remains the default for content without an assessment.
The mapping applies to the dashboard ring and legend, published-insight navigation
and headings, claim badges, and newly generated assessment tables.

`palette.css` defines the neutral surfaces and light/dark status tokens. The build
normalizes legacy presentation colors in CSS and inline SVG attributes, including
the preserved September layout. It does not apply a grayscale image filter, change
any finding or status, or alter archived evidence. Solid/dashed lines and filled/open
markers distinguish observed chart data from estimates without requiring hue.
