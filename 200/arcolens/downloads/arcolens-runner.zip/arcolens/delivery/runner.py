"""Portable entry point: verify, package, analyze, and build Arcolens."""

from __future__ import annotations

import argparse
import json
import re
from datetime import date
from pathlib import Path

from .core import ROOT, check_run, digest, latest, python, read, save
from .package import create
from .render import build


def verify_package(root: Path = ROOT) -> dict:
    manifest = read(root / "PACKAGE_MANIFEST.json")
    for name, expected in manifest["files"].items():
        path = (root / name).resolve()
        if not path.is_relative_to(root.resolve()) or digest(path) != expected:
            raise ValueError(f"Package file missing or changed: {name}")
    return {
        "status": "passed",
        "files": len(manifest["files"]),
        "run": check_run(latest(root), root),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("verify-package")
    p = sub.add_parser("package")
    p.add_argument("--output", type=Path, required=True)
    for name in ["build", "update"]:
        p = sub.add_parser(name)
        p.add_argument("--output", type=Path, required=True)
        p.add_argument("--run", type=Path)
        p.add_argument("--editorial", type=Path)
        p.add_argument("--refresh", type=Path)
        if name == "update":
            p.add_argument("--csv", type=Path, required=True)
            p.add_argument("--analysis-date", type=date.fromisoformat)
            p.add_argument(
                "--cadence", choices=["monthly", "fortnightly"], default="monthly"
            )
            p.add_argument("--models", action="store_true")
            p.add_argument("--refresh-claims", action="store_true")
    args = parser.parse_args()
    if args.command == "verify-package":
        result = verify_package()
    elif args.command == "package":
        result = create(args.output)
    else:
        editorial, refresh = args.editorial, args.refresh
        if args.output.exists():
            raise ValueError("Output already exists; use a new delivery folder.")
        if args.command == "update":
            match = re.fullmatch(
                r"incident_tracker_export_(\d{4}-\d{2}-\d{2})\.csv", args.csv.name
            )
            day = args.analysis_date or (
                date.fromisoformat(match[1]) if match else None
            )
            if day is None or day > date.today():
                raise ValueError("Supply a valid export date, no later than today.")
            previous = latest() if (ROOT / "LATEST_RUN.json").exists() else None
            command = [
                "-m",
                "tracker",
                "run",
                "--input",
                str(args.csv.resolve()),
                "--analysis-date",
                day.isoformat(),
                "--cadence",
                args.cadence,
            ]
            if previous:
                check_run(previous)
                command += ["--previous-run", str(previous)]
            python(*command)
            run = latest()
            if args.refresh_claims:
                from tracker.refresh import live_fetcher, refresh_claims

                refresh = ROOT / "logs/delivery" / run.name / "source-check"
                refresh_claims(
                    read(ROOT / "research/published_claims_raw.json"),
                    live_fetcher(),
                    refresh,
                    mode="live",
                )
            if args.models:
                from tracker.editorial import run_editorial_cycle

                editorial = ROOT / "logs/editorial" / ("delivery-" + run.name)
                status = run_editorial_cycle(run, editorial)
                if status.get("status") != "completed_requires_human_review":
                    raise ValueError(
                        "The model review needs attention; no new delivery was built."
                    )
        else:
            run = args.run.resolve() if args.run else latest()
        if run.resolve() != latest().resolve():
            raise ValueError(
                "Build the current verified run so the package and dashboard share a baseline."
            )
        package = ROOT / "dist/arcolens-runner.zip"
        create(package)
        result = build(run, args.output, package, editorial=editorial, refresh=refresh)
        save(
            ROOT / "LATEST_DELIVERY.json",
            {
                "path": str(args.output.resolve()),
                "run_id": run.name,
                "manifest_sha256": digest(args.output / "DELIVERY_MANIFEST.json"),
            },
        )
        result = {k: v for k, v in result.items() if k != "files"}
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
