"""Review current results; add recurring monitoring and analysis tools in Monitor."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .render import Renderer, STATUS, link
from .monitor import dashboard_panel
from .monitor_overview import queue_panel, results_panel
from .highlights import panel as highlight_panel


def install(renderer: Renderer) -> None:
    site = renderer.out
    curated = json.loads((site / "review-data.json").read_text())
    candidates = {c["candidate_id"]: c for c in curated["candidates"]}
    claims = {c["claim_id"]: c for c in curated.get("claims", [])}
    items = []
    for c in renderer.candidates:
        copy = candidates.get(c["candidate_id"], c)
        draft = renderer.model_drafts.get(c["candidate_id"])
        items.append(
            {
                "id": c["candidate_id"],
                "kind": "candidate",
                "title": copy.get("display_title", c["title"]),
                "wording": (
                    draft["suggested_wording"]
                    if draft and not copy.get("presentation_override")
                    else copy["proposed_website_text"]
                ),
                "calculation": copy.get(
                    "calculation_confidence", c["calculation_confidence"]
                ),
                "interpretation": copy.get(
                    "interpretation_confidence", c["interpretation_confidence"]
                ),
                "caveats": list(
                    dict.fromkeys(
                        [
                            *copy.get("review_notes", []),
                            *copy.get("caveats", c["caveats"]),
                        ]
                    )
                ),
                "chart": copy.get("chart_configuration", c["chart_configuration"]),
                "evidence": c["evidence_ids"],
                "page": f"finding-{c['candidate_id']}.html",
                "status": "Candidate",
                "selected": copy.get("is_shortlisted", False),
                "priority_order": (
                    curated.get("shortlist", []).index(c["candidate_id"])
                    if c["candidate_id"] in curated.get("shortlist", [])
                    else 99
                ),
                "summary": copy.get("summary"),
                "source_pages": copy.get("source_pages", []),
                "key_limitation": copy.get("key_limitation", ""),
                "wording_evidence": copy.get("wording_evidence_ids", c["evidence_ids"]),
                "model": renderer.model_reviews.get(c["candidate_id"]),
            }
        )
    for original in renderer.claims:
        c = claims.get(original["claim_id"], original)
        items.append(
            {
                "id": c["claim_id"],
                "kind": "claim",
                "title": c["exact_wording"],
                "wording": c.get("proposed_revision") or c["exact_wording"],
                "replacement_proposed": bool(c.get("proposed_revision")),
                "calculation": c["reason"],
                "interpretation": c.get("interpretation", ""),
                "caveats": c.get("editorial_flags", []),
                "chart": c.get("calculation_definition", {}),
                "evidence": c["evidence_ids"],
                "page": f"claim-{c['claim_id']}.html",
                "status": STATUS.get(c["status"], c["status"]),
                "source_url": c.get("source_url"),
                "model": renderer.model_reviews.get(c["claim_id"]),
            }
        )
    annual = renderer.timelines
    data = {
        "run_id": renderer.run.name,
        "input_sha256": renderer.meta["input"]["sha256"],
        "items": items,
        "measures": renderer.measures,
        "annual": annual,
        "analysis_date": renderer.meta.get("analysis_date", "2026-09-27"),
        "monitoring": getattr(renderer, "monitoring", {"configured": False}),
    }
    (site / "workbench-data.js").write_text(
        "window.ARCOLENS_WORKBENCH="
        + json.dumps(data, ensure_ascii=False).replace("<", "\\u003c")
        + ";\n"
    )
    write_reports(site, data)
    for path in site.glob("*.html"):
        if path.name == "workbench.html":
            continue
        text = path.read_text()
        if '<div class="appbar-actions">' not in text:
            continue
        lens_base = '<svg class="mode-lens" viewBox="0 0 24 28" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
        review_lens = (
            lens_base
            + '<path d="M12 3C4 8 4 20 12 25C20 20 20 8 12 3Z"/><path d="M2 14h20" opacity=".45"/></svg>'
        )
        monitor_lens = (
            lens_base
            + '<path d="M6 3Q13 14 6 25H18Q11 14 18 3Z"/><path d="M2 14h20" opacity=".45"/></svg>'
        )
        controls = (
            '<div class="view-switch" role="group" aria-label="Analysis mode">'
            '<button type="button" data-analysis-mode="review" aria-pressed="true" title="Review insights for publication">'
            + review_lens
            + '<span>Review</span></button><button type="button" data-analysis-mode="workbench" aria-pressed="false" title="Monitor the monthly update">'
            + monitor_lens
            + "<span>Monitor</span></button></div>"
        )
        text = text.replace("Monthly process", "Updates")
        if path.name in ("OPEN_REVIEW.html", "index.html"):
            measure = data["measures"].get("candidate.IT-C003.variant0.rank1", {})
            window = measure.get("window", {})
            if window.get("min_observed") and window.get("max_observed"):
                coverage = window["min_observed"][:4] + "–" + window["max_observed"][:4]
                text = text.replace(
                    '<span class="metric-foot">September export</span>',
                    '<span class="metric-foot">' + coverage + "</span>",
                )
        if (
            path.name in ("OPEN_REVIEW.html", "index.html")
            and '<section class="metric-strip"' in text
        ):
            marker = text.index('<section class="metric-strip"')
            end = text.index("</section>", marker) + len("</section>")
            text = (
                text[:marker]
                + '<section class="dashboard-priorities">'
                + '<section class="monitor-workspace" data-monitor-addition hidden aria-label="Monthly monitoring workspace">'
                + dashboard_panel(data["monitoring"])
                + '<div class="monitor-workspace-grid">'
                + queue_panel(data)
                + results_panel(data)
                + "</div></section>"
                + highlight_panel(data)
                + text[marker:end]
                + "</section>"
                + text[end:]
            )
        text = text.replace(
            '<div class="appbar-actions">', '<div class="appbar-actions">' + controls, 1
        )
        text = text.replace(
            "</head>",
            '<link rel="stylesheet" href="workbench.css"><script src="workbench-data.js" defer></script><script src="analysis-core.js" defer></script><script src="workbench.js" defer></script></head>',
            1,
        )
        path.write_text(text)
    # Preserve old bookmarks, taking each item to its existing review page.
    redirect = r"""<script>
const address = new URL(location.href);
const item = address.searchParams.get("item");
const page = item && /^(IT-[CDP]\d{3}|[A-Z]+-[A-Z0-9]+)$/.test(item) ? (item.startsWith("IT-") ? "finding-" : "claim-") + item + ".html" : "OPEN_REVIEW.html";
address.pathname = address.pathname.replace(/[^/]*$/, page);
address.searchParams.delete("item"); address.searchParams.set("mode", "monitor"); location.replace(address);
</script>"""
    (site / "workbench.html").write_text(
        (site / "OPEN_REVIEW.html")
        .read_text()
        .replace("</head>", redirect + "</head>", 1)
    )


def write_reports(site: Path, data: dict[str, Any]) -> None:
    downloads = site / "downloads"
    downloads.mkdir(exist_ok=True)
    for kind, name, title in [
        ("candidate", "candidate-insights.md", "Candidate findings"),
        ("claim", "published-insight-audit.md", "Published-insight audit"),
    ]:
        lines = [
            "# " + title,
            "",
            (
                "Simon, review the evidence for each candidate before choosing what to publish."
                if kind == "candidate"
                else "Simon, use these assessments to decide which published insights need updating."
            ),
            "",
            "Run: " + data["run_id"],
            "Input SHA-256: " + data["input_sha256"],
            "",
            "These findings describe the supplied incident records. They require human review before publication.",
            "",
        ]
        for item in data["items"]:
            if item["kind"] != kind:
                continue
            label = (
                "Proposed wording"
                if kind == "candidate" or item.get("replacement_proposed")
                else "Published wording; no replacement proposed"
            )
            lines += [
                "## " + item["id"] + ": " + item["title"],
                "",
                "Status: " + item["status"],
                "",
                "**" + label + "**",
                "",
                item["wording"],
                "",
                (
                    "**Calculation confidence**"
                    if kind == "candidate"
                    else "**Assessment reason**"
                ),
                "",
                item["calculation"],
                "",
                "**Interpretation**",
                "",
                item["interpretation"],
                "",
                "**Limitations**",
                "",
            ]
            lines += ["- " + c for c in item["caveats"]]
            sources = item.get("source_pages", [])
            if sources:
                lines += ["", "**Affected tracker pages**", ""]
                lines += [
                    f"- [{source['page']}]({source['url']}) → {source['chart']}"
                    for source in sources
                ]
            elif item.get("source_url"):
                lines += ["", "**Tracker source**", "", item["source_url"]]
            lines += [
                "",
                "**Chart settings**",
                "",
                "```json",
                json.dumps(item["chart"], indent=2, ensure_ascii=False),
                "```",
                "",
                "**Calculation evidence**",
                "",
            ]
            for key in item["evidence"]:
                measure = data["measures"][key]
                share = (
                    "not applicable"
                    if measure.get("percent") is None
                    else f"{measure['percent']:.2f}%"
                )
                lines += [
                    f"- {key}: {measure.get('numerator')} / {measure.get('denominator')} ({share}). Contributing IDs: run/{measure.get('numerator_ids_ref', '')}"
                ]
            lines += [
                "",
                "Model review: "
                + (
                    json.dumps(item["model"], ensure_ascii=False)
                    if item["model"]
                    else "No completed model review is attached to this delivery."
                ),
                "",
            ]
        (downloads / name).write_text("\n".join(lines), encoding="utf-8")
