"""Actionable monitoring results from the current audit and verified check history."""

from __future__ import annotations

from collections import Counter
from datetime import date
import html
from typing import Any


def claim_summary(item: dict[str, Any], measures: dict[str, Any]) -> tuple[str, str]:
    """Use current measurements rather than baking September's values into the UI."""
    key = item["id"]
    if key == "HOME-01" and (size := measures.get("claim.HOME-01.size")):
        return (
            "Record count",
            f'{size["numerator"]:,} records in the export. Update the static page count.',
        )
    if key == "OVERVIEW-03":
        first = measures.get("claim.OVERVIEW-03.level1")
        second = measures.get("claim.OVERVIEW-03.level2")
        if (
            first
            and second
            and all(m.get("percent") is not None for m in [first, second])
        ):
            return (
                "EU risk-tier shares",
                f'Tier 1: {first["percent"]:.1f}%. Tier 2: {second["percent"]:.1f}%. '
                "Replace the published percentages with the current export figures.",
            )
    if key == "TIME-04":
        annual = sorted(
            (int(ref.rsplit(".", 1)[1]), measures[ref])
            for ref in item["evidence"]
            if ref.startswith("claim.TIME-04.level1.") and ref in measures
        )
        declines = [
            (a, b)
            for (a, ma), (b, mb) in zip(annual, annual[1:])
            if ma.get("percent") is not None
            and mb.get("percent") is not None
            and mb["percent"] < ma["percent"]
        ]
        if declines:
            years = ", ".join(f"{a}–{b}" for a, b in declines)
            return (
                "EU tier-1 trend",
                f"The share fell in {years}. Revise the claim that it increased every year.",
            )
    return item["title"], item["wording"]


def queue_panel(data: dict[str, Any]) -> str:
    e = html.escape
    claims = [item for item in data["items"] if item["kind"] == "claim"]
    queue = [
        item for item in claims if item["status"] in {"Update needed", "Unsupported"}
    ]
    queue.sort(key=lambda item: ["Update needed", "Unsupported"].index(item["status"]))
    unresolved = sum(item["status"] == "Unresolved" for item in claims)
    rows = []
    for item in queue[:3]:
        title, wording = claim_summary(item, data["measures"])
        status = "updates" if item["status"] == "Update needed" else "unsupported"
        rows.append(
            f'<a class="insight-row monitor-issue" href="{e(item["page"])}">'
            f"<div><h3>{e(title)}</h3><p>{e(wording)}</p></div>"
            f'<span class="badge" data-assessment="{status}">{e(item["status"])}</span></a>'
        )
    if not rows:
        rows.append(
            '<p class="monitor-empty">No corrections flagged in the current audit.</p>'
        )
    foot = (
        f'<a class="monitor-queue-foot" href="published.html#unresolved">{unresolved} statements need clarification →</a>'
        if unresolved
        else ""
    )
    return (
        '<section class="insight-overview monitor-overview" aria-labelledby="monitor-issues-title">'
        '<div class="insight-heading"><h2 id="monitor-issues-title">Corrections to review</h2>'
        f'<a href="published.html#updates">{len(queue)} flagged</a></div>'
        + "".join(rows)
        + foot
        + "</section>"
    )


def results_panel(data: dict[str, Any]) -> str:
    e = html.escape
    state = data["monitoring"]
    recent = next(iter(state.get("checks", [])), None)
    source = state.get("source_check", {}).get("summary", {})
    baseline = date.fromisoformat(data["analysis_date"])
    baseline_label = f"{baseline:%b} {baseline.day}, {baseline.year}"
    export_value = "Pending"
    export_detail = f"Next export after {baseline_label}"
    if recent and recent["new_data"]:
        export_value, export_detail = "Received", recent["label"]
    elif recent and recent["label"] != "No new export":
        export_value, export_detail = "Attention", recent["label"]
    elif not recent:
        export_value, export_detail = "Unchecked", "No delivery check recorded"
    sources = source.get("present")
    source_only = source.get("app_source_unchanged", 0) + source.get(
        "reference_source_unchanged", 0
    )
    unmatched = sum(
        source.get(k, 0)
        for k in [
            "changed",
            "absent",
            "page_unavailable",
            "app_source_changed_quote_unverifiable",
            "reference_source_changed_quote_unverifiable",
        ]
    )
    reviewed = [item for item in data["items"] if item.get("model")]
    outcomes = Counter(item["model"]["disposition"] for item in reviewed)
    cards = [
        ("monthly.html", "Next export", export_value, export_detail),
        (
            "source-check.html",
            "Quotations matched",
            str(sources) if sources is not None else "—",
            (
                f"{source_only} additional source-only checks"
                if sources is not None
                else "No source check recorded"
            ),
        ),
        (
            "source-check.html",
            "Source alerts",
            str(unmatched) if source else "—",
            (
                "Changed, missing, or unverifiable statements"
                if unmatched
                else (
                    "No statement changes flagged"
                    if source
                    else "No source check recorded"
                )
            ),
        ),
        (
            "model-review.html",
            "Model review",
            str(len(reviewed)),
            (
                f'{outcomes["revise"]} revisions suggested'
                + (f'; {outcomes["withhold"]} withheld' if outcomes["withhold"] else "")
                if reviewed
                else "No completed reviews"
            ),
        ),
    ]
    return (
        '<section class="metric-strip monitor-results" aria-label="Latest monitoring results">'
        + "".join(
            f'<a class="metric" href="{e(href)}"><span class="metric-label">{e(label)}</span>'
            f'<strong>{e(value)}</strong><span class="metric-foot">{e(detail)}</span></a>'
            for href, label, value, detail in cards
        )
        + "</section>"
    )


def paired(review: str, monitor: str, label: str) -> str:
    """Both panels occupy one grid cell, preserving geometry when switching modes."""
    return (
        f'<div class="mode-panels" aria-label="{html.escape(label)}">'
        f'<div class="mode-panel is-active" data-mode-panel="review">{review}</div>'
        f'<div class="mode-panel" data-mode-panel="workbench" inert aria-hidden="true">{monitor}</div></div>'
    )
