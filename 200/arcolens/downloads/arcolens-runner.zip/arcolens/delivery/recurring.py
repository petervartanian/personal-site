"""Receive checked cloud downloads, detect missed deliveries, and run the review."""

from __future__ import annotations

import argparse
from contextlib import contextmanager
from datetime import date, datetime, timedelta, timezone
import json
import os
from pathlib import Path
import re
import sys
from typing import Any, Iterator
import uuid

from .core import ROOT, digest, read, save

EXPORT = re.compile(r"incident_tracker_export_(\d{4}-\d{2}-\d{2})\.csv\Z")


def utc_stamp(value: str) -> datetime:
    stamp = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if stamp.tzinfo is None:
        raise ValueError("Source timestamps must include a time zone")
    return stamp.astimezone(timezone.utc)


def source_check(
    receipt: dict[str, Any], policy: dict[str, Any], root: Path, now: datetime
) -> dict[str, Any]:
    """Check a connector receipt; this does not independently authenticate Drive."""
    errors: list[str] = []
    inboxes: list[str] = []
    if policy.get("cadence", "monthly") not in {"monthly", "fortnightly"}:
        raise ValueError("Unrecognized delivery cadence")
    if (
        not isinstance(policy.get("max_age_days", 35), int)
        or policy.get("max_age_days", 35) < 1
    ):
        raise ValueError("Maximum export age must be a positive number of days")
    if receipt.get("transport") != "connected_google_drive":
        errors.append("The source check did not use the configured Drive connector")
    if receipt.get("account") != policy["account"]:
        errors.append("The source check used a different Drive account")
    age = now - utc_stamp(receipt["checked_at_utc"])
    if age < -timedelta(minutes=5) or age > timedelta(hours=24):
        errors.append("The Drive check is future-dated or more than 24 hours old")
    folders = receipt.get("folders", [])
    by_id = {folder["id"]: folder for folder in folders}
    if len(by_id) != len(folders):
        errors.append("A source folder was recorded more than once")
    required = set(policy["folder_ids"])
    if not required or required != set(by_id):
        errors.append(
            "The receipt does not cover exactly the configured source folders"
        )
    checked_files = []
    intake_root = (root / "intake/drive").resolve()
    for folder_id in sorted(required & set(by_id)):
        folder = by_id[folder_id]
        if (
            folder.get("status") != "complete"
            or folder.get("all_pages_read") is not True
        ):
            errors.append(f"Source folder {folder_id} was not read completely")
        files = folder.get("files")
        if not isinstance(files, list):
            errors.append(f"Source folder {folder_id} has no file inventory")
            continue
        for item in files:
            name = item.get("name", "")
            if not name.startswith("incident_tracker_export_"):
                continue
            matched = EXPORT.fullmatch(name)
            if not matched:
                errors.append(f"Unrecognized modern export filename: {name}")
                continue
            try:
                if not item.get("id"):
                    raise ValueError("Missing Drive file ID")
                if date.fromisoformat(matched[1]) > now.date():
                    raise ValueError("Future export date")
                path = Path(item["local_path"])
                resolved = path.resolve()
                if (
                    path.is_symlink()
                    or not path.is_file()
                    or not resolved.is_relative_to(intake_root)
                    or resolved.name != name
                ):
                    raise ValueError(
                        "Download is not an original-name file inside intake/drive"
                    )
                if any(parent.is_symlink() for parent in path.parents):
                    raise ValueError("Download path contains a symbolic link")
                downloaded = utc_stamp(item["retrieved_at_utc"])
                if downloaded > now + timedelta(minutes=5) or downloaded > utc_stamp(
                    receipt["checked_at_utc"]
                ):
                    raise ValueError("Invalid download timestamp")
                if digest(path) != item["sha256"]:
                    raise ValueError("Downloaded bytes do not match the receipt")
                inboxes.append(str(resolved.parent))
                checked_files.append(
                    {
                        "source_id": item["id"],
                        "name": name,
                        "sha256": item["sha256"],
                        "local_path": str(resolved),
                    }
                )
            except (KeyError, TypeError, ValueError, OSError) as error:
                errors.append(f"{name}: {error}")
    return {
        "status": "passed" if not errors else "source_delivery_needs_attention",
        "errors": errors,
        "inboxes": sorted(set(inboxes)),
        "downloads": checked_files,
        "checked_at_utc": receipt["checked_at_utc"],
        "provenance_limit": "Connector observations and downloaded hashes are recorded. This receipt is not a publisher signature or proof of Arcola's collection date.",
    }


def freshness(
    intake: dict[str, Any], today: date, policy: dict[str, Any]
) -> dict[str, Any]:
    from tracker.__main__ import next_due

    selected = intake.get("selected") or {}
    baseline = intake.get("baseline") or {}
    same = selected.get("sha256") == baseline.get("input_sha256") and bool(selected)
    # Renaming identical bytes must not reset the age of the analyzed data.
    day = baseline.get("export_date") if same else selected.get("filename_date")
    day = day or baseline.get("export_date")
    if not day:
        return {"status": "no_dated_export", "needs_attention": True}
    export_day = date.fromisoformat(day)
    due = next_due(export_day, policy.get("cadence", "monthly"))
    days_old = (today - export_day).days
    overdue = days_old > policy.get("max_age_days", 35)
    missing = today >= due and not intake.get("ready_for_analysis")
    return {
        "status": (
            "export_overdue"
            if overdue
            else (
                "expected_update_not_received" if missing else "within_delivery_window"
            )
        ),
        "needs_attention": overdue or missing,
        "data_date": day,
        "days_old": days_old,
        "next_expected_date": due.isoformat(),
        "same_bytes_as_baseline": same,
        "note": "An unchanged file may be legitimate, but it does not establish that a fresh export was produced. Confirm upstream delivery when an expected update does not arrive.",
    }


@contextmanager
def single_run(root: Path) -> Iterator[None]:
    """A crashed run leaves an explicit lock to diagnose, never an automatic paid retry."""
    lock = root / "intake/recurring.lock"
    lock.parent.mkdir(parents=True, exist_ok=True)
    token = uuid.uuid4().hex
    try:
        handle = os.open(lock, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError as error:
        raise ValueError(
            "Another recurring run is active or was interrupted; inspect intake/recurring.lock before retrying"
        ) from error
    try:
        with os.fdopen(handle, "w") as stream:
            json.dump(
                {
                    "pid": os.getpid(),
                    "token": token,
                    "started_at_utc": datetime.now(timezone.utc).isoformat(),
                },
                stream,
            )
        yield
    finally:
        if lock.exists() and read(lock).get("token") == token:
            lock.unlink()


def run(
    config: Path,
    receipt_path: Path,
    policy_path: Path,
    downloads: Path,
    root: Path = ROOT,
    now: datetime | None = None,
) -> dict[str, Any]:
    from scripts.check_monthly import check_monthly, run_step
    from tracker.data import load_incidents
    from tracker.intake import inspect_exports
    from .check_and_publish import deliver

    now = now or datetime.now(timezone.utc)
    output = (
        root
        / "logs/recurring"
        / (now.strftime("%Y%m%dT%H%M%S%fZ") + "-" + uuid.uuid4().hex[:8])
    )
    output.mkdir(parents=True, exist_ok=False)
    report: dict[str, Any] = {
        "schema_version": 1,
        "started_at_utc": now.isoformat(),
        "output": str(output),
        "analysis_invoked": False,
        "model_cycle_invoked": False,
        "published": False,
        "exit_code": 2,
    }
    try:
        with single_run(root):
            policy = {"cadence": "monthly", "max_age_days": 35}
            try:
                policy = read(policy_path)
                receipt = read(receipt_path)
                save(output / "source_policy.json", policy)
                save(output / "source_receipt.json", receipt)
                source = source_check(receipt, policy, root, now)
            except (KeyError, TypeError, ValueError, OSError) as error:
                source = {
                    "status": "source_delivery_needs_attention",
                    "errors": [str(error)],
                    "inboxes": [],
                }
            report["source_delivery"] = source
            intake = inspect_exports(
                root,
                [downloads, *(Path(p) for p in source["inboxes"])],
                now.date(),
                load_incidents,
            )
            save(output / "intake.json", intake)
            report["intake_status"] = intake["status"]
            report["freshness"] = (
                {"status": "not_evaluated", "needs_attention": True}
                if source["errors"]
                else freshness(intake, now.date(), policy)
            )
            if source["errors"] or report["freshness"]["needs_attention"]:
                # Keep the published-quotation audit live even when upstream delivery fails.
                report["claim_refresh"] = run_step(
                    "refresh",
                    [
                        sys.executable,
                        "-B",
                        "-m",
                        "tracker",
                        "refresh-claims",
                        "--output",
                        str(output / "claim_refresh"),
                    ],
                    root,
                    output,
                    600,
                )
                report["status"] = (
                    "source_delivery_needs_attention"
                    if source["errors"]
                    else report["freshness"]["status"]
                )
            else:
                check = check_monthly(
                    root, downloads, [Path(p) for p in source["inboxes"]], now.date()
                )
                report.update(
                    check_status=check["status"],
                    check_output=check["output"],
                    analysis_invoked=check.get("analysis_invoked", False),
                    model_cycle_invoked=check.get("model_cycle_invoked", False),
                )
                publication = deliver(check, config, root)
                report.update(
                    status=check["status"],
                    exit_code=check["exit_code"],
                    delivery=publication,
                    published=publication.get("status") == "deployed",
                )
                if (
                    check.get("analysis_invoked")
                    and check["exit_code"] == 0
                    and publication.get("status") != "deployed"
                ):
                    report.update(status="publication_needs_attention", exit_code=2)
    except Exception as error:
        report.update(status="recurring_failed", error=str(error))
    report["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
    save(output / "summary.json", report)
    save(
        output / "manifest.json",
        {
            "files": {
                p.relative_to(output).as_posix(): digest(p)
                for p in sorted(output.rglob("*"))
                if p.is_file() and p.name != "manifest.json"
            }
        },
    )
    save(
        root / "LATEST_RECURRING.json",
        {
            "path": str(output),
            "status": report["status"],
            "manifest_sha256": digest(output / "manifest.json"),
        },
    )
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--source-check", type=Path, required=True)
    parser.add_argument("--source-policy", type=Path, required=True)
    parser.add_argument("--downloads", type=Path, default=Path.home() / "Downloads")
    args = parser.parse_args()
    report = run(args.config, args.source_check, args.source_policy, args.downloads)
    print(json.dumps(report, indent=2))
    raise SystemExit(report["exit_code"])


if __name__ == "__main__":
    main()
