"""Date-exact chart detail, bound to the verified annual incident ID sets."""

from __future__ import annotations

import csv
import calendar
import hashlib
import html
import json
import math
import re
from bisect import bisect_right
from datetime import date, timedelta
from pathlib import Path
from typing import Any


def partial_measure(renderer: Any, identifier: str, points: list[dict]) -> dict | None:
    keys = [f"candidate.{identifier}.partial_current_year"]
    if points:
        prefix = points[0]["calculation_id"].rsplit(".annual.", 1)[0]
        keys.append(prefix + ".partial_current_year")
    return next(
        (
            renderer.measures[k]
            for k in keys
            if k in renderer.measures
            and renderer.measures[k]["window"].get("requested_years")
            == [renderer.day.year]
        ),
        None,
    )


def previous_anniversary(day: date) -> date:
    """A calendar 12-month window, including leap days where applicable."""
    try:
        return day.replace(year=day.year - 1)
    except ValueError:
        return day.replace(year=day.year - 1, day=28)


def build_series(renderer: Any) -> dict[str, dict]:
    source = renderer.root / renderer.meta["input"]["snapshot_path"]
    if (
        hashlib.sha256(source.read_bytes()).hexdigest()
        != renderer.meta["input"]["sha256"]
    ):
        raise ValueError("Daily timeline input differs from the verified export")
    dates = {}
    with source.open(newline="", encoding="utf-8-sig") as stream:
        for row in csv.DictReader(stream):
            identifier = row["aiid_id"].strip()
            if identifier in dates:
                raise ValueError("Duplicate incident ID in timeline input")
            dates[identifier] = (
                date.fromisoformat(row["date"][:10]) if row["date"] else None
            )
    result = {}
    for candidate in renderer.candidates:
        points = renderer.annual(candidate)
        if not points:
            continue
        identifier = candidate["candidate_id"]
        partial = partial_measure(renderer, identifier, points)
        measures = [renderer.measures[p["calculation_id"]] for p in points]
        if partial:
            measures.append(partial)
        union = {"numerator": set(), "denominator": set()}
        for measure in measures:
            for side in union:
                ids = json.loads(
                    (renderer.run / measure[side + "_ids_ref"]).read_text()
                )
                if len(ids) != measure[side] or len(set(ids)) != len(ids):
                    raise ValueError("Timeline needs distinct incident counts")
                expected_years = measure["window"]["requested_years"]
                for incident in ids:
                    day = dates.get(incident)
                    if (
                        day is None
                        or day.year not in expected_years
                        or day > renderer.day
                    ):
                        raise ValueError(
                            f"Invalid timeline date for incident {incident}"
                        )
                union[side].update(ids)
        ordered = {
            side: sorted(dates[i].toordinal() for i in ids)
            for side, ids in union.items()
        }

        def row(day: date, start: date, window: str) -> dict:
            nums = [
                bisect_right(ordered[s], day.toordinal())
                - bisect_right(ordered[s], start.toordinal() - 1)
                for s in ("numerator", "denominator")
            ]
            return {
                "date": day.isoformat(),
                "window_start": start.isoformat(),
                "window": window,
                "numerator": nums[0],
                "denominator": nums[1],
                "percent": 100 * nums[0] / nums[1] if nums[1] else None,
                "daily_numerator": sum(dates[i] == day for i in union["numerator"]),
                "daily_denominator": sum(dates[i] == day for i in union["denominator"]),
            }

        historical = []
        day = date(points[0]["year"], 12, 31)
        last = date(points[-1]["year"], 12, 31)
        while day <= last:
            historical.append(
                row(
                    day,
                    previous_anniversary(day) + timedelta(days=1),
                    "preceding_12_months",
                )
            )
            day += timedelta(days=1)
        by_date = {r["date"]: r for r in historical}
        for point in points:
            anchor = by_date[f'{point["year"]}-12-31']
            if any(anchor[k] != point[k] for k in ("numerator", "denominator")):
                raise ValueError("Daily chart fails to reproduce its annual anchor")
        current = []
        observed_current = []
        if partial:
            day = date(renderer.day.year, 1, 1)
            while day <= renderer.day:
                current.append(row(day, date(day.year, 1, 1), "year_to_date"))
                observed_current.append(
                    row(
                        day,
                        previous_anniversary(day) + timedelta(days=1),
                        "preceding_12_months",
                    )
                )
                day += timedelta(days=1)
            if any(current[-1][k] != partial[k] for k in ("numerator", "denominator")):
                raise ValueError(
                    "Daily chart fails to reproduce its partial-year anchor"
                )
        elapsed = (renderer.day - date(renderer.day.year, 1, 1)).days + 1
        days = (date(renderer.day.year + 1, 1, 1) - date(renderer.day.year, 1, 1)).days
        projection = (
            {
                "date": f"{renderer.day.year}-12-31",
                "numerator": partial["numerator"] * days / elapsed,
                "denominator": partial["denominator"] * days / elapsed,
                "percent": partial["percent"],
                "status": "Unadjusted year-end estimate",
            }
            if partial
            else None
        )
        if projection:
            scenarios = [{"basis": "calendar_pace", **projection}]
            for point in points:
                year = point["year"]
                matching_day = date(
                    year,
                    renderer.day.month,
                    min(
                        renderer.day.day,
                        calendar.monthrange(year, renderer.day.month)[1],
                    ),
                )
                historical_partial = row(matching_day, date(year, 1, 1), "year_to_date")
                if (
                    not historical_partial["numerator"]
                    or not historical_partial["denominator"]
                ):
                    continue
                numerator = (
                    partial["numerator"]
                    * point["numerator"]
                    / historical_partial["numerator"]
                )
                denominator = (
                    partial["denominator"]
                    * point["denominator"]
                    / historical_partial["denominator"]
                )
                scenarios.append(
                    {
                        "basis": "historical_timing",
                        "year": year,
                        "historical_through_cutoff": historical_partial,
                        "historical_full_year": point,
                        "numerator": numerator,
                        "denominator": denominator,
                        "percent": (
                            100 * numerator / denominator if denominator else None
                        ),
                    }
                )
            bounds = {}
            for view, field in [("counts", "numerator"), ("share", "percent")]:
                values = [s[field] for s in scenarios if s[field] is not None]
                if view == "share":
                    values = [v for v in values if 0 <= v <= 100]
                bounds[view] = [min(values), max(values)] if values else None
            projection["range"] = {
                "method": "calendar_pace_and_historical_timing_envelope",
                "bounds": bounds,
                "scenarios": scenarios,
                "interpretation": "Min–max across stated pace and historical timing assumptions; no calibrated probability coverage.",
                "excludes": [
                    "unobserved reporting delays",
                    "future backfill",
                    "classification revisions",
                    "changes in collection coverage",
                ],
            }
        result[identifier] = {
            "id": identifier,
            "points": points,
            "partial": partial,
            "default_view": "counts" if identifier == "IT-C001" else "share",
            "cutoff": renderer.day.isoformat(),
            "historical": historical,
            "current": current,
            "observed_current": observed_current,
            "projection": projection,
        }
    from .forecast import apply

    apply(result, renderer.day)
    return result


def value(row: dict, view: str) -> float | None:
    return row["numerator"] if view == "counts" else row["percent"]


def svg(series: dict, include_partial: bool, view: str | None = None) -> str:
    """Static fallback; the interactive renderer uses the same daily rows and scale."""
    view = view or series["default_view"]
    historic, current = series["historical"], (
        series["current"] if include_partial else []
    )
    observed_rows = historic + (series["observed_current"] if current else [])
    projection = series["projection"] if current else None
    uniform_share = series["id"] == "IT-C001" and view == "share"
    top, bottom, left, right = 38, 226, 70, 740
    first_day, last_day = date.fromisoformat(historic[0]["date"]), date.fromisoformat(
        historic[-1]["date"]
    )
    cutoff = date.fromisoformat(series["cutoff"])
    year_end = date(cutoff.year, 12, 31)
    axis_end = year_end if current else last_day
    maximum = max(
        [
            1,
            *[value(r, view) or 0 for r in observed_rows],
            value(projection, view) or 0 if projection else 0,
            (
                projection["range"]["bounds"][view][1]
                if projection and projection["range"]["bounds"][view]
                else 0
            ),
        ]
    )
    step = 10 ** math.floor(math.log10(maximum))
    ceiling = math.ceil(maximum / step) * step if view == "counts" else 100
    y = lambda v: bottom - (v or 0) / ceiling * (bottom - top)
    hx = lambda d: left + (date.fromisoformat(d) - first_day).days / max(
        1, (axis_end - first_day).days
    ) * (right - left)
    cx = hx
    fmt = lambda v: (
        "—"
        if v is None
        else (
            f"{math.floor(v + .5):,}"
            if view == "counts"
            else f"{v:.2f}".rstrip("0").rstrip(".") + "%"
        )
    )
    descriptions = [f'{p["year"]}: {fmt(value(p, view))}' for p in series["points"]]
    bounds = (
        projection["range"]["bounds"][view]
        if projection and not uniform_share
        else None
    )
    rounding = projection["range"].get("display_step", 1) if projection else 1
    nearest = bool(
        projection and projection["range"].get("display_rounding") == "nearest"
    )
    lower_round = (
        lambda v: math.floor(v / rounding + (0.5 if nearest else 0)) * rounding
    )
    upper_round = (
        lambda v: (
            math.floor(v / rounding + 0.5) if nearest else math.ceil(v / rounding)
        )
        * rounding
    )
    range_text = (
        f"{lower_round(bounds[0]):,}–{upper_round(bounds[1]):,}"
        if bounds and view == "counts"
        else f"{bounds[0]:.1f}–{bounds[1]:.1f}%" if bounds else "—"
    )
    model_range = bool(
        projection
        and projection["range"].get("coverage_probability")
        and view == "counts"
    )
    coverage = (
        f'{projection["range"]["coverage_probability"] * 100:g}%' if model_range else ""
    )
    range_kind = f"central {coverage} model range" if model_range else "scenario range"
    if current:
        descriptions += [
            f"Records in preceding 12 months through {series['cutoff']}: {fmt(value(observed_rows[-1], view))}",
            f"{cutoff.year} so far (separate calendar-year total): {fmt(value(current[-1], view))}",
        ]
        if not uniform_share:
            descriptions.append(f"{cutoff.year} year-end {range_kind}: {range_text}")
    parts = [
        f'<svg viewBox="0 0 780 278" class="daily-chart" role="img" aria-label="{html.escape("; ".join(descriptions))}" data-daily-chart="{series["id"]}">'
    ]
    for tick in (0, ceiling / 2, ceiling):
        tick_label = fmt(tick) if view == "counts" else f"{tick:g}%"
        parts += [
            f'<line x1="{left}" x2="{right}" y1="{y(tick):.3f}" y2="{y(tick):.3f}" class="daily-grid"/>',
            f'<text x="{left-8}" y="{y(tick)+4:.3f}" text-anchor="end" class="axis-label">{tick_label}</text>',
        ]

    def trace(rows: list[dict], x: Any, kind: str) -> None:
        path = ""
        previous = None
        for r in rows:
            v = value(r, view)
            if v is None:
                previous = None
                continue
            px, py = x(r["date"]), y(v)
            path += f"M{px:.3f},{py:.3f}" if previous is None else f"H{px:.3f}V{py:.3f}"
            previous = r
        parts.append(
            f'<path class="daily-trace daily-{kind}" data-daily-points="{len(rows)}" d="{path}"/>'
        )

    trace(observed_rows, hx, "historical")
    for p in series["points"]:
        px, py = hx(f'{p["year"]}-12-31'), y(value(p, view))
        parts += [
            f'<circle cx="{px:.3f}" cy="{py:.3f}" r="3.8" class="daily-annual-dot"><title>{p["year"]}: {fmt(value(p, view))}</title></circle>',
            f'<text x="{px:.3f}" y="{bottom+23}" text-anchor="middle" class="axis-label">{p["year"]}</text>',
        ]
    if current:
        observed, estimated = value(observed_rows[-1], view), value(projection, view)
        if observed is not None and estimated is not None:
            ox, oy = cx(series["cutoff"]), y(observed)
            parts += [
                f'<circle cx="{ox:.3f}" cy="{oy:.3f}" r="4.5" class="daily-observed-dot" data-observed-value="{observed}"/>',
            ]
            if bounds:
                low, high = y(bounds[0]), y(bounds[1])
                parts.append(
                    f'<g class="year-end-range" data-lower="{bounds[0]}" data-upper="{bounds[1]}" data-date="{year_end}">'
                    f"<title>{cutoff.year} year-end {range_kind}: {range_text}</title>"
                    f'<path class="forecast-fan" data-origin-date="{series["cutoff"]}" data-origin-value="{observed}" d="M{ox:.3f},{oy:.3f}L{right},{high:.3f}L{right},{low:.3f}Z"/>'
                    "</g>"
                )
        parts += [
            f'<text x="{right}" y="{bottom+23}" text-anchor="middle" class="axis-label">{cutoff.year}</text>',
        ]
    parts.append("</svg>")
    if current and observed is not None and estimated is not None:
        if uniform_share:
            parts.append(
                '<dl class="daily-endpoints is-single" aria-label="Share of all records"><div><dt>Share of records</dt><dd>100%</dd></div></dl>'
            )
            return "".join(parts)
        parts.append(
            '<dl class="daily-endpoints" aria-label="Current-year chart points">'
            f"<div><dt>12 months to {cutoff:%b} {cutoff.day}</dt><dd>{fmt(observed)}</dd></div>"
            f'<div><dt>{cutoff.year} year-end range{f" (central {coverage})" if model_range else ""}</dt><dd>{"n ≈ " if view == "counts" else ""}{range_text}</dd></div>'
            "</dl>"
        )
    return "".join(parts)


def latest_reading(series: dict) -> str:
    """Match the default headline to the observed 12-month curve, including this year."""
    rows = series["historical"] + series["observed_current"]
    first, last = rows[0], rows[-1]
    view = series["default_view"]
    key = "numerator" if view == "counts" else "percent"
    start, end = first[key], last[key]

    def fmt(value: float | None) -> str:
        if value is None:
            return "—"
        return (
            f"{value:,.0f}"
            if view == "counts"
            else f"{value:.2f}".rstrip("0").rstrip(".") + "%"
        )

    direction = (
        "flat"
        if start is None or end is None or start == end
        else "increase" if end > start else "decrease"
    )
    if start == end:
        values = f'<div class="trend-values"><strong>{fmt(end)}</strong></div>'
    else:
        arrow = {"increase": "↗", "decrease": "↘", "flat": "→"}[direction]
        verb = {"increase": "increased to", "decrease": "decreased to", "flat": "to"}[
            direction
        ]
        values = (
            f'<div class="trend-values" aria-label="{fmt(start)} {verb} {fmt(end)}">'
            f'<span>{fmt(start)}</span><span class="value-arrow {direction}" aria-hidden="true">{arrow}</span>'
            f"<strong>{fmt(end)}</strong></div>"
        )

    def date_label(iso: str) -> str:
        day = date.fromisoformat(iso)
        return (
            str(day.year)
            if iso.endswith("-12-31")
            else f"{day:%b} {day.day}, {day.year}"
        )

    start_label, end_label = date_label(first["date"]), date_label(last["date"])
    period = (
        end_label if first["date"] == last["date"] else start_label + "–" + end_label
    )
    measure = (
        "12-month record count" if view == "counts" else "12-month share of records"
    )
    return (
        f'<div class="trend-reading"><div><span class="measure-label">{measure}</span>'
        + values
        + f'</div><span class="period-label">{period}</span></div>'
    )


def update_charts(site: Path, series: dict[str, dict]) -> int:
    count = 0
    for path in site.glob("*.html"):
        if path.name == "workbench.html":
            continue
        text = path.read_text()
        current_id = None

        def button_direction(match: re.Match) -> str:
            identifier = match[2]
            if identifier not in series:
                return match[0]
            current = series[identifier]
            rows = current["historical"] + current["observed_current"]
            key = "numerator" if current["default_view"] == "counts" else "percent"
            first, last = rows[0][key], rows[-1][key]
            direction = (
                "neutral"
                if identifier == "IT-C001"
                else (
                    "flat"
                    if first is None or last is None or first == last
                    else "increase" if last > first else "decrease"
                )
            )
            return match[1] + f' data-trend-direction="{direction}">'

        text = re.sub(
            r'(<button\b[^>]*data-trend="([^"]+)"[^>]*)>',
            button_direction,
            text,
        )

        def replace(match: re.Match) -> str:
            nonlocal count, current_id
            figure = match[0]
            if 'class="finding-chart"' not in figure:
                return figure
            explicit = re.search(
                r'data-(?:timeline|projection|observed-partial)="([^"]+)"', figure
            )
            if explicit:
                current_id = explicit[1]
            elif path.stem.startswith("finding-"):
                current_id = path.stem.removeprefix("finding-")
            if current_id not in series:
                return figure
            include = 'data-year-view="partial"' in figure
            opening = figure[: figure.index(">")]
            opening = re.sub(r' data-timeline="[^"]*"', "", opening)
            caption = (
                "Share of records"
                if series[current_id]["default_view"] == "share"
                else "Records"
            )
            count += 1
            return (
                opening
                + f' data-timeline="{current_id}">'
                + f"<figcaption>{caption}</figcaption>"
                + svg(series[current_id], include)
                + "</figure>"
            )

        text = re.sub(r"<figure\b.*?</figure>", replace, text, flags=re.S)
        text = re.sub(
            r'(<section\b[^>]*data-trend-pane="([^"]+)"[^>]*>.*?)<div class="trend-reading">.*?<span class="period-label">.*?</span></div>',
            lambda match: (
                match[1] + latest_reading(series[match[2]])
                if match[2] in series
                else match[0]
            ),
            text,
            flags=re.S,
        )
        text = re.sub(
            r'<p class="forecast-legend"[^>]*>.*?</p>',
            '<p class="forecast-legend" data-year-view="partial"><a href="methods.html#section-projecting-2026">Chart method</a></p>',
            text,
            flags=re.S,
        )
        path.write_text(text)
    return count


def write_evidence(site: Path, series: dict[str, dict], metadata: dict) -> None:
    payload = {
        "schema_version": 4,
        "input_sha256": metadata["input"]["sha256"],
        "date_field": "date",
        "cutoff": metadata["analysis_date"],
        "historical_window": "(same calendar date one year earlier, current date]; Feb 29 maps to Feb 28",
        "observed_curve_window": "Same trailing 12-calendar-month window for historical and current-year dates",
        "current_window": "January 1 through each date; separate from the plotted trailing window",
        "series": series,
    }
    (site / "daily-timeline.json").write_text(json.dumps(payload, ensure_ascii=False))
