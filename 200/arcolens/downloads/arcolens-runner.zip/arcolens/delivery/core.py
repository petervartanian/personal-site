"""Shared, path-independent delivery operations."""

from __future__ import annotations

import hashlib
import json
import subprocess
import sys
import zipfile
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]


def read(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def save(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def execute(command: list[str], cwd: Path = ROOT, **kwargs: Any) -> str:
    result = subprocess.run(
        command, cwd=cwd, text=True, capture_output=True, check=False, **kwargs
    )
    if result.returncode:
        raise RuntimeError(
            f"Command failed ({result.returncode}): {command[0]}\n{result.stdout[-2000:]}\n{result.stderr[-4000:]}"
        )
    return result.stdout


def latest(root: Path = ROOT) -> Path:
    return root / read(root / "LATEST_RUN.json")["path"]


def check_run(run: Path, root: Path = ROOT) -> dict[str, Any]:
    from tracker.__main__ import verify_run

    return verify_run(run.resolve(), root.resolve())


def safe_extract(archive: Path, target: Path) -> None:
    with zipfile.ZipFile(archive) as source:
        for item in source.infolist():
            resolved = (target / item.filename).resolve()
            if not resolved.is_relative_to(target.resolve()) or "\\" in item.filename:
                raise ValueError("Unsafe archive path")
            if (item.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError("Archive symlinks are not allowed")
        source.extractall(target)


def python(*arguments: str, root: Path = ROOT) -> str:
    return execute([sys.executable, "-B", *arguments], root)
