# Optional website publishing

Local analysis and dashboard generation need only Python. An ordinary build does not publish or install a schedule. Publishing to Peter's
existing /200 site also requires Node, Git, the existing site checkout, and its
GitHub authentication. Those tools and credentials are not included in the ZIP.

The operator's private configuration specifies repository, remote_url, branch,
site_url, node, and password_file. Keep it outside the package and repository.
The password file must be readable only by its owner. It is passed to encryption
through standard input, never copied into Git, the package, logs, or arguments.

The optional `delivery.recurring` integration checks
authenticated source receipts and expected delivery dates before delegating to
the publishing entry point below. See [Receiving exports](SOURCE_DELIVERY.md).

For an explicitly configured installation, the publishing entry point is:

    python -m delivery.check_and_publish --config PATH_TO_PRIVATE_CONFIG

It accepts the same --downloads, --inbox, and --context options as the existing
monthly check. --dry-run builds and verifies ciphertext without changing or
pushing the site. It does not disable the preceding monthly analysis or model
review: use --completed-check to rehearse publication without new model calls. --completed-check accepts a saved check summary so a delivery
problem can be repaired without repeating analysis or model calls. The wrapper
revalidates the exact run, editorial manifest, evidence binding, and numeric
screening before publishing.

When explicitly invoked, only a successful new-data check can publish. An unchanged input
makes no deployment or model call. A failed analysis, source check, or model
review leaves the last published review in place and reports the issue.

Each deployment verifies every output hash and link, stages only encrypted
/200/vault files, commits, and pushes normally. It refuses a dirty checkout,
unexpected remote, unsafe paths, unrelated staged work, or divergent local
history. A concurrent remote update causes a normal push failure, never a
force-push. The saved receipt names the commit and source run. The publisher waits for both the website checks and GitHub Pages deployment
to succeed before recording the update as live.

The public MIT tracker is never changed. Arcolens remains a private review
workspace whose candidate text requires human publication decisions.
