"""Shared navigation and chart-control placement for every generated release."""

import re
from pathlib import Path

PAGE_INTROS = {
    "OPEN_REVIEW.html": (
        '<span data-intro-mode="review">Review the '
        '<a href="candidates.html">top findings</a> and '
        '<a href="published.html">suggested corrections to the tracker</a>.</span>'
        '<span data-intro-mode="workbench" hidden>Review the '
        '<a href="#monitor-issues-title">flagged corrections</a> and '
        '<a href="monthly.html">check the update schedule</a>.</span>'
    ),
    "candidates.html": (
        'Open a candidate to review its evidence. The <a href="charts.html">chart '
        "settings</a> show which tracker views can illustrate it."
    ),
    "charts.html": (
        "Choose a view below to illustrate a "
        '<a href="candidates.html">candidate insight</a>.'
    ),
    "published.html": (
        "This audit checks claims already on the tracker. The "
        '<a href="candidates.html">candidate insights</a> offer possible additions.'
    ),
    "methods.html": (
        'Read the assumptions behind the <a href="candidates.html">findings</a> and the '
        '<a href="data-quality.html">Data-quality findings</a>.'
    ),
    "additional.html": (
        'These investigations grew out of the <a href="candidates.html">candidate review</a> '
        'and the <a href="published.html">published-insight audit</a>.'
    ),
    "monthly.html": (
        'Check the schedule for <a href="OPEN_REVIEW.html?mode=monitor" '
        'data-preserve-mode>Monitor</a>, or use <a href="files.html">Files and evidence</a> '
        "to run an export yourself."
    ),
    "files.html": (
        'Download the reports behind the <a href="candidates.html">candidate insights</a> '
        'and <a href="published.html">published-insight audit</a>. The '
        '<a href="setup.html">setup guide</a> lets you run the analysis on your next CSV.'
    ),
}


def add_intro(text: str, intro: str) -> str:
    """Place the reader's next step after the page heading."""
    return re.sub(
        r'(<header class="page-head[^\"]*"[^>]*>.*?</header>)',
        lambda match: match[0] + '<p class="page-intro">' + intro + "</p>",
        text,
        count=1,
        flags=re.S,
    )


def install(site: Path) -> None:
    """Group supporting pages lower down and include current-year observations by default."""
    for path in site.glob("*.html"):
        text = path.read_text()
        if 'class="sidebar"' not in text:
            continue
        # Sources, provenance, and limitations remain in the evidence and finding pages.
        text = re.sub(r"<footer>.*?</footer>", "", text, flags=re.S)
        if path.name in ("OPEN_REVIEW.html", "index.html", "workbench.html"):
            text = re.sub(
                r"<h1>.*?</h1>",
                "<h1>What does the data show?</h1>",
                text,
                count=1,
                flags=re.S,
            )
            text = re.sub(
                r'(<a\b[^>]*href=")SIMON_BRIEF\.pdf("[^>]*>)(.*?)(</a>)',
                lambda match: match[1]
                + "files.html"
                + match[2]
                + re.sub(r"Report\s*$", "Reports and code", match[3])
                + match[4],
                text,
                count=1,
                flags=re.S,
            )
            text = re.sub(
                r"<title>.*?</title>",
                "<title>What does the data show? | Arcolens</title>",
                text,
                count=1,
                flags=re.S,
            )
            for class_name in ("trend-definition", "chart-boundary", "forecast-legend"):
                text = re.sub(
                    rf'<p class="{class_name}"[^>]*>.*?</p>', "", text, flags=re.S
                )
            # Calendar-year totals already appear in the chart's annual ledger.
            text = re.sub(
                r'<section class="current-observation"[^>]*>.*?</section>',
                "",
                text,
                flags=re.S,
            )
            text = re.sub(
                r'<div class="trend-note"><p>.*?</p>',
                '<div class="trend-note">',
                text,
                flags=re.S,
            )
            text = text.replace(
                '<div class="trend-note">',
                '<div class="trend-note"><a href="methods.html#section-projecting-2026">Chart method</a>',
            )
        text = text.replace(
            'class="nav-text">Findings</span>',
            'class="nav-text">Candidate insights</span>',
        )
        text = text.replace(
            'aria-label="Findings, chart settings, and published insights"',
            'aria-label="Candidate insights, chart settings, and published insights"',
        )
        text = text.replace(
            '<span class="appbar-path">Findings</span>',
            '<span class="appbar-path">Candidate insights</span>',
        )
        intro = PAGE_INTROS.get(
            "OPEN_REVIEW.html"
            if path.name in ("index.html", "workbench.html")
            else path.name
        )
        if intro:
            if (
                path.name == "methods.html"
                and not (site / "data-quality.html").is_file()
            ):
                intro = intro.replace(
                    '<a href="data-quality.html">Data-quality findings</a>',
                    '<a href="history/september/data-quality.html">'
                    "September data-quality findings</a>",
                )
            text = add_intro(text, intro)
        nav = re.search(r'<nav aria-label="Review sections">(.*?)</nav>', text, re.S)
        if nav and 'class="nav-secondary"' not in nav[1]:
            links = list(
                re.finditer(
                    r'<a\b[^>]*href="(?:methods|additional|monthly|files)\.html"[^>]*>.*?</a>',
                    nav[1],
                    re.S,
                )
            )
            if len(links) != 4:
                raise ValueError(
                    f"Expected four supporting navigation links: {path.name}"
                )
            primary = nav[1]
            for link in reversed(links):
                primary = primary[: link.start()] + primary[link.end() :]
            contents = (
                primary
                + '<div class="nav-secondary">'
                + "".join(link[0] for link in links)
                + "</div>"
            )
            text = text[: nav.start(1)] + contents + text[nav.end(1) :]
        # Current-year records are part of the one report, including without JavaScript.
        text = re.sub(r'<div class="year-choices"[^>]*>.*?</div>', "", text, flags=re.S)
        text = re.sub(
            r'<figure\b[^>]*data-year-view="complete"[^>]*>.*?</figure>',
            "",
            text,
            flags=re.S,
        )
        text = re.sub(
            r'<[^>]+data-year-view="partial"[^>]*>',
            lambda match: re.sub(r'\s+hidden(?:="[^"]*")?', "", match[0]),
            text,
        )
        text = text.replace('<script src="partial-year.js" defer></script>', "")
        if 'src="current-years.js"' not in text:
            text = text.replace(
                "</head>", '<script src="current-years.js" defer></script></head>'
            )
        if 'href="presentation.css"' not in text:
            text = text.replace(
                "</head>", '<link rel="stylesheet" href="presentation.css"></head>'
            )
        path.write_text(text)
