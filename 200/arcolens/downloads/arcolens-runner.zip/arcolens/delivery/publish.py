"""Publish a verified, encrypted review to the configured existing website."""

from __future__ import annotations

import argparse
import json
import io
import subprocess
import tarfile
import os
import shutil
import tempfile
import time
from pathlib import Path
from typing import Any

from .core import ROOT, digest, execute, read, save
from .render import verify_site


def wait_for_host(
    repo: Path, repository: str, commit: str, timeout: int = 300
) -> dict[str, Any]:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        runs = json.loads(
            execute(
                [
                    "gh",
                    "run",
                    "list",
                    "--repo",
                    repository,
                    "--commit",
                    commit,
                    "--limit",
                    "10",
                    "--json",
                    "databaseId,name,status,conclusion",
                ],
                repo,
            )
        )
        selected = [
            r
            for r in runs
            if r["name"] in {"Check website", "pages build and deployment"}
        ]
        failed = [
            r
            for r in selected
            if r["status"] == "completed" and r["conclusion"] != "success"
        ]
        if failed:
            raise RuntimeError("Hosting checks failed: " + json.dumps(failed))
        if len({r["name"] for r in selected}) == 2 and all(
            r["status"] == "completed" and r["conclusion"] == "success"
            for r in selected
        ):
            return {"status": "deployed", "checks": selected}
        time.sleep(5)
    raise TimeoutError(
        "The commit was pushed, but hosting completion was not confirmed in time."
    )


def publish(delivery: Path, config_path: Path, dry_run: bool = False) -> dict[str, Any]:
    config = read(config_path)
    repo = Path(config["repository"]).resolve()
    if (
        config["remote_url"]
        != execute(["git", "remote", "get-url", "origin"], repo).strip()
    ):
        raise ValueError("The publishing repository has a different remote.")
    if execute(["git", "status", "--porcelain"], repo).strip():
        raise ValueError(
            "The website checkout has other changes. They were left untouched."
        )
    record = read(delivery / "DELIVERY_MANIFEST.json")
    actual = {
        "simon-review/" + p.relative_to(delivery / "simon-review").as_posix(): digest(p)
        for p in (delivery / "simon-review").rglob("*")
        if p.is_file()
    }
    if actual != record["files"]:
        raise ValueError("Delivery files do not match their manifest.")
    verify_site(delivery / "simon-review")
    password_path = Path(config["password_file"]).expanduser().resolve()
    if os.name != "nt" and password_path.stat().st_mode & 0o077:
        raise ValueError(
            "The publishing password file must be readable only by its owner."
        )
    password = password_path.read_text().rstrip("\r\n")
    if not password:
        raise ValueError("The publishing password is empty.")
    # Fast-forward only. Concurrent user work is never reset or force-pushed.
    execute(["git", "fetch", "origin", config.get("branch", "main")], repo)
    head = execute(["git", "rev-parse", "HEAD"], repo).strip()
    remote = execute(["git", "rev-parse", "FETCH_HEAD"], repo).strip()
    if head != remote:
        execute(["git", "merge", "--ff-only", "FETCH_HEAD"], repo)
        if execute(["git", "rev-parse", "HEAD"], repo).strip() != remote:
            raise ValueError(
                "Local commits are ahead of the publishing branch; publication stopped."
            )
    with tempfile.TemporaryDirectory(prefix="arcolens-encrypted-") as temp:
        stage = Path(temp) / "vault"
        build_command = [
            config.get("node", "node"),
            "scripts/build-200.mjs",
            "--arcolens-source",
            str(delivery / "simon-review"),
            "--delivery-manifest",
            str(delivery / "DELIVERY_MANIFEST.json"),
            "--brand-mark",
            str(ROOT / "delivery/assets/brand-mark.svg"),
            "--output",
            str(stage),
        ]
        execute(build_command, repo, input=password + "\n")
        verification = json.loads(
            execute(
                [
                    config.get("node", "node"),
                    "scripts/verify-200.mjs",
                    "--vault",
                    str(stage),
                ],
                repo,
                input=password + "\n",
            )
        )
        result = {
            "status": "verified_preview" if dry_run else "pushed_awaiting_host",
            "run_id": record["run_id"],
            "input_sha256": record["input_sha256"],
            "delivery_manifest_sha256": digest(delivery / "DELIVERY_MANIFEST.json"),
            "verification": verification,
            "target": config["site_url"],
            "password_recorded": False,
        }
        if not dry_run:
            vault = repo / "200/vault"
            # The clean checkout is already committed. Read its rollback snapshot
            # from Git so cloud-backed working files need not be hydrated first.
            archived = subprocess.run(
                ["git", "archive", "--format=tar", "HEAD", "200/vault"],
                cwd=repo,
                capture_output=True,
                check=True,
            ).stdout
            with tarfile.open(fileobj=io.BytesIO(archived)) as archive:
                old = {
                    Path(member.name).name: archive.extractfile(member).read()
                    for member in archive.getmembers()
                    if member.isfile()
                }
            try:
                for p in vault.iterdir():
                    if p.is_file():
                        p.unlink()
                for p in stage.iterdir():
                    shutil.copy2(p, vault / p.name)
                execute(["git", "add", "--", "200/vault"], repo)
                staged = execute(
                    ["git", "diff", "--cached", "--name-only"], repo
                ).splitlines()
                if any(not p.startswith("200/vault/") for p in staged):
                    raise ValueError("Unrelated staged changes; publication stopped.")
                execute(
                    [
                        "git",
                        "commit",
                        "-m",
                        f"Refresh private Arcolens review for {record['analysis_date']}",
                    ],
                    repo,
                )
            except Exception:
                # Restore only the generated vault, never unrelated files or user commits.
                for p in vault.iterdir():
                    if p.is_file():
                        p.unlink()
                for name, content in old.items():
                    (vault / name).write_bytes(content)
                execute(["git", "reset", "--", "200/vault"], repo)
                raise
            result["commit"] = execute(["git", "rev-parse", "HEAD"], repo).strip()
            try:
                execute(
                    [
                        "git",
                        "-c",
                        "http.postBuffer=524288000",
                        "push",
                        "origin",
                        "HEAD:" + config.get("branch", "main"),
                    ],
                    repo,
                )
            except Exception as error:
                result.update(
                    status="push_failed",
                    error=str(error),
                    recovery="The verified commit remains local. Reconcile concurrent remote changes and retry the normal push; never force-push.",
                )
                save(delivery / "PUBLISH_RECEIPT.json", result)
                raise
            if config.get("github_repository"):
                try:
                    result["hosting"] = wait_for_host(
                        repo, config["github_repository"], result["commit"]
                    )
                    result["status"] = "deployed"
                except Exception as error:
                    result.update(status="hosting_needs_attention", error=str(error))
                    save(delivery / "PUBLISH_RECEIPT.json", result)
                    raise
    save(
        delivery / ("PUBLISH_PREVIEW.json" if dry_run else "PUBLISH_RECEIPT.json"),
        result,
    )
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--delivery", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    print(
        json.dumps(
            publish(args.delivery.resolve(), args.config.resolve(), args.dry_run),
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
