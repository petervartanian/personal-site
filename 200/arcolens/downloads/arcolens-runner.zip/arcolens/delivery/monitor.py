"""Show the installed scheduler and verified check history without exposing settings."""

from __future__ import annotations

import calendar
from datetime import date, datetime, time, timedelta, timezone
import html
from pathlib import Path
import tomllib
from typing import Literal
from zoneinfo import ZoneInfo
from typing import Any

from pydantic import BaseModel, Field
from .core import digest, read

DISPLAY_ZONE = "Europe/London"


class Schedule(BaseModel):
    cadence: Literal["monthly", "fortnightly"]
    state: Literal["ACTIVE", "PAUSED"]
    timezone_name: str = "America/New_York"
    hour: int = Field(default=9, ge=0, le=23)
    minute: int = Field(default=0, ge=0, le=59)
    month_day: int = Field(default=27, ge=1, le=31)
    anchor: date = date(2026, 9, 27)

    def next_check(self, now: datetime) -> datetime | None:
        if self.state != "ACTIVE":
            return None
        zone = ZoneInfo(self.timezone_name)
        local = now.astimezone(zone)
        if self.cadence == "monthly":
            year, month = local.year, local.month
            for _ in range(2):
                day = min(self.month_day, calendar.monthrange(year, month)[1])
                candidate = datetime(
                    year, month, day, self.hour, self.minute, tzinfo=zone
                )
                if candidate > local:
                    return candidate
                month += 1
                if month == 13:
                    year, month = year + 1, 1
        else:
            day = self.anchor + timedelta(
                days=14 * max(0, (local.date() - self.anchor).days // 14)
            )
            candidate = datetime.combine(day, time(self.hour, self.minute), zone)
            if candidate <= local:
                candidate = datetime.combine(
                    day + timedelta(days=14), time(self.hour, self.minute), zone
                )
            return candidate
        raise ValueError("Unable to determine next scheduled check")


def schedule_from_file(path: Path, timezone_name: str, anchor: date) -> Schedule:
    raw = tomllib.loads(path.read_text())
    if raw.get("kind") != "heartbeat":
        raise ValueError("Expected the installed thread automation")
    rule = dict(item.split("=", 1) for item in raw["rrule"].split(";"))
    allowed = {"FREQ", "INTERVAL", "BYMONTHDAY", "BYHOUR", "BYMINUTE", "BYSECOND"}
    if set(rule) - allowed or rule.get("BYSECOND", "0") != "0":
        raise ValueError(
            "Unsupported schedule details; inspect the installed automation"
        )
    if rule.get("FREQ") == "MONTHLY":
        if rule.get("INTERVAL", "1") != "1":
            raise ValueError("Only a monthly interval of one is supported")
        cadence = "monthly"
    elif rule.get("FREQ") == "WEEKLY" and rule.get("INTERVAL") == "2":
        cadence = "fortnightly"
    else:
        raise ValueError("The installed schedule is neither monthly nor fortnightly")
    return Schedule(
        cadence=cadence,
        state=raw["status"],
        timezone_name=timezone_name,
        hour=int(rule.get("BYHOUR", 9)),
        minute=int(rule.get("BYMINUTE", 0)),
        month_day=int(rule.get("BYMONTHDAY", 27)),
        anchor=anchor,
    )


def date_label(value: str | None) -> str:
    if not value:
        return "No check recorded"
    day = datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(
        ZoneInfo(DISPLAY_ZONE)
    )
    return f"{day:%b} {day.day}, {day.year}"


def verified_checks(root: Path) -> list[dict[str, Any]]:
    labels = {
        "unchanged_export": "No new export",
        "completed_requires_human_review": "New findings ready for review",
        "unchanged_export_editorial_needs_attention": "Review needed",
        "source_delivery_needs_attention": "Export delivery needs attention",
        "expected_update_missing": "Expected export missing",
        "publication_needs_attention": "Website update needs attention",
        "recurring_failed": "Check needs attention",
    }
    checks = []
    for path in sorted((root / "logs/recurring").glob("*/summary.json"), reverse=True):
        manifest = path.parent / "manifest.json"
        if not manifest.is_file() or read(manifest).get("files", {}).get(
            "summary.json"
        ) != digest(path):
            continue
        report = read(path)
        checks.append(
            {
                "at": report.get("finished_at_utc") or report["started_at_utc"],
                "label": labels.get(report["status"], "Check needs attention"),
                "new_data": bool(report.get("analysis_invoked")),
                "model_review": bool(report.get("model_cycle_invoked")),
                "published": bool(report.get("published")),
            }
        )
        if len(checks) == 6:
            break
    return checks


def time_label(hour: int, minute: int) -> str:
    return f"{hour % 12 or 12}:{minute:02d} " + ("a.m." if hour < 12 else "p.m.")


def ordinal(day: int) -> str:
    suffix = (
        "th"
        if 10 <= day % 100 <= 20
        else {1: "st", 2: "nd", 3: "rd"}.get(day % 10, "th")
    )
    return str(day) + suffix


def snapshot(
    root: Path, analysis_date: str, now: datetime | None = None
) -> dict[str, Any]:
    now = now or datetime.now(timezone.utc)
    state = {
        "configured": False,
        "analysis_date": analysis_date,
        "captured_at": now.isoformat(),
        "checks": verified_checks(root),
        "display_timezone": DISPLAY_ZONE,
    }
    path = root / "intake/schedule_display.json"
    if not path.is_file():
        return state
    settings = read(path)
    schedule = schedule_from_file(
        Path(settings["automation_path"]),
        settings["timezone"],
        date.fromisoformat(settings["fortnightly_anchor"]),
    )
    policy = read(root / "intake/source_policy.json")
    if policy["cadence"] != schedule.cadence:
        raise ValueError(
            "The export policy and installed automation use different cadences"
        )
    next_check = schedule.next_check(now)
    if next_check:
        next_check = next_check.astimezone(ZoneInfo(DISPLAY_ZONE))
    state.update(
        configured=True,
        cadence=schedule.cadence,
        active=schedule.state == "ACTIVE",
        next_check=next_check.isoformat() if next_check else None,
        cadence_label="Monthly" if schedule.cadence == "monthly" else "Every two weeks",
        schedule_label=(
            f"Monthly on the {ordinal(schedule.month_day)}"
            if schedule.cadence == "monthly"
            else "Every two weeks"
        ),
        next_label=(
            f"{next_check:%b} {next_check.day} at {next_check:%H:%M} (London [{next_check:%Z}])"
            if next_check
            else "Paused"
        ),
    )
    inbox = policy.get("primary_folder_id", "")
    if inbox and inbox.replace("-", "").replace("_", "").isalnum():
        state["inbox_url"] = "https://drive.google.com/drive/folders/" + inbox
    return state


def dashboard_panel(state: dict[str, Any]) -> str:
    """Keep the schedule visible alongside the findings."""
    e = html.escape
    if not state.get("configured"):
        return '<section class="monitor-status monitor-compact"><a href="setup.html">Recurring updates</a><span>Schedule not configured</span></section>'
    recent = next(iter(state.get("checks", [])), None)
    last = (
        e(date_label(recent["at"]) + ": " + recent["label"])
        if recent
        else "No check recorded"
    )
    return (
        '<section class="monitor-status monitor-compact" aria-label="Monitoring schedule">'
        '<div><a href="monthly.html">' + e(state["cadence_label"]) + " monitoring</a>"
        '<span class="monitor-state">'
        + ("Active" if state["active"] else "Paused")
        + "</span></div>"
        "<dl><div><dt>Next check</dt><dd>" + e(state["next_label"]) + "</dd></div>"
        "<div><dt>Last check</dt><dd>" + last + "</dd></div></dl></section>"
    )


def page_body(state: dict[str, Any]) -> str:
    e = html.escape
    if not state.get("configured"):
        return '<section class="content-section"><h2>Recurring updates are not configured on this computer</h2><p>You can run the analysis whenever a new CSV arrives. <a href="setup.html">Follow the installation and rerun instructions</a>. The downloaded package does not include Peter’s hosted schedule or connected accounts.</p></section>'
    status = "Active" if state["active"] else "Paused"
    rows = "".join(
        "<tr><td>"
        + e(date_label(c["at"]))
        + "</td><td>"
        + e(c["label"])
        + "</td><td>"
        + ("New data analyzed" if c["new_data"] else "Existing export retained")
        + "</td></tr>"
        for c in state["checks"]
    )
    inbox = (
        '<p>For your next review, add the dated Arcola CSV to the <a href="'
        + e(state.get("inbox_url", "files.html"))
        + '">shared export inbox</a> before the scheduled check. Keep the export date in the filename, such as <code>incident_tracker_export_2026-10-27.csv</code>.</p>'
    )
    if state["analysis_date"] == "2026-09-27":
        inbox += "<p>The transfer rehearsal used the September export. The unattended cycle still needs a test with a new export.</p>"
    return (
        '<section class="content-section"><h2>Schedule</h2><p><strong>'
        + e(state["cadence_label"])
        + " schedule is "
        + status.lower()
        + "</strong></p><p>"
        + e(state["schedule_label"])
        + ". Next check: <strong>"
        + e(state["next_label"])
        + "</strong>.</p>"
        "</section>"
        '<section class="content-section"><h2>What runs automatically</h2><ol class="structured-list">'
        "<li>Retrieve a valid dated CSV from the export inbox.</li><li>Check whether published statements have changed.</li><li>Analyze a fresh export.<ul><li>Compare it with the previous export.</li><li>Regenerate the candidate report.</li><li>Audit the published insights.</li><li>Independently review each model draft.</li></ul></li>"
        "<li>Publish the verified update to this private dashboard.</li></ol><p>An unchanged CSV does not trigger new model calls. Peter receives failure alerts. You and Peter decide what to publish on the tracker.</p></section>"
        '<section class="content-section"><h2>Recent checks</h2><div class="table-scroll"><table><thead><tr><th>Date</th><th>Result</th><th>Analysis</th></tr></thead><tbody>'
        + rows
        + "</tbody></table></div></section>"
        '<section class="content-section"><h2>Send your next export</h2>'
        + inbox
        + "<p>Runs on Peter’s Mac with Codex and the connected accounts available.</p></section>"
    )
