"""Current presentation copy bound to the analysis that supports it."""

from __future__ import annotations

from html import escape
import re
from typing import Any

from .core import digest, read

CANDIDATE_FIELDS = {
    "calculation_confidence",
    "caveats",
    "chart_configuration",
    "finding",
    "interpretation_confidence",
    "key_limitation",
    "priority_reason",
    "proposed_website_text",
    "review_notes",
    "scope_note",
    "summary",
}
CLAIM_FIELDS = {
    "calculation_definition",
    "editorial_flags",
    "interpretation",
    "proposed_revision",
    "reason",
}


def replacements(renderer, resources) -> dict[str, str]:
    """Do not carry snapshot-specific wording into a different analysis."""
    resource = read(resources / "review-copy.json")
    binding = resource["binding"]
    if (
        renderer.meta["input"]["sha256"] != binding["input_sha256"]
        or renderer.day.isoformat() != binding["analysis_date"]
        or any(
            not (renderer.run / name).is_file()
            or digest(renderer.run / name) != expected
            for name, expected in binding["files"].items()
        )
    ):
        return {}
    return dict(
        sorted(
            resource["replacements"].items(),
            key=lambda pair: len(pair[0]),
            reverse=True,
        )
    )


def rewrite(value: Any, changes: dict[str, str]) -> Any:
    if isinstance(value, str):
        for old, new in changes.items():
            value = value.replace(old, new)
        return value
    if isinstance(value, list):
        return [rewrite(item, changes) for item in value]
    if isinstance(value, dict):
        return {key: rewrite(item, changes) for key, item in value.items()}
    return value


def prepare(data: dict, renderer, resources) -> None:
    changes = replacements(renderer, resources)
    if not changes:
        return
    for group, fields in [("candidates", CANDIDATE_FIELDS), ("claims", CLAIM_FIELDS)]:
        for item in data.get(group, []):
            for key in fields & item.keys():
                item[key] = rewrite(item[key], changes)
            if group == "candidates":
                # The curated current wording takes precedence over the preserved model draft.
                item["presentation_override"] = True


def install(site, renderer, resources) -> None:
    """Edit display prose while retaining quotations and recorded model reviews."""
    changes = replacements(renderer, resources)
    if not changes:
        return
    html_changes = {
        escape(old, quote=True): escape(new, quote=True) for old, new in changes.items()
    }
    protected = re.compile(
        r"<blockquote\b[^>]*>.*?</blockquote>"
        r"|<(?:script|style|pre|code)\b[^>]*>.*?</(?:script|style|pre|code)>"
        r"|<section\b[^>]*>\s*<h2\b[^>]*>Independent model review</h2>.*?</section>",
        re.S | re.I,
    )
    for path in site.glob("*.html"):
        if path.name in {"model-review.html", "source-check.html"}:
            continue
        text = path.read_text()
        pieces = []
        end = 0
        for match in protected.finditer(text):
            pieces.extend([rewrite(text[end : match.start()], html_changes), match[0]])
            end = match.end()
        pieces.append(rewrite(text[end:], html_changes))
        updated = "".join(pieces)
        if updated != text:
            path.write_text(updated)
