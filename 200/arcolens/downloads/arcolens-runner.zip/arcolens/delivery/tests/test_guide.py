"""Guide routes must follow the selected findings, including empty future runs."""

import json
from pathlib import Path
import re
import tempfile
from types import SimpleNamespace
import unittest

from delivery.guide import install


class GuideTests(unittest.TestCase):
    def test_missing_example_uses_a_current_candidate_and_empty_run_is_honest(self):
        with tempfile.TemporaryDirectory() as directory:
            site = Path(directory)
            for candidates in ([{"candidate_id": "IT-D999"}], []):
                (site / "OPEN_REVIEW.html").write_text(
                    '<head></head><body><main id="main"></main></body>'
                )
                (site / "finding-IT-D999.html").write_text(
                    '<head></head><body><main id="main"></main></body>'
                )
                install(
                    SimpleNamespace(
                        out=site,
                        candidates=candidates,
                        monitoring={"configured": False},
                    )
                )
                config = json.loads(
                    re.search(
                        r'id="arcolens-guide-config">(.*?)</script>',
                        (site / "OPEN_REVIEW.html").read_text(),
                    ).group(1)
                )
                step = config["steps"][1]
                if candidates:
                    self.assertEqual(step["page"], "finding-IT-D999.html")
                else:
                    self.assertEqual(step["page"], "candidates.html")
                    self.assertIn("no candidate findings", step["text"])
                self.assertIn("not configured", config["steps"][4]["heading"])


if __name__ == "__main__":
    unittest.main()
