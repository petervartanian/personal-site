"""Guard exact evidence, fresh-run wording, and the compact review surface."""

from __future__ import annotations

import copy
import json
import tempfile
import unittest
import zipfile
from datetime import date
from pathlib import Path

from delivery.core import ROOT, digest, latest, read, save
from delivery.focused_review import apply, prepare, source_html, sources_for
from delivery.render import RESOURCES, Renderer
from delivery.daily_timeline import build_series
from delivery.core import safe_extract
import shutil
import re
from delivery.review_baseline import load as load_review_baseline
from delivery.workbench import install


class PresentationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.folder = tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        self.site = Path(self.folder.name) / "review"
        self.site.mkdir()
        self.run = latest()
        self.renderer = Renderer(ROOT, self.run, self.site)
        with zipfile.ZipFile(RESOURCES / "september-review.zip") as archive:
            self.curated = json.loads(archive.read("simon-review/review-data.json"))
        safe_extract(
            RESOURCES / "september-review.zip", Path(self.folder.name) / "archive"
        )
        shutil.copytree(
            Path(self.folder.name) / "archive/simon-review",
            self.site,
            dirs_exist_ok=True,
        )
        self.renderer.timelines = build_series(self.renderer)
        self.renderer.review_baseline = load_review_baseline(self.run, RESOURCES)

    def test_ten_priorities_retain_all_candidates_and_exact_tracker_sources(
        self,
    ) -> None:
        original_hash = digest(self.run / "candidates.json")
        data = prepare(self.renderer)
        self.assertEqual(
            data["shortlist"],
            [
                "IT-C003",
                "IT-C004",
                "IT-C002",
                "IT-C005",
                "IT-C001",
                "IT-D005",
                "IT-D001",
                "IT-D002",
                "IT-D004",
                "IT-D006",
            ],
        )
        self.assertEqual(len(data["candidates"]), 13)
        self.assertEqual(digest(self.run / "candidates.json"), original_hash)
        by_id = {c["candidate_id"]: c for c in data["candidates"]}
        self.assertEqual(
            {c["candidate_id"] for c in data["candidates"] if not c["is_shortlisted"]},
            {"IT-D003", "IT-P001", "IT-P002"},
        )
        self.assertEqual(
            by_id["IT-C003"]["display_title"],
            "Deepfake video leads the single-purpose tags",
        )
        self.assertEqual(
            by_id["IT-C003"]["title"],
            "Deepfake Video Generation is the largest primary-purpose category",
        )
        self.assertEqual(
            by_id["IT-C004"]["source_pages"][0]["url"],
            "https://airisk.mit.edu/ai-incident-tracker/incident-overview",
        )
        self.assertEqual(by_id["IT-C004"]["source_pages"][0]["chart_id"], "C04")
        self.assertEqual(by_id["IT-D003"]["source_pages"], [])

    def test_additions_keep_their_denominators_and_material_limits(self) -> None:
        data = prepare(self.renderer)
        by_id = {c["candidate_id"]: c for c in data["candidates"]}
        expected = {
            "discovery.d5642ae3bc.base": (128, 141),
            "discovery.d5642ae3bc.7c4bf965f2": (127, 140),
            "discovery.a9dfb24f8c.annual.2021": (35, 80),
            "discovery.a9dfb24f8c.annual.2025": (90, 452),
            "discovery.637e47bb95.dist.2021.89664dafa1": (19, 80),
            "discovery.637e47bb95.dist.2025.89664dafa1": (349, 452),
            "discovery.87a856248f.annual.2021": (1, 80),
            "discovery.87a856248f.annual.2025": (63, 452),
        }
        for identifier, counts in expected.items():
            measure = self.renderer.measures[identifier]
            self.assertEqual((measure["numerator"], measure["denominator"]), counts)
        for identifier in ["IT-D001", "IT-D002", "IT-D004", "IT-D006"]:
            self.assertTrue(by_id[identifier]["is_shortlisted"])
            self.assertTrue(by_id[identifier]["wording_evidence_ids"])
            self.assertTrue(
                all(
                    key in self.renderer.measures
                    for key in by_id[identifier]["wording_evidence_ids"]
                )
            )
        self.assertEqual(by_id["IT-D001"]["chart_fit"], "Chart window differs")
        self.assertIn(
            "zero or missing scores are treated as not qualifying",
            by_id["IT-D002"]["proposed_website_text"],
        )
        self.assertIn("covers all records", by_id["IT-D004"]["proposed_website_text"])
        self.assertIn("single record", by_id["IT-D006"]["proposed_website_text"])
        self.assertIn("share dipped in 2024", by_id["IT-D006"]["key_limitation"])
        self.assertIn("2025 records", by_id["IT-D006"]["display_title"])
        self.assertNotIn("rose", by_id["IT-D006"]["display_title"])

    def test_overreliance_wording_links_to_chart_window_measure(self) -> None:
        data = prepare(self.renderer)
        candidate = next(
            c for c in data["candidates"] if c["candidate_id"] == "IT-D005"
        )
        identifier = "discovery.0b6342a068.7c4bf965f2"
        self.assertEqual(candidate["wording_evidence_ids"], [identifier])
        measure = self.renderer.measures[identifier]
        self.assertEqual((measure["numerator"], measure["denominator"]), (52, 56))
        self.assertIn("52 of the 56", candidate["proposed_website_text"])
        self.assertIn("2016–2025", candidate["proposed_website_text"])
        self.assertIn("53", candidate["audit_original_wording"])
        self.assertIn("60", candidate["audit_original_wording"])
        self.assertIn("Four earlier records", candidate["scope_note"])
        self.assertEqual(
            candidate["chart_configuration"]["date_range"], "2016-01-01 to 2025-12-31"
        )
        self.assertIn(
            "all records through December 31, 2025",
            candidate["audit_original_chart_configuration"]["date_range"],
        )
        again = prepare(self.renderer)
        repeated = next(
            c for c in again["candidates"] if c["candidate_id"] == "IT-D005"
        )
        self.assertEqual(
            repeated["audit_original_wording"], candidate["audit_original_wording"]
        )

    def test_future_run_does_not_reuse_snapshot_copy_or_discovery_ids(self) -> None:
        self.renderer.meta = copy.deepcopy(self.renderer.meta)
        self.renderer.meta["input"]["sha256"] = "new-input"
        self.renderer.day = date(2027, 2, 1)
        self.renderer.candidates = copy.deepcopy(self.renderer.candidates)
        for candidate in self.renderer.candidates:
            candidate["proposed_website_text"] = (
                "Fresh run wording for " + candidate["candidate_id"]
            )
            if candidate["candidate_id"] == "IT-D005":
                candidate["candidate_id"] = "IT-D099"
        data = prepare(self.renderer)
        self.assertIn("IT-D099", data["shortlist"])
        self.assertNotIn("IT-D005", data["shortlist"])
        for candidate in data["candidates"]:
            self.assertTrue(
                candidate["proposed_website_text"].startswith("Fresh run wording")
            )
            self.assertNotIn("52 of the 56", candidate["proposed_website_text"])

    def test_same_csv_with_changed_analysis_cannot_reuse_saved_wording(self) -> None:
        prepare(self.renderer)
        altered = Path(self.folder.name) / "altered-run"
        altered.mkdir()
        for name in ["candidates.json", "calculations.json"]:
            (altered / name).write_bytes((self.run / name).read_bytes())
        candidates = read(altered / "candidates.json")
        candidates[0]["proposed_website_text"] = "Recomputed annual finding"
        save(altered / "candidates.json", candidates)
        self.renderer.run = altered
        self.renderer.candidates = candidates
        data = prepare(self.renderer)
        self.assertEqual(
            data["candidates"][0]["proposed_website_text"], "Recomputed annual finding"
        )

    def test_review_and_workbench_share_wording_evidence_and_folded_details(
        self,
    ) -> None:
        prepare(self.renderer)
        install(self.renderer)
        apply(self.renderer)
        page = (self.site / "finding-IT-D005.html").read_text()
        self.assertIn("52 of the 56", page)
        self.assertIn("Compare date windows", page)
        self.assertIn('<details class="review-detail">', page)
        self.assertNotIn('<details class="review-detail" open', page)
        self.assertIn('src="review.js"', page)
        self.assertIn('src="focused-review.js"', page)
        self.assertIn(
            ">Top findings</h2>", (self.site / "OPEN_REVIEW.html").read_text()
        )
        self.assertNotIn(
            "selected findings</h2>", (self.site / "OPEN_REVIEW.html").read_text()
        )
        directory = (self.site / "candidates.html").read_text()
        self.assertIn("Timeline and annual totals", directory)
        self.assertIn("finding-IT-D006.html", directory)
        rows = re.findall(r"<tr>.*?</tr>", directory, re.S)
        d001 = next(row for row in rows if 'href="finding-IT-D001.html"' in row)
        d005 = next(row for row in rows if 'href="finding-IT-D005.html"' in row)
        self.assertIn("Chart window differs", d001)
        self.assertIn("Chart view available", d005)
        self.assertIn("monitor-workspace", (self.site / "OPEN_REVIEW.html").read_text())
        workbench = json.loads(
            (self.site / "workbench-data.js")
            .read_text()
            .removeprefix("window.ARCOLENS_WORKBENCH=")
            .rstrip(";\n")
        )
        item = next(i for i in workbench["items"] if i["id"] == "IT-D005")
        self.assertIn("52 of the 56", item["wording"])
        self.assertEqual(item["wording_evidence"], ["discovery.0b6342a068.7c4bf965f2"])
        # Check the generated export/copy payload, not just the retained fixture.
        by_id = {i["id"]: i for i in workbench["items"]}
        canonical = {
            c["candidate_id"]: c
            for c in read(self.renderer.review_baseline / "review-data.json")[
                "candidates"
            ]
        }
        for identifier in ["IT-C001", "IT-C002", "IT-D006", "IT-D003", "IT-D004"]:
            # Descriptive compatibility prose can change; all chart controls stay fixed.
            self.assertEqual(
                {
                    k: v
                    for k, v in by_id[identifier]["chart"].items()
                    if k != "compatibility"
                },
                {
                    k: v
                    for k, v in canonical[identifier]["chart_configuration"].items()
                    if k != "compatibility"
                },
            )
        for identifier in ["IT-C001", "IT-C002", "IT-D006"]:
            self.assertIn(
                "not been verified end to end",
                by_id[identifier]["chart"]["compatibility"],
            )
        for identifier in ["IT-D003", "IT-D004"]:
            self.assertIn("annual", by_id[identifier]["chart"]["setting"])
            self.assertIn("denominator", by_id[identifier]["chart"]["setting"])
            self.assertNotIn(
                "Proportions with all legend series visible",
                by_id[identifier]["chart"]["setting"],
            )
        self.assertEqual(
            sum(
                "filter_instructions" in i["chart"]
                for i in workbench["items"]
                if i["id"].startswith("IT-")
            ),
            11,
        )
        self.assertIn(
            "no visible Proportions toggle", by_id["IT-D005"]["chart"]["compatibility"]
        )
        report = (self.site / "downloads/candidate-insights.md").read_text()
        self.assertIn("Affected tracker pages", report)
        self.assertIn("52 of the 56", report)
        top_report = (self.site / "downloads/selected-findings.md").read_text()
        self.assertTrue(top_report.startswith("# Top findings\n"))
        self.assertEqual(len(re.findall(r"^## ", top_report, re.M)), 10)

    def test_source_links_are_escaped_and_non_web_urls_are_rejected(self) -> None:
        candidate = {
            "chart_ids": ["C01"],
            "chart_configuration": {"primary_chart": "C01"},
        }
        self.assertEqual(
            sources_for(
                candidate,
                [
                    {
                        "chart_id": "C01",
                        "source_url": "javascript:alert(1)",
                        "name": "Unsafe",
                    }
                ],
            ),
            [],
        )
        html = source_html(
            [
                {
                    "url": "https://example.org/?a=1&b=2",
                    "page": "<img src=x>",
                    "chart": "<script>x</script>",
                }
            ]
        )
        self.assertNotIn("<script>", html)
        self.assertIn("&lt;img", html)


if __name__ == "__main__":
    unittest.main()
