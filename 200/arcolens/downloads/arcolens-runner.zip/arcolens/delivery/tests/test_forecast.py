"""Historical counts, non-leaking checks, and forecasting bounds."""

import json
import math
import statistics
import unittest
from datetime import date

from delivery.forecast import RESOURCE, estimate, fit, historical_pairs


class VintageForecastTests(unittest.TestCase):
    def test_every_count_reproduces_from_bundled_snapshot_records(self):
        sources = {
            v["snapshot_date"]: v for v in json.loads(RESOURCE.read_text())["vintages"]
        }
        pairs = historical_pairs(date(2026, 9, 27))
        self.assertEqual(
            [
                (p["year"], p["observed"], p["final"], p["late_additions"])
                for p in pairs
            ],
            [
                (2022, 39, 73, 17),
                (2023, 70, 120, 29),
                (2024, 146, 221, 24),
                (2025, 246, 346, 32),
            ],
        )
        for p in pairs:
            origin = sources[p["origin"]]["records"]
            outcome = sources[p["outcome"]]["records"]
            old = {
                r["incident_id"]
                for r in origin
                if r["date"][:4] == str(p["year"]) and r["date"] <= p["origin"]
            }
            final = {
                r["incident_id"] for r in outcome if r["date"][:4] == str(p["year"])
            }
            late = {
                r["incident_id"]
                for r in outcome
                if r["incident_id"] in final - old and r["date"] <= p["origin"]
            }
            self.assertEqual(set(p["origin_ids"]), old)
            self.assertEqual(set(p["outcome_ids"]), final)
            self.assertEqual(set(p["late_addition_ids"]), late)
            self.assertTrue(old <= final)

    def test_small_sample_predictive_interval_recomputed_independently(self):
        model = estimate(231, date(2026, 9, 27))
        rates = [
            math.log(73 / 39) / 98,
            math.log(120 / 70) / 98,
            math.log(221 / 146) / 105,
            math.log(346 / 246) / 105,
        ]
        mean = sum(rates) / 4
        sd = math.sqrt(sum((x - mean) ** 2 for x in rates) / 3)
        self.assertAlmostEqual(model["median"], 231 * math.exp(mean * 99))
        for interval, critical, coverage in [
            (model, 0.7648923284043453, 0.50),
            (model["wider_interval"], 2.3533634348018264, 0.90),
        ]:
            margin = critical * sd * 99 * math.sqrt(1.25)
            self.assertEqual(interval["coverage_probability"], coverage)
            self.assertAlmostEqual(
                interval["bounds"]["counts"][0], 231 * math.exp(mean * 99 - margin)
            )
            self.assertAlmostEqual(
                interval["bounds"]["counts"][1], 231 * math.exp(mean * 99 + margin)
            )
        self.assertEqual(model["target_snapshot_date"], "2027-01-04")
        self.assertEqual(model["bounds"]["share"], [100, 100])

    def test_central_band_has_half_probability_and_keeps_wider_uncertainty(self):
        model = estimate(231, date(2026, 9, 27))
        critical = model["fit"]["t_critical"]
        # Analytic Student-t CDF for three degrees of freedom, independent of fit.
        z = critical / math.sqrt(3)
        cdf = 0.5 + (math.atan(z) + z / (1 + z * z)) / math.pi
        self.assertAlmostEqual(2 * cdf - 1, 0.50)
        low, high = model["bounds"]["counts"]
        wide_low, wide_high = model["wider_interval"]["bounds"]["counts"]
        self.assertLess(wide_low, low)
        self.assertLess(low, model["median"])
        self.assertLess(model["median"], high)
        self.assertLess(high, wide_high)
        self.assertAlmostEqual(wide_low, 255.04418750093683)
        self.assertAlmostEqual(wide_high, 538.3643027522514)

    def test_backtests_train_only_on_already_observed_outcomes(self):
        model = estimate(231, date(2026, 9, 27))
        for check in model["backtests"]:
            self.assertEqual(check["coverage_probability"], 0.90)
            training = [
                p for p in model["training"] if p["year"] in check["training_years"]
            ]
            origin = next(
                p["origin"] for p in model["training"] if p["year"] == check["year"]
            )
            self.assertTrue(all(p["outcome"] < origin for p in training))
            self.assertTrue(check["covered"])
            self.assertLess(
                check["baseline_absolute_error"], check["model_absolute_error"]
            )
        self.assertEqual(len(model["backtests"]), 2)

    def test_next_csv_changes_count_and_horizon_without_network(self):
        before = estimate(231, date(2026, 9, 27))
        more = estimate(250, date(2026, 9, 27))
        later = estimate(250, date(2026, 10, 27))
        self.assertAlmostEqual(more["median"] / before["median"], 250 / 231)
        self.assertLess(later["median"], more["median"])
        self.assertGreaterEqual(later["bounds"]["counts"][0], 250)
        self.assertLess(
            later["bounds"]["counts"][1] - later["bounds"]["counts"][0],
            more["bounds"]["counts"][1] - more["bounds"]["counts"][0],
        )
        self.assertIsNone(estimate(231, date(2026, 6, 27)))
        self.assertIsNone(estimate(231, date(2028, 9, 27)))
        self.assertIsNone(estimate(0, date(2026, 9, 27)))

    def test_no_artificial_spread_for_identical_completion_rates(self):
        rate = math.log(2) / 100
        model = fit(100, 100, [{"log_daily_completion_rate": rate}] * 4)
        self.assertAlmostEqual(model["median"], 200)
        self.assertEqual(model["bounds"], [200, 200])


if __name__ == "__main__":
    unittest.main()
