"""Keep presentation edits within their source snapshot and outside quotations."""

from datetime import date
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest

from delivery.core import digest, save
from delivery.review_copy import install, prepare, replacements


class ReviewCopyTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        self.path = Path(self.folder.name)
        self.run = self.path / "run"
        self.run.mkdir()
        self.source = self.run / "claim_audit.json"
        self.source.write_text('{"immutable": true}')
        self.renderer = SimpleNamespace(
            run=self.run,
            day=date(2026, 9, 27),
            meta={"input": {"sha256": "recorded-input"}},
        )
        save(
            self.path / "review-copy.json",
            {
                "binding": {
                    "input_sha256": "recorded-input",
                    "analysis_date": "2026-09-27",
                    "files": {"claim_audit.json": digest(self.source)},
                },
                "replacements": {"Original wording.": "Revised wording."},
            },
        )

    def test_changed_analysis_cannot_reuse_current_copy(self):
        self.assertTrue(replacements(self.renderer, self.path))
        self.source.write_text('{"changed": true}')
        data = {"claims": [{"reason": "Original wording."}]}
        prepare(data, self.renderer, self.path)
        self.assertEqual(data["claims"][0]["reason"], "Original wording.")
        self.assertEqual(replacements(self.renderer, self.path), {})

    def test_current_copy_preserves_quotes_and_model_history(self):
        source_hash = digest(self.source)
        data = {
            "candidates": [
                {
                    "proposed_website_text": "Original wording.",
                    "audit_original_wording": "Original wording.",
                }
            ],
            "claims": [
                {"exact_wording": "Original wording.", "reason": "Original wording."}
            ],
        }
        prepare(data, self.renderer, self.path)
        self.assertEqual(data["claims"][0]["exact_wording"], "Original wording.")
        self.assertEqual(data["claims"][0]["reason"], "Revised wording.")
        self.assertEqual(
            data["candidates"][0]["audit_original_wording"], "Original wording."
        )
        quoted = "<blockquote>Original wording.</blockquote>"
        model = "<section><h2>Independent model review</h2><p>Original wording.</p></section>"
        page = self.path / "claim-example.html"
        page.write_text("<p>Original wording.</p>" + quoted + model)
        history = self.path / "model-review.html"
        history.write_text("<p>Original wording.</p>")
        history_hash = digest(history)
        install(self.path, self.renderer, self.path)
        self.assertTrue(page.read_text().startswith("<p>Revised wording.</p>"))
        self.assertIn(quoted, page.read_text())
        self.assertIn(model, page.read_text())
        self.assertEqual(digest(history), history_hash)
        self.assertEqual(digest(self.source), source_hash)


if __name__ == "__main__":
    unittest.main()
