"""Actual dates must determine chart detail; annual and projected totals stay distinct."""

import csv
import json
import re
import shutil
import subprocess
import tempfile
import unittest
import zipfile
from datetime import date, timedelta
from pathlib import Path

from delivery.core import ROOT, latest
from delivery.daily_timeline import (
    build_series,
    previous_anniversary,
    svg,
    update_charts,
)
from delivery.partial_year import update_september
from delivery.render import Renderer, RESOURCES


class DailyTimelineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.renderer = Renderer(ROOT, latest(), ROOT / "_unused")
        cls.series = build_series(cls.renderer)
        with (ROOT / cls.renderer.meta["input"]["snapshot_path"]).open(
            newline="", encoding="utf-8-sig"
        ) as stream:
            cls.dates = {
                r["aiid_id"]: date.fromisoformat(r["date"][:10])
                for r in csv.DictReader(stream)
                if r["date"]
            }

    def test_every_daily_window_matches_independent_id_count(self):
        for identifier, series in self.series.items():
            sets = {side: set() for side in ("numerator", "denominator")}
            for measure in [
                *[
                    self.renderer.measures[p["calculation_id"]]
                    for p in series["points"]
                ],
                series["partial"],
            ]:
                for side in sets:
                    sets[side].update(
                        json.loads(
                            (self.renderer.run / measure[side + "_ids_ref"]).read_text()
                        )
                    )
            for row in (
                series["historical"] + series["current"] + series["observed_current"]
            ):
                start, end = date.fromisoformat(
                    row["window_start"]
                ), date.fromisoformat(row["date"])
                for side, ids in sets.items():
                    expected = sum(start <= self.dates[i] <= end for i in ids)
                    self.assertEqual(
                        row[side], expected, (identifier, row["date"], side)
                    )
                    self.assertEqual(
                        row["daily_" + side], sum(self.dates[i] == end for i in ids)
                    )
                self.assertEqual(
                    row["percent"],
                    (
                        100 * row["numerator"] / row["denominator"]
                        if row["denominator"]
                        else None
                    ),
                )

    def test_annual_and_partial_anchors_are_preserved_for_all_six_charts(self):
        self.assertEqual(len(self.series), 6)
        expected = {
            "IT-C001": 231,
            "IT-C002": 43,
            "IT-D002": 41,
            "IT-D003": 107,
            "IT-D004": 148,
            "IT-D006": 23,
        }
        for identifier, series in self.series.items():
            self.assertEqual(series["points"][0]["year"], 2021)
            self.assertEqual(len(series["historical"]), 1462)
            self.assertEqual(len(series["current"]), 270)
            self.assertEqual(len(series["observed_current"]), 270)
            self.assertEqual(series["current"][-1]["numerator"], expected[identifier])
            by_date = {r["date"]: r for r in series["historical"]}
            for p in series["points"]:
                for side in ("numerator", "denominator", "percent"):
                    self.assertEqual(by_date[str(p["year"]) + "-12-31"][side], p[side])
        self.assertEqual(
            [p["numerator"] for p in self.series["IT-C001"]["points"]],
            [80, 108, 179, 304, 452],
        )
        self.assertEqual(previous_anniversary(date(2024, 2, 29)), date(2023, 2, 28))
        self.assertAlmostEqual(
            self.series["IT-C001"]["projection"]["calendar_pace"], 231 * 365 / 270
        )

    def test_year_end_range_is_numeric_and_daily_observations_are_unchanged(self):
        for identifier, series in self.series.items():
            chart = svg(series, True)
            self.assertIn('data-daily-points="1732"', chart)
            self.assertNotIn("future-period", chart)
            self.assertNotIn("forecast-segment", chart)
            self.assertNotIn("daily-estimate-dot", chart)
            self.assertEqual(chart.count('class="year-end-range"'), 1)
            path = re.search(
                r'<path class="daily-trace daily-historical"[^>]*d="([^"]+)"', chart
            )[1]
            self.assertEqual(path.count("M"), 1)
            self.assertEqual(path.count("H"), 1731)
            expected = series["projection"]["range"]["bounds"][series["default_view"]]
            segment = re.search(r'<g class="year-end-range"([^>]+)', chart)[1]
            self.assertIn('data-date="2026-12-31"', segment)
            fan = re.search(r'<path class="forecast-fan"([^>]+)', chart)[1]
            range_group = re.search(r'<g class="year-end-range".*?</g>', chart)[0]
            self.assertEqual(range_group.count("<path"), 1)
            self.assertIn('data-origin-date="2026-09-27"', fan)
            current_value = series["observed_current"][-1][
                "numerator" if series["default_view"] == "counts" else "percent"
            ]
            self.assertIn(f'data-origin-value="{current_value}"', fan)
            for attr, value in zip(["lower", "upper"], expected):
                self.assertAlmostEqual(
                    float(re.search("data-" + attr + r'="([^"]+)"', segment)[1]), value
                )
            self.assertNotIn("year-end-range", svg(series, False))
        all_records = self.series["IT-C001"]
        self.assertEqual(all_records["observed_current"][-1]["numerator"], 350)
        self.assertEqual(all_records["current"][-1]["numerator"], 231)
        self.assertIn("n ≈ 330–420", svg(all_records, True))
        self.assertIn("2026 year-end range (central 50%)", svg(all_records, True))

    def test_range_reproduces_independent_historical_timing_calculations(self):
        for identifier, series in self.series.items():
            if identifier == "IT-C001":
                continue
            values = [series["partial"]["numerator"] * 365 / 270]
            percentages = [series["partial"]["percent"]]
            for point in series["points"]:
                measure = self.renderer.measures[point["calculation_id"]]
                projected = {}
                for side in ["numerator", "denominator"]:
                    ids = json.loads(
                        (self.renderer.run / measure[side + "_ids_ref"]).read_text()
                    )
                    count = sum(
                        self.dates[i] <= date(point["year"], 9, 27) for i in ids
                    )
                    projected[side] = (
                        series["partial"][side] * len(ids) / count if count else None
                    )
                if projected["numerator"] is not None and projected["denominator"]:
                    values.append(projected["numerator"])
                    percentages.append(
                        100 * projected["numerator"] / projected["denominator"]
                    )
            self.assertEqual(
                series["projection"]["range"]["bounds"]["counts"],
                [min(values), max(values)],
            )
            expected = [v for v in percentages if v is not None and 0 <= v <= 100]
            self.assertEqual(
                series["projection"]["range"]["bounds"]["share"],
                [min(expected), max(expected)],
            )

    def test_workbench_ranges_views_and_csv_preserve_window_distinction(self):
        node = shutil.which("node")
        if not node:
            self.skipTest("Node unavailable")
        with tempfile.TemporaryDirectory() as folder:
            data = Path(folder) / "series.json"
            data.write_text(json.dumps(self.series))
            script = r"""
const assert=require('node:assert/strict'),fs=require('node:fs'),core=require(process.argv[1]),all=JSON.parse(fs.readFileSync(process.argv[2]));
for(const s of Object.values(all)){
 for(const view of ['counts','share']){
  const m=core.layout(s,view,2024,2026,true);
  assert.equal(m.historical[0].date,'2024-12-31');assert.equal(m.current.at(-1).date,'2026-09-27');
  assert.equal(m.projection.percent,m.current.at(-1).percent);
  const chart=core.svg(s,view,2024,2026,true);
  if(s.id==='IT-C001'&&view==='share'){
    assert.ok(!chart.includes('year-end-range'));assert.ok(!chart.includes('forecast-fan'));assert.ok(chart.includes('is-single'));assert.equal((chart.match(/<dd>100%<\/dd>/g)||[]).length,1);assert.ok(!chart.includes('100–100'));
  }else{
    assert.ok(chart.includes('year-end-range'));assert.ok(chart.includes('class="forecast-fan"'));const ox=m.cx(s.cutoff).toFixed(3),oy=m.y(m.observed.at(-1)[view==='counts'?'numerator':'percent']).toFixed(3);assert.ok(chart.includes('d="M'+ox+','+oy+'L740,'));
  }
  assert.ok(!chart.includes('forecast-segment'));assert.ok(!chart.includes('NaN'));assert.ok(!chart.includes('partial-year-segment'));assert.equal(m.observed.at(-1).date,'2026-09-27');assert.equal(m.observedCurrent.length,270);assert.ok(!chart.includes('daily-current-background'));assert.ok(Math.abs((m.hx(s.cutoff)-m.hx('2025-12-31'))/(m.hx('2026-12-31')-m.hx('2025-12-31'))-270/365)<1e-10);
  assert.ok(!core.svg(s,view,2024,2025,false).includes('year-end-range'));
  assert.equal(core.layout(s,view,2026,2026,true).historical.length,0);
  assert.ok(!core.svg(s,view,2026,2026,true).includes('NaN'));
 }
}
const s=all['IT-C001'],m=core.layout(s,'counts',2021,2026,true);
const review=core.layout(s,'counts',2021,2026,true,false),reviewSVG=core.svg(s,'counts',2021,2026,true,false),monitorSVG=core.svg(s,'counts',2021,2026,true,true);
assert.equal(review.projection,null);assert.deepEqual(review.observed,m.observed);assert.equal(review.cx(s.cutoff),m.cx(s.cutoff));assert.equal(review.y(350),m.y(350));assert.ok(!reviewSVG.includes('forecast-fan'));assert.ok(!reviewSVG.includes('year-end range'));assert.ok(reviewSVG.includes('2026 so far'));assert.ok(reviewSVG.includes('>231</dd>'));assert.ok(reviewSVG.includes('data-observed-value="350"'));assert.equal(monitorSVG.match(/<g class="year-end-range".*?<\/g>/)[0].match(/<path/g).length,1);assert.ok(monitorSVG.includes('central 50%'));
assert.equal(core.points(s,s.cutoff,'counts',2021,2026,true).at(-1).value,231);
assert.deepEqual(core.headline(s,'counts',2021,2026),{first:80,last:350,period:'2021–Sep 27, 2026',measure:'12-month record count',direction:'increase'});
assert.equal(core.headline(s,'counts',2021,2025).last,452);
assert.equal(core.headline(s,'share',2021,2026).direction,'flat');
assert.equal(core.headline(all['IT-C002'],'share',2021,2026).direction,'decrease');
assert.equal(core.headline(all['IT-C002'],'share',2021,2026).last,60/350*100);
assert.equal(core.rangeText(m.projection,'counts'),'330–420');assert.ok(core.svg(s,'counts',2021,2026,true).includes('central 50%'));assert.equal(m.projection.range.coverage_probability,.5);assert.equal(m.projection.range.wider_interval.coverage_probability,.9);assert.equal(m.projection.calendar_pace,231*365/270);assert.equal(m.observed.at(-1).numerator,350);assert.equal(m.observed.at(-1).window,'preceding_12_months');
assert.ok(core.csv(m.current.map(r=>[r.date,r.window,r.numerator])).includes('"2026-09-27","year_to_date","231"'));
"""
            subprocess.run(
                [
                    node,
                    "-e",
                    script,
                    str(RESOURCES.parent / "assets/analysis-core.js"),
                    str(data),
                ],
                check=True,
                capture_output=True,
            )

    def test_current_charts_change_but_preserved_history_and_evidence_do_not(self):
        with tempfile.TemporaryDirectory() as folder:
            site = Path(folder)
            with zipfile.ZipFile(RESOURCES / "september-review.zip") as archive:
                for item in archive.infolist():
                    name = Path(item.filename)
                    if len(name.parts) == 2 and not item.is_dir():
                        (site / name.name).write_bytes(archive.read(item))
            old = (site / "OPEN_REVIEW.html").read_bytes()
            history = site / "history/september"
            history.mkdir(parents=True)
            (history / "OPEN_REVIEW.html").write_bytes(old)
            scenarios = (site / "projections-2026.json").read_bytes()
            update_september(site, RESOURCES)
            self.assertEqual(update_charts(site, self.series), 24)
            self.assertEqual((history / "OPEN_REVIEW.html").read_bytes(), old)
            self.assertEqual((site / "projections-2026.json").read_bytes(), scenarios)
            text = (site / "OPEN_REVIEW.html").read_text()
            self.assertEqual(text.count('class="year-end-range"'), 6)
            self.assertNotIn('class="forecast-segment"', text)
            self.assertEqual(text.count('data-daily-points="1462"'), 6)
            self.assertEqual(text.count('data-daily-points="1732"'), 6)
            self.assertEqual(text.count('class="period-label">2021–Sep 27, 2026'), 6)
            self.assertEqual(text.count('class="value-arrow increase"'), 4)
            self.assertEqual(text.count('class="value-arrow decrease"'), 2)
            methods = (site / "methods.html").read_text()
            self.assertIn("74 records dated 2025", methods)
            self.assertIn("231 × 365 ÷ 270 ≈ 312", methods)
            self.assertNotIn("methods table only", methods)
            self.assertIn("including 2026", methods)
            self.assertNotIn("two straight branches", methods.lower())


if __name__ == "__main__":
    unittest.main()
