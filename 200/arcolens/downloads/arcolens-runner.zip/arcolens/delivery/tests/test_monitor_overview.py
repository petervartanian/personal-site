"""Monitoring must distinguish new results from a check of an unchanged export."""

import unittest

from delivery.monitor_overview import claim_summary, queue_panel, results_panel


class MonitorOverviewTests(unittest.TestCase):
    def data(self) -> dict:
        return {
            "analysis_date": "2026-09-27",
            "items": [],
            "measures": {},
            "monitoring": {
                "checks": [{"label": "No new export", "new_data": False}],
                "source_check": {
                    "summary": {"present": 52, "app_source_unchanged": 7, "changed": 0}
                },
            },
        }

    def test_unchanged_export_does_not_claim_a_new_comparison(self) -> None:
        data = self.data()
        result = results_panel(data)
        self.assertIn("Pending", result)
        self.assertIn("Next export after Sep 27, 2026", result)
        self.assertIn("7 additional source-only checks", result)
        self.assertNotIn("Received", result)
        data["monitoring"]["checks"][0] = {
            "label": "New findings ready for review",
            "new_data": True,
        }
        self.assertIn("Received", results_panel(data))

    def test_updated_status_removes_claim_from_correction_queue(self) -> None:
        data = self.data()
        claim = {
            "id": "TEST",
            "kind": "claim",
            "status": "Update needed",
            "title": "Current claim",
            "wording": "Replacement <text>",
            "page": "claim-TEST.html",
            "evidence": [],
        }
        data["items"].append(claim)
        self.assertIn("Replacement &lt;text&gt;", queue_panel(data))
        claim["status"] = "Supported"
        self.assertNotIn("Current claim", queue_panel(data))
        self.assertIn("No corrections flagged", queue_panel(data))

    def test_risk_tier_summary_tracks_new_values(self) -> None:
        item = {"id": "OVERVIEW-03"}
        measures = {
            "claim.OVERVIEW-03.level1": {"percent": 8.6},
            "claim.OVERVIEW-03.level2": {"percent": 21.4},
        }
        title, wording = claim_summary(item, measures)
        self.assertEqual(title, "EU risk-tier shares")
        self.assertIn("8.6%", wording)
        self.assertIn("21.4%", wording)
        self.assertNotIn("5.1%", wording)

    def test_failed_source_checks_do_not_display_no_alerts(self) -> None:
        data = self.data()
        data["monitoring"]["source_check"]["summary"].update(
            changed=2, absent=1, page_unavailable=1
        )
        result = results_panel(data)
        self.assertIn("<strong>4</strong>", result)
        self.assertNotIn("No statement changes flagged", result)


if __name__ == "__main__":
    unittest.main()
