"""Delivery regressions: privacy, stale-copy prevention, and publication gates."""

from __future__ import annotations

import json
import re
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

from delivery.check_and_publish import deliver
from delivery.core import safe_extract
from delivery.render import LinkCheck, Renderer, verify_site


class DeliveryTests(unittest.TestCase):
    def test_new_export_build_keeps_historical_links_in_the_archive(self) -> None:
        from delivery.core import ROOT, latest
        from delivery.package import create
        from delivery.render import build

        with tempfile.TemporaryDirectory() as folder:
            target = Path(folder)
            package = target / "runner.zip"
            create(package)
            # Exercise the full new-export renderer and its link verification.
            # The same verified data avoids inventing a fresh Arcola export.
            with patch("delivery.render.matching_frozen", return_value=False):
                result = build(latest(), target / "delivery", package, ROOT)
            site = target / "delivery/simon-review"
            self.assertEqual(result["verification"]["status"], "passed")
            workbench = json.loads(
                (site / "workbench-data.js")
                .read_text()
                .removeprefix("window.ARCOLENS_WORKBENCH=")
                .rstrip(";\n")
            )
            items = {item["id"]: item for item in workbench["items"]}
            baseline = ROOT / "delivery/resources/current-baseline"
            reviews = json.loads((baseline / "editorial/review.json").read_text())[
                "reviews"
            ]
            self.assertEqual(
                sum(bool(item.get("model")) for item in items.values()), 32
            )
            self.assertEqual({review["item_id"] for review in reviews}, set(items))
            curated = json.loads((baseline / "review-data.json").read_text())[
                "candidates"
            ]
            for candidate in curated:
                if candidate["candidate_id"] in {
                    "IT-C001",
                    "IT-C002",
                    "IT-D006",
                    "IT-D003",
                    "IT-D004",
                }:
                    # The current copy can clarify compatibility prose without changing controls.
                    self.assertEqual(
                        {
                            k: v
                            for k, v in items[candidate["candidate_id"]][
                                "chart"
                            ].items()
                            if k != "compatibility"
                        },
                        {
                            k: v
                            for k, v in candidate["chart_configuration"].items()
                            if k != "compatibility"
                        },
                    )
            source_check = (site / "source-check.html").read_text()
            self.assertIn("2026-10-01T15:51:08.568039+00:00", source_check)
            self.assertIn(
                "Javascript rendered text checked</dt><dd>False", source_check
            )
            self.assertIn(
                'href="history/september/SIMON_BRIEF.pdf"',
                (site / "files.html").read_text(),
            )
            self.assertIn(
                'href="history/september/data-quality.html"',
                (site / "methods.html").read_text(),
            )
            self.assertNotIn(
                'href="data-quality.html"', (site / "methods.html").read_text()
            )
            # The tour must still lead to real outputs after the CSV changes.
            from urllib.parse import urlsplit

            config = json.loads(
                re.search(
                    r'id="arcolens-guide-config">(.*?)</script>',
                    (site / "OPEN_REVIEW.html").read_text(),
                    re.S,
                ).group(1)
            )
            self.assertEqual(len(config["steps"]), 5)
            for step in config["steps"]:
                page = site / step["page"]
                self.assertTrue(page.is_file(), step["page"])
                self.assertTrue((site / urlsplit(step["link"][0]).path).is_file())
                if step.get("heading"):
                    self.assertIn(">" + step["heading"] + "</h2>", page.read_text())
            self.assertNotIn(
                'id="arcolens-guide-config"',
                (site / "history/september/OPEN_REVIEW.html").read_text(),
            )

    def test_failed_check_cannot_publish(self) -> None:
        for status in [
            "editorial_failed",
            "analysis_or_website_check_failed",
            "intake_failed",
        ]:
            result = deliver(
                {"exit_code": 2, "status": status, "analysis_invoked": True},
                Path("not-read"),
            )
            self.assertEqual(result["status"], "held_after_failed_check")
            self.assertFalse(result["published"])

    def test_unchanged_check_does_not_rebuild_or_call_models(self) -> None:
        result = deliver(
            {"exit_code": 0, "analysis_invoked": False, "status": "unchanged_export"},
            Path("not-read"),
        )
        self.assertEqual(result["status"], "unchanged_no_publication")

    def test_claimed_success_without_review_is_rejected(self) -> None:
        with self.assertRaises(ValueError):
            deliver(
                {
                    "exit_code": 0,
                    "analysis_invoked": True,
                    "status": "completed_without_review",
                    "website_refresh_ok": True,
                },
                Path("not-read"),
            )

    def test_archive_traversal_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            with zipfile.ZipFile(root / "unsafe.zip", "w") as archive:
                archive.writestr("../outside", "bad")
            with self.assertRaises(ValueError):
                safe_extract(root / "unsafe.zip", root / "output")
            self.assertFalse((root / "outside").exists())

    def test_missing_and_escaping_links_are_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            for target in ["missing.csv", "../private.txt", "%2e%2e/private.txt"]:
                (root / "index.html").write_text(f'<a href="{target}">Download</a>')
                with self.assertRaises(ValueError):
                    verify_site(root)

    def test_runtime_counts_and_date_come_from_new_run(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            run = root / "run"
            out = root / "out"
            run.mkdir()
            out.mkdir()
            files = {
                "run_metadata.json": {
                    "analysis_date": "2027-02-01",
                    "input": {"sha256": "test"},
                    "result_counts": {"records": 2047},
                },
                "candidates.json": [],
                "claim_audit.json": [],
                "chart_outcomes.json": [],
                "calculations.json": {"measures": {}},
            }
            for name, value in files.items():
                (run / name).write_text(json.dumps(value))
            renderer = Renderer(root, run, out)
            renderer.current_pages()
            home = (out / "OPEN_REVIEW.html").read_text()
            self.assertIn("February 2027", home)
            self.assertIn("2,047", home)
            self.assertNotIn("1,698", home)
            self.assertNotIn("September export", home)
            self.assertEqual(renderer.counts["candidates.html"], 0)

    def test_candidate_text_is_escaped(self) -> None:
        from delivery.render import structured

        self.assertEqual(
            structured("<script>alert(1)</script>"),
            "&lt;script&gt;alert(1)&lt;/script&gt;",
        )

    def test_stale_model_review_is_rejected(self) -> None:
        from delivery.check_and_publish import verify_editorial

        with tempfile.TemporaryDirectory() as folder:
            cycle = Path(folder)
            (cycle / "status.json").write_text(
                json.dumps(
                    {"status": "completed_requires_human_review", "run_id": "older-run"}
                )
            )
            with patch("tracker.editorial_adoption._manifest"):
                with self.assertRaisesRegex(ValueError, "exact run"):
                    verify_editorial(cycle, cycle / "current-run")

    def test_completed_new_export_reaches_publisher_after_review(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            run = root / "runs/new-run"
            run.mkdir(parents=True)
            (run / "run_metadata.json").write_text(
                json.dumps({"input": {"sha256": "new-data"}})
            )
            report = {
                "exit_code": 0,
                "status": "completed_requires_human_review",
                "analysis_invoked": True,
                "website_refresh_ok": True,
                "analysis_run": str(run),
                "selected_input": {"sha256": "new-data"},
                "editorial_output": str(root / "cycle"),
                "output": str(root / "check"),
            }
            with (
                patch("delivery.check_and_publish.latest", return_value=run),
                patch("delivery.check_and_publish.verify_editorial") as review,
                patch("delivery.package.create"),
                patch("delivery.render.build"),
                patch(
                    "delivery.publish.publish", return_value={"status": "deployed"}
                ) as publish,
                patch(
                    "delivery.check_and_publish.digest", return_value="manifest-hash"
                ),
            ):
                self.assertEqual(
                    deliver(report, root / "config", root)["status"], "deployed"
                )
                review.assert_called_once_with(root / "cycle", run, None)
                publish.assert_called_once()

    def test_saved_but_invalid_adoption_does_not_approve_an_old_review(self) -> None:
        from delivery.check_and_publish import verify_editorial

        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            cycle, run = root / "cycle", root / "runs/current"
            cycle.mkdir()
            run.mkdir(parents=True)
            (cycle / "status.json").write_text(
                json.dumps(
                    {"status": "completed_requires_human_review", "run_id": "older"}
                )
            )
            (root / "LATEST_EDITORIAL_ADOPTION.json").write_text(
                json.dumps({"status": "not_adopted"})
            )
            with patch("tracker.editorial_adoption._manifest"):
                with self.assertRaisesRegex(ValueError, "verified equivalent"):
                    verify_editorial(cycle, run)

    def test_adoption_never_substitutes_different_evidence_or_context(self) -> None:
        from delivery.check_and_publish import verify_editorial
        from tracker.editorial_adoption import ADOPTED

        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            cycle, run = root / "cycle", root / "runs/current"
            cycle.mkdir()
            run.mkdir(parents=True)
            (cycle / "status.json").write_text(
                json.dumps(
                    {"status": "completed_requires_human_review", "run_id": "older"}
                )
            )
            (cycle / "evidence.json").write_text(
                json.dumps({"run_id": "older", "value": 1})
            )
            (root / "LATEST_EDITORIAL_ADOPTION.json").write_text("{}")
            with (
                patch("tracker.editorial_adoption._manifest"),
                patch(
                    "tracker.editorial_adoption.verify_adoption_record",
                    return_value={"status": ADOPTED, "paths": {"cycle": str(cycle)}},
                ),
                patch(
                    "tracker.editorial.evidence_payload",
                    return_value={"run_id": "current", "value": 2},
                ),
            ):
                with self.assertRaisesRegex(ValueError, "does not match"):
                    verify_editorial(cycle, run)

    def test_workbench_uses_same_wording_and_retains_all_caveats(self) -> None:
        from types import SimpleNamespace
        from delivery.workbench import install

        with tempfile.TemporaryDirectory() as folder:
            site = Path(folder)
            candidate = {
                "candidate_id": "TEST",
                "title": "A finding",
                "proposed_website_text": "Calculated wording",
                "calculation_confidence": "High",
                "interpretation_confidence": "Limited",
                "caveats": ["Sampling bias"],
                "chart_configuration": {"view": "proportion"},
                "evidence_ids": ["m"],
            }
            (site / "review-data.json").write_text(
                json.dumps(
                    {
                        "candidates": [
                            {
                                **candidate,
                                "proposed_website_text": "Carefully reviewed wording",
                                "review_notes": ["Date limit"],
                            }
                        ]
                    }
                )
            )

            def page(name: str, *args: object) -> None:
                (site / name).write_text(
                    '<head></head><body class="detail-page"><div class="appbar-actions"></div></body>'
                )

            renderer = SimpleNamespace(
                out=site,
                candidates=[candidate],
                claims=[],
                model_drafts={},
                model_reviews={},
                run=Path("verified-run"),
                meta={"input": {"sha256": "csv-hash"}},
                measures={"m": {"numerator": 2}},
                calculations={"series": {}},
                timelines={},
                page=page,
            )
            page("OPEN_REVIEW.html")
            original = (site / "OPEN_REVIEW.html").read_text()
            install(renderer)
            text = (site / "workbench-data.js").read_text()
            data = json.loads(
                text.removeprefix("window.ARCOLENS_WORKBENCH=").rstrip(";\n")
            )
            self.assertEqual(data["items"][0]["wording"], "Carefully reviewed wording")
            self.assertEqual(
                data["items"][0]["caveats"], ["Date limit", "Sampling bias"]
            )
            self.assertEqual(data["input_sha256"], "csv-hash")
            self.assertFalse(data["monitoring"]["configured"])
            self.assertIn(
                "<span>Monitor</span>", (site / "OPEN_REVIEW.html").read_text()
            )
            self.assertNotIn(
                ">Workbench</button>", (site / "OPEN_REVIEW.html").read_text()
            )
            self.assertNotIn(
                "workbench-layout", (site / "OPEN_REVIEW.html").read_text()
            )
            self.assertIn(
                "location.replace(address)", (site / "workbench.html").read_text()
            )
            self.assertIn(
                'aria-label="Analysis mode"', (site / "OPEN_REVIEW.html").read_text()
            )


if __name__ == "__main__":
    unittest.main()
