"""Recurring delivery must never conceal missing inputs or duplicate paid work."""

from datetime import date, datetime, timezone
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from delivery.core import digest, save
from delivery.recurring import freshness, run, single_run, source_check


class RecurringTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name).resolve()
        self.now = datetime(2026, 9, 28, 12, tzinfo=timezone.utc)
        self.policy = {
            "account": "peter",
            "folder_ids": ["source-a", "source-b"],
            "cadence": "monthly",
            "max_age_days": 35,
        }
        self.receipt = {
            "transport": "connected_google_drive",
            "account": "peter",
            "checked_at_utc": self.now.isoformat(),
            "folders": [
                {"id": name, "status": "complete", "all_pages_read": True, "files": []}
                for name in self.policy["folder_ids"]
            ],
        }
        self.intake = {
            "status": "unchanged_export",
            "ready_for_analysis": False,
            "selected": {"sha256": "same", "filename_date": "2026-09-27"},
            "baseline": {"input_sha256": "same", "export_date": "2026-09-27"},
        }

    def test_complete_empty_sources_are_recorded_without_inventing_downloads(self):
        result = source_check(self.receipt, self.policy, self.root, self.now)
        self.assertEqual(result["status"], "passed")
        self.assertEqual(result["downloads"], [])

    def test_incomplete_pagination_and_missing_folder_fail(self):
        self.receipt["folders"][0]["all_pages_read"] = False
        self.receipt["folders"].pop()
        self.assertEqual(
            len(source_check(self.receipt, self.policy, self.root, self.now)["errors"]),
            2,
        )

    def test_stale_source_receipt_fails(self):
        self.receipt["checked_at_utc"] = "2026-09-26T00:00:00Z"
        self.assertTrue(
            source_check(self.receipt, self.policy, self.root, self.now)["errors"]
        )

    def test_download_must_be_present_original_name_and_hash_bound(self):
        name = "incident_tracker_export_2026-09-27.csv"
        path = self.root / "intake/drive/id/version" / name
        path.parent.mkdir(parents=True)
        path.write_bytes(b"original CSV")
        item = {
            "id": "id",
            "name": name,
            "local_path": str(path),
            "sha256": digest(path),
            "retrieved_at_utc": self.now.isoformat(),
        }
        self.receipt["folders"][0]["files"] = [item]
        self.assertFalse(
            source_check(self.receipt, self.policy, self.root, self.now)["errors"]
        )
        path.write_bytes(b"changed")
        self.assertTrue(
            source_check(self.receipt, self.policy, self.root, self.now)["errors"]
        )

    def test_eligible_but_undownloaded_file_is_not_ignored(self):
        self.receipt["folders"][0]["files"] = [
            {"id": "id", "name": "incident_tracker_export_2026-09-27.csv"}
        ]
        self.assertTrue(
            source_check(self.receipt, self.policy, self.root, self.now)["errors"]
        )

    def test_renaming_identical_bytes_does_not_reset_due_date(self):
        self.intake["selected"]["filename_date"] = "2026-10-27"
        result = freshness(self.intake, date(2026, 10, 27), self.policy)
        self.assertEqual(result["status"], "expected_update_not_received")
        self.assertEqual(result["data_date"], "2026-09-27")

    def test_recent_changed_export_is_eligible_and_old_changed_export_is_held(self):
        self.intake.update(ready_for_analysis=True, status="different_export")
        self.intake["selected"]["sha256"] = "changed"
        self.assertFalse(
            freshness(self.intake, date(2026, 9, 28), self.policy)["needs_attention"]
        )
        self.assertTrue(
            freshness(self.intake, date(2026, 12, 1), self.policy)["needs_attention"]
        )

    def test_lock_prevents_concurrent_run_and_cleans_up_on_failure(self):
        with self.assertRaisesRegex(ValueError, "active or was interrupted"):
            with single_run(self.root):
                with single_run(self.root):
                    self.fail("Overlapping run acquired lock")
        self.assertFalse((self.root / "intake/recurring.lock").exists())

    def test_failed_source_check_still_refreshes_claims_without_models_or_publication(
        self,
    ):
        self.receipt["folders"][0]["status"] = "failed"
        save(self.root / "policy.json", self.policy)
        save(self.root / "receipt.json", self.receipt)
        with (
            patch("tracker.intake.inspect_exports", return_value=self.intake),
            patch(
                "scripts.check_monthly.run_step", return_value={"returncode": 0}
            ) as refresh,
            patch("scripts.check_monthly.check_monthly") as check,
            patch("delivery.check_and_publish.deliver") as publish,
        ):
            result = run(
                self.root / "config",
                self.root / "receipt.json",
                self.root / "policy.json",
                self.root / "downloads",
                self.root,
                self.now,
            )
        refresh.assert_called_once()
        check.assert_not_called()
        publish.assert_not_called()
        self.assertEqual(result["status"], "source_delivery_needs_attention")
        self.assertEqual(result["exit_code"], 2)
        self.assertFalse(result["model_cycle_invoked"])

    def test_successful_new_data_uses_existing_full_review_and_publisher(self):
        self.intake.update(ready_for_analysis=True, status="different_export")
        self.intake["selected"]["sha256"] = "new"
        save(self.root / "policy.json", self.policy)
        save(self.root / "receipt.json", self.receipt)
        checked = {
            "status": "completed_requires_human_review",
            "exit_code": 0,
            "output": str(self.root / "check"),
            "analysis_invoked": True,
            "model_cycle_invoked": True,
        }
        with (
            patch("tracker.intake.inspect_exports", return_value=self.intake),
            patch("scripts.check_monthly.check_monthly", return_value=checked) as check,
            patch(
                "delivery.check_and_publish.deliver",
                return_value={"status": "deployed"},
            ) as publish,
        ):
            result = run(
                self.root / "config",
                self.root / "receipt.json",
                self.root / "policy.json",
                self.root / "downloads",
                self.root,
                self.now,
            )
        check.assert_called_once()
        publish.assert_called_once_with(checked, self.root / "config", self.root)
        self.assertTrue(result["published"])
        self.assertEqual(result["exit_code"], 0)

    def test_missing_source_receipt_still_checks_claims_without_models(self):
        save(self.root / "policy.json", self.policy)
        with (
            patch("tracker.intake.inspect_exports", return_value=self.intake),
            patch(
                "scripts.check_monthly.run_step", return_value={"returncode": 0}
            ) as refresh,
            patch("scripts.check_monthly.check_monthly") as check,
        ):
            result = run(
                self.root / "config",
                self.root / "missing.json",
                self.root / "policy.json",
                self.root / "downloads",
                self.root,
                self.now,
            )
        refresh.assert_called_once()
        check.assert_not_called()
        self.assertEqual(result["status"], "source_delivery_needs_attention")

    def test_due_update_without_new_bytes_is_not_success(self):
        later = datetime(2026, 10, 27, 12, tzinfo=timezone.utc)
        self.receipt["checked_at_utc"] = later.isoformat()
        save(self.root / "policy.json", self.policy)
        save(self.root / "receipt.json", self.receipt)
        with (
            patch("tracker.intake.inspect_exports", return_value=self.intake),
            patch("scripts.check_monthly.run_step", return_value={"returncode": 0}),
            patch("scripts.check_monthly.check_monthly") as check,
        ):
            result = run(
                self.root / "config",
                self.root / "receipt.json",
                self.root / "policy.json",
                self.root / "downloads",
                self.root,
                later,
            )
        check.assert_not_called()
        self.assertEqual(result["status"], "expected_update_not_received")
        self.assertEqual(result["exit_code"], 2)


if __name__ == "__main__":
    unittest.main()
