"""Scheduler status must describe the real installation without leaking settings."""

from datetime import date, datetime
import json
from pathlib import Path
import tempfile
import unittest

from delivery.core import digest, save
from delivery.monitor import Schedule, page_body, snapshot, verified_checks


class MonitorTests(unittest.TestCase):
    def test_monthly_schedule_uses_local_time_across_dst(self) -> None:
        schedule = Schedule(cadence="monthly", state="ACTIVE")
        self.assertEqual(
            schedule.next_check(
                datetime.fromisoformat("2026-09-28T14:00:00+00:00")
            ).isoformat(),
            "2026-10-27T09:00:00-04:00",
        )
        self.assertEqual(
            schedule.next_check(
                datetime.fromisoformat("2026-10-28T14:00:00+00:00")
            ).isoformat(),
            "2026-11-27T09:00:00-05:00",
        )

    def test_paused_schedule_has_no_next_run(self) -> None:
        self.assertIsNone(
            Schedule(cadence="monthly", state="PAUSED").next_check(
                datetime.now().astimezone()
            )
        )

    def test_fortnightly_anchor_is_preserved(self) -> None:
        schedule = Schedule(
            cadence="fortnightly", state="ACTIVE", anchor=date(2026, 9, 27)
        )
        self.assertEqual(
            schedule.next_check(
                datetime.fromisoformat("2026-09-28T14:00:00+00:00")
            ).isoformat(),
            "2026-10-11T09:00:00-04:00",
        )

    def test_copy_without_private_binding_is_unconfigured(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            state = snapshot(Path(folder), "2026-09-27")
            self.assertFalse(state["configured"])
            self.assertIn("not configured", page_body(state))
            self.assertNotIn("Active", page_body(state))

    def test_real_scheduler_binding_redacts_prompt_and_local_paths(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            automation = root / "automation.toml"
            automation.write_text(
                'kind = "heartbeat"\nstatus = "ACTIVE"\nprompt = "private-account-and-instructions"\nrrule = "FREQ=MONTHLY;BYMONTHDAY=27;BYHOUR=9;BYMINUTE=0;BYSECOND=0"\n'
            )
            save(
                root / "intake/schedule_display.json",
                {
                    "automation_path": str(automation),
                    "timezone": "America/New_York",
                    "fortnightly_anchor": "2026-09-27",
                },
            )
            save(
                root / "intake/source_policy.json",
                {
                    "cadence": "monthly",
                    "account": "private-account",
                    "primary_folder_id": "approved-inbox",
                },
            )
            state = snapshot(
                root, "2026-09-27", datetime.fromisoformat("2026-09-28T14:00:00+00:00")
            )
            self.assertEqual(state["next_check"], "2026-10-27T13:00:00+00:00")
            self.assertEqual(state["next_label"], "Oct 27 at 13:00 (London [GMT])")
            self.assertEqual(state["display_timezone"], "Europe/London")
            for now, expected in [
                ("2026-08-28T14:00:00+00:00", "Sep 27 at 14:00 (London [BST])"),
                ("2026-10-28T14:00:00+00:00", "Nov 27 at 14:00 (London [GMT])"),
            ]:
                converted = snapshot(root, "2026-09-27", datetime.fromisoformat(now))
                self.assertEqual(converted["next_label"], expected)
                self.assertNotIn("New York", page_body(converted))
            self.assertEqual(state["cadence"], "monthly")
            self.assertNotIn("private-account", json.dumps(state))
            self.assertNotIn(folder, json.dumps(state))
            self.assertNotIn("rrule", json.dumps(state))
            save(root / "intake/source_policy.json", {"cadence": "fortnightly"})
            with self.assertRaisesRegex(ValueError, "different cadences"):
                snapshot(root, "2026-09-27")

    def test_tampered_check_cannot_be_presented_as_verified_history(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            summary = root / "logs/recurring/example/summary.json"
            save(
                summary,
                {
                    "started_at_utc": "2026-09-28T14:00:00Z",
                    "status": "unchanged_export",
                    "private": "private-account",
                },
            )
            save(
                summary.parent / "manifest.json",
                {"files": {"summary.json": digest(summary)}},
            )
            checks = verified_checks(root)
            self.assertEqual(checks[0]["label"], "No new export")
            self.assertNotIn("private-account", json.dumps(checks))
            summary.write_text(
                summary.read_text().replace("unchanged_export", "recurring_failed")
            )
            self.assertEqual(verified_checks(root), [])


if __name__ == "__main__":
    unittest.main()
