"""Recorded reviews must remain exact, grounded, and limited to their own evidence."""

import json
from pathlib import Path
import shutil
import tempfile
import unittest

from delivery.core import ROOT, latest, read
from delivery.render import RESOURCES, Renderer
from delivery.review_baseline import load


class ReviewBaselineTests(unittest.TestCase):
    def test_recorded_review_covers_every_current_item(self):
        run = latest()
        folder = load(run, RESOURCES)
        self.assertIsNotNone(folder)
        reviewed = read(folder / "editorial/review.json")["reviews"]
        expected = {c["candidate_id"] for c in read(run / "candidates.json")}
        expected.update(
            c["claim_id"] for c in Renderer(ROOT, run, ROOT / "_unused").claims
        )
        self.assertEqual({r["item_id"] for r in reviewed}, expected)
        self.assertEqual(len(reviewed), 32)
        status = read(folder / "editorial/status.json")
        self.assertEqual(
            status["review_dispositions"], {"pass": 15, "revise": 17, "withhold": 0}
        )
        curated = read(folder / "review-data.json")
        candidates = {c["candidate_id"]: c for c in curated["candidates"]}
        self.assertIn(
            "not been verified end to end",
            candidates["IT-C001"]["chart_configuration"]["compatibility"],
        )
        self.assertIn(
            "all-record annual denominator",
            candidates["IT-D003"]["chart_configuration"]["setting"],
        )
        self.assertTrue(
            all(
                "filter_instructions" in c["chart_configuration"]
                for c in candidates.values()
                if not c["candidate_id"].startswith("IT-P")
            )
        )
        historical = read(folder / "source-check/claim_refresh_report.json")
        self.assertEqual(
            historical["generated_at_utc"], "2026-10-01T15:51:08.568039+00:00"
        )
        self.assertEqual(historical["summary"]["present"], 52)
        self.assertEqual(historical["summary"]["app_source_unchanged"], 7)
        self.assertFalse(historical["summary"]["javascript_rendered_text_checked"])
        from delivery.core import digest

        for page in historical["pages"].values():
            self.assertEqual(
                digest(folder / "source-check" / page["raw_path"]), page["sha256"]
            )

    def test_changed_evidence_does_not_inherit_recorded_review(self):
        with tempfile.TemporaryDirectory() as directory:
            run = Path(directory)
            baseline = read(RESOURCES / "current-baseline/manifest.json")
            shutil.copy2(latest() / "run_metadata.json", run / "run_metadata.json")
            for name in baseline["binding"]["files"]:
                shutil.copy2(latest() / name, run / name)
            (run / "candidates.json").write_text("[]\n")
            self.assertIsNone(load(run, RESOURCES))

    def test_tampered_review_is_rejected_before_display(self):
        with tempfile.TemporaryDirectory() as directory:
            resources = Path(directory)
            shutil.copytree(
                RESOURCES / "current-baseline", resources / "current-baseline"
            )
            draft = resources / "current-baseline/editorial/draft.json"
            data = json.loads(draft.read_text())
            data["publication_authorized"] = True
            draft.write_text(json.dumps(data))
            with self.assertRaisesRegex(ValueError, "Recorded review evidence changed"):
                load(latest(), resources)


if __name__ == "__main__":
    unittest.main()
