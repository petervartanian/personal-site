"""Concise interface copy, leaving quotations and research artifacts intact."""

import html
import json
from pathlib import Path

REPLACEMENTS = {
    "A real 1,200-record export compared with September: added records and changed classifications.": "Compare September with an earlier 1,200-record export.",
    "Record 1607, zero-coded scores, validation evidence, and historical-snapshot limits.": "Classification problems that need Arcola’s attention.",
    "A severity-label patch, corrected presets, and replacement wording for 19 statements.": "Prepared fixes for the public tracker.",
    "Documented autonomy categories and the remaining behavior and severity questions.": "What the classification fields mean.",
    "Verified controls and detail windows, plus differences between the live mirror and the export.": "Results from testing the live tracker.",
    "The discovery process produced six additional candidates, beyond the five starting examples. These include behavior and autonomy fields that need supporting tables, as well as severity and subdomain comparisons.": "The search produced six additional candidates. The five starting examples remain available.",
    "The checks found the severity headline and preset defects, corrected the chart-menu inventory, and confirmed that Clear restores the national-security default threshold of 4 rather than an unfiltered view.": "The checks identified the defects described under Site corrections. They also confirmed that Clear restores the national-security threshold to 4. The chart inventory reflects the controls found during these checks.",
    "The local review dashboard has source, link, and content checks. Browser rendering of this redesigned local dashboard was unavailable; the live-site checks above concern the public tracker.": "Arcolens was checked in the in-app browser on September 29, 2026. The checks above concern the public tracker.",
    "Evidence, definitions, and source record": "Supporting evidence",
    "Evidence, sensitivity checks, and original caveats": "Supporting evidence",
    "Shared methods and limitations": "Methods",
    "The analysis maps 49 common fields and retains every changed ID and before-and-after value. It separates additions from changes within shared records. It does not fill absent modern fields with invented values.": "The comparison maps 49 common fields. Each change retains its incident ID and both values. Added records are listed separately. Fields absent from the older export remain missing.",
    "Mappings, counts and source hashes": "Comparison evidence",
    "Discovery and selection ledger": "Selection ledger",
    "The full ledger records screened-out, merged, withheld, and selected comparisons.": "The ledger records every selection decision.",
    "Limits and evidence": "Model limitations",
    "Model, record IDs, and checks": "Forecast evidence",
    "Historical snapshots and checksums": "Snapshot files",
    "Raw model records and earlier reviews are preserved.": "Review history is preserved.",
    "The daily 12-month curve passes through annual totals and continues through the 2026 observations. A vertical bar at December 31 spans the numerical year-end scenario range.": "The daily curve continues through the 2026 observations. At each December 31, its 12-month total equals the annual count. A shaded segment connects the latest point to the year-end range.",
    "The 2026 scenario ranges appear as vertical bars at year-end and in the methods table. They do not adjust for reporting delays or estimate all real-world incidents.": "Category-chart ranges show sensitivity to historical timing assumptions. They make no adjustment for reporting delays.",
    "Definitions resolved and still outstanding": "Field definitions",
    "Ready. The source-scope evidence and exclusion sensitivity are ready.": "Ready. The supporting diagnosis is complete.",
    "Ready. The patch, corrected presets, and replacements are prepared for application and final testing.": "Ready. The proposed fixes await testing by the maintainer.",
    "Diagnostic and limits": "Reference-check report",
    "Metrics, definitions and provenance": "Reference-check evidence",
    "Replacement text and evidence mapping": "Proposed corrections",
    "Candidate insights with suggested wording, chart settings, confidence, and caveats": "Candidate insight report",
    "Checks of published insights and proposed corrections": "Published-insight audit",
    "Chart configurations and display limits": "Chart settings",
    "Calculations and contributing incident IDs": "Calculation evidence",
}


def install(site: Path) -> dict[str, int]:
    """Edit current interface prose; do not rewrite archived or raw evidence pages."""
    changes = {}
    page_copy = json.loads(
        (Path(__file__).parent / "resources/review-ui-copy.json").read_text()
    )
    for path in site.glob("*.html"):
        text = path.read_text()
        count = 0
        if path.name not in {
            "model-review.html",
            "source-check.html",
        } and not path.name.startswith("evidence-"):
            for old, new in REPLACEMENTS.items():
                count += text.count(old)
                text = text.replace(old, new)
        # Exact passages on named current pages only. The archived presentation,
        # source quotations, raw model reviews, and research files stay intact.
        for old, new in page_copy.get(path.name, {}).items():
            for source, replacement in dict(
                [(old, new), (html.escape(old), html.escape(new))]
            ).items():
                count += text.count(source)
                text = text.replace(source, replacement)
        if count:
            path.write_text(text)
            changes[path.name] = count
    return changes
