"""Connect a successful monthly check to a fresh private dashboard deployment."""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .core import ROOT, digest, latest, read, save


def verify_editorial(cycle: Path, run: Path, context: Path | None = None) -> None:
    from tracker.editorial import (
        EditorialDraft,
        EditorialReview,
        evidence_payload,
        validate_draft,
        validate_review,
    )
    from tracker.editorial_adoption import _manifest

    _manifest(cycle, cycle / "manifest.json")
    status = read(cycle / "status.json")
    if status.get("status") != "completed_requires_human_review":
        raise ValueError("No completed independent review for this exact run.")
    rebound = False
    if status.get("run_id") != run.name:
        from tracker.editorial_adoption import ADOPTED, verify_adoption_record

        adoption_path = run.parent.parent / "LATEST_EDITORIAL_ADOPTION.json"
        if not adoption_path.is_file():
            raise ValueError("No completed independent review for this exact run.")
        adoption = verify_adoption_record(read(adoption_path), run)
        if (
            adoption.get("status") != ADOPTED
            or Path(adoption.get("paths", {}).get("cycle", "")).resolve()
            != cycle.resolve()
        ):
            raise ValueError(
                "No verified equivalent-evidence adoption for this review."
            )
        rebound = True
    evidence = read(cycle / "evidence.json")
    expected = evidence_payload(run, context)
    if rebound:
        # The independent adoption verifier checked both immutable runs, all
        # requests/responses, and exact evidence equality except the run ID.
        expected["run_id"] = evidence["run_id"]
    if evidence != expected:
        raise ValueError("Recorded model evidence does not match this run.")
    draft = EditorialDraft.model_validate(read(cycle / "draft.json"))
    review = EditorialReview.model_validate(read(cycle / "review.json"))
    if not validate_draft(draft, evidence, digest(cycle / "evidence.json"))[
        "all_grounded"
    ]:
        raise ValueError("Draft numeric checks failed.")
    if not validate_review(
        review, evidence, digest(cycle / "evidence.json"), digest(cycle / "draft.json")
    )["all_grounded"]:
        raise ValueError("Independent review checks failed.")


def deliver(
    report: dict[str, Any], config: Path, root: Path = ROOT, dry_run: bool = False
) -> dict[str, Any]:
    if report.get("exit_code") != 0:
        return {
            "status": "held_after_failed_check",
            "check_status": report.get("status"),
            "published": False,
        }
    if not report.get("analysis_invoked"):
        return {"status": "unchanged_no_publication", "published": False}
    if (
        report.get("status") != "completed_requires_human_review"
        or report.get("website_refresh_ok") is not True
    ):
        raise ValueError("The recurring check did not complete all required stages.")
    run = latest(root)
    if (
        Path(report["analysis_run"]).resolve() != run.resolve()
        or read(run / "run_metadata.json")["input"]["sha256"]
        != report["selected_input"]["sha256"]
    ):
        raise ValueError(
            "The completed check and current analysis refer to different inputs."
        )
    cycle = Path(report["editorial_output"])
    context = (
        Path(report["context"]["path"])
        if report.get("context", {}).get("status") == "matched"
        else None
    )
    verify_editorial(cycle, run, context)
    from .package import create
    from .render import build
    from .publish import publish

    package = root / "dist/arcolens-runner.zip"
    create(package, root)
    output = (
        root
        / "deliveries"
        / (datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ") + "-" + run.name)
    )
    build(
        run,
        output,
        package,
        root,
        cycle,
        Path(report["output"]) / "claim_refresh",
        context,
    )
    result = publish(output, config, dry_run)
    save(
        root / "LATEST_DELIVERY.json",
        {
            "path": str(output),
            "run_id": run.name,
            "manifest_sha256": digest(output / "DELIVERY_MANIFEST.json"),
            "publication": result,
        },
    )
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--downloads", type=Path, default=Path.home() / "Downloads")
    parser.add_argument("--inbox", type=Path, action="append", default=[])
    parser.add_argument("--context", type=Path)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--completed-check", type=Path)
    args = parser.parse_args()
    if args.completed_check:
        report = read(args.completed_check)
    else:
        from scripts.check_monthly import check_monthly

        report = check_monthly(ROOT, args.downloads, args.inbox, context=args.context)
    result = deliver(report, args.config, dry_run=args.dry_run)
    # Keep delivery results outside the original check's immutable execution manifest.
    save(
        ROOT / "logs/delivery-results" / (Path(report["output"]).name + ".json"), result
    )
    print(json.dumps({"check_status": report["status"], "delivery": result}, indent=2))
    raise SystemExit(report.get("exit_code", 2))


if __name__ == "__main__":
    main()
