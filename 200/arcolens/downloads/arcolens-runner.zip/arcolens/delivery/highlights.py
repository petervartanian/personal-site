"""Short dashboard findings derived from the current delivery's evidence."""

from __future__ import annotations

import html
from typing import Any

from .focused_review import source_html


def panel(data: dict[str, Any]) -> str:
    e = html.escape
    items = {i["id"]: i for i in data["items"] if i["kind"] == "candidate"}
    selected = [item for item in items.values() if item.get("selected")]
    if selected:
        selected.sort(key=lambda item: item.get("priority_order", 99))
        rows = "".join(
            '<div class="insight-row selected-insight"><div><h3><a href="'
            + e(item["page"])
            + '">'
            + e(item["title"])
            + "</a></h3><p>"
            + e(item.get("summary") or item["wording"])
            + '</p><p class="selected-limit">'
            + e(item.get("key_limitation", ""))
            + "</p>"
            + (source_html(item["source_pages"]) if item.get("source_pages") else "")
            + "</div></div>"
            for item in selected
        )
        return (
            '<section class="insight-overview" aria-labelledby="insight-title">'
            '<div class="insight-heading"><h2 id="insight-title">Top findings</h2><a href="candidates.html">All '
            + str(len(items))
            + "</a></div>"
            + rows
            + "</section>"
        )
    measures = data["measures"]
    rows: list[tuple[str, str, str]] = []
    series = data["annual"].get("IT-C002", {}).get("points", [])
    if "IT-C002" in items and len(series) > 1:
        first, last = series[0], series[-1]
        if first["percent"] is not None and last["percent"] is not None:
            rows.append(
                (
                    "IT-C002",
                    f'Capability or robustness: {first["percent"]:.2f}% to {last["percent"]:.2f}%',
                    f'Of records dated {first["year"]}, {first["numerator"]:,} of {first["denominator"]:,} had this primary classification; '
                    f'in {last["year"]}, {last["numerator"]:,} of {last["denominator"]:,} did.',
                )
            )
    rank = measures.get("candidate.IT-C003.variant0.rank1")
    runner_up = measures.get("candidate.IT-C003.variant0.rank2")
    if "IT-C003" in items and rank and rank.get("percent") is not None:
        purpose = rank["definition"]["target"]["equals"]["ai_goal_primary"][0]
        wording = f'{rank["numerator"]:,} of {rank["denominator"]:,} records ({rank["percent"]:.1f}%), across all dates.'
        if runner_up:
            other = runner_up["definition"]["target"]["equals"]["ai_goal_primary"][0]
            wording += f' {other} follows with {runner_up["numerator"]:,} ({runner_up["percent"]:.1f}%).'
        title = (
            f"{purpose}: the most frequent primary purpose"
            if not runner_up or rank["numerator"] > runner_up["numerator"]
            else f"{purpose}: tied for the most frequent primary purpose"
        )
        rows.append(("IT-C003", title, wording))
    fraud = measures.get("candidate.IT-C004.primary")
    if "IT-C004" in items and fraud and fraud.get("percent") is not None:
        window = fraud["window"]
        start, end = window["requested_min_year"], window["requested_max_year"]
        rows.append(
            (
                "IT-C004",
                f'Fraud, scams, and targeted manipulation: {fraud["percent"]:.1f}% within the malicious-actor domain',
                f'{fraud["numerator"]:,} of {fraud["denominator"]:,} records dated {start}–{end}, using primary classifications.',
            )
        )
    if not rows:
        rows = [(i["id"], i["title"], i["wording"]) for i in list(items.values())[:3]]
    if not rows:
        return ""
    body = "".join(
        f'<a class="insight-row" href="{e(items[key]["page"])}"><div><h3>{e(title)}</h3><p>{e(wording)}</p></div>'
        '<span class="insight-arrow" aria-hidden="true">→</span></a>'
        for key, title, wording in rows
    )
    return (
        '<section class="insight-overview" aria-labelledby="insight-title">'
        '<div class="insight-heading"><h2 id="insight-title">Top findings</h2>'
        f'<a href="candidates.html">All {len(items)}</a></div>{body}</section>'
    )
