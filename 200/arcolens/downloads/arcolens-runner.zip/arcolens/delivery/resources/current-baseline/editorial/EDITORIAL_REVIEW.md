# Model drafting and independent review



Source run: `20260928T040513138055Z-fbdc9a5f21b9`.



Publication is not authorized. This is an editorial review against supplied calculations, not validation of source classifications.



## IT-C001



In the September 27, 2026 export, annual incident-record counts rose each year from 2021 through 2025: 80, 108, 179, 304, and 452, respectively. Each count includes all records dated that year. These database counts may reflect changes in reporting and coverage; they do not measure population incidence.



Independent review: **revise**

Complete-year counts reproduce: 80, 108, 179, 304, 452 for 2021 through 2025 (candidate.IT-C001.counts.2021 to .2025), each equal to its dated cohort, undated_count 0, includes_incomplete_year false. The strict increase holds inside the window. The robustness row candidate.IT-C001.sensitivity2.2020 shows 92 records dated 2020, more than the 80 dated 2021, so 2021 is a local low and the window start shapes the story. Gemini-only counts (sensitivity4: 80, 105, 170, 299, 447) and the exclude-#353 variant (sensitivity3) remain monotone. Partial 2026 is 231 records through 2026-09-25 (partial_current_year) and is correctly kept out.

C01 stacked by domain in counts with a host preset of exact years 2021 to 2025 portrays the totals only if all seven domains stay visible and segments are summed. The ordinary Year >= control cannot exclude 2026, so the preset or a table is required. Live totals match the export but classifications differ (SITE-MIRROR-DIFFERENCE), so chart readings are not export figures.

Bounded to the export and to record counts, with an incidence disclaimer. It omits that 2020 exceeded 2021, which invites reading the five-year rise as the origin of a longer trend. 'rose each year' is accurate for the stated window.

- Draft drops the 2020 robustness row (92 records) that the source run carried; without it the 2021 start reads as a trend origin.

- Draft evidence list omits candidate.IT-C001.sensitivity2.2020 and the partial-year row that justify the window choice.

- Per-year multi-occurrence record counts quoted in the source caveats have no calculation IDs and must not be published.

Reviewer proposed wording: In the September 27, 2026 export, the number of incident records dated in each year rose from 80 in 2021 to 108 in 2022, 179 in 2023, 304 in 2024 and 452 in 2025. The preceding year, 2020, had 92 records, so 2021 is a local low rather than the start of a longer series. These counts describe records in this database and may reflect changes in reporting and coverage; they do not measure how often AI incidents occur.



## IT-C002



In the September 27, 2026 export, the share of incident records primarily classified as “7.3 Lack of capability or robustness” fell each year from 2021 through 2025, from 33 of 80 (41.2%) to 45 of 452 (10.0%). The count increased from 33 to 45 as other categories grew faster. The lower recorded share does not establish that AI became more robust or safer.



Independent review: **pass**

Primary 7.3 shares reproduce and fall strictly: 33/80 (41.25%), 33/108 (30.6%), 37/179 (20.7%), 44/304 (14.5%), 45/452 (10.0%) (candidate.IT-C002.primary.2021 to .2025). Counts are 33, 33, 37, 44, 45, flat from 2021 to 2022, so 'increased from 33 to 45' is an endpoint statement. The decline survives every supplied variant: any-label incident share 66.25% to 26.8% (sensitivity0), assignment share 31.0% to 13.5% (sensitivity1), gemini-only 41.25% to 10.1% (sensitivity6), severity-restricted populations (sensitivity8, sensitivity9), and removal of domain 4 from the population 44.6% to 22.8% (sensitivity10). Within primary domain 7, 7.3 is 94% to 100% of records every year (sensitivity3), so the headline decline is the decline of domain 7's share of all records. 'Other categories grew faster' is supported by growth rows, chiefly 4.3 from 3 to 192 (growth.4.3.2021, growth.4.3.2025).

C02 primary-subdomain proportions with a host preset of exact years 2021 to 2025 and all series visible is faithful; filtering to 7.3 or hiding series changes the denominator. The 'All Subdomains' proportion view shows assignment shares (sensitivity1), a different quantity that must not be presented as the headline. Live values differ from the export.

Bounded and correct; share and count directions are stated separately and robustness improvement is disclaimed. The source's statement that 2021 is a local maximum of the longer 7.3 series is not backed by a supplied calculation and should not be added without one.

- No supplied calculation covers 7.3 shares before 2021; the local-maximum caveat is unverified here.

- Counts were flat 33 to 33 between 2021 and 2022; 'increased' applies to endpoints only.

- 33/80 is exactly 41.25%; the draft's 41.2% follows round-half-even, which differs from 41.3% under half-up.

Reviewer proposed wording: Among incident records dated 2021 to 2025 in the September 27, 2026 export, the share whose primary subdomain is '7.3 Lack of capability or robustness' fell every year, from 33 of 80 (41.25%) in 2021 to 45 of 452 (10.0%) in 2025, while the number of such records went from 33 to 45. The share fell because other categories grew faster, chiefly '4.3 Fraud, scams, and targeted manipulation' (3 records in 2021, 192 in 2025); it is not evidence that AI systems became more robust.



## IT-C003



Among 1,698 incident records dated September 26, 1983–September 25, 2026 in the September 27 export, “Deepfake Video Generation” is the most frequent single primary-purpose tag: 316 records (18.6%), followed by “Chatbot”: 181 (10.7%). This is a plurality, not a majority. The chart's “Other” slice combines multiple less frequent purposes.



Independent review: **pass**

Primary-purpose ranking reproduces: Deepfake Video Generation 316/1,698 (18.6%), Chatbot 181 (10.7%), Deepfake Image Generation 135 (8.0%), Writing Assistant 122 (7.2%), Autonomous Driving 115 (6.8%) (candidate.IT-C003.variant0.rank1 to rank5). The leader is stable through 2025 (variant1: 274/1,467), for 2021 to 2025 (variant2: 265/1,123), gemini-only (variant3), exclude-#353 (variant4), known-field (variant5) and 2026 year-to-date (variant6: 42/231, where Deepfake Image Generation with 33 passes Chatbot with 26). Under primary-or-secondary scope the order changes: Deepfake Video Generation 364, Voice Generation 329, Chatbot 223 (secondary0 to secondary2), so 'followed by Chatbot' holds for primary tags only, which the draft states. Plurality, not majority, is correct.

C03 pie stacked by aiGoal with every slice visible, including Other, is faithful for primary-purpose composition over all dates. The source's 394-record size for the Other slice has no supplied calculation ID and the draft rightly omits it. The denominator 1,698 belongs in the caption because tooltips show only numerators. Live pie values differ from the export.

Accurate and scoped to 'single primary-purpose tag'. Analyst lumpings quoted in the source caveats (362, 556) are not supplied calculations and should not be quoted.

- Under primary-or-secondary scope Voice Generation (329) outranks Chatbot (223); keep the primary-only scope explicit wherever the ranking is repeated.

- In 2026 year-to-date records Chatbot falls to third; the all-dates ranking is not current-year composition.

- The Other slice size and lumping totals lack calculation IDs and must not appear in copy.

Reviewer proposed wording: Among the 1,698 incident records in the September 27, 2026 export (dated September 26, 1983 to September 25, 2026), the most frequent single primary-purpose tag is 'Deepfake Video Generation', on 316 records (18.6%), followed by 'Chatbot' on 181 (10.7%). This is a plurality, not a majority. The chart's 'Other' slice combines several less frequent purposes and is not itself a purpose.



## IT-C004



In the September 27, 2026 export, 368 of 535 incident records (68.8%) dated 2016–2025 and primarily classified as “4 Malicious actors” have primary subdomain “4.3 Fraud, scams and targeted manipulation.” The within-domain share was 71 of 122 (58.2%) for 2016–2023 and 297 of 413 (71.9%) for 2024–2025.



Independent review: **pass**

368/535 (68.8%) reproduces (candidate.IT-C004.primary), as do the pooled sub-periods 71/122 (58.2%) for 2016 to 2023 (sensitivity7) and 297/413 (71.9%) for 2024 to 2025 (sensitivity8); the parts sum to the whole (122 + 413 = 535; 71 + 297 = 368). Variants stay near 69%: all dates 440/641 (68.6%, sensitivity0), 2021 to 2025 351/506 (69.4%, sensitivity1), gemini-only 359/523 (68.6%, sensitivity5), exclude-#353 unchanged (sensitivity4), known-field unchanged (sensitivity6), 2026 year-to-date 70/104 (67.3%, sensitivity9). Any-label 4.3 within the primary domain gives 404/535 (75.5%, sensitivity2) and any-domain plus any-label gives 468/621 (75.4%, sensitivity3), so the primary-within-primary definition is the conservative one and must be named.

C04 with Domain = 4 Malicious actors, exact Year 2016 to 2025 and Primary Subdomain stacking in counts shows the 4.3 segment against the domain total; the percentage has to be a caption because C04 has no visible proportions toggle. The site check confirms C04's menu lacks All Subdomains, so any-label figures cannot be shown there. Live values differ from the export.

Precise: 'primarily classified as' and 'primary subdomain' are both stated, the window is closed, and the pooled comparison is labeled. Subdomain punctuation should match the taxonomy string '4.3 Fraud, scams, and targeted manipulation'.

- 2024 to 2025 supplies 413 of 535 records, so the headline is dominated by two years; the draft says so.

- Any-label definitions give about 75%; a silent scope change would move the figure seven points.

- Minor punctuation mismatch with the taxonomy label.

Reviewer proposed wording: In the September 27, 2026 export, 368 of the 535 incident records dated 2016 to 2025 and primarily classified as '4 Malicious actors' (68.8%) have the primary subdomain '4.3 Fraud, scams, and targeted manipulation'. The within-domain share was 71 of 122 (58.2%) for records dated 2016 to 2023 and 297 of 413 (71.9%) for 2024 to 2025.



## IT-C005



In the September 27, 2026 export, among 1,698 records dated September 26, 1983–September 25, 2026, 90 (5.3%) have a direct severity score of at least 4 in the original ten harm dimensions. Including indirect scores yields 148 (8.7%); also including model-inferred scores yields 286 (16.8%). These are alternative counts of records, not additive harm totals. Inferred assessments do not verify that severe harm occurred.



Independent review: **revise**

Ten-dimension lower-bound counts reproduce: direct 90/1,698 (5.3%), direct plus indirect 148 (8.7%), all channels 286 (16.8%) (candidate.IT-C005.10.direct.lower_bound, .10.direct+indirect.lower_bound, .10.direct+indirect+inferred.lower_bound). Upper bounds are 92, 150 and 288 (.upper_bound rows); the draft quotes bounds only for the second and third. Thirteen-dimension figures 111, 177, 376 and bounds 113, 179, 378 reproduce. Inferred-only crossings 138 equal 286 minus 148 (inferred_only_crossings). Excluding the two zero-coded records (#413, #1607) leaves 148/1,696 and 286/1,696 (variant12); through 2025 the counts are 138/1,467 and 271/1,467 (variant13); gemini-only 145/1,655 and 281/1,655 (variant14). 286 equals the export scalar highest_severity_10 >= 4 and 376 equals highest_severity >= 4 (export_highest_severity_10_ge4, export_highest_severity_ge4); no exported scalar yields 148 or 90. The headline field exceeds the direct maximum for 782/1,698 records (46.1%) (headline_exceeds_direct_maximum).

No live aggregate control reproduces any of these counts. The timeline severe-harm preset sends an ignored minSeverity key, and the effective minSeverityHighest=4 selects the inferred-inclusive thirteen-dimension headline (SITE-SEVERITY-PRESET), which on this export is 376, not 148 or 286. The incident detail labels that headline as direct-only (SITE-SEVERITY-LABEL). C05 shows one incident's direct and indirect series only. A supporting table is the only faithful display, as the draft says.

The nested-count structure and 'not additive' statement are correct. The publishable sentence gives the direct-only figure without its upper bound while the caveat bounds the other two, which reads as if 90 were exact. 'at least 4' is preferable to 'severe' unless the rubric level is cited.

- Direct-only count lacks its 90 to 92 bound in the wording and its upper-bound row in evidence_ids.

- Zero-coded scores remain of undefined meaning (ZERO-SEVERITY); every threshold count needs its bound.

- Thresholds are ordinal rubric levels; the three added dimensions have no supplied threshold definitions.

Reviewer proposed wording: In the September 27, 2026 export of 1,698 records dated September 26, 1983 to September 25, 2026, 90 records (5.3%) have a directly reported severity score of at least 4 in one of the original ten harm dimensions; counting indirect scores as well gives 148 (8.7%), and counting model-inferred scores too gives 286 (16.8%). Two records carry zero-coded scores of undefined meaning, so the corresponding upper bounds are 92, 150 and 288. These are alternative counts of the same records under different evidence channels, not additive totals, and inferred scores do not verify that the harm occurred.



## IT-D001



In the September 27, 2026 export, 128 of 141 incident records (90.8%) dated 2011–2025 and primarily classified as “3 Misinformation” have primary subdomain “3.1 False or misleading information.” This percentage describes records within that primary domain.



Independent review: **pass**

128/141 (90.8%) reproduces (discovery.d5642ae3bc.base; records dated through 2025, observed 2011-04-05 to 2025-12-31). The C04 window 2016 to 2025 gives 127/140 (90.7%) (7c4bf965f2; first observed domain-3 record 2017-07-01). Variants: all dates including 2026 151/165 (91.5%, fb5b9ebd33), 2021 to 2025 126/135 (93.3%, 9c7c8d5bd6), exclude-#353 unchanged (10ab0db203), gemini-only 124/137 (90.5%, 461cda1401), any-label 3.1 within primary domain 3 129/141 (91.5%, 50d382ec39), 2026 year-to-date 23/24 (272fa82e7c). The concentration is stable across definitions.

C04 with Domain = 3 Misinformation, exact Year 2016 to 2025 and Primary Subdomain stacking displays 127/140, not the 128/141 headline; the draft labels both. No proportions toggle, so the percentage is a caption. Live values differ.

Correct conditional framing. 'dated 2011 to 2025' describes the observed range rather than a chosen floor; 'dated through 2025' matches the definition. High concentration may reflect how the classifier uses domain 3's sibling subdomains, which the caveat covers.

- Describe the window as 'through 2025' rather than implying a 2011 floor.

- No calculation shows the sibling-subdomain distribution, so the taxonomy-use explanation is plausible but untested.

Reviewer proposed wording: In the September 27, 2026 export, 128 of the 141 incident records dated through 2025 and primarily classified as '3 Misinformation' (90.8%) have the primary subdomain '3.1 False or misleading information'. On the overview bar chart, which starts at 2016, the figure is 127 of 140 (90.7%).



## IT-D002



In the September 27, 2026 export, the share of incident records with a direct or indirect severity score of at least 3 in any original ten harm dimensions fell each year during 2021–2025, from 35 of 80 (43.8%) to 90 of 452 (19.9%). The qualifying count rose from 35 to 90. Inferred scores are excluded. A lower recorded share does not establish safer AI.



Independent review: **pass**

Annual shares reproduce and fall strictly: 35/80 (43.75%), 36/108 (33.3%), 53/179 (29.6%), 86/304 (28.3%), 90/452 (19.9%) (discovery.a9dfb24f8c.annual.2021 to .2025). The 2023 to 2024 step is 1.3 points and would reverse if about five more 2024 records qualified, so 'fell each year' rests on a thin middle step. Gemini-only (461cda1401: 43.75, 32.4, 30.0, 28.1, 19.7) and exclude-#353 (10ab0db203) variants stay monotone; 2026 year-to-date is 41/231 (17.7%). Denominators are full annual cohorts. No supplied calculation gives the inferred-inclusive or thirteen-dimension annual series, so robustness to channel choice is unverified even though the source says such variants exist.

No aggregate chart matches direct-or-indirect >= 3 across the original ten dimensions. The live severe-harm preset selects an inferred-inclusive headline (SITE-SEVERITY-PRESET) and cannot reproduce this series. A supporting table is the right vehicle and the draft uses one.

Definition stated, inferred channels explicitly excluded, safety disclaimer present. 'in any original ten harm dimensions' should read 'in any of the original ten harm dimensions'. Printing the annual series next to 'fell each year' lets readers see the small 2023 to 2024 step.

- 2023 to 2024 decline is 1.3 points, within a handful of records.

- Inferred-inclusive and thirteen-dimension annual variants are absent from the supplied calculations.

- Zero-coded severity semantics are unresolved; the lower-bound policy should be named in published text.

Reviewer proposed wording: In the September 27, 2026 export, the share of incident records with a reported direct or indirect severity score of at least 3 in any of the original ten harm dimensions was 35 of 80 (43.75%) in 2021, 36 of 108 (33.3%) in 2022, 53 of 179 (29.6%) in 2023, 86 of 304 (28.3%) in 2024 and 90 of 452 (19.9%) in 2025. The count of such records rose from 35 to 90. Model-inferred scores are excluded, and zero or missing components are treated as not qualifying. A lower recorded share does not show that AI became safer.



## IT-D003



In the September 27, 2026 export, the share of incident records tagged “Tool” for behavior type rose each year from 2021 through 2025, from 19 of 80 (23.8%) to 256 of 452 (56.6%). Each denominator includes all records dated that year. The pattern describes database annotations and may reflect changes in reporting and coverage.



Independent review: **revise**

Annual shares reproduce: 19/80 (23.75%), 36/108 (33.3%), 96/179 (53.6%), 171/304 (56.25%), 256/452 (56.6%) (discovery.452c9459ca.annual.2021 to .2025). The 2024 to 2025 step is 0.4 points; two fewer qualifying 2025 records would reverse it, so the series plateaus after 2023 rather than rising. Known-only denominators (78, 105, 174, 298, 444) give 24.4, 34.3, 55.2, 57.4, 57.7% (known.2021 to .2025), a 0.3-point last step; gemini-only goes 55.9% to 56.8% (461cda1401.2024, .2025). Exclude-#353 is unchanged. 2026 year-to-date is 107/231 (46.3%), below both 2024 and 2025.

Behavior type is not a chart grouping; table-only presentation is correct.

'rose each year' is literally true and misleading: nearly all of the rise happened between 2021 and 2023, and 2024 to 2025 are flat within rounding. The supplied evidence never defines the 'Tool' tag, so readers cannot interpret the finding.

- Final step is 0.4 points; the wording implies continuing growth.

- The behavior-type 'Tool' definition is not supplied.

- 2026 year-to-date (46.3%) is below 2025; context only, but it cuts against a rising narrative.

Reviewer proposed wording: In the September 27, 2026 export, the share of incident records tagged 'Tool' for behavior type rose from 19 of 80 (23.75%) in 2021 to 96 of 179 (53.6%) in 2023 and was then roughly flat: 171 of 304 (56.25%) in 2024 and 256 of 452 (56.6%) in 2025. These are automated tags in this database and may reflect changes in reporting and coverage.



## IT-D004



In the September 27, 2026 export, the share of all incident records tagged “Human-controlled” in the national-security autonomy field rose each year during 2021–2025, from 19 of 80 (23.8%) to 349 of 452 (77.2%). These denominators include all records dated each year, regardless of national-security score. The figures describe recorded classifications, not the distribution or safety of deployed AI systems.



Independent review: **pass**

Annual shares reproduce and rise strictly: 19/80 (23.75%), 42/108 (38.9%), 113/179 (63.1%), 201/304 (66.1%), 349/452 (77.2%) (discovery.637e47bb95.annual.2021 to .2025); the smallest step is 3.0 points (2023 to 2024). Known-only denominators equal the full cohorts (known.2021 to .2025), so the field is populated for every record. Gemini-only (461cda1401) and exclude-#353 (10ab0db203) variants are monotone. Distribution rows show the complement: Human-supervised fell from 42/80 (52.5%) to 64/452 (14.2%) and Full autonomy from 19/80 (23.75%) to 39/452 (8.6%) (dist.2021.*, dist.2025.*). 2026 year-to-date is 148/231 (64.1%).

Not a chart grouping; table-only presentation is correct.

Bounded; correctly states that the denominator is all records rather than a national-security subset. Reporting one category in isolation hides that the shift is mainly from Human-supervised to Human-controlled. The tag's meaning is not defined in supplied evidence.

- One-category framing; the three-way distribution makes the shift interpretable.

- Tag semantics undefined; not a measure of oversight quality.

Reviewer proposed wording: In the September 27, 2026 export, the share of all incident records tagged 'Human-controlled' in the national-security autonomy field rose each year, from 19 of 80 (23.75%) in 2021 to 349 of 452 (77.2%) in 2025, while 'Human-supervised' fell from 42 of 80 (52.5%) to 64 of 452 (14.2%) and 'Full autonomy' from 19 of 80 (23.75%) to 39 of 452 (8.6%). These are automated tags describing this database, not measures of how deployed systems are overseen.



## IT-D005



In the September 27, 2026 export, 53 of 60 incident records (88.3%) dated 2012–2025 and primarily classified as “5 Human-Computer Interaction” have primary subdomain “5.1 Overreliance and unsafe use.” This is a share within the selected primary domain.



Independent review: **pass**

53/60 (88.3%) reproduces (discovery.0b6342a068.base; observed 2012-12-10 to 2025-11-10). The C04 window 2016 to 2025 gives 52/56 (92.9%) (7c4bf965f2). Variants: all dates 61/69 (88.4%, fb5b9ebd33), 2021 to 2025 42/43 (97.7%, 9c7c8d5bd6), exclude-#353 52/59 (88.1%, 10ab0db203), gemini-only 53/60 (461cda1401), any-label 53/60 (8cd96f4ebf), 2026 year-to-date 8/9 (272fa82e7c). Three of the seven non-5.1 records are dated before 2016, which is why the chart window reads higher.

C04 with Domain = 5 Human-Computer Interaction, exact Year 2016 to 2025 and Primary Subdomain in counts shows 52/56, not the headline; the draft labels both. No proportions toggle.

Correct conditional framing with a small-group caveat. Prefer 'dated through 2025' to 'dated 2012 to 2025'.

- Denominator of 60; a few reclassifications move the percentage several points.

- Excluding #353 changes the numerator, confirming the probable duplicate record sits in this cell.

Reviewer proposed wording: In the September 27, 2026 export, 53 of the 60 incident records dated through 2025 and primarily classified as '5 Human-Computer Interaction' (88.3%) have the primary subdomain '5.1 Overreliance and unsafe use'. On the overview bar chart, which starts at 2016, the figure is 52 of 56 (92.9%). The group is small.



## IT-D006



In the September 27, 2026 export, the share of incident records primarily classified as “3.1 False or misleading information” increased from 1 of 80 (1.2%) in 2021 to 63 of 452 (13.9%) in 2025. The share dipped in 2024, so it did not rise every year. These figures describe selected database records and may reflect changes in reporting and coverage.



Independent review: **pass**

Annual shares reproduce: 1/80 (1.25%), 9/108 (8.3%), 21/179 (11.7%), 32/304 (10.5%), 63/452 (13.9%) (discovery.87a856248f.annual.2021 to .2025); the 2024 dip of 1.2 points is real. Gemini-only: 1/80, 9/105, 20/170, 32/299, 60/447 (461cda1401), same shape. Exclude-#353 unchanged. 2026 year-to-date 23/231 (10.0%). The 2021 numerator is a single record.

C02 primary-subdomain proportions with an exact-year preset and all series visible is faithful; do not filter to 3.1.

Honest about the 2024 dip and the one-record baseline. '1.2%' for 1/80 reflects round-half-even; 1.25% avoids the ambiguity. Relative-growth phrasing should stay out given the baseline.

- 1/80 is exactly 1.25%; '1.2%' depends on rounding convention.

- One-record 2021 baseline; the endpoint comparison is sensitive to a single classification.

- 2026 year-to-date (10.0%) is below 2025; context only.

Reviewer proposed wording: In the September 27, 2026 export, the share of incident records primarily classified as '3.1 False or misleading information' was 1 of 80 (1.25%) in 2021, 9 of 108 (8.3%) in 2022, 21 of 179 (11.7%) in 2023, 32 of 304 (10.5%) in 2024 and 63 of 452 (13.9%) in 2025. The 2021 figure rests on a single record. These are automated classifications of records in this database and may reflect changes in reporting and coverage.



## IT-P001



In the September 27, 2026 export, covering records dated September 26, 1983–September 25, 2026, 1,220 of 1,698 records (71.8%) contain at least one non-placeholder potential-cause annotation in each of the six diagram categories. Empty and N/A placeholders are excluded. These are model-proposed explanations within a prompted framework; their presence does not establish six verified causes per incident.



Independent review: **pass**

All-six coverage 1,220/1,698 (71.8%) reproduces (profile.causes.all_six). Per-category coverage: Technology 1,698 (100%), Process and Methods 1,686 (99.3%), Human Factors 1,676 (98.7%), Data Inputs 1,604 (94.5%), Management 1,555 (91.6%), Regulatory Environment 1,364 (80.3%) (category0 to category5); Regulatory Environment binds, and all-six cannot exceed it. All 1,698 records parse (parseable). Excluding #353 gives 1,219/1,697; excluding #1607 gives 1,220/1,697 (sensitivity0, sensitivity1).

C06 shows one incident's six branches and cannot show coverage; a table is required. Incident 1's example annotations are illustrative, and live annotations may differ.

Correctly frames the result as annotation coverage inside a prompted six-category template, not causes. Technology at 100% is worth stating because it shows the template, not the incidents, drives coverage.

- Coverage is a property of the prompt template; present it as a data-quality note rather than an insight.

- Non-placeholder detection excludes empty and N/A only; annotation validity is unchecked.

Reviewer proposed wording: In the September 27, 2026 export, 1,220 of 1,698 records (71.8%) carry at least one non-placeholder potential-cause annotation in every one of the six diagram categories; every record has a Technology annotation, and Regulatory Environment is the least covered category (1,364 records, 80.3%). These are model-proposed explanations produced within a prompted six-category template, not verified causes.



## IT-P002



In the September 27, 2026 export, among 32 records dated September 26, 1983–September 18, 2026 with overall national-security scores of at least 4, 17 (53.1%) also scored at least 4 for information warfare and intelligence security, compared with 13 (40.6%) for societal stability and human rights. These overlapping, model-assigned categories describe a small selected group, not population risk.



Independent review: **revise**

At overall >= 4 the group is 32 records; axis counts at >= 4 are information 17 (53.1%), societal 13 (40.6%), sovereignty 10 (31.3%), physical 9 (28.1%), economic 1 (3.1%) (profile.natsec.threshold4.*). At >= 3 (271 records) information leads 175 (64.6%) to societal 138 (50.9%) (threshold3.*). At >= 5 only 3 records qualify and the order reverses: societal 3 of 3, physical 1, information 0 (threshold5.*). Through 2025 the group is 30 with information 16 and societal 12 (sensitivity2.*); excluding #353 and #1607 changes nothing (sensitivity3.*). The 17-versus-13 gap is four records.

C07 radar shows one incident (544) and cannot show the comparison; a table is required. Axes are ordinal 1 to 5; radar area is not a quantity.

Bounded to a small selected group with overlapping categories. The chart block mixes decimal precision (31.25%, 28.1%, 3.125%). The threshold-5 reversal is the strongest caveat and belongs in the wording.

- Inconsistent rounding in the supporting figures.

- Threshold-5 reversal (3 records, all societal) appears only in evidence, not in the wording.

- Group of 32 with a four-record gap; do not describe information as 'leading' without the threshold qualifier.

Reviewer proposed wording: In the September 27, 2026 export, 32 records have an overall national-security score of at least 4. Of these, 17 (53.1%) score at least 4 for information warfare and intelligence security and 13 (40.6%) for societal stability and human rights; the categories overlap. Only 3 records score 5 overall, and all 3 score 5 on societal stability. These are model-assigned ordinal scores within a small, selectively reported group, not estimates of national-security risk.



## Published statements



### HOME-01: revise

The export holds 1,698 unique incident records (claim.HOME-01.size); the static page text says 1,600, a shortfall of 98. Supplied context reports a headless render showing 1,697 on 2026-09-27 and the mirror at 1,698 on 2026-09-28 (SITE-MIRROR-DIFFERENCE); those renders were not repeated here. The ID-prefix proxy dating 1,600 to about July 2026 is unverified and not needed for the correction.

Not chart-based. The static fallback and any live counter should carry the same 'as of' date.

'1,600 real-world report incidents' is stale and mixes units: the tracker counts incident records, not reports. 'classifies' is fine.

Proposed revision: The MIT AI Incident Tracker classifies incident records from the AI Incident Database by risk, cause, harm, severity and other dimensions; the September 27, 2026 export contains 1,698 incident records. [If a live counter is used, show its 'as of' date.]



### HOME-02: revise

'AI incidents are on the rise' has no population, window or exposure denominator. Database record counts rose from 80 (2021) to 452 (2025) (claim.HOME-02.context_counts.2021 to .2025), but 2020 had 92 records (candidate.IT-C001.sensitivity2.2020), so even the record series is not monotone from 2020. Primary system-safety domain 378/1,698 (22.3%) and the missing-information flag 42/1,698 (2.5%) (primary_safety, missing_information_flag) do not bear on the sentence. The pipeline and framework statements are process descriptions the export cannot verify beyond the model_name field.

Not chart-based.

The opening clause asserts real-world incidence from a voluntary, selectively reported collection; that is the overclaim. The remainder is descriptive and can stand with a source citation.

Proposed revision: The number of AI incident records in the AI Incident Database dated each year rose from 80 in 2021 to 452 in 2025 (September 27, 2026 export); these counts reflect reporting and coverage as well as underlying events. Databases of such reports vary in structure, which limits their use for policymaking. The AI Incident Tracker classifies AIID reports with Arcola AI's LLM pipeline using the MIT Risk Repository and a harm-severity rating based on CSET's AI Harm Taxonomy.



### HOME-06: revise

The empirical hooks are: system-safety domain 7 is the second-most frequent primary domain at 378/1,698 (22.3%) (claim.HOME-06.primary_safety); intentional tags rose from 17/80 (21.25%) in 2021 to 291/452 (64.4%) in 2025 (intentional_context.2021 to .2025); the missing-information flag is 42/1,698 (2.5%) (missing_information_flag) and measures classifier-flagged gaps, not reporting completeness.

Bar and pie charts exist per the site checks. The example label 'System Failures' does not match the taxonomy string '7 AI system safety, failures, & limitations'.

'prevalence of system safety issues' and 'incomplete reporting gaps' imply measurements the export cannot supply; 'trends in causal attributes' describes database tags.

Proposed revision: Key visualizations include bar and pie charts of incident-record counts and proportions across risk domains (for example '7 AI system safety, failures, & limitations' and '1 Discrimination & Toxicity') and of causal attributes over time. The accompanying notes describe patterns in the recorded classifications, such as the share of records tagged to system-safety failures and to intentional causes. They describe this database; they do not measure how common AI incidents are or how completely they are reported.



### TIME-01: pass

Primary 4.3 share rises every year: 3/80 (3.75%), 13/108 (12.0%), 38/179 (21.2%), 105/304 (34.5%), 192/452 (42.5%) (claim.TIME-01.primary.2021 to .2025); smallest step 7.9 points. Any-label share also rises every year: 6/80 (7.5%), 17/108 (15.7%), 56/179 (31.3%), 131/304 (43.1%), 227/452 (50.2%) (any.2021 to .2025). The claim holds under either reading of 'associated with'. 2021 rests on 3 (primary) or 6 (any-label) records. 2026 year-to-date 70/231 (30.3%) is context only (ytd_primary).

C02 primary-subdomain proportions over exact years 2021 to 2025 with all series visible shows the primary series; the any-label series has no faithful chart, and the 'All Subdomains' view shows assignment shares, a different quantity.

Supported. 'clear' is editorial but the steps are large. Naming 'primary subdomain' and 'incident records in the database' would remove ambiguity.

Proposed revision: Among incident records dated 2021 to 2025, the share whose primary subdomain is '4.3 Fraud, scams, and targeted manipulation' rose every year, from 3 of 80 (3.75%) in 2021 to 192 of 452 (42.5%) in 2025 (September 27, 2026 export). Counting any risk tag rather than only the primary one, the share rose from 6 of 80 (7.5%) to 227 of 452 (50.2%). These are shares of records in this database, not measures of how common such incidents are.



### TIME-02: pass

Primary 7.3 share falls every year: 41.25%, 30.6%, 20.7%, 14.5%, 10.0% (claim.TIME-02.primary.2021 to .2025); any-label share falls every year: 66.25%, 57.4%, 40.2%, 35.5%, 26.8% (any.2021 to .2025). Counts rose 33 to 45 (primary) and 53 to 121 (any-label). 2026 year-to-date 43/231 (18.6%) is context only (ytd_primary).

As TIME-01: C02 primary proportions over exact years; the any-label series has no faithful chart.

Supported as a proportion statement under either reading. It must not be repeated elsewhere as robustness improving; adding the rising counts prevents that reading.

Proposed revision: Among incident records dated 2021 to 2025, the share whose primary subdomain is '7.3 Lack of capability or robustness' fell every year, from 33 of 80 (41.25%) in 2021 to 45 of 452 (10.0%) in 2025, while the number of such records rose from 33 to 45 (September 27, 2026 export). The falling share reflects faster growth in other categories; it is not evidence that AI systems became more robust.



### TIME-03: revise

With primary purpose in {Deepfake Video Generation, Deepfake Image Generation, Voice Generation, Image Generation}: 19/108 (17.6%) in 2022, 74/179 (41.3%), 147/304 (48.4%), 239/452 (52.9%) in 2025 (claim.TIME-03.strict_primary.2022 to .2025). Expanded purpose set: 22, 75, 148, 243 (53.8%) (expanded_primary.*). Primary-or-secondary: 23, 77, 161, 256 (56.6%) (strict_primary_secondary.*). All dates: 601/1,698 (35.4%) (strict_all_dates); 2026 year-to-date 101/231 (43.7%) (strict_partial_current_year). 'around half' holds only if 'now' means records dated 2025; it fails for all records (35%) and is marginal for 2026 to date (44%).

C03 pie by aiGoal shows primary purposes for a chosen window; the four-purpose union requires summing slices. A timeline count view needs a host preset to fix years.

'dramatically', 'now' and the purpose set are undefined. The count increase (19 to 239) is large under any supplied definition, but the 'around half' clause depends on the endpoint chosen, and the sentence mixes counts with a share.

Proposed revision: Incident records whose primary AI purpose is tagged Deepfake Video Generation, Deepfake Image Generation, Voice Generation or Image Generation rose from 19 of 108 records dated 2022 (17.6%) to 239 of 452 records dated 2025 (52.9%) in the September 27, 2026 export. Across all records in the export they are 601 of 1,698 (35.4%).



### TIME-04: revise

Tier-1 shares: 3/108 (2.8%) in 2022, 9/179 (5.0%) in 2023, 15/304 (4.9%) in 2024, 24/452 (5.3%) in 2025 (claim.TIME-04.level1.2022 to .2025). 2023 to 2024 falls by 0.09 points, so 'increased each year' fails by one record; '4% in 2025' is 5.3% in this export. Earlier years (level1_context_before.2016 to .2021): 4.9%, 4.0%, 8.7%, 13.6%, 6.5%, 8.75%; 2022 is the lowest year of 2016 to 2025, so the window starts at the trough. 2026 year-to-date 4/231 (1.7%) (ytd_level1). Supplied context reports eight records moved from tier 1 to tier 3 in one batch between the mirror sync and this export, about 8% of tier-1 records, so these tags move in batches.

A timeline stacked by EU AI Act tier with an exact-year preset would show the series if that grouping exists; any live reading will differ from the export after reclassification batches.

Unsupported as written: neither the monotone increase nor the 4% endpoint reproduces. The trailing ']' is a typo. 'classified as level 1 (Unacceptable) under the EU AI Act' presents automated tags as legal classification. The original bullet should not stand; the replacement is optional and must carry the volatility caveat.

Proposed revision: Incident records tagged tier 1 (Unacceptable) under the EU AI Act were 3 of 108 (2.8%) in 2022, 9 of 179 (5.0%) in 2023, 15 of 304 (4.9%) in 2024 and 24 of 452 (5.3%) in 2025 in the September 27, 2026 export; 2022 was the lowest year of 2016 to 2025. These are automated tags that are revised between exports, not legal determinations.



### TIME-05: revise

Intentional share rises every year: 17/80 (21.25%), 36/108 (33.3%), 90/179 (50.3%), 192/304 (63.2%), 291/452 (64.4%) (claim.TIME-05.causal_intent.2021 to .2025); the last step is 1.2 points, about five records. Known-only denominators are identical (causal_intent.known.*). Human causal-entity share rises every year: 22/80 (27.5%), 41/108 (38.0%), 94/179 (52.5%), 198/304 (65.1%), 310/452 (68.6%) (causal_entity.2021 to .2025); known-only 27.8, 38.0, 52.8, 65.1, 69.0% (causal_entity.known.*). 2026 year-to-date: 130/231 (56.3%) and 142/231 (61.5%), both below 2025 (ytd_causal_intent, ytd_causal_entity).

A timeline stacked by causal intent or causal entity in proportions with an exact-year preset would show both series if those groupings exist; not verified here.

Numbers reproduce. 'intentionally caused incidents' states causation as fact; these are LLM-assigned tags and the pilot did not evaluate the current model. 'attributed to Human rather than AI' is acceptable shorthand for a rising Human share; the residual includes AI and a few Other or unknown values.

Proposed revision: Among incident records dated 2021 to 2025, the share tagged as intentionally caused rose each year, from 17 of 80 (21.25%) to 291 of 452 (64.4%), and the share whose causal entity is tagged Human rather than AI rose each year, from 22 of 80 (27.5%) to 310 of 452 (68.6%) (September 27, 2026 export). These are automated causal tags, not verified findings about intent.



### TIME-06: revise

Post-deployment 1,663/1,698 (97.9%) (claim.TIME-06.post) supports 'overwhelming majority'. Pre-deployment by complete year: 2016 4/41 (9.8%), 2017 3/50 (6.0%), 2018 1/46 (2.2%), 2019 2/44 (4.5%), 2020 3/92 (3.3%), 2021 1/80 (1.25%), 2022 1/108 (0.9%), 2023 3/179 (1.7%), 2024 2/304 (0.7%), 2025 2/452 (0.4%) (pre.2016 to .2025); sparse earlier years include 1996 1/1 and 2011 1/3 (pre.1996, pre.2011), and many years have no records. 2026 year-to-date 8/231 (3.5%) (ytd_pre). 'no more than a few percent in any year' fails for 2016 (9.8%) and 2017 (6.0%) under ordinary readings and trivially for sparse years.

A timeline stacked by causal timing from 2016 onward would show the 2016 and 2017 bars above later years; the default chart's 2016 floor is not the claim's stated window.

'overwhelming majority' is supported; 'a few percent in any year' is not. 'incidents assessed' is fine.

Proposed revision: Almost all incident records are tagged post-deployment: 1,663 of 1,698 (97.9%) in the September 27, 2026 export. Pre-deployment tags were 4 of 41 records (9.8%) in 2016 and 3 of 50 (6.0%) in 2017, and between 0.4% and 4.5% in each year from 2018 to 2025.



### OVERVIEW-01: pass

830/1,698 (48.9%) tagged Intentional (claim.OVERVIEW-01.all); 830/1,696 (48.9%) excluding two records with unknown intent (known). Both are within about one point of half.

An overview chart by causal intent would show the share; the live value may differ from the export.

'About half' accurately describes 48.9%, and 'tagged as' correctly attributes the label. This review disagrees with the source's 'not verifiable' status: no predeclared tolerance is needed to accept 48.9% as about half. Adding the exact figure and date improves precision.

Proposed revision: About half of incident records, 830 of 1,698 (48.9%) in the September 27, 2026 export, are tagged as intentionally caused.



### OVERVIEW-02: pass

Pre-deployment 32/1,698 (1.9%), post-deployment 1,663/1,698 (97.9%), Other 3 (0.2%) (claim.OVERVIEW-02.pre, .post, .other). 'only 2%' matches 1.9% rounded.

An overview chart by causal timing; the live value may differ from the export.

Supported. 'Almost all' fits 97.9%.

Proposed revision: Almost all incident records are tagged post-deployment: 1,663 of 1,698 (97.9%) in the September 27, 2026 export; 32 (1.9%) are tagged pre-deployment and 3 as Other.



### OVERVIEW-03: revise

Tier 1: 87/1,698 (5.1%); tier 2: 435/1,698 (25.6%) (claim.OVERVIEW-03.level1, .level2), against the published 5.7% and 33%. The tier-2 share falls steeply by year, 53.8% (2021) to 8.0% (2025) (level2_context.2021 to .2025), so the all-records tier-2 share declines as newer records accumulate, consistent with 33% being an older snapshot; the ID-prefix match to April 2025 is suggestive and unverified. Supplied context reports the mirror at 95/1,697 tier 1 before eight records were moved to tier 3, so tier-1 counts move in batches.

An overview chart by EU AI Act tier; live values already differ from both the published text and the export.

Numbers are stale. 'and therefore prohibited under the EU AI Act' is a legal conclusion the classifier tag cannot support; scope, exemptions and application dates are not assessed. 'would be classed' hedges the tier but not the prohibition.

Proposed revision: In the September 27, 2026 export, the classifier assigns EU AI Act tier 1 (Unacceptable) to 87 of 1,698 incident records (5.1%) and tier 2 (High Risk) to 435 (25.6%). These are automated tags that change between exports; they are not legal determinations, and whether a practice is prohibited depends on the Act's scope, exemptions and dates of application, which the tags do not assess.



### OVERVIEW-04: pass

Deepfake Video Generation 316/1,698 (18.6%) leads Chatbot 181 (10.7%) and Deepfake Image Generation 135 (8.0%) (claim.OVERVIEW-04.08fea3890a66, .4db675e01582, .2eff61a22915); the leader is stable across the IT-C003 variants, including through 2025 and 2026 year-to-date.

C03 pie by aiGoal; the aggregated Other slice may exceed any named slice and must not be read as a category.

Supported as a primary-purpose statement; 'attributed to' is fine. Keep 'primary' because Voice Generation outranks Chatbot under primary-or-secondary scope.

Proposed revision: The primary AI-purpose tag attributed to the most incident records is Deepfake Video Generation, 316 of 1,698 (18.6%) in the September 27, 2026 export, followed by Chatbot (181, 10.7%).



### OVERVIEW-05: pass

Primary domain 4: 641/1,698 (37.8%); domain 7: 378 (22.3%); domain 1: 281 (16.5%) (claim.OVERVIEW-05.b42bf733eb83, .7e468c14a922, .adb1b3c71dba). The ranking holds over all dates including 2026 to date.

Domain bar or overview pie by domain; live values differ from the export.

Supported for primary classification. 'across the full dataset' should be dated.

Proposed revision: Across all incident records in the September 27, 2026 export, the most frequent primary risk domain is '4 Malicious actors' (641 of 1,698, 37.8%), followed by '7 AI system safety, failures, & limitations' (378, 22.3%).



### OVERVIEW-06: revise

Primary 4.3 within primary domain 4: 440/641 (68.6%) (claim.OVERVIEW-06.primary); any-label 4.3 within the same population: 478/641 (74.6%) (any_subdomain_within_primary_domain); default bar from 2016 including 2026 to date: 438/639 (68.5%) (bar_default). Complete years 2016 to 2025 give 368/535 (68.8%) (candidate.IT-C004.primary).

C04 with Domain = 4 in counts shows the segment; the default window includes partial 2026. No proportions toggle.

'vast majority' overstates roughly two-thirds to three-quarters; it is a majority, not a vast one. State the number and the definition.

Proposed revision: Within incident records primarily classified as '4 Malicious actors', 440 of 641 (68.6%) have the primary subdomain '4.3 Fraud, scams, and targeted manipulation' in the September 27, 2026 export; on the overview bar chart, which starts at 2016, the figure is 438 of 639 (68.5%).



### TIME-VALIDATION: revise

No supplied calculation addresses classifier agreement. The export has one retained classification per record and no human reference labels or repeated runs. Supplied context (VALIDATION-SCOPE) states the June 2026 pilot used 10 incidents, two reviewers and eight models, and that the export's models (gemini-3.5-flash for 1,696 rows, mistral-large-latest for 2) are not in the pilot's model list. The agreement statistics quoted in the source's reason and the confidence-field distribution were not verified here and have no calculation IDs.

Not chart-based.

'article forthcoming' is stale per supplied context. 'comparable to the agreement between 2 independent human experts' reports a 10-incident pilot on other models as if it covered the current tool; 'improving its reliability' is not demonstrated by supplied evidence. The closing caveat is appropriate and should stay.

Proposed revision: The LLM classifier was evaluated in a small pilot published in June 2026 (10 incidents, 2 expert reviewers, 8 models) [link the June 30, 2026 update and quote its agreement statistics directly]. That pilot did not include the model used for the current classifications, so its results do not establish the accuracy of the current tags. Spot-checks have been used to give feedback on misclassifications, and incidents remain where the classification will not match expert consensus.



### OVERVIEW-VALIDATION: revise

Identical text to TIME-VALIDATION. No supplied calculation addresses classifier agreement; the export carries one classification per record with no reference labels or repeated runs. Supplied context (VALIDATION-SCOPE): the June 2026 pilot used 10 incidents, two reviewers and eight models, none of which is the export's gemini-3.5-flash or mistral-large-latest. Quoted agreement statistics and the confidence-field distribution were not verified here.

Not chart-based.

'article forthcoming' is stale. The comparability sentence extends a 10-incident pilot on other models to the current tool; 'improving its reliability' is undemonstrated. Keep the closing caveat.

Proposed revision: The LLM classifier was evaluated in a small pilot published in June 2026 (10 incidents, 2 expert reviewers, 8 models) [link the June 30, 2026 update and quote its agreement statistics directly]. That pilot did not include the model used for the current classifications, so its results do not establish the accuracy of the current tags. Spot-checks have been used to give feedback on misclassifications, and incidents remain where the classification will not match expert consensus.



### VIEW-VALIDATION: revise

Identical text to TIME-VALIDATION. No supplied calculation addresses classifier agreement; the export carries one classification per record with no reference labels or repeated runs. Supplied context (VALIDATION-SCOPE): the June 2026 pilot used 10 incidents, two reviewers and eight models, none of which is the export's gemini-3.5-flash or mistral-large-latest. Quoted agreement statistics and the confidence-field distribution were not verified here.

Not chart-based; the incident-view page shows per-record classifications whose accuracy this statement is meant to qualify.

'article forthcoming' is stale. The comparability sentence extends a 10-incident pilot on other models to the current tool; 'improving its reliability' is undemonstrated. Keep the closing caveat.

Proposed revision: The LLM classifier was evaluated in a small pilot published in June 2026 (10 incidents, 2 expert reviewers, 8 models) [link the June 30, 2026 update and quote its agreement statistics directly]. That pilot did not include the model used for the current classifications, so its results do not establish the accuracy of the current tags. Spot-checks have been used to give feedback on misclassifications, and incidents remain where the classification will not match expert consensus.



### NATSEC-VALIDATION: revise

Identical text to TIME-VALIDATION. No supplied calculation addresses classifier agreement; the export carries one classification per record with no reference labels or repeated runs. Supplied context (VALIDATION-SCOPE): the June 2026 pilot used 10 incidents, two reviewers and eight models, none of which is the export's gemini-3.5-flash or mistral-large-latest. The source additionally notes that prior small-sample validation does not cover national-security labels. Quoted agreement statistics were not verified here.

Not chart-based; C07 radar scores on this page are the labels the statement qualifies.

'article forthcoming' is stale. The comparability sentence extends a 10-incident pilot on other models and other taxonomies to the national-security scores; 'improving its reliability' is undemonstrated. Keep the closing caveat.

Proposed revision: The LLM classifier was evaluated in a small pilot published in June 2026 (10 incidents, 2 expert reviewers, 8 models) [link the June 30, 2026 update and quote its agreement statistics directly]. That pilot did not include the model used for the current classifications or the national-security scores shown here, so its results do not establish their accuracy. Spot-checks have been used to give feedback on misclassifications, and incidents remain where the classification will not match expert consensus.

