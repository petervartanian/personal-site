# Claim refresh report

Mode: **live**. Generated 2026-10-01T15:51:08.568039+00:00. Registry was **not** edited.

| Metric | Value |
| --- | --- |
| pages_fetched | 10 |
| pages_ok | 10 |
| claims_checked | 59 |
| present | 52 |
| changed | 0 |
| absent | 0 |
| app_source_unchanged | 7 |
| app_source_changed_quote_unverifiable | 0 |
| reference_source_unchanged | 0 |
| reference_source_changed_quote_unverifiable | 0 |
| page_unavailable | 0 |
| pages_with_changed_bytes | 3 |
| javascript_rendered_text_checked | False |
| registry_edited | False |

| Claim | Quote status | 8-gram overlap | Page bytes changed since registry |
| --- | --- | --- | --- |
| HOME-01 | present | 1.0 | False |
| HOME-02 | present | 1.0 | False |
| HOME-03 | present | 1.0 | False |
| HOME-04 | present | 1.0 | False |
| HOME-05 | present | 1.0 | False |
| HOME-06 | present | 1.0 | False |
| HOME-07 | present | 1.0 | False |
| HOME-08 | present | 1.0 | False |
| HOME-09 | present | 1.0 | False |
| HOME-SCOPE-01 | present | 1.0 | False |
| HOME-SCOPE-02 | present | 1.0 | False |
| HOME-SCOPE-03 | present | 1.0 | False |
| HOME-SCOPE-04 | present | 1.0 | False |
| HOME-SCOPE-05 | present | 1.0 | False |
| HOME-SCOPE-06 | present | 1.0 | False |
| TIME-01 | present | 1.0 | False |
| TIME-02 | present | 1.0 | False |
| TIME-03 | present | 1.0 | False |
| TIME-04 | present | 1.0 | False |
| TIME-05 | present | 1.0 | False |
| TIME-06 | present | 1.0 | False |
| TIME-SCOPE-01 | present | 1.0 | False |
| TIME-SCOPE-02 | present | 1.0 | False |
| OVERVIEW-01 | present | 1.0 | False |
| OVERVIEW-02 | present | 1.0 | False |
| OVERVIEW-03 | present | 1.0 | False |
| OVERVIEW-04 | present | 1.0 | False |
| OVERVIEW-05 | present | 1.0 | False |
| OVERVIEW-06 | present | 1.0 | False |
| OVERVIEW-SCOPE-01 | present | 1.0 | False |
| OVERVIEW-SCOPE-02 | present | 1.0 | False |
| VIEW-SCOPE-01 | present | 1.0 | False |
| NATSEC-SCOPE-01 | present | 1.0 | False |
| HARM-SCOPE-01 | present | 1.0 | False |
| TIME-LIMITATIONS | present | 1.0 | False |
| TIME-VALIDATION | present | 1.0 | False |
| TIME-CAUTION | present | 1.0 | False |
| OVERVIEW-LIMITATIONS | present | 1.0 | False |
| OVERVIEW-VALIDATION | present | 1.0 | False |
| OVERVIEW-CAUTION | present | 1.0 | False |
| VIEW-LIMITATIONS | present | 1.0 | False |
| VIEW-VALIDATION | present | 1.0 | False |
| VIEW-CAUTION | present | 1.0 | False |
| NATSEC-LIMITATIONS | present | 1.0 | False |
| NATSEC-VALIDATION | present | 1.0 | False |
| NATSEC-CAUTION | present | 1.0 | False |
| DEFINITION-HARM-V2 | present | 1.0 | True |
| DEFINITION-HARM-CSET | present | 1.0 | True |
| DEFINITION-NATSEC-SCALE | present | 1.0 | True |
| DEFINITION-NATSEC-THREAT | present | 1.0 | True |
| DEFINITION-NATSEC-OVERALL | present | 1.0 | True |
| DEFINITION-INCIDENT-DATE | present | 1.0 | True |
| APP-DIRECT | app_source_unchanged | 1.0 | False |
| APP-INDIRECT | app_source_unchanged | 1.0 | False |
| APP-INFERRED | app_source_unchanged | 1.0 | False |
| APP-HIGHEST | app_source_unchanged | 1.0 | False |
| APP-PRIMARY | app_source_unchanged | 1.0 | False |
| APP-ALLSUBDOMAINS | app_source_unchanged | 1.0 | False |
| APP-HARMCATEGORIES | app_source_unchanged | 1.0 | False |

Human review: for any 'changed' or 'absent' quote, compare the raw capture with the registered text, then version the registry and check definitions deliberately. Nothing was edited automatically.
