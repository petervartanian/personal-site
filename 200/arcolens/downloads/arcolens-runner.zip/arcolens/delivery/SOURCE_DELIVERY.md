# Receiving exports

The recurring installation reads an agreed Drive folder through the authenticated
Google Drive connector. Arcola must still produce the export and place it in that
folder. Creating an inbox does not configure Arcola's export service.

Each export keeps its original `incident_tracker_export_YYYY-MM-DD.csv` filename.
List each configured folder directly and follow every page. General Drive search
can omit shared-drive files, so an empty search is not evidence that the folder is
empty. Download each eligible file into a new source-ID and retrieval-time directory
under `intake/drive`. Never overwrite an earlier retrieval, relabel a historical
file, substitute the public chart data, or extract connector credentials.

The scheduled agent records a source receipt after downloading. It contains:

- `transport`: `connected_google_drive`; the configured account alias; and a
  time-zone-qualified `checked_at_utc` timestamp.
- `folders`: every configured folder's `id`, `status` (`complete` or `failed`),
  `all_pages_read`, and full `files` inventory containing each file's `id` and
  original `name`.
  - Eligible CSV entries also contain `local_path`, `sha256`, and
    `retrieved_at_utc`.
  - Record source modification/version information if the connector returns it;
    otherwise record it as unavailable. Do not invent it from retrieval time.
- A note if the file is an existing-export rehearsal. A successful receipt is
  evidence of transfer, not evidence of a new dataset.

The operator's private source policy names the account, exact folder IDs, cadence
(`monthly` or `fortnightly`), and maximum allowed age in days. Source receipts and
the private policy stay outside the downloadable package.

Run `python -m delivery.recurring` with the private publishing configuration,
source receipt, and source policy. `--help` lists the arguments. This entry point:

1. Refuses overlapping runs and incomplete or outdated source checks.
2. Verifies every eligible download's path, original filename, and content hash.
3. Validates CSV contents using the existing intake rules.
4. Flags an expected update that has not arrived. Renaming identical bytes does
   not reset the analyzed data's age.
5. Rechecks public quotations even when no new export arrives or source delivery
   fails. A blocked delivery makes no model call or dashboard publication.
6. Passes fresh changed input to the existing analysis, independent model review,
   comparison, packaging, and encrypted publishing process.

Every attempt gets a separate `logs/recurring` directory with a manifest.
`LATEST_RECURRING.json` identifies the latest attempt. The existing report remains
live if a source, analysis, review, or deployment check fails.

An interrupted run leaves `intake/recurring.lock`. Inspect the recorded process
and its logs before removing a stale lock. Never automatically retry a paid model
call solely because a lock remains. A completed monthly check can be delivered
again through `delivery.check_and_publish --completed-check` without repeating
analysis or model calls.

This is a Codex-assisted schedule on the operator's Mac, not an independent cloud
service: Codex, the Mac, Drive authorization, model authorization, and hosting
access must be available. A genuine changed export is required to validate the
complete unattended changed-data cycle.
