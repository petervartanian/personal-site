"""Small-sample year-end intervals from genuine AIID snapshot vintages."""

from __future__ import annotations

import html
import json
import math
import re
import shutil
import statistics
from datetime import date, timedelta
from pathlib import Path

RESOURCE = Path(__file__).parent / "resources/historical-completion.json"
# Two-sided 90% Student-t quantiles (0.95 CDF), NIST table / direct evaluation.
T90 = {1: 6.313751514800932, 2: 2.919985580355516, 3: 2.3533634348018264}
# Central 50% Student-t quantiles (0.75 CDF).
T50 = {1: 1.0, 2: math.sqrt(2 / 3), 3: 0.7648923284043453}


def historical_pairs(cutoff: date) -> list[dict]:
    data = json.loads(RESOURCE.read_text())
    vintages = data["vintages"]
    result = []
    for origin in vintages:
        start = date.fromisoformat(origin["snapshot_date"])
        if start.month != 9 or start.year >= cutoff.year:
            continue
        end = next(
            (
                v
                for v in vintages
                if v["snapshot_date"].startswith(f"{start.year + 1}-01")
            ),
            None,
        )
        if not end or date.fromisoformat(end["snapshot_date"]) >= cutoff:
            continue
        initial = {
            r["incident_id"]
            for r in origin["records"]
            if f"{start.year}-01-01" <= r["date"] <= str(start)
        }
        final = {
            r["incident_id"]
            for r in end["records"]
            if r["date"].startswith(str(start.year))
        }
        late = {
            r["incident_id"]
            for r in end["records"]
            if r["incident_id"] in final - initial and r["date"] <= str(start)
        }
        if not initial or not final:
            continue
        horizon = (date.fromisoformat(end["snapshot_date"]) - start).days
        result.append(
            {
                "year": start.year,
                "origin": str(start),
                "outcome": end["snapshot_date"],
                "observed": len(initial),
                "final": len(final),
                "late_additions": len(late),
                "origin_ids": sorted(initial, key=int),
                "outcome_ids": sorted(final, key=int),
                "late_addition_ids": sorted(late, key=int),
                "removed_ids": sorted(initial - final, key=int),
                "origin_url": origin["url"],
                "outcome_url": end["url"],
                "horizon_days": horizon,
                "log_daily_completion_rate": math.log(len(final) / len(initial))
                / horizon,
            }
        )
    return sorted(result, key=lambda r: r["year"])[-4:]


def fit(
    count: int, horizon: int, pairs: list[dict], coverage_probability: float = 0.90
) -> dict:
    if len(pairs) not in (2, 3, 4) or count <= 0 or horizon < 0:
        raise ValueError(
            "Completion model needs 2–4 prior vintages and positive counts"
        )
    rates = [p["log_daily_completion_rate"] for p in pairs]
    location = statistics.mean(rates) * horizon
    scale = statistics.stdev(rates) * horizon * math.sqrt(1 + 1 / len(rates))
    critical = {0.50: T50, 0.90: T90}[coverage_probability][len(rates) - 1]
    width = critical * scale
    return {
        "median": count * math.exp(location),
        "bounds": [
            max(count, count * math.exp(location - width)),
            max(count, count * math.exp(location + width)),
        ],
        "log_location": location,
        "log_predictive_scale": scale,
        "degrees_of_freedom": len(rates) - 1,
        "t_critical": critical,
        "coverage_probability": coverage_probability,
    }


def estimate(count: int, cutoff: date) -> dict | None:
    # These vintages cover late-year completion, not early-year seasonality.
    if cutoff.month < 9 or count <= 0:
        return None
    pairs = historical_pairs(cutoff)
    if len(pairs) < 3 or cutoff.year - pairs[-1]["year"] > 2:
        return None
    target = date(cutoff.year + 1, 1, 1)
    target += timedelta(days=(-target.weekday()) % 7)
    fitted = fit(count, (target - cutoff).days, pairs, coverage_probability=0.50)
    wider = fit(count, (target - cutoff).days, pairs)
    tests = []
    for index in range(2, len(pairs)):
        held = pairs[index]
        forecast = fit(held["observed"], held["horizon_days"], pairs[:index])
        start = date.fromisoformat(held["origin"])
        elapsed = (start - date(start.year, 1, 1)).days + 1
        days = (date(start.year + 1, 1, 1) - date(start.year, 1, 1)).days
        baseline = held["observed"] * days / elapsed
        tests.append(
            {
                "year": held["year"],
                "training_years": [p["year"] for p in pairs[:index]],
                "observed_at_origin": held["observed"],
                "actual": held["final"],
                **forecast,
                "covered": forecast["bounds"][0]
                <= held["final"]
                <= forecast["bounds"][1],
                "calendar_pace_baseline": baseline,
                "model_absolute_error": abs(forecast["median"] - held["final"]),
                "baseline_absolute_error": abs(baseline - held["final"]),
            }
        )
    return {
        "method": "snapshot_completion_log_rate_student_t",
        "coverage_probability": 0.50,
        "bounds": {"counts": fitted["bounds"], "share": [100, 100]},
        "wider_interval": {
            "coverage_probability": 0.90,
            "bounds": {"counts": wider["bounds"], "share": [100, 100]},
            "fit": wider,
        },
        "median": fitted["median"],
        "fit": fitted,
        "display_step": 10,
        "display_rounding": "nearest",
        "target_snapshot_date": str(target),
        "training": pairs,
        "backtests": tests,
        "target": "Forecast-year records in the first weekly January snapshot; later backfill excluded.",
        "interpretation": "The chart displays the central 50% model interval. Half of the predictive probability lies outside it. Methods and evidence include the wider nominal 90% interval. Both assume exchangeable normal log completion rates. Two rolling-origin tests are insufficient to measure interval coverage.",
        "includes": [
            "historically observed late additions before the January snapshot",
            "variation among years",
            "small-sample parameter uncertainty",
        ],
        "excludes": [
            "backfill after the first January snapshot",
            "classification changes",
            "structural changes in collection or Arcola coverage",
            "unreported real-world incidents",
        ],
        "assumptions": [
            "Recent historical completion rates transfer from AIID to Arcola.",
            "Log completion grows at a constant average daily rate within the remaining period.",
            "Currently observed records are retained.",
            "The four historical years are exchangeable despite their declining completion ratios.",
        ],
    }


def apply(series: dict, cutoff: date) -> None:
    item = series.get("IT-C001")
    if not item or not item["partial"]:
        return
    result = estimate(item["partial"]["numerator"], cutoff)
    if result:
        projection = item["projection"]
        projection["timing_only_range"] = projection["range"]
        projection["calendar_pace"] = projection["numerator"]
        projection.update(
            numerator=result["median"],
            denominator=result["median"],
            status="Snapshot-based year-end estimate",
            range=result,
        )


def methods(site: Path, series: dict) -> None:
    item = series.get("IT-C001", {})
    projection = item.get("projection") or {}
    model = projection.get("range", {})
    if model.get("method") != "snapshot_completion_log_rate_student_t":
        return
    lo, hi = model["bounds"]["counts"]
    observed = item["partial"]["numerator"]
    cutoff = date.fromisoformat(item["cutoff"])
    elapsed = (cutoff - date(cutoff.year, 1, 1)).days + 1
    days = (date(cutoff.year + 1, 1, 1) - date(cutoff.year, 1, 1)).days
    backfill_link = (
        '<a href="backfill-evidence.json">Later backfill evidence</a>'
        if (site / "backfill-evidence.json").exists()
        else '<a href="https://incidentdatabase.ai/blog/incident-report-2026-may-june-july/">Later backfill evidence</a>'
    )
    lower, upper = math.floor(lo / 10 + 0.5) * 10, math.floor(hi / 10 + 0.5) * 10
    wide_lo, wide_hi = model["wider_interval"]["bounds"]["counts"]
    wide_lower, wide_upper = math.floor(wide_lo / 10) * 10, math.ceil(wide_hi / 10) * 10
    table_rows = "".join(
        f'<tr><td>{p["year"]}</td><td><a href="{p["origin_url"]}">{p["origin"]}</a>: {p["observed"]}</td>'
        f'<td><a href="{p["outcome_url"]}">{p["outcome"]}</a>: {p["final"]}</td><td>{p["late_additions"]}</td></tr>'
        for p in model["training"]
    )
    tests = "".join(
        f'<li>{p["year"]}: predicted {p["median"]:.0f}, interval {p["bounds"][0]:.0f}–{p["bounds"][1]:.0f}; observed {p["actual"]}. Calendar-pace baseline: {p["calendar_pace_baseline"]:.0f}.</li>'
        for p in model["backtests"]
    )
    text = (
        '<section class="content-section"><h2 id="section-projecting-2026">Year-end estimates</h2>'
        f'<p>The all-records chart shows the <strong>central 50% range: approximately {lower:,}–{upper:,} records</strong> dated {item["cutoff"][:4]}, '
        f'with a model median of {model["median"]:.0f}. Half of the model’s predictive probability lies outside this band.</p>'
        f"<p>The wider <strong>90% range is approximately {wide_lower:,}–{wide_upper:,} records</strong>. "
        f'Both intervals use the same model and target the first weekly January snapshot ({model["target_snapshot_date"]}). '
        "The central band displays a smaller portion of the same forecast distribution. Later additions can increase the annual total beyond that snapshot.</p>"
        "<h3>Historical reporting patterns</h3><p>Each pair below comes from public AIID backups. The September count is what the database held then. "
        "The January count includes subsequent incidents and late additions for the same calendar year. Late additions have dates on or before the September snapshot.</p>"
        '<div class="table-scroll" tabindex="0"><table><thead><tr><th>Year</th><th>September snapshot</th><th>January snapshot</th><th>Late additions</th></tr></thead><tbody>'
        + table_rows
        + "</tbody></table></div>"
        "<p>The model fits the four log completion rates, log(January count ÷ September count) ÷ elapsed days. "
        "It scales them to the remaining time and uses a Student-t predictive interval with three degrees of freedom, including uncertainty in the fitted average. "
        "The lower bound cannot fall below the current recorded count. Chart labels round the central 50% bounds to the nearest ten; the wider 90% bounds round outward to tens. "
        "The shaded band and downloadable evidence retain the unrounded bounds.</p>"
        '<h3>Retrospective checks (90% intervals)</h3><ul class="structured-list">'
        + tests
        + "</ul>"
        "<p>Each check uses only earlier snapshot pairs. Both outcomes fell inside their intervals. Two checks are insufficient to measure interval coverage. "
        "The calendar-pace baseline had smaller point errors in both checks. The interval model accounts for uncertainty and late additions. "
        "Completion ratios declined across the four years, so the assumption that they are exchangeable remains uncertain. The 2021 report-level schema and its five-record September cohort were excluded before fitting.</p>"
        "<h3>Reading the band</h3><p>The solid daily curve, including 2026, counts the preceding 12 months. At December 31 that window equals the calendar-year total. "
        "The shaded segment connects the last observed point to the year-end interval. Only the year-end bounds are estimated. "
        "The observed 2026 calendar-year count remains separate. Category charts retain their timing-scenario ranges; they have no assigned probability and no adjustment for reporting delays.</p>"
        "<h3>Limits and evidence</h3><p>The model transfers AIID reporting patterns to the Arcola export. It cannot anticipate changes in collection coverage, removals or reclassification, "
        "or incidents that never enter the database. It applies from September through December and recalculates from the new count and date. "
        "The training snapshots are bundled for reproducibility and must be refreshed as additional completed years become available.</p>"
        f"<p>The calendar-pace calculation, {observed} × {days} ÷ {elapsed} ≈ {observed*days/elapsed:.0f}, remains in the evidence as a baseline. "
        "Separate editorial batches identify 74 records dated 2025 added during February–July 2026; this later backfill is outside the January forecast target.</p>"
        '<p><a href="year-end-model.json">Model, record IDs, and checks</a> | <a href="historical-completion.json">Historical snapshots and checksums</a> | '
        + backfill_link
        + "</p>"
        '<p>References: <a href="https://incidentdatabase.ai/research/snapshots/">AIID snapshot archive</a>, '
        '<a href="https://otexts.com/fpp3/prediction-intervals.html">Prediction intervals</a>, '
        '<a href="https://otexts.com/fpp3/tscv.html">Time-series cross-validation</a>, '
        '<a href="https://www.itl.nist.gov/div898/handbook/eda/section3/eda3672.htm">Student-t critical values</a>.</p></section>'
    )
    path = site / "methods.html"
    page = path.read_text()
    pattern = r'<section class="content-section">(?:<span id="section-projecting-2026"></span>)?<h2 id="(?:section-projecting-2026|section-partial-year)".*?</section>'
    page, count = re.subn(pattern, lambda _: text, page, flags=re.S)
    if count != 1:
        raise ValueError("Expected exactly one year-end methods section")
    page = page.replace(
        ">2026: observations and scenarios</a>", ">Year-end estimates</a>"
    )
    path.write_text(page)
    (site / "year-end-model.json").write_text(json.dumps(model, indent=2))
    shutil.copy2(RESOURCE, site / "historical-completion.json")
