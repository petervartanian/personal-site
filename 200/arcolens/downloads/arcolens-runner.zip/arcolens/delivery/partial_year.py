"""Keep unfinished-year observations distinct from unvalidated pace scenarios."""

from __future__ import annotations

import html
import json
import re
import shutil
from pathlib import Path


def observed_figure(figure: str, series: dict) -> str:
    """Replace the frozen scenario point using the chart's existing linear scale."""
    identifier = re.search(r'data-projection="([^"]+)"', figure)[1]
    item = series[identifier]
    observed = item["observed"]
    count = item["unit"] == "records"
    value = observed["numerator"] if count else observed["percent"]
    points = []
    for numerator, denominator, group in re.findall(
        r'<g data-calculation="[^"]+" data-numerator="([^"]+)" data-denominator="([^"]+)">(.*?)</g>',
        figure,
    ):
        circle = re.search(r'<circle cx="([^"]+)" cy="([^"]+)"', group)
        measure = (
            float(numerator) if count else 100 * float(numerator) / float(denominator)
        )
        points.append((measure, float(circle[1]), float(circle[2])))
    first = points[0]
    other = next(p for p in points[1:] if p[0] != first[0])
    slope = (other[2] - first[2]) / (other[0] - first[0])
    intercept = first[2] - slope * first[0]
    segment = re.search(r'<line class="forecast-segment"[^>]*x2="([^"]+)"', figure)
    x, y = float(segment[1]), intercept + slope * value
    boundary = (points[-1][1] + x) / 2
    label = (
        f"{value:,.0f} records"
        if count
        else f"{value:.2f}% ({observed['numerator']} of {observed['denominator']} records)"
    )
    description = (
        f"2026 so far: {label}. Partial year; reporting and backfill remain incomplete."
    )
    grid = [
        float(v)
        for v in re.findall(r'<line x1="[^"]+" x2="[^"]+" y1="([^"]+)"', figure)
    ]
    top, bottom = min(grid), max(grid)
    marker = (
        f'<g data-observed-partial="{identifier}" data-observed-value="{value:.12f}" '
        f'data-numerator="{observed["numerator"]}" data-denominator="{observed["denominator"]}">'
        f"<title>{html.escape(description)}</title>"
        f'<line x1="{boundary:.3f}" x2="{boundary:.3f}" y1="{top}" y2="{bottom}" '
        'stroke="#94afaf" stroke-width="1" stroke-dasharray="2 5"/>'
        f'<circle cx="{x:.3f}" cy="{y:.3f}" r="5" fill="#786886" stroke="#f3f9f8" stroke-width="2"/>'
        "</g>"
    )
    figure, replacements = re.subn(r'<g data-projection="[^"]+".*?</g>', marker, figure)
    if replacements != 1:
        raise ValueError("Expected one unfinished-year scenario point")
    figure = re.sub(
        r'2026 projected: [^<"]+?Whisker shows timing scenarios, not a confidence interval\.',
        html.escape(description),
        figure,
    )
    return figure.replace(">projected</tspan>", ">so far</tspan>")


def update_september(site: Path, resources: Path) -> dict:
    """Correct the current presentation; leave the preserved historical copy intact."""
    projections = json.loads((site / "projections-2026.json").read_text())
    backfill = json.loads((resources / "backfill-20260928.json").read_text())
    if projections["input_sha256"] != backfill["csv_sha256"]:
        raise ValueError("Backfill evidence belongs to a different export")
    changed = 0
    for path in site.glob("*.html"):
        text = path.read_text()

        def replace(match: re.Match) -> str:
            nonlocal changed
            figure = match[0]
            if "data-projection=" not in figure:
                return figure
            changed += 1
            return observed_figure(figure, projections["series"])

        text = re.sub(r"<figure\b[^>]*>.*?</figure>", replace, text, flags=re.S)
        text = re.sub(
            r'<p class="forecast-legend"[^>]*>.*?</p>',
            '<p class="forecast-legend" data-year-view="partial">'
            "The separate point shows 2026 so far; recent records may still be missing. "
            '<a href="methods.html#section-projecting-2026">Reporting delays and pace scenarios</a></p>',
            text,
            flags=re.S,
        )
        text = text.replace(
            "disabled>Complete years</button>", "disabled>Through 2025</button>"
        )
        text = text.replace(
            "disabled>Include 2026</button>", "disabled>2026 so far</button>"
        )
        path.write_text(text)
    if changed != 12:
        raise ValueError(f"Expected twelve current annual figures; found {changed}")

    methods = site / "methods.html"
    text = methods.read_text()
    start = text.index(
        '<section class="content-section"><h2 id="section-projecting-2026"'
    )
    end = text.index("</section>", start) + len("</section>")
    old_section = text[start:end]
    table = re.search(r'<div class="table-scroll".*?</div>', old_section, re.S)[0]
    table = table.replace(
        "Projecting 2026 table", "2026 observations and pace scenarios"
    )
    table = table.replace("Projected full year", "Unadjusted pace scenario")
    table = table.replace("Timing scenarios", "Historical timing scenarios")
    section = (
        '<section class="content-section"><h2 id="section-projecting-2026">2026: observations and scenarios</h2>'
        "<p>The charts show <strong>231 records dated in 2026</strong> in the September 27 export. "
        "These calendar-year-to-date figures remain separate from the plotted rolling values. "
        'The solid curve counts records in the preceding 12 calendar months, recalculated for every day, including 2026. Each December 31 anchor equals its calendar-year total. The filled September 27 point uses that same rolling window; it includes records from late 2025 as well as 2026. Records for earlier years can also be added or revised later.</p><p>The vertical bar at December 31 shows the numerical year-end scenario range. For all records, the current assumptions give approximately 312–342. Its endpoints are the minimum and maximum across the calendar-pace calculation and the five historical-timing scenarios. Daily resolution follows the dates supplied in the export; it does not establish that every event date is precise. Hover over a curve or use the arrow keys to inspect dates. <a href="daily-timeline.json">Daily values and window definitions</a>.</p>'
        "<h3>Older years continue to grow</h3><p>Matching AIID’s published batches to this export identifies "
        "<strong>74 records dated 2025 that were added during February–July 2026</strong>: "
        '33 in the <a href="https://incidentdatabase.ai/blog/incident-report-2026-february-march-april/">February–April batch</a> '
        'and 41 in the <a href="https://incidentdatabase.ai/blog/incident-report-2026-may-june-july/">May–July batch</a>. '
        "This confirms backfilling, but does not tell us how many 2026 records are still missing. "
        '<a href="backfill-evidence.json">Matched IDs and dates</a>.</p>'
        "<h3>Year-end scenario range</h3><p><strong>231 × 365 ÷ 270 ≈ 312</strong> is the result of extending "
        "the currently recorded daily pace through December 31. The calendar-pace calculation is one input to the displayed range, "
        "not a forecast. It makes no allowance for incidents already dated in 2026 that have not yet entered this export.</p>"
        + table
        + '<ul class="structured-list"><li>Shares hold the observed category mix constant. Their scenario values '
        "therefore equal the partial-year shares; they do not extrapolate an earlier trend.</li>"
        "<li>Historical timing scenarios apply each 2021–2025 full-year-to-September-27 ratio to the current count. "
        "Those earlier years come from this same, later snapshot. The ranges cannot measure reporting delays "
        "or serve as probability-calibrated prediction intervals. A prediction interval assigns probability under a fitted model; see <a href='https://otexts.com/fpp3/prediction-intervals.html'>Forecasting: Principles and Practice</a>.</li>"
        "<li>Both a lower and a higher eventual 2026 total remain possible. These scenarios do not establish which "
        "is more likely. A forecast needs evidence about reporting delays and evaluation against historical snapshots.</li></ul>"
        '<p><a href="projections-2026.json">Scenario calculations and contributing record IDs</a></p></section>'
    )
    text = text[:start] + section + text[end:]
    text = text.replace(">Projecting 2026</a>", ">2026: observations and scenarios</a>")
    text = text.replace(
        "Solid trend lines end at 2025. Dashed segments extend to a conditional full-year 2026 projection; the actual partial-year figures appear separately.",
        "The daily 12-month curve passes through annual totals and continues through the 2026 observations. A vertical bar at December 31 spans the numerical year-end scenario range.",
    )
    text = text.replace(
        "2026 projections extrapolate current record counts. They do not estimate all real-world incidents or resolve reporting bias.",
        "The 2026 scenario ranges appear as vertical bars at year-end and in the methods table. They do not adjust for reporting delays or estimate all real-world incidents.",
    )
    methods.write_text(text)
    shutil.copy2(resources / "backfill-20260928.json", site / "backfill-evidence.json")
    return {"current_figures_corrected": changed, "historical_copy_changed": False}
