"""Render verified runs, without carrying snapshot-specific claims into new data."""

from __future__ import annotations

import html
import json
import math
import re
import shutil
import tempfile
from collections import Counter
from datetime import date, datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from typing import Any
from urllib.parse import unquote, urlsplit

from .core import ROOT, check_run, digest, read, safe_extract, save
from .palette import badge

ASSETS = Path(__file__).parent / "assets"
RESOURCES = Path(__file__).parent / "resources"
NAV = [
    ("OPEN_REVIEW.html", "Dashboard"),
    ("candidates.html", "Candidate insights"),
    ("charts.html", "Chart settings"),
    ("published.html", "Published insights"),
    ("methods.html", "Methods & confidence"),
    ("additional.html", "Discoveries"),
    ("monthly.html", "Updates"),
    ("files.html", "Files and evidence"),
]
STATUS = {
    "Supported": "Supported",
    "Needs a numerical or wording update": "Update needed",
    "Unsupported under the stated interpretation": "Unsupported",
    "Not verifiable with the available data or an ambiguous definition": "Unresolved",
}


def e(value: Any) -> str:
    return html.escape(str(value), quote=True)


def link(path: str, label: str) -> str:
    return f'<a href="{e(path)}">{e(label)}</a>'


def structured(value: Any) -> str:
    if isinstance(value, dict):
        return (
            '<dl class="chart-spec">'
            + "".join(
                f'<dt>{e(k.replace("_", " ").capitalize())}</dt><dd>{structured(v)}</dd>'
                for k, v in value.items()
                if v is not None
            )
            + "</dl>"
        )
    if isinstance(value, list):
        return (
            '<ul class="structured-list">'
            + "".join(f"<li>{structured(v)}</li>" for v in value)
            + "</ul>"
        )
    return e(value)


def section(title: str, body: str) -> str:
    return f'<section class="content-section"><h2>{e(title)}</h2>{body}</section>'


def guide_html(source: str) -> str:
    """Render the package guide's headings, paragraphs, lists, and command blocks."""
    output: list[str] = []
    block: list[str] = []
    kind = ""

    def inline(text: str) -> str:
        return re.sub(r"`([^`]+)`", r"<code>\1</code>", e(text))

    def flush() -> None:
        nonlocal kind
        if not block:
            return
        if kind == "code":
            output.append("<pre><code>" + e("\n".join(block)) + "</code></pre>")
        elif kind == "list":
            output.append(
                "<ul>" + "".join("<li>" + inline(x) + "</li>" for x in block) + "</ul>"
            )
        else:
            output.append("<p>" + inline(" ".join(block)) + "</p>")
        block.clear()
        kind = ""

    for line in source.splitlines():
        if not line.strip():
            flush()
            continue
        if line.startswith("# "):
            flush()
            continue
        if line.startswith("## "):
            flush()
            title = line[3:]
            anchor = re.sub(r"[^a-z0-9]+", "-", title.lower()).strip("-")
            output.append(f'<h2 id="{anchor}">{inline(title)}</h2>')
            continue
        next_kind = (
            "code"
            if line.startswith("    ")
            else "list" if line.startswith("- ") else "paragraph"
        )
        if next_kind != kind:
            flush()
        kind = next_kind
        block.append(
            line[4:] if kind == "code" else line[2:] if kind == "list" else line
        )
    flush()
    return '<div class="setup-guide">' + "".join(output) + "</div>"


def table(headers: list[str], rows: list[list[str]]) -> str:
    return (
        '<div class="table-scroll" tabindex="0"><table><thead><tr>'
        + "".join(f'<th scope="col">{e(h)}</th>' for h in headers)
        + "</tr></thead><tbody>"
        + "".join(
            "<tr>" + "".join(f"<td>{cell}</td>" for cell in row) + "</tr>"
            for row in rows
        )
        + "</tbody></table></div>"
    )


def matching_frozen(run: Path) -> bool:
    binding = read(RESOURCES / "september-review.json")
    meta = read(run / "run_metadata.json")
    return (
        meta["input"]["sha256"] == binding["input_sha256"]
        and meta["analysis_date"] == binding["analysis_date"]
        and all(
            digest(run / name) == expected
            for name, expected in binding["files"].items()
        )
    )


class Renderer:
    def __init__(
        self, root: Path, run: Path, out: Path, editorial: Path | None = None
    ) -> None:
        self.root, self.run, self.out = root, run, out
        self.meta = read(run / "run_metadata.json")
        self.day = date.fromisoformat(self.meta["analysis_date"])
        self.candidates = read(run / "candidates.json")
        self.claims = [
            c
            for c in read(run / "claim_audit.json")
            if c.get("empirical") and c.get("publication_status") == "current_tracker"
        ]
        for claim in self.claims:
            if "[live count, shown with its 'as of' date]" in (
                claim.get("proposed_revision") or ""
            ):
                claim["proposed_revision"] = (
                    "The MIT AI Incident Tracker classifies incident records from the AI Incident Database by risk, cause, harm, severity, and other dimensions."
                )
        self.charts = [
            c
            for c in read(run / "chart_outcomes.json")
            if c["chart_id"] in [f"C{i:02}" for i in range(1, 8)] + ["TABLE"]
        ]
        self.calculations = read(run / "calculations.json")
        self.measures = self.calculations["measures"]
        self.counts = {
            "candidates.html": len(self.candidates),
            "charts.html": len([c for c in self.charts if c["chart_id"] != "TABLE"]),
            "published.html": len(self.claims),
        }
        self.model_reviews = (
            {r["item_id"]: r for r in read(editorial / "review.json")["reviews"]}
            if editorial
            else {}
        )
        self.model_drafts = (
            {r["candidate_id"]: r for r in read(editorial / "draft.json")["candidates"]}
            if editorial
            else {}
        )

    def model_note(self, identifier: str) -> str:
        item = self.model_reviews.get(identifier)
        return section("Independent model review", structured(item)) if item else ""

    def annual(self, candidate: dict[str, Any]) -> list[dict[str, Any]]:
        preferred = {
            "IT-C001": "candidate.IT-C001.counts",
            "IT-C002": "candidate.IT-C002.primary",
        }.get(candidate["candidate_id"])
        if not preferred:
            preferred = next(
                (
                    key.rsplit(".", 1)[0]
                    for key in candidate["evidence_ids"]
                    if ".annual." in key
                ),
                None,
            )
        return self.calculations.get("series", {}).get(preferred, {}).get("points", [])

    def trend(self, candidate: dict[str, Any]) -> str:
        points = self.annual(candidate)
        if not points:
            return ""
        count = candidate["candidate_id"] == "IT-C001"
        year = self.day.year
        from .daily_timeline import partial_measure

        partial = partial_measure(self, candidate["candidate_id"], points)
        if partial and partial["window"].get("requested_years") != [year]:
            partial = None
        observed = (
            (partial["numerator"] if count else partial.get("percent"))
            if partial
            else None
        )
        values = [p["numerator"] if count else p["percent"] for p in points]
        ceiling = (
            max([1, *[v for v in values if v is not None], observed or 0]) * 1.15
            if count
            else 100
        )

        def figure(include: bool) -> str:
            slots = len(points) + bool(include and observed is not None)
            xs = [40 + i * 520 / max(1, slots - 1) for i in range(len(points))]
            ys = [170 - (v or 0) * 145 / ceiling for v in values]
            line = " ".join(f"{x:.2f},{y:.2f}" for x, y in zip(xs, ys))
            description = "; ".join(
                f"{p['year']}: {p['numerator']} of {p['denominator']} records"
                for p in points
            )
            if include and partial:
                description += f"; {year} so far: {partial['numerator']} of {partial['denominator']} records; reporting incomplete"
            svg = f'<svg viewBox="0 0 610 215" role="img" aria-label="{e(description)}"><polyline points="{line}" fill="none" stroke="#347985" stroke-width="3"/>'
            for point, x, y in zip(points, xs, ys):
                label = (
                    str(point["numerator"])
                    if count
                    else (
                        "—" if point["percent"] is None else f"{point['percent']:.2f}%"
                    )
                )
                svg += f'<circle cx="{x}" cy="{y}" r="3" fill="#347985"/><text x="{x}" y="192" text-anchor="middle" class="axis-label">{point["year"]}</text><text x="{x}" y="{y-9}" text-anchor="middle" class="axis-label">{label}</text>'
            if include and observed is not None:
                x, y = 560, 170 - observed * 145 / ceiling
                label = f"{observed:,.0f}" if count else f"{observed:.2f}%"
                boundary = (xs[-1] + x) / 2
                svg += f'<g data-observed-partial="{candidate["candidate_id"]}" data-observed-value="{observed}"><line x1="{boundary}" x2="{boundary}" y1="25" y2="170" stroke="#94afaf" stroke-width="1" stroke-dasharray="2 5"/><circle cx="{x}" cy="{y}" r="5" fill="#786886"/><text x="{x}" y="{y-10}" text-anchor="middle" class="axis-label">{label}</text><text x="{x}" y="192" text-anchor="middle" class="axis-label">{year} so far</text></g>'
            attribute = (
                f' data-year-view="{"partial" if include else "complete"}"'
                if observed is not None
                else ""
            )
            return f'<figure class="finding-chart" data-timeline="{candidate["candidate_id"]}"{attribute}>{svg}</svg></figure>'

        body = figure(False) + (figure(True) if observed is not None else "")
        if partial and observed is not None:
            body += f'<div data-year-view="partial"><p><strong>{year} so far:</strong> {partial["numerator"]:,} of {partial["denominator"]:,} records. The year is unfinished.</p><p>The curve includes records available through {e(self.day.isoformat())}, counted over the preceding 12 months at each date. Reporting delays and later additions limit comparisons. <a href="methods.html#section-partial-year">Unadjusted pace scenarios and limits</a>.</p></div>'
        body += table(
            ["Year", "Records", "All records", "Share"],
            [
                [
                    str(p["year"]),
                    str(p["numerator"]),
                    str(p["denominator"]),
                    "—" if p["percent"] is None else f"{p['percent']:.2f}%",
                ]
                for p in points
            ],
        )
        return body

    def partial_year_methods(self) -> str:
        year = self.day.year
        elapsed = (self.day - date(year, 1, 1)).days + 1
        days = (date(year + 1, 1, 1) - date(year, 1, 1)).days
        rows = []
        for candidate in self.candidates:
            from .daily_timeline import partial_measure

            partial = partial_measure(
                self, candidate["candidate_id"], self.annual(candidate)
            )
            if not partial or partial["window"].get("requested_years") != [year]:
                continue
            count = candidate["candidate_id"] == "IT-C001"
            recorded = (
                f"{partial['numerator']:,} records"
                if count
                else f"{partial['percent']:.2f}% ({partial['numerator']} of {partial['denominator']})"
            )
            scenario = (
                f"≈{partial['numerator'] * days / elapsed:,.0f} records"
                if count
                else f"{partial['percent']:.2f}% (unchanged mix)"
            )
            projection = self.timelines.get(candidate["candidate_id"], {}).get(
                "projection"
            )
            bounds = (
                projection["range"]["bounds"]["counts" if count else "share"]
                if projection
                else None
            )
            span = (
                (
                    f"{math.floor(bounds[0]):,}–{math.ceil(bounds[1]):,}"
                    if count
                    else f"{bounds[0]:.1f}–{bounds[1]:.1f}%"
                )
                if bounds
                else "—"
            )
            rows.append([e(candidate["title"]), recorded, scenario, span])
        return (
            '<section class="content-section"><span id="section-projecting-2026"></span><h2 id="section-partial-year">Year-end scenario ranges</h2>'
            "<p>Historical curves count records in the preceding 12 calendar months at daily intervals. Each December 31 point equals the annual total. The same daily curve continues through the current-year observations, using the same 12-month window. The vertical bar at December 31 spans the numerical year-end scenario range. Calendar-year-to-date figures remain separate from rolling 12-month values. Earlier calendar years can still gain records through reporting and later additions.</p>"
            "<p>The range spans the calendar-pace estimate and scenarios that apply earlier years’ full-year-to-same-cutoff ratios to current counts. It summarizes sensitivity to those timing assumptions. Reporting delays, later backfill, classification changes, and changes in collection coverage remain unmodeled. The bounds have no calibrated probability coverage. Scenario inputs and bounds are in <a href='daily-timeline.json'>daily-timeline.json</a>.</p>"
            + table(
                ["Finding", "Recorded so far", "Calendar pace", "Scenario range"], rows
            )
            + "</section>"
        )

    def page(self, name: str, title: str, body: str, active: str) -> None:
        nav = ""
        for i, (url, label) in enumerate(NAV):
            count = self.counts.get(url)
            marker = (
                f'<span class="nav-index" aria-hidden="true">{["", "I", "II", "III"][i]}</span>'
                if i in (1, 2, 3)
                else ""
            )
            nav += (
                f'<a href="{url}"'
                + (' aria-current="page"' if url == active else "")
                + f'>{marker}<span class="nav-text">{label}</span>'
                + (f'<b class="nav-count">{count}</b>' if count is not None else "")
                + "</a>"
            )
        logo = (ASSETS / "brand-mark.svg").read_text() + (
            ASSETS / "brand-lettering.svg"
        ).read_text()
        stamp = self.day.strftime("%b %d, %Y").replace(" 0", " ")
        text = f"""<!doctype html><html lang="en-US"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{e(title)} | Arcolens</title><link rel="stylesheet" href="dashboard.css"><script src="review.js" defer></script></head><body class="detail-page"><a class="skip" href="#main">Skip to content</a><div class="shell"><aside class="sidebar"><a class="brand" href="OPEN_REVIEW.html" aria-label="Arcolens dashboard">{logo}</a><nav aria-label="Review sections">{nav}</nav></aside><div class="workspace"><header class="appbar"><span class="appbar-path">{e(dict(NAV).get(active, 'Evidence'))}</span><div class="appbar-actions"><span class="snapshot-tag">Snapshot: <strong>{stamp}</strong></span></div></header><main id="main"><article class="reading-page"><header class="page-head"><h1>{e(title)}</h1></header>{body}</article><footer><span>Source: Arcola export, {stamp}. Findings describe this dataset.</span><a href="files.html">Evidence and sources</a></footer></main></div></div><p id="copy-feedback" role="status" aria-live="polite"></p></body></html>"""
        (self.out / name).write_text(text, encoding="utf-8")

    def figures(self, ids: list[str]) -> str:
        rows = []
        for key in dict.fromkeys(ids):
            m = self.measures[key]
            pct = "—" if m.get("percent") is None else f"{m['percent']:.2f}%"
            unit = m.get("definition", {}).get("denominator", "incidents")
            rows.append(
                [
                    e(key),
                    f"{m['numerator']:,}",
                    f"{m['denominator']:,}",
                    pct,
                    e(unit),
                    link("downloads/run/" + m["numerator_ids_ref"], "Contributing IDs"),
                ]
            )
        return table(
            [
                "Calculation",
                "Numerator",
                "Denominator",
                "Share",
                "Denominator unit",
                "Evidence",
            ],
            rows,
        )

    def current_pages(self) -> None:
        rows = {c["candidate_id"]: c for c in self.candidates}
        chart_sections = ""
        for chart in self.charts:
            items = [rows[i] for i in chart["candidate_ids"] if i in rows]
            body = (
                "<p>"
                + e(chart["decision"])
                + "</p>"
                + table(
                    ["Candidate", "Proposed finding"],
                    [
                        [
                            link(f"finding-{c['candidate_id']}.html", c["title"]),
                            e(c["proposed_website_text"]),
                        ]
                        for c in items
                    ],
                )
            )
            chart_sections += section(chart["name"], body)
        self.page(
            "candidates.html", "Candidate insights", chart_sections, "candidates.html"
        )
        self.page(
            "charts.html",
            "Chart settings",
            "".join(
                section(
                    c["title"],
                    "<p>"
                    + link(f"finding-{c['candidate_id']}.html", "Open finding")
                    + "</p>"
                    + structured(c["chart_configuration"]),
                )
                for c in self.candidates
            ),
            "charts.html",
        )
        for c in self.candidates:
            proposed = self.model_drafts.get(c["candidate_id"], {}).get(
                "suggested_wording", c["proposed_website_text"]
            )
            body = section(
                "Suggested wording",
                f'<p id="wording">{e(proposed)}</p><button type="button" data-copy="wording">Copy text</button>',
            )
            body += self.model_note(c["candidate_id"])
            trend = self.trend(c)
            if trend:
                body += section("Annual figures", self.year_control() + trend)
            body += section("Chart settings", structured(c["chart_configuration"]))
            body += section(
                "Confidence and limitations",
                structured(
                    {
                        "Calculation": c["calculation_confidence"],
                        "Interpretation": c["interpretation_confidence"],
                        "Limitations": c["caveats"],
                        "Selection": c["eligibility"],
                    }
                ),
            )
            body += section("Figures and evidence", self.figures(c["evidence_ids"]))
            body += section("Sensitivity checks", structured(c["robustness"]))
            self.page(
                f"finding-{c['candidate_id']}.html", c["title"], body, "candidates.html"
            )
        audit_rows = []
        audit_order = {
            "Supported": 0,
            "Unresolved": 1,
            "Update needed": 2,
            "Unsupported": 3,
        }
        for c in sorted(
            self.claims,
            key=lambda row: audit_order.get(
                STATUS.get(row["status"], row["status"]), 4
            ),
        ):
            status = STATUS.get(c["status"], c["status"])
            audit_rows.append(
                [
                    link(f"claim-{c['claim_id']}.html", c["exact_wording"]),
                    badge(status),
                    e(c["reason"]),
                ]
            )
            body = section(
                "Published wording",
                "<blockquote>"
                + e(c["exact_wording"])
                + "</blockquote><p>"
                + link(c["source_url"], "Published source")
                + "</p>",
            )
            body += section(
                "Assessment",
                "<p>"
                + badge(status)
                + "</p>"
                + structured(
                    {
                        "Reason": c["reason"],
                        "Interpretation": c.get("interpretation"),
                        "Proposed revision": c.get("proposed_revision"),
                        "Caveats": c.get("editorial_flags", []),
                    }
                ),
            )
            body += section("Calculation evidence", self.figures(c["evidence_ids"]))
            body += self.model_note(c["claim_id"])
            self.page(
                f"claim-{c['claim_id']}.html", c["claim_id"], body, "published.html"
            )
        self.page(
            "published.html",
            "Published insights",
            "<p>Numerical assessments use this export and the pinned published wording. The latest source check is linked below; changed wording requires review before updating the registry.</p><p>"
            + link("source-check.html", "Latest source check")
            + "</p>"
            + table(["Published statement", "Assessment", "Reason"], audit_rows),
            "published.html",
        )
        self.page(
            "methods.html",
            "Methods & confidence",
            "<p>These are descriptive findings about reported, classified incident records. Reporting coverage, changing classification methods, and missing source evidence limit generalization.</p>"
            + section(
                "Analysis method",
                "<p>"
                + link("downloads/methodology.md", "Read the complete method")
                + "</p>",
            )
            + self.partial_year_methods()
            + section(
                "Model review",
                "<p>"
                + link("model-review.html", "Review status and model suggestions")
                + "</p>",
            ),
            "methods.html",
        )
        self.page(
            "additional.html",
            "Discoveries",
            section(
                "Current selection",
                "<p>"
                + link(
                    "downloads/run/discovery_ledger.json",
                    "Full discovery and selection ledger",
                )
                + "</p>",
            )
            + section(
                "Earlier research",
                "<p>The September review preserves the earlier source checks, corrections, data-quality findings, and historical comparisons. Those findings retain their original dates and are not silently applied to this export.</p><p>"
                + link(
                    "history/september/OPEN_REVIEW.html", "Open the September review"
                )
                + "</p>",
            ),
            "additional.html",
        )
        totals = self.meta["result_counts"]
        home = (
            '<section class="metric-strip">'
            + "".join(
                f'<a class="metric {theme}" href="{url}"><span class="metric-label">{label}</span><strong>{value:,}</strong></a>'
                for label, value, url, theme in [
                    ("Records", totals["records"], "files.html", "mint"),
                    ("Candidates", len(self.candidates), "candidates.html", "blue"),
                    (
                        "Published statements",
                        len(self.claims),
                        "published.html",
                        "coral",
                    ),
                    ("Chart views", self.counts["charts.html"], "charts.html", "lilac"),
                ]
            )
            + "</section>"
        )
        home += section(
            "Findings by chart",
            table(
                ["Chart", "Candidates"],
                [
                    [link("candidates.html", c["name"]), str(len(c["candidate_ids"]))]
                    for c in self.charts
                ],
            ),
        )
        annual = [c for c in self.candidates if self.annual(c)]
        annual.sort(key=lambda c: c["candidate_id"] != "IT-C001")
        if annual:
            controls = (
                '<div class="trend-select" role="group" aria-label="Choose the trend shown">'
                + "".join(
                    f'<button type="button" data-trend="{e(c["candidate_id"])}">{e("All records" if c["candidate_id"] == "IT-C001" else c["title"])}</button>'
                    for c in annual
                )
                + "</div>"
            )
            home += section(
                "Trends",
                self.year_control()
                + controls
                + "".join(
                    f'<div data-trend-pane="{e(c["candidate_id"])}">{self.trend(c)}<p>{link("finding-" + c["candidate_id"] + ".html", "Open finding")}</p></div>'
                    for c in annual
                ),
            )
        home += section(
            "Published statements",
            structured(
                dict(Counter(STATUS.get(c["status"], c["status"]) for c in self.claims))
            ),
        )
        home += (
            '<div class="article-links">'
            + link("model-review.html", "Model review")
            + link("source-check.html", "Latest source check")
            + link("history/september/OPEN_REVIEW.html", "September review")
            + "</div>"
        )
        self.page(
            "OPEN_REVIEW.html", self.day.strftime("%B %Y"), home, "OPEN_REVIEW.html"
        )
        save(
            self.out / "review-data.json",
            {
                "run_id": self.run.name,
                "analysis_date": self.day.isoformat(),
                "records": totals["records"],
                "candidates": self.candidates,
                "claims": self.claims,
                "source_hashes": {"input": self.meta["input"]["sha256"]},
            },
        )

    def delivery_pages(self, editorial: Path | None, refresh: Path | None) -> None:
        self.page(
            "files.html",
            "Files and evidence",
            section(
                "Your reports",
                table(
                    ["What you want to review", "Read online", "Download"],
                    [
                        [
                            "Candidate insights with suggested wording, chart settings, confidence, and caveats",
                            link("candidates.html", "Review candidate insights"),
                            link(
                                "downloads/candidate-insights.md",
                                "Download candidate report",
                            ),
                        ],
                        [
                            "Checks of published insights and proposed corrections",
                            link("published.html", "Review published insights"),
                            link(
                                "downloads/published-insight-audit.md",
                                "Download published-insight audit",
                            ),
                        ],
                        [
                            "Chart configurations and display limits",
                            link("charts.html", "Open chart settings"),
                            link(
                                "downloads/run/candidates.json",
                                "Download candidate data (JSON)",
                            ),
                        ],
                    ],
                ),
            )
            + section(
                "Run your next export",
                "<p>The package contains everything needed to reproduce this review. Follow the setup guide to analyze a new CSV.</p><p>"
                + link(
                    "downloads/arcolens-runner.zip",
                    "Download the complete runnable package",
                )
                + "</p><p>"
                + link("setup.html", "Open the setup guide")
                + "</p><p>For the hosted monthly review, "
                + link("monthly.html", "send your next export")
                + ".</p>",
            )
            + section(
                "Check the evidence",
                table(
                    ["Evidence", "Download"],
                    [
                        [
                            "Calculations and contributing incident IDs",
                            link(
                                "downloads/analysis-run.zip",
                                "Download verified analysis",
                            ),
                        ],
                        [
                            "Input CSV",
                            link("downloads/input.csv", "Download the Arcola export"),
                        ],
                        [
                            "Published-insight audit data",
                            link(
                                "downloads/run/claim_audit.json",
                                "Download audit data (JSON)",
                            ),
                        ],
                        [
                            "Methods",
                            link("downloads/methodology.md", "Read the methodology"),
                        ],
                        [
                            "Installation guide",
                            link(
                                "downloads/START_HERE.md", "Download the instructions"
                            ),
                        ],
                    ],
                ),
            )
            + section(
                "Earlier work",
                "<p>"
                + link(
                    "history/september/SIMON_BRIEF.pdf",
                    "Original September brief (PDF)",
                )
                + "</p><p>"
                + link(
                    "history/september/files.html",
                    "September archive",
                )
                + "</p>",
            ),
            "files.html",
        )
        guide = (ROOT / "delivery/START_HERE.md").read_text()
        self.page(
            "setup.html",
            "Setup",
            "<p>"
            + link(
                "downloads/arcolens-runner.zip",
                "Download the complete runnable package",
            )
            + "</p>"
            + guide_html(guide),
            "files.html",
        )
        from .monitor import page_body

        self.page("monthly.html", "Updates", page_body(self.monitoring), "monthly.html")
        if editorial:
            status = read(editorial / "status.json")
            model_body = (
                "<p>Model output is a proposal for human review. A completed model review does not establish classification accuracy or authorize publication to the tracker.</p>"
                + structured(status)
            )
            for filename in ["draft.json", "review.json"]:
                if (editorial / filename).exists():
                    model_body += section(
                        filename.removesuffix(".json").capitalize(),
                        structured(read(editorial / filename)),
                    )
        else:
            model_body = "<p>No completed model review is attached to this delivery. Findings retain their recorded programmatic or session-reviewed status. Earlier model reviews must not be treated as approving new data or expanded evidence.</p>"
        self.page("model-review.html", "Model review", model_body, "methods.html")
        source = "<p>No new source check accompanied this build. The audit uses captured wording whose retrieval dates are recorded in the evidence.</p>"
        if refresh and (refresh / "claim_refresh_report.json").exists():
            source = structured(read(refresh / "claim_refresh_report.json"))
        self.page("source-check.html", "Latest source check", source, "published.html")

    def year_control(self) -> str:
        return ""


class LinkCheck(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.links: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        for key, value in attrs:
            if key in ("href", "src") and value:
                self.links.append(value)


def verify_site(site: Path) -> dict[str, Any]:
    broken = []
    pages = [
        p for p in site.rglob("*.html") if "downloads" not in p.relative_to(site).parts
    ]
    for page in pages:
        parser = LinkCheck()
        parser.feed(page.read_text())
        for url in parser.links:
            parts = urlsplit(url)
            if (
                parts.scheme
                or parts.netloc
                or not parts.path
                or parts.path.startswith("/")
            ):
                continue
            target = (page.parent / unquote(parts.path)).resolve()
            if not target.is_relative_to(site.resolve()) or not target.exists():
                broken.append(f"{page.relative_to(site)}: {url}")
    if broken:
        raise ValueError("Broken or escaping review links: " + repr(broken[:12]))
    return {"status": "passed", "html_pages": len(pages), "local_links_resolve": True}


def build(
    run: Path,
    output: Path,
    package: Path,
    root: Path = ROOT,
    editorial: Path | None = None,
    refresh: Path | None = None,
    context: Path | None = None,
) -> dict[str, Any]:
    run, output, root = run.resolve(), output.resolve(), root.resolve()
    check_run(run, root)
    retained_review = None
    if editorial is None:
        from .review_baseline import load as load_review_baseline

        retained_review = load_review_baseline(run, RESOURCES)
        if retained_review:
            editorial = retained_review / "editorial"
            context = retained_review / "editorial-context.json"
            if refresh is None and (retained_review / "source-check").is_dir():
                refresh = retained_review / "source-check"
    if editorial and retained_review is None:
        from .check_and_publish import verify_editorial

        verify_editorial(editorial, run, context)
    # Attach a new review separately without replacing the approved presentation
    # of unchanged evidence. A different export still gets freshly rendered pages.
    preserve = matching_frozen(run)
    if output.exists():
        raise ValueError(
            "Use a new output directory; earlier deliveries are preserved."
        )
    binding = read(RESOURCES / "september-review.json")
    if digest(RESOURCES / "september-review.zip") != binding["archive_sha256"]:
        raise ValueError("Preserved presentation archive changed")
    output.mkdir(parents=True)
    site = output / "simon-review"
    site.mkdir()
    with tempfile.TemporaryDirectory() as temp:
        safe_extract(RESOURCES / "september-review.zip", Path(temp))
        frozen = Path(temp) / "simon-review"
        shutil.copytree(frozen, site / "history/september")
        if preserve:
            shutil.copytree(frozen, site, dirs_exist_ok=True)
    for path in ASSETS.iterdir():
        if path.is_file():
            shutil.copy2(path, site / path.name)
    if not preserve:
        shutil.copy2(ASSETS / "current-review.js", site / "review.js")
    renderer = Renderer(root, run, site, editorial)
    renderer.review_baseline = retained_review
    from .daily_timeline import build_series, update_charts, write_evidence

    from .monitor import snapshot

    renderer.monitoring = snapshot(root, renderer.meta["analysis_date"])
    if refresh and (refresh / "claim_refresh_report.json").is_file():
        source_check = read(refresh / "claim_refresh_report.json")
        source_summary = source_check["summary"]
        renderer.monitoring["source_check"] = {
            "at": source_check["generated_at_utc"],
            "summary": {
                key: value
                for key, value in source_summary.items()
                if isinstance(value, int) and not isinstance(value, bool)
            },
        }
    if renderer.model_reviews:
        renderer.monitoring["model_review"] = {
            "candidates": sum(
                c["candidate_id"] in renderer.model_reviews for c in renderer.candidates
            ),
            "claims": sum(
                c["claim_id"] in renderer.model_reviews for c in renderer.claims
            ),
        }
    renderer.timelines = build_series(renderer)
    if not preserve:
        renderer.current_pages()
    renderer.delivery_pages(editorial, refresh)
    from .focused_review import prepare as prepare_focused_review

    prepare_focused_review(renderer)
    if preserve:
        from .partial_year import update_september

        update_september(site, RESOURCES)
    update_charts(site, renderer.timelines)
    write_evidence(site, renderer.timelines, renderer.meta)
    from .forecast import methods as forecast_methods

    forecast_methods(site, renderer.timelines)
    if preserve and editorial:
        methods = site / "methods.html"
        text = methods.read_text()
        old = "Real model drafting and a separate model review were executed for the earlier eleven-candidate set. The two new profiles have session review and independent code verification, but have not had a new paid model review. Human selection is still required; raw model records and prior runs remain preserved."
        if text.count(old) != 1:
            raise ValueError(
                "The preserved review-status paragraph changed; inspect it before replacing it."
            )
        status = read(editorial / "status.json")
        counts = status["review_dispositions"]
        updated = (
            f"The current model review covers all {status['reviewed_candidates']} findings and "
            f"{status['reviewed_published_claims']} published statements. The independent reviewer "
            f"marked {counts['pass']} as passing and {counts['revise']} for revision. "
            "Human selection is still required; source classification accuracy remains unverified. "
            "Raw model records and earlier reviews are preserved."
        )
        text = text.replace(old, e(updated))
        text = text.replace(
            'href="downloads/FINAL_VALIDATION.json">Final run validation',
            'href="downloads/run/validation.json">Current run validation',
        )
        text = text.replace(
            'href="downloads/final_fable_review_adjudication.md">Review adjudication record',
            'href="model-review.html">Current model review',
        )
        methods.write_text(text)
    from .workbench import install

    install(renderer)
    from .palette import install as install_palette

    install_palette(site)
    from .presentation import install as install_presentation

    install_presentation(site)
    from .copyedit import install as install_copyedit

    install_copyedit(site)
    from .focused_review import apply as apply_focused_review

    apply_focused_review(renderer)
    from .guide import install as install_guide

    install_guide(renderer)
    downloads = site / "downloads"
    downloads.mkdir(exist_ok=True)
    shutil.copy2(package, downloads / "arcolens-runner.zip")
    shutil.copytree(run, downloads / "run")
    shutil.copy2(
        root / renderer.meta["input"]["snapshot_path"], downloads / "input.csv"
    )
    shutil.copy2(root / "docs/methodology.md", downloads / "methodology.md")
    shutil.copy2(ROOT / "delivery/START_HERE.md", downloads / "START_HERE.md")
    shutil.make_archive(str(downloads / "analysis-run"), "zip", run)
    verification = verify_site(site)
    record = {
        "schema_version": 1,
        "presentation_version": "arcolens-delivery-27",
        "run_id": run.name,
        "input_sha256": renderer.meta["input"]["sha256"],
        "analysis_date": renderer.meta["analysis_date"],
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "preserved_september_presentation": preserve,
        "verification": verification,
        "files": {
            "simon-review/" + p.relative_to(site).as_posix(): digest(p)
            for p in sorted(site.rglob("*"))
            if p.is_file()
        },
    }
    save(output / "DELIVERY_MANIFEST.json", record)
    return record
