"""A five-stop guide to the current deliverables, regenerated with each export."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .render import Renderer


def install(renderer: Renderer) -> None:
    site = renderer.out
    candidates = [
        item
        for item in renderer.candidates
        if (site / f"finding-{item['candidate_id']}.html").is_file()
    ]
    example = next(
        (item for item in candidates if item["candidate_id"] == "IT-C003"),
        candidates[0] if candidates else None,
    )
    finding = (
        f"finding-{example['candidate_id']}.html" if example else "candidates.html"
    )
    configured = getattr(renderer, "monitoring", {}).get("configured", False)
    steps = [
        {
            "title": "Candidate insights",
            "page": "candidates.html",
            "target": "candidates",
            "text": "Start with the top findings. Open one to read the suggested wording and check its evidence.",
            "link": [
                "downloads/candidate-insights.md",
                "Download the candidate report",
            ],
        },
        {
            "title": "Chart settings",
            "page": finding,
            "heading": "Chart settings",
            "text": "Use these filters to show the finding on the tracker. Check whether the chart supports the required dates and categories.",
            "link": ["charts.html", "See all chart settings"],
        },
        {
            "title": "Confidence and bias",
            "page": finding,
            "heading": "Confidence and limitations",
            "text": "Check how the finding was calculated and where its interpretation depends on incomplete reporting or unverified labels.",
            "link": ["methods.html", "Read the methods"],
        },
        {
            "title": "Suggested wording",
            "page": finding,
            "heading": "Suggested wording",
            "text": "Copy the draft for the tracker. Keep the dates, denominator, and qualifications when you edit it.",
            "link": ["files.html", "Get the reports and runnable code"],
        },
        {
            "title": "The monthly review",
            "page": "monthly.html",
            "mode": "monitor",
            "heading": (
                "What runs automatically"
                if configured
                else "Recurring updates are not configured on this computer"
            ),
            "text": (
                "Add your next CSV to the shared inbox. Monthly checks refresh the findings when new data arrives and flag published insights that need updating. You and Peter choose what to publish."
                if configured
                else "Run the next CSV with the included code to refresh the findings and audit published insights. Follow Setup to arrange monthly checks on this computer."
            ),
            "link": ["published.html", "Review the published-insight audit"],
        },
    ]
    if not example:
        for step in steps[1:4]:
            step.pop("heading", None)
            step["target"] = "candidates"
            step["text"] = (
                "This run selected no candidate findings. The candidate report records the selection results; settings, caveats, and wording appear here when a finding is selected."
            )
    config = json.dumps({"steps": steps}, ensure_ascii=False).replace("<", "\\u003c")
    for path in site.glob("*.html"):
        content = path.read_text()
        if "<main " not in content or 'id="arcolens-guide-config"' in content:
            continue
        content = content.replace(
            "</head>",
            '<link rel="stylesheet" href="guide.css">'
            '<script src="guide.js" defer></script></head>',
            1,
        )
        content = content.replace(
            "</body>",
            '<script type="application/json" id="arcolens-guide-config">'
            + config
            + "</script></body>",
            1,
        )
        path.write_text(content)
