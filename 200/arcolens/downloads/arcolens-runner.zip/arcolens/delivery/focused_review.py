"""Readable candidate selection over verified, unchanged analysis artifacts."""

from __future__ import annotations

from copy import deepcopy
from html.parser import HTMLParser
import re
from typing import TYPE_CHECKING, Any
from urllib.parse import urlsplit

from .core import digest, read, save
from .render import RESOURCES, e, link, section, structured

if TYPE_CHECKING:
    from .render import Renderer


def disclosure(title: str, body: str) -> str:
    return (
        '<details class="review-detail"><summary>'
        + e(title)
        + '</summary><div class="review-detail-body">'
        + body
        + "</div></details>"
    )


def source_label(url: str) -> str:
    slug = urlsplit(url).path.rstrip("/").rsplit("/", 1)[-1]
    labels = {
        "ai-incident-tracker": "Tracker home",
        "incident-timeline": "Incident Timeline",
        "incident-overview": "Incident Overview",
        "incident-view": "Incident View",
        "natsec-incident-view": "National Security Incident View",
        "natsec-impact-framework": "National Security Impact Framework",
        "harm-taxonomy": "Harm Taxonomy",
    }
    return labels.get(slug, slug.replace("-", " ").capitalize() or urlsplit(url).netloc)


def web_url(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    parts = urlsplit(value)
    return value if parts.scheme in {"https", "http"} and parts.netloc else None


def sources_for(candidate: dict[str, Any], charts: list[dict]) -> list[dict]:
    ids = list(candidate.get("chart_ids", []))
    primary = candidate.get("chart_configuration", {}).get("primary_chart")
    if primary in ids:
        ids.remove(primary)
        ids.insert(0, primary)
    by_id = {chart["chart_id"]: chart for chart in charts}
    sources = []
    for identifier in ids:
        chart = by_id.get(identifier)
        url = web_url(chart.get("source_url")) if chart else None
        if url:
            sources.append(
                {
                    "chart_id": identifier,
                    "page": source_label(url),
                    "chart": chart["name"],
                    "url": url,
                    "primary": identifier == primary,
                }
            )
    return sources


def source_html(sources: list[dict]) -> str:
    if not sources:
        return "<p>No existing aggregate chart matches this finding. Use its supporting table.</p>"
    return (
        '<ul class="tracker-sources">'
        + "".join(
            "<li>"
            + link(source["url"], source["page"])
            + ' <span class="source-arrow" aria-hidden="true">→</span> <span class="source-chart">'
            + e(source["chart"])
            + "</span></li>"
            for source in sources
        )
        + "</ul>"
    )


def prepare(renderer: Renderer) -> dict[str, Any]:
    data = read(renderer.out / "review-data.json")
    if getattr(renderer, "review_baseline", None):
        data = read(renderer.review_baseline / "review-data.json")
        data["run_id"] = renderer.run.name
    selection = read(RESOURCES / "review-selection.json")
    if len(selection["priorities"]) > 10:
        raise ValueError("Choose at most ten top findings.")
    current_binding = {
        "input_sha256": renderer.meta["input"]["sha256"],
        "analysis_date": renderer.day.isoformat(),
        "files": {
            name: digest(renderer.run / name) for name in selection["snapshot"]["files"]
        },
    }
    bound = current_binding == selection["snapshot"]
    recorded_hashes = data.get("source_hashes", {})
    matching_source = recorded_hashes.get("input") == current_binding[
        "input_sha256"
    ] or all(
        recorded_hashes.get(name) == expected
        for name, expected in current_binding["files"].items()
    )
    curated = (
        {c["candidate_id"]: c for c in data.get("candidates", [])}
        if matching_source
        and data.get("analysis_date") == renderer.day.isoformat()
        and (bound or data.get("presentation_binding") == current_binding)
        else {}
    )
    candidates = []
    for original in renderer.candidates:
        candidate = {**original, **curated.get(original["candidate_id"], {})}
        candidate["source_pages"] = sources_for(candidate, renderer.charts)
        candidate["display_title"] = candidate.get("display_title", candidate["title"])
        candidate["is_shortlisted"] = False
        candidate["key_limitation"] = next(
            iter(candidate.get("review_notes") or candidate.get("caveats") or []), ""
        )
        draft = renderer.model_drafts.get(candidate["candidate_id"])
        if draft:
            candidate["proposed_website_text"] = draft["suggested_wording"]
        candidates.append(candidate)
    selected = []
    for choice in selection["priorities"]:
        # Discovery IDs can change between runs. Match the finding's meaning, not its ID.
        matches = [
            c
            for c in candidates
            if c["title"].startswith(choice["title_prefix"]) and not c["is_shortlisted"]
        ]
        if len(matches) != 1:
            continue
        candidate = matches[0]
        candidate["is_shortlisted"] = True
        candidate["priority_reason"] = choice["reason"]
        if bound and candidate["candidate_id"] == choice["candidate_id"]:
            evidence_ids = choice["evidence_ids"]
            if not all(
                identifier in candidate["evidence_ids"]
                and identifier in renderer.measures
                for identifier in evidence_ids
            ):
                raise ValueError(
                    "Selected wording has unresolved calculation evidence."
                )
            candidate["summary"] = choice["summary"]
            candidate.setdefault("audit_original_title", candidate["display_title"])
            candidate["display_title"] = choice["display_title"]
            candidate["key_limitation"] = choice["limitation"]
            candidate["wording_evidence_ids"] = evidence_ids
            candidate.setdefault(
                "audit_original_wording", candidate["proposed_website_text"]
            )
            candidate["scope_note"] = choice.get("scope_note")
            if choice.get("chart_fit"):
                candidate["chart_fit"] = choice["chart_fit"]
            if choice.get("review_notes"):
                candidate.setdefault(
                    "audit_original_notes", candidate.get("review_notes", [])
                )
                candidate["review_notes"] = choice["review_notes"]
            if choice.get("chart_configuration_overrides"):
                candidate.setdefault(
                    "audit_original_chart_configuration",
                    deepcopy(candidate["chart_configuration"]),
                )
                candidate["chart_configuration"] = {
                    **candidate["chart_configuration"],
                    **choice["chart_configuration_overrides"],
                }
            candidate["proposed_website_text"] = choice["wording"]
            candidate["presentation_override"] = True
        else:
            candidate["summary"] = candidate["proposed_website_text"]
            candidate["wording_evidence_ids"] = candidate["evidence_ids"]
        selected.append(candidate)
    data.update(
        candidates=candidates,
        shortlist=[c["candidate_id"] for c in selected],
        shortlist_scope="Editorial priorities among the available findings",
        presentation_binding=current_binding,
    )
    from .review_copy import prepare as prepare_copy

    prepare_copy(data, renderer, RESOURCES)
    save(renderer.out / "review-data.json", data)
    return data


class Sections(HTMLParser):
    """Locate complete sections without changing surrounding approved markup."""

    def __init__(self, text: str) -> None:
        super().__init__(convert_charrefs=False)
        self.text = text
        self.offsets = [0] + [m.end() for m in re.finditer("\n", text)]
        self.stack: list[int] = []
        self.ranges: list[tuple[int, int]] = []
        self.feed(text)

    def position(self) -> int:
        line, column = self.getpos()
        return self.offsets[line - 1] + column

    def handle_starttag(self, tag, attrs):
        if tag == "section":
            self.stack.append(self.position())

    def handle_endtag(self, tag):
        if tag == "section" and self.stack:
            self.ranges.append((self.stack.pop(), self.position() + len("</section>")))


def edit_section(text: str, title: str, transform) -> str:
    matches = []
    for start, end in Sections(text).ranges:
        chunk = text[start:end]
        heading = re.search(r"<h2\b[^>]*>" + re.escape(title) + "</h2>", chunk)
        if heading:
            matches.append((start, end))
    if not matches:
        return text
    start, end = min(matches, key=lambda pair: pair[1] - pair[0])
    return text[:start] + transform(text[start:end]) + text[end:]


def fold(section_html: str) -> str:
    if 'class="review-detail"' in section_html:
        return section_html
    opening = section_html.index(">") + 1
    heading = re.search(r"<h2\b[^>]*>.*?</h2>", section_html, re.S)
    if not heading:
        return section_html
    return (
        section_html[:opening]
        + '<details class="review-detail"><summary>'
        + heading[0]
        + '</summary><div class="review-detail-body">'
        + section_html[opening : heading.start()]
        + section_html[heading.end() : -len("</section>")]
        + "</div></details></section>"
    )


def apply(renderer: Renderer) -> None:
    """Add selection and attribution without replacing the current app or its charts."""
    data = read(renderer.out / "review-data.json")
    candidates = data["candidates"]
    selected = [
        c
        for identifier in data["shortlist"]
        for c in candidates
        if c["candidate_id"] == identifier
    ]
    by_id = {c["candidate_id"]: c for c in candidates}
    for candidate in candidates:
        identifier = candidate["candidate_id"]
        page = renderer.out / f"finding-{identifier}.html"
        if not page.exists():
            continue
        text = page.read_text()
        if candidate["is_shortlisted"]:
            text = re.sub(
                r"<h1>.*?</h1>",
                lambda _: "<h1>" + e(candidate["display_title"]) + "</h1>",
                text,
                count=1,
                flags=re.S,
            )
            text = re.sub(
                r"<title>.*?</title>",
                lambda _: "<title>"
                + e(candidate["display_title"])
                + " | Arcolens</title>",
                text,
                count=1,
                flags=re.S,
            )
        text = re.sub(
            r'(<p\b[^>]*id="wording[^"]*"[^>]*>).*?(</p>)',
            lambda m: m[1] + e(candidate["proposed_website_text"]) + m[2],
            text,
            count=1,
            flags=re.S,
        )
        attribution = section(
            "Affected tracker page", source_html(candidate["source_pages"])
        )
        if candidate.get("chart_fit"):
            attribution += '<p class="chart-fit">' + e(candidate["chart_fit"]) + "</p>"
        if candidate["is_shortlisted"]:
            attribution = (
                '<p class="key-limitation"><strong>Keep in view:</strong> '
                + e(candidate["key_limitation"])
                + "</p>"
                + attribution
            )
        text = edit_section(
            text, "Suggested wording", lambda chunk: chunk + attribution
        )
        if candidate.get("scope_note"):
            key = candidate["wording_evidence_ids"][0]
            measure = renderer.measures[key]
            figure = (
                '<figure class="finding-chart concentration" data-calculation="'
                + e(key)
                + '" data-numerator="'
                + str(measure["numerator"])
                + '" data-denominator="'
                + str(measure["denominator"])
                + '"><figcaption>Records in the selected subdomain, 2016–2025</figcaption>'
                + '<div class="big-share">'
                + f'{measure["percent"]:.1f}%'
                + '</div><p class="fraction">'
                + f'{measure["numerator"]} of {measure["denominator"]} records</p>'
                + '<div class="share-track" aria-hidden="true"><span style="width:'
                + f'{measure["percent"]:.5f}%'
                + '"></span></div>'
                + '<p class="chart-foot">Within the selected primary domain and the chart’s 2016–2025 window.</p></figure>'
            )
            text = re.sub(
                r'<figure class="finding-chart concentration".*?</figure>',
                lambda _: figure,
                text,
                count=1,
                flags=re.S,
            )

            def settings(chunk):
                for label, value in {
                    "Time window": "January 1, 2016–December 31, 2025.",
                    "Counts or proportions": f'{measure["numerator"]}/{measure["denominator"]} ({measure["percent"]:.1f}%). Display bar counts; place the share in accompanying text.',
                }.items():
                    chunk = re.sub(
                        r"(<dt>" + label + r"</dt><dd>).*?(</dd>)",
                        lambda m: m[1] + e(value) + m[2],
                        chunk,
                        count=1,
                        flags=re.S,
                    )
                chunk = re.sub(
                    r'<p class="fit-note">.*?</p>',
                    lambda _: '<p class="fit-note"><strong>Chart view available</strong>'
                    + e(candidate["chart_configuration"]["compatibility"])
                    + "</p>",
                    chunk,
                    count=1,
                    flags=re.S,
                )
                return chunk

            text = edit_section(text, "Chart settings", settings)
            text = text.replace(
                "The denominator is only 60 primary human-computer-interaction records.",
                "The chart-window denominator is only 56 primary human-computer-interaction records.",
            )
            text = text.replace(
                "The headline covers all records through 2025; the bar chart starts at 2016. Four earlier records explain the window difference.",
                "The original all-complete-years result includes four earlier records. The suggested wording uses the chart’s 2016–2025 window.",
            )
            text = text.replace(
                "Excluding record 353 as a sensitivity gives 52 of 59 (88.1%);",
                "Across all complete years, excluding record 353 as a sensitivity gives 52 of 59 (88.1%);",
            )
            comparison = disclosure(
                "Compare date windows",
                "<p>"
                + e(candidate["scope_note"])
                + "</p><p>"
                + e(candidate["audit_original_wording"])
                + "</p>",
            )
            text = text.replace("</article>", comparison + "</article>", 1)
        for title in [
            "Figures",
            "Chart settings",
            "Confidence and limitations",
            "Calculation evidence",
        ]:
            text = edit_section(text, title, fold)
        page.write_text(text)
    # Keep the existing grouped candidate table and its thirteen rows.
    listing = renderer.out / "candidates.html"
    if listing.exists():
        from .highlights import panel

        entries = [
            dict(
                c,
                id=c["candidate_id"],
                kind="candidate",
                page=f"finding-{c['candidate_id']}.html",
                title=c["display_title"],
                wording=c["proposed_website_text"],
                selected=c["is_shortlisted"],
                priority_order=(
                    data["shortlist"].index(c["candidate_id"])
                    if c["candidate_id"] in data["shortlist"]
                    else 99
                ),
            )
            for c in candidates
        ]
        block = panel(
            {
                "items": entries,
                "measures": renderer.measures,
                "annual": renderer.timelines,
            }
        )
        text = listing.read_text()
        first = min((start for start, _ in Sections(text).ranges), default=-1)
        if first >= 0:
            text = text[:first] + block + text[first:]
        # The changed date window must agree with its directory row.
        text = re.sub(
            r"<tr>.*?</tr>",
            lambda match: (
                match[0]
                .replace("Chart window differs", "Chart view available")
                .replace(
                    "The denominator is only 60 primary human-computer-interaction records.",
                    "The chart-window denominator is 56 primary human-computer-interaction records.",
                )
                if 'href="finding-IT-D005.html"' in match[0]
                else match[0]
            ),
            text,
            flags=re.S,
        )
        listing.write_text(text)
    for page in renderer.out.glob("*.html"):
        text = page.read_text()
        for candidate in selected:
            text = re.sub(
                r'(<a\b[^>]*href="finding-'
                + re.escape(candidate["candidate_id"])
                + r'\.html"[^>]*>)([^<]*)(</a>)',
                lambda m: m[1] + e(candidate["display_title"]) + m[3],
                text,
            )
        text = text.replace(
            "</head>",
            '<link rel="stylesheet" href="review-focus.css"><script src="focused-review.js" defer></script></head>',
            1,
        )
        page.write_text(text)
    # Keep published quotations and assessments intact, adding their exact source.
    for claim in data.get("claims", []):
        page = renderer.out / f"claim-{claim['claim_id']}.html"
        url = web_url(claim.get("source_url"))
        if page.exists() and url:
            text = page.read_text()
            if e(url) not in text:
                text = edit_section(
                    text,
                    "Published wording",
                    lambda chunk: chunk
                    + section(
                        "Tracker source", "<p>" + link(url, source_label(url)) + "</p>"
                    ),
                )
                page.write_text(text)
    stamp = renderer.day.strftime("%B %d, %Y").replace(" 0", " ")
    lines = ["# Top findings", "", "Arcola export: " + stamp + ".", ""]
    for c in selected:
        lines += [
            "## " + c["display_title"],
            "",
            c["proposed_website_text"],
            "",
            "Keep in view: " + c["key_limitation"],
            "",
        ]
        lines += [
            f"- [{s['page']}]({s['url']}) → {s['chart']}" for s in c["source_pages"]
        ]
        lines += [
            "",
            "Wording evidence: "
            + ", ".join(c.get("wording_evidence_ids", c["evidence_ids"])),
            "",
            "Full candidate evidence: " + ", ".join(c["evidence_ids"]),
            "",
        ]
    (renderer.out / "downloads").mkdir(exist_ok=True)
    (renderer.out / "downloads/selected-findings.md").write_text(
        "\n".join(lines) + "\n"
    )

    from .review_copy import install as install_copy

    install_copy(renderer.out, renderer, RESOURCES)
