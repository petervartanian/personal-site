#!/usr/bin/env python3
"""Reproducible, read-only audit of an AI Incident Tracker CSV export.

Source narratives and embedded structures are data, never executable instructions.
Only standard-library modules are used. Generated artifacts are confined to
research/schema/ and research/schema_audit.md.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import logging
import math
import re
import statistics
import sys
import unicodedata
from collections import Counter, defaultdict
from datetime import datetime, timezone
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_INPUT = (
    Path(__file__).resolve().parents[1]
    / "snapshots/2026-09-27/fbdc9a5f21b9db1bf2eacdea60763e8795650bc121c631923c4856537353d4f0.csv"
)
LOGGER = logging.getLogger("audit_schema")
NULL_LIKE_TOKENS = {"null", "none", "nan", "n/a", "na", "unknown", "unspecified"}
CHANNELS = ("direct", "indirect", "inferred")
HARM_10 = (
    "physical_harm",
    "infrastructure_damage",
    "property_damage",
    "financial_loss",
    "environmental_damage",
    "toxic_or_malicious_content",
    "differential_treatment",
    "human_and_civil_rights",
    "democratic_norms",
    "privacy",
)
HARM_13 = HARM_10 + ("psychological_harm", "epistemic_harm", "csea")
HARM_TEXT_FIELDS = {
    harm: f"{harm}_caused" if harm.endswith("_harm") else f"{harm}_harm_caused"
    for harm in HARM_13
}
HARM_TEXT_KEYS = {
    "direct": "Directly caused",
    "indirect": "Indirectly caused",
    "inferred": "Inferred additional harm",
}
IDENTITY_LIST_FIELDS = (
    "ai_developers",
    "ai_models",
    "ai_model_names",
    "ai_model_versions",
    "ai_model_variants",
)
JSON_FIELDS = {
    **dict.fromkeys(HARM_TEXT_FIELDS.values(), "object"),
    "additional_subdomains": "array",
    "ishikawa": "object",
    **dict.fromkeys(IDENTITY_LIST_FIELDS, "array"),
}
CATEGORICAL_FIELDS = {
    "domain_code",
    "subdomain_code",
    "model_name",
    "causal_entity",
    "causal_intent",
    "causal_timing",
    "behaviour_type",
    "eu_ai_act_risk_level",
    "ai_goal_primary",
    "ai_goal_secondary",
    "ai_goal_confidence",
    "confidence",
    "natsec_scope",
    "natsec_primary_target",
    "natsec_confidence",
    "natsec_response_level",
    "prompt_version",
    "missing_information",
    "ai_identity_source",
    "natsec_imminence_level",
    "natsec_autonomy_level",
    "natsec_novelty_level",
}
FREE_TEXT_ENTITY_FIELDS = {
    "alleged_deployer",
    "alleged_developer",
    "alleged_harmed_parties",
    "subject_model_name",
    "natsec_other_affected",
    "natsec_alleged_perpetrator",
}
PEOPLE_FIELDS = (
    "total_people_reported_harmed",
    "total_people_inferred_harmed",
    "total_people_reported_exposed",
    "total_people_inferred_exposed",
)


def sort_ids(values: Any) -> list[str]:
    return sorted(
        set(values),
        key=lambda value: (
            not value.isdigit(),
            int(value) if value.isdigit() else value,
        ),
    )


class Checks:
    """Machine-readable checks; diagnostic differences are not called proven errors."""

    def __init__(self) -> None:
        self.definitions: dict[str, dict[str, Any]] = {}
        self.events: list[dict[str, Any]] = []

    def register(self, code: str, interpretation: str, definition: str) -> None:
        self.definitions[code] = {
            "code": code,
            "interpretation": interpretation,
            "definition": definition,
        }

    def add(self, code: str, row: dict[str, str], evidence: Any) -> None:
        if code not in self.definitions:
            raise ValueError(f"Unregistered check: {code}")
        self.events.append(
            {
                "check_code": code,
                "aiid_id": row["aiid_id"],
                "evidence": evidence,
            }
        )

    def summary(self) -> dict[str, Any]:
        by_code: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for event in self.events:
            by_code[event["check_code"]].append(event)
        return {
            code: {
                **definition,
                "event_count": len(by_code[code]),
                "incident_count": len({event["aiid_id"] for event in by_code[code]}),
                "aiid_ids": sort_ids(event["aiid_id"] for event in by_code[code]),
            }
            for code, definition in sorted(self.definitions.items())
        }


def dump_json(path: Path, value: Any) -> None:
    """Write reproducible, standards-compliant JSON."""
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="raise")
        writer.writeheader()
        for row in rows:
            writer.writerow(
                {
                    key: (
                        json.dumps(value, ensure_ascii=False, sort_keys=True)
                        if isinstance(value, (dict, list))
                        else value
                    )
                    for key, value in row.items()
                }
            )


def json_type(value: Any) -> str:
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, dict):
        return "object"
    if isinstance(value, list):
        return "array"
    if isinstance(value, int):
        return "integer"
    if isinstance(value, float):
        return "number"
    return "string"


def cell_type(value: str) -> str:
    if not value.strip():
        return "blank"
    if value.strip().startswith(("[", "{")):
        try:
            return "json_" + json_type(json.loads(value))
        except (ValueError, TypeError):
            return "invalid_json_candidate"
    if value in {"true", "false", "True", "False"}:
        return "boolean_string"
    if re.fullmatch(r"[-+]?\d+", value):
        return "integer_string"
    if re.fullmatch(r"[-+]?(?:\d*\.\d+|\d+\.?)(?:[eE][-+]?\d+)?", value):
        return "number_string"
    return "string"


def source_rows(path: Path) -> tuple[list[str], list[dict[str, str]], dict[str, Any]]:
    # A portable limit below a signed 32-bit boundary is ample for this export.
    csv.field_size_limit(2**31 - 1)
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        headers = reader.fieldnames or []
        rows: list[dict[str, str]] = []
        defects: list[dict[str, Any]] = []
        for index, row in enumerate(reader, start=1):
            if None in row or any(value is None for value in row.values()):
                defects.append({"record_number": index, "row": row})
            rows.append({key: value or "" for key, value in row.items() if key})
    raw = path.read_bytes()
    metadata = {
        "path": str(path.resolve()),
        "filename": path.name,
        "sha256": hashlib.sha256(raw).hexdigest(),
        "size_bytes": len(raw),
        "encoding": "utf-8-sig",
        "utf8_bom_present": raw.startswith(b"\xef\xbb\xbf"),
        "csv_delimiter": ",",
        "row_width_defects": defects,
        "duplicate_header_names": {
            key: count for key, count in Counter(headers).items() if count > 1
        },
    }
    return headers, rows, metadata


def field_role(field: str) -> str:
    if field == "aiid_id":
        return "incident_identifier"
    if field in {"date", "classified_at"}:
        return "timestamp"
    if field in JSON_FIELDS:
        return "json_" + JSON_FIELDS[field]
    if field in {"report_count", "number_of_occurrences"} or field in PEOPLE_FIELDS:
        return "integer_count_with_semantic_caveats"
    if "severity" in field or field.endswith("_score"):
        return "ordinal_score_or_derived_score"
    if field in CATEGORICAL_FIELDS:
        return "categorical_scalar"
    if field in FREE_TEXT_ENTITY_FIELDS:
        return "free_text_entity_label_not_safe_to_split"
    if field == "source_url":
        return "source_provenance_url"
    return "free_text"


def profile_fields(
    headers: list[str], rows: list[dict[str, str]]
) -> list[dict[str, Any]]:
    profiles: list[dict[str, Any]] = []
    for field in headers:
        values = [row[field] for row in rows]
        counts = Counter(values)
        profiles.append(
            {
                "name": field,
                "role": field_role(field),
                "rows": len(values),
                "blank_count": sum(not value.strip() for value in values),
                "empty_string_count": counts[""],
                "whitespace_only_count": sum(
                    bool(value) and not value.strip() for value in values
                ),
                "leading_or_trailing_whitespace_count": sum(
                    value != value.strip() for value in values
                ),
                "blank_aiid_ids": sort_ids(
                    row["aiid_id"] for row in rows if not row[field].strip()
                ),
                "null_like_token_counts": {
                    value: count
                    for value, count in counts.items()
                    if value.strip().lower() in NULL_LIKE_TOKENS
                },
                "distinct_including_blank": len(counts),
                "distinct_nonblank": sum(bool(value.strip()) for value in counts),
                "type_counts": dict(Counter(cell_type(value) for value in values)),
                "min_string_length": min(map(len, values), default=0),
                "max_string_length": max(map(len, values), default=0),
                "top_values": [
                    {
                        "value": value[:300],
                        "count": count,
                        "truncated": len(value) > 300,
                    }
                    for value, count in counts.most_common(6)
                ],
                "all_value_counts": (
                    dict(sorted(counts.items()))
                    if field_role(field)
                    in {
                        "categorical_scalar",
                        "integer_count_with_semantic_caveats",
                        "ordinal_score_or_derived_score",
                        "free_text_entity_label_not_safe_to_split",
                    }
                    or (len(counts) <= 100 and max(map(len, counts), default=0) <= 500)
                    else None
                ),
            }
        )
    return profiles


def normalize_title(value: str) -> str:
    value = unicodedata.normalize("NFKC", value).casefold()
    return " ".join(re.findall(r"[^\W_]+", value, flags=re.UNICODE))


def duplicate_audit(
    headers: list[str], rows: list[dict[str, str]], output_dir: Path
) -> dict[str, Any]:
    grouping: dict[str, dict[str, list[dict[str, str]]]] = {
        key: defaultdict(list)
        for key in (
            "identifier",
            "raw_row",
            "row_without_id",
            "title_exact",
            "title_normalized",
            "description_exact",
            "description_normalized",
        )
    }
    for row in rows:
        grouping["identifier"][row["aiid_id"]].append(row)
        grouping["raw_row"][json.dumps([row[field] for field in headers])].append(row)
        grouping["row_without_id"][
            json.dumps([row[field] for field in headers if field != "aiid_id"])
        ].append(row)
        grouping["title_exact"][row["title"]].append(row)
        grouping["title_normalized"][normalize_title(row["title"])].append(row)
        grouping["description_exact"][row["description"]].append(row)
        grouping["description_normalized"][normalize_title(row["description"])].append(
            row
        )
    groups = {
        kind: [
            {
                "aiid_ids": [row["aiid_id"] for row in members],
                "titles": [row["title"] for row in members],
                "dates": [row["date"] for row in members],
                "group_size": len(members),
                "descriptions": (
                    [row["description"] for row in members]
                    if kind.startswith("description")
                    else None
                ),
            }
            for members in group.values()
            if len(members) > 1
        ]
        for kind, group in grouping.items()
    }
    stopwords = {
        "a",
        "an",
        "and",
        "are",
        "as",
        "at",
        "by",
        "for",
        "from",
        "in",
        "into",
        "is",
        "of",
        "on",
        "or",
        "the",
        "to",
        "with",
        "alleged",
        "allegedly",
        "reportedly",
        "reported",
        "report",
        "reports",
        "s",
        "ai",
    }
    normalized = [normalize_title(row["title"]) for row in rows]
    tokens = [set(title.split()) - stopwords for title in normalized]
    candidates: list[dict[str, Any]] = []
    for left in range(len(rows)):
        for right in range(left + 1, len(rows)):
            shared = tokens[left] & tokens[right]
            if len(shared) < 4:
                continue
            overlap = len(shared) / min(len(tokens[left]), len(tokens[right]))
            if overlap < 0.70:
                continue
            jaccard = len(shared) / len(tokens[left] | tokens[right])
            similarity = SequenceMatcher(
                None, normalized[left], normalized[right], autojunk=False
            ).ratio()
            if not (similarity >= 0.86 or (jaccard >= 0.65 and len(shared) >= 5)):
                continue
            candidates.append(
                {
                    "aiid_id_left": rows[left]["aiid_id"],
                    "aiid_id_right": rows[right]["aiid_id"],
                    "title_left": rows[left]["title"],
                    "title_right": rows[right]["title"],
                    "date_left": rows[left]["date"],
                    "date_right": rows[right]["date"],
                    "same_date": rows[left]["date"] == rows[right]["date"],
                    "normalized_character_similarity": round(similarity, 6),
                    "token_jaccard": round(jaccard, 6),
                    "shared_tokens": sorted(shared),
                    "semantic_duplicate_status": "candidate_only_requires_source_review",
                }
            )
    write_csv(
        output_dir / "title_similarity_candidates.csv",
        candidates,
        [
            "aiid_id_left",
            "aiid_id_right",
            "title_left",
            "title_right",
            "date_left",
            "date_right",
            "same_date",
            "normalized_character_similarity",
            "token_jaccard",
            "shared_tokens",
            "semantic_duplicate_status",
        ],
    )
    by_id = {row["aiid_id"]: row for row in rows}
    evidence_fields = (
        "aiid_id",
        "title",
        "date",
        "alleged_harmed_parties",
        "report_count",
        "number_of_occurrences",
        "description",
        "classification_summary",
    )
    dump_json(
        output_dir / "title_similarity_evidence.json",
        [
            {
                "pair": [candidate["aiid_id_left"], candidate["aiid_id_right"]],
                "records": [
                    {field: by_id[candidate[key]][field] for field in evidence_fields}
                    for key in ("aiid_id_left", "aiid_id_right")
                ],
            }
            for candidate in candidates
        ],
    )
    ids = [int(row["aiid_id"]) for row in rows if row["aiid_id"].isdigit()]
    return {
        "distinct_aiid_ids": len(grouping["identifier"]),
        "blank_identifier_count": sum(not row["aiid_id"].strip() for row in rows),
        "integer_identifier_count": len(ids),
        "identifier_range": [min(ids), max(ids)] if ids else None,
        "missing_ids_within_observed_range": (
            sorted(set(range(min(ids), max(ids) + 1)) - set(ids)) if ids else []
        ),
        "duplicate_groups": groups,
        "duplicate_group_counts": {key: len(value) for key, value in groups.items()},
        "near_title_candidate_pair_count": len(candidates),
        "near_title_candidate_incident_count": len(
            {
                item[key]
                for item in candidates
                for key in ("aiid_id_left", "aiid_id_right")
            }
        ),
        "near_title_candidates": candidates,
        "near_title_rule": "NFKC/casefold/word normalization; remove fixed stopwords; at least 4 shared informative tokens and overlap coefficient >=0.70; retain character SequenceMatcher >=0.86 OR Jaccard >=0.65 with >=5 shared tokens. Pairs remain in source-ID order, not ranked by similarity.",
        "semantic_deduplication_limit": "Title similarity is a deterministic candidate screen, not an exhaustive semantic duplicate detector or proof that two records concern the same real-world event. Do not merge without source review.",
    }


def timestamp_audit(
    rows: list[dict[str, str]], analysis_date: str, checks: Checks, output_dir: Path
) -> dict[str, Any]:
    checks.register(
        "unparseable_timestamp",
        "structural_error",
        "Nonblank date/classified_at does not parse with datetime.fromisoformat.",
    )
    checks.register(
        "incident_date_after_analysis_date",
        "temporal_diagnostic",
        "Raw incident date falls after the baseline analysis date.",
    )
    checks.register(
        "classification_before_incident_date",
        "temporal_diagnostic",
        "classified_at precedes the raw incident date.",
    )
    checks.register(
        "classification_after_analysis_date",
        "temporal_diagnostic",
        "classified_at calendar date falls after the baseline analysis date.",
    )
    result: dict[str, Any] = {}
    parsed: dict[str, dict[str, datetime]] = defaultdict(dict)
    baseline = datetime.fromisoformat(analysis_date).date()
    for field in ("date", "classified_at"):
        values: list[tuple[datetime, str]] = []
        for row in rows:
            try:
                value = datetime.fromisoformat(row[field])
            except ValueError:
                checks.add(
                    "unparseable_timestamp", row, {"field": field, "value": row[field]}
                )
                continue
            values.append((value, row["aiid_id"]))
            parsed[row["aiid_id"]][field] = value
            if value.date() > baseline:
                checks.add(
                    (
                        "incident_date_after_analysis_date"
                        if field == "date"
                        else "classification_after_analysis_date"
                    ),
                    row,
                    {field: row[field], "analysis_date": analysis_date},
                )
        ordered = sorted(values)
        result[field] = {
            "parsed_count": len(values),
            "distinct_timestamp_count": len({value for value, _ in values}),
            "min": ordered[0][0].isoformat() if ordered else None,
            "min_aiid_ids": (
                sort_ids(
                    identifier for value, identifier in values if value == ordered[0][0]
                )
                if ordered
                else []
            ),
            "max": ordered[-1][0].isoformat() if ordered else None,
            "max_aiid_ids": (
                sort_ids(
                    identifier
                    for value, identifier in values
                    if value == ordered[-1][0]
                )
                if ordered
                else []
            ),
            "utc_offset_counts": dict(
                Counter(str(value.utcoffset()) for value, _ in values)
            ),
            "midnight_count": sum(
                (value.hour, value.minute, value.second, value.microsecond)
                == (0, 0, 0, 0)
                for value, _ in values
            ),
            "year_counts": dict(
                sorted(Counter(value.year for value, _ in values).items())
            ),
            "month_counts": dict(
                sorted(Counter(value.strftime("%Y-%m") for value, _ in values).items())
            ),
            "day_counts": dict(
                sorted(Counter(value.date().isoformat() for value, _ in values).items())
            ),
            "january_1_count": sum(
                (value.month, value.day) == (1, 1) for value, _ in values
            ),
        }
    for row in rows:
        item = parsed[row["aiid_id"]]
        if (
            "date" in item
            and "classified_at" in item
            and item["classified_at"] < item["date"]
        ):
            checks.add(
                "classification_before_incident_date",
                row,
                {key: row[key] for key in ("date", "classified_at")},
            )
    years = [
        {
            "year": year,
            "incident_records": count,
            "complete_calendar_year": year < baseline.year,
        }
        for year, count in result["date"]["year_counts"].items()
    ]
    write_csv(
        output_dir / "incident_year_counts.csv",
        years,
        ["year", "incident_records", "complete_calendar_year"],
    )
    result["meanings"] = {
        "date": "Raw AIID incident-date candidate, provisionally per docs/coordination.md; all values preserved. The export itself contains no date-definition documentation or precision/estimated-date flag. Do not relabel as report date.",
        "classified_at": "Classification timestamp; not incident, first-report, publication, discovery, submission, or database-entry date.",
        "report_date_fields_present": [],
        "database_created_or_updated_fields_present": [],
        "export_date": "Filename date only; not an event date or a historical database snapshot series.",
        "year_2026": "Incomplete observation year at the 2026-09-27 baseline; exclude from complete-year comparisons.",
    }
    return result


def numeric_audit(
    profiles: list[dict[str, Any]], rows: list[dict[str, str]], checks: Checks
) -> dict[str, Any]:
    checks.register(
        "negative_count",
        "structural_diagnostic",
        "A count field contains a negative integer.",
    )
    checks.register(
        "int32_max_people_count",
        "possible_clipping_or_sentinel",
        "A people field equals 2147483647, the signed 32-bit maximum; provenance is needed to distinguish a true count from clipping.",
    )
    checks.register(
        "reported_harmed_exceeds_reported_exposed",
        "definition_dependent_diagnostic",
        "total_people_reported_harmed > total_people_reported_exposed. Contradiction only if exposed is intended to include all harmed people.",
    )
    checks.register(
        "inferred_harmed_exceeds_inferred_exposed",
        "definition_dependent_diagnostic",
        "total_people_inferred_harmed > total_people_inferred_exposed. Inferred populations/overlap are not documented.",
    )
    summaries: dict[str, Any] = {}
    for profile in profiles:
        if (
            set(profile["type_counts"]) != {"integer_string"}
            or profile["name"] == "aiid_id"
        ):
            continue
        field = profile["name"]
        values = [int(row[field]) for row in rows]
        ordered = sorted(values)
        maximum = max(values)
        minimum = min(values)
        summaries[field] = {
            "count": len(values),
            "min": minimum,
            "max": maximum,
            "median": statistics.median(values),
            "p90_nearest_rank": ordered[math.ceil(0.90 * len(ordered)) - 1],
            "p99_nearest_rank": ordered[math.ceil(0.99 * len(ordered)) - 1],
            "arithmetic_sum_diagnostic_only": sum(values),
            "zero_count": values.count(0),
            "one_count": values.count(1),
            "negative_count": sum(value < 0 for value in values),
            "above_javascript_safe_integer_count": sum(
                abs(value) > 2**53 - 1 for value in values
            ),
            "above_signed_32_bit_integer_count": sum(
                value > 2**31 - 1 for value in values
            ),
            "above_signed_32_bit_integer_aiid_ids": sort_ids(
                row["aiid_id"] for row in rows if int(row[field]) > 2**31 - 1
            ),
            "min_aiid_ids": sort_ids(
                row["aiid_id"] for row in rows if int(row[field]) == minimum
            ),
            "max_aiid_ids": sort_ids(
                row["aiid_id"] for row in rows if int(row[field]) == maximum
            ),
            "value_counts": dict(sorted(Counter(values).items())),
            "zero_aiid_ids": sort_ids(
                row["aiid_id"] for row in rows if int(row[field]) == 0
            ),
        }
        if field in PEOPLE_FIELDS or field in {"report_count", "number_of_occurrences"}:
            for row in rows:
                if int(row[field]) < 0:
                    checks.add(
                        "negative_count", row, {"field": field, "value": row[field]}
                    )
                if field in PEOPLE_FIELDS and int(row[field]) == 2**31 - 1:
                    checks.add(
                        "int32_max_people_count",
                        row,
                        {"field": field, "value": row[field]},
                    )
    for row in rows:
        for kind in ("reported", "inferred"):
            harmed = f"total_people_{kind}_harmed"
            exposed = f"total_people_{kind}_exposed"
            if int(row[harmed]) > int(row[exposed]):
                checks.add(
                    f"{kind}_harmed_exceeds_{kind}_exposed",
                    row,
                    {harmed: row[harmed], exposed: row[exposed]},
                )
    return summaries


def documented_rubric_audit(output_dir: Path) -> dict[str, Any]:
    """Use the chart agent's hashed local public-source snapshot, if available.

    The audit does not execute downloaded code and does not write to research/web.
    It records evidence coverage explicitly when the optional snapshot is absent.
    """
    manifest_path = ROOT / "research" / "web" / "manifest.json"
    if not manifest_path.exists():
        return {"status": "source_snapshot_not_available", "source": None}
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    sources = [
        source
        for source in manifest.get("sources", [])
        if source.get("status") == "retrieved"
        and "docs.google.com/spreadsheets/d/e/2PACX-1vSpCMLxgUTv7nxD2G05OGOOzhVy_kzlnAknKSzZHLppiHiBRRHhukmJW2p7VI8pBQ-n7SCB1-6C74cq/pubhtml"
        in source.get("requested_url", "")
        and "gid=1189599743" in source.get("requested_url", "")
    ]
    if not sources:
        return {"status": "source_snapshot_not_available", "source": None}
    source = sources[0]
    raw_path = (ROOT / source["raw_path"]).resolve()
    text_path = (ROOT / source["text_path"]).resolve()
    if not raw_path.is_relative_to(ROOT) or not text_path.is_relative_to(ROOT):
        raise ValueError("Public-source snapshot paths must stay inside the project")
    raw_hash = hashlib.sha256(raw_path.read_bytes()).hexdigest()
    text_hash = hashlib.sha256(text_path.read_bytes()).hexdigest()
    if raw_hash != source["raw_sha256"] or text_hash != source["text_sha256"]:
        raise ValueError("Published rubric snapshot does not match its provenance hash")
    lines = text_path.read_text(encoding="utf-8").splitlines()
    labels = {
        1: "Negligible",
        2: "Minor",
        3: "Substantial",
        4: "Severe",
        5: "Catastrophic",
    }
    header_start = lines.index("Rating") + 1
    header_names = lines[header_start : header_start + 10]
    expected_names = [
        "Physical Harm",
        "Infrastructure Damage",
        "Property Damage",
        "Financial Loss",
        "Environmental Damage",
        "Toxic or Malicious Content",
        "Differential Treatment",
        "Human/Civil Rights",
        "Democratic Norms",
        "Privacy",
    ]
    if header_names != expected_names:
        raise ValueError(
            "Published rubric header layout changed; manual schema review required"
        )
    rubric_rows: list[dict[str, Any]] = []
    for score, label in labels.items():
        index = next(
            index
            for index, line in enumerate(lines)
            if line == label and index > 0 and lines[index - 1] == str(score)
        )
        criteria = lines[index + 1 : index + 11]
        if len(criteria) != 10:
            raise ValueError("Published rubric criteria are incomplete")
        for harm, displayed_name, criterion in zip(
            HARM_10, header_names, criteria, strict=True
        ):
            rubric_rows.append(
                {
                    "scale_title": lines[0],
                    "score": score,
                    "label": label,
                    "harm_dimension": harm,
                    "displayed_dimension": displayed_name,
                    "criterion_verbatim": criterion,
                }
            )
    result = {
        "status": "verified_against_local_public_source_snapshot",
        "source": {
            key: source[key]
            for key in (
                "requested_url",
                "final_url",
                "retrieved_at_utc",
                "raw_path",
                "raw_sha256",
                "text_path",
                "text_sha256",
                "parent_url",
                "discovery_relation",
            )
        },
        "scale_title": lines[0],
        "score_labels": labels,
        "dimensions_in_this_published_tab": list(HARM_10),
        "added_export_dimensions_not_defined_in_this_tab": list(HARM_13[10:]),
        "rubric_rows": rubric_rows,
        "level_1_interpretation": "Negligible includes BOTH absence of harm and low-level harm (for example, physical: 'None to minor injuries'). Neither score>=1 nor score==1 is a valid binary reported-harm indicator. Score>1 means above the negligible band for these ten categories, not all harm.",
        "zero_interpretation": "Zero is not a published rubric level; retain as an out-of-rubric encoding, not a sixth named severity category.",
        "version_scope": "The published document title explicitly says v2. This is a rubric version, separate from classifier prompt aiid.v2/aiid.v2.1 and ten-versus-thirteen-dimension arithmetic. The tab defines ten dimensions only; this export contains no explicit rubric-version column.",
    }
    dump_json(output_dir / "published_harm_rubric_v2.json", result)
    write_csv(
        output_dir / "published_harm_rubric_v2.csv", rubric_rows, list(rubric_rows[0])
    )
    return result


def parse_structures(
    rows: list[dict[str, str]], checks: Checks, output_dir: Path
) -> tuple[dict[str, dict[str, Any]], dict[str, Any]]:
    checks.register(
        "json_parse_error",
        "structural_error",
        "An expected JSON field is nonblank but cannot be decoded as strict JSON.",
    )
    checks.register(
        "json_root_type_mismatch",
        "structural_error",
        "An expected JSON field has the wrong root type.",
    )
    checks.register(
        "json_duplicate_object_key",
        "structural_error",
        "An object repeats a key; ordinary JSON decoders retain only the last value.",
    )
    nodes: dict[tuple[str, str], dict[str, Any]] = {}
    parsed: dict[str, dict[str, Any]] = defaultdict(dict)
    top_summary: dict[str, Any] = {}

    def walk(field: str, path: str, value: Any, identifier: str) -> None:
        node = nodes.setdefault(
            (field, path),
            {
                "types": Counter(),
                "ids": set(),
                "keysets": Counter(),
                "lengths": Counter(),
                "scalars": Counter(),
            },
        )
        node["types"][json_type(value)] += 1
        node["ids"].add(identifier)
        if isinstance(value, dict):
            node["keysets"][json.dumps(sorted(value))] += 1
            for key, child in value.items():
                walk(field, f"{path}.{key}", child, identifier)
        elif isinstance(value, list):
            node["lengths"][len(value)] += 1
            for child in value:
                walk(field, path + "[]", child, identifier)
        else:
            node["scalars"][json.dumps(value, ensure_ascii=False)] += 1

    for field, expected_type in JSON_FIELDS.items():
        counts: Counter[str] = Counter()
        blank_ids: list[str] = []
        empty_ids: list[str] = []
        for row in rows:
            raw = row[field]
            if not raw.strip():
                parsed[row["aiid_id"]][field] = None
                blank_ids.append(row["aiid_id"])
                counts["blank"] += 1
                continue
            duplicate_keys: list[str] = []

            def object_pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
                duplicate_keys.extend(
                    key
                    for key, count in Counter(key for key, _ in pairs).items()
                    if count > 1
                )
                return dict(pairs)

            def reject_constant(value: str) -> None:
                raise ValueError(f"Nonstandard JSON constant: {value}")

            try:
                value = json.loads(
                    raw, object_pairs_hook=object_pairs, parse_constant=reject_constant
                )
            except ValueError as error:
                parsed[row["aiid_id"]][field] = None
                checks.add(
                    "json_parse_error",
                    row,
                    {"field": field, "error": str(error), "raw": raw},
                )
                counts["parse_error"] += 1
                continue
            parsed[row["aiid_id"]][field] = value
            counts[json_type(value)] += 1
            if json_type(value) != expected_type:
                checks.add(
                    "json_root_type_mismatch",
                    row,
                    {
                        "field": field,
                        "expected": expected_type,
                        "actual": json_type(value),
                    },
                )
            if duplicate_keys:
                checks.add(
                    "json_duplicate_object_key",
                    row,
                    {"field": field, "keys": duplicate_keys},
                )
            if value in ([], {}):
                empty_ids.append(row["aiid_id"])
            walk(field, "$", value, row["aiid_id"])
        top_summary[field] = {
            "expected_root_type": expected_type,
            "root_counts": dict(counts),
            "blank_aiid_ids": sort_ids(blank_ids),
            "empty_container_count": len(empty_ids),
            "empty_container_aiid_ids": sort_ids(empty_ids),
        }
    path_profiles: list[dict[str, Any]] = []
    for (field, path), node in sorted(nodes.items()):
        scalar_counts = node["scalars"]
        path_profiles.append(
            {
                "field": field,
                "path": path,
                "node_count": sum(node["types"].values()),
                "incident_count": len(node["ids"]),
                "type_counts": dict(node["types"]),
                "object_keyset_counts": dict(node["keysets"]),
                "array_length_counts": dict(sorted(node["lengths"].items())),
                "distinct_scalar_count": len(scalar_counts),
                "top_scalar_values": [
                    {"value": json.loads(value), "count": count}
                    for value, count in scalar_counts.most_common(5)
                ],
                "all_scalar_values": (
                    [
                        {"value": json.loads(value), "count": count}
                        for value, count in sorted(scalar_counts.items())
                    ]
                    if scalar_counts
                    and len(scalar_counts) <= 100
                    and max(map(len, scalar_counts)) <= 300
                    else None
                ),
            }
        )
    with (output_dir / "parsed_structures.jsonl").open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(
                json.dumps(
                    {"aiid_id": row["aiid_id"], **parsed[row["aiid_id"]]},
                    ensure_ascii=False,
                    allow_nan=False,
                )
                + "\n"
            )
    return parsed, {
        "expected_json_field_count": len(JSON_FIELDS),
        "nonblank_json_cell_count": sum(
            count
            for item in top_summary.values()
            for kind, count in item["root_counts"].items()
            if kind != "blank"
        ),
        "blank_json_cell_count": sum(
            item["root_counts"].get("blank", 0) for item in top_summary.values()
        ),
        "fields": top_summary,
        "paths": path_profiles,
        "ishikawa_interpretation": "Six suggested-cause axes: Management, Technology, Human Factors, Process and Methods, Data Inputs, Regulatory Environment. Each holds an array of Cause/Explanation string objects; N/A objects are placeholders. These are narrative classifications, distinct from the primary causal_entity/intent/timing taxonomy and not independent verified causes.",
    }


def risk_code(value: str) -> str | None:
    match = re.match(r"^(\d+(?:\.\d+)?)\s+", value)
    return match.group(1) if match else None


def classification_audit(
    rows: list[dict[str, str]],
    parsed: dict[str, dict[str, Any]],
    checks: Checks,
    output_dir: Path,
) -> dict[str, Any]:
    checks.register(
        "primary_domain_subdomain_prefix_mismatch",
        "structural_error",
        "Numeric prefix of primary subdomain differs from primary domain.",
    )
    checks.register(
        "additional_classification_shape",
        "structural_error",
        "Additional classification is not an object with string code and justification.",
    )
    checks.register(
        "additional_subdomain_bad_code",
        "structural_error",
        "Additional subdomain does not contain a valid numeric subdomain prefix or known parent domain.",
    )
    checks.register(
        "additional_repeats_primary_subdomain",
        "redundant_membership",
        "An additional subdomain has the same numeric code as the primary subdomain.",
    )
    checks.register(
        "duplicate_additional_subdomain",
        "redundant_membership",
        "Two additional entries within one incident have the same numeric subdomain code.",
    )
    checks.register(
        "ai_goal_secondary_repeats_primary",
        "redundant_membership",
        "Secondary AI goal exactly repeats primary AI goal.",
    )
    domain_labels: dict[str, set[str]] = defaultdict(set)
    subdomain_labels: dict[str, set[str]] = defaultdict(set)
    for row in rows:
        if code := risk_code(row["domain_code"]):
            domain_labels[code].add(row["domain_code"])
    domain_names = {code: sorted(values)[0] for code, values in domain_labels.items()}
    memberships: list[dict[str, Any]] = []
    lengths: Counter[int] = Counter()
    additional_keys: Counter[str] = Counter()
    for row in rows:
        primary_domain = risk_code(row["domain_code"])
        primary_subdomain = risk_code(row["subdomain_code"])
        if (
            not primary_subdomain
            or not primary_domain
            or primary_subdomain.split(".")[0] != primary_domain
        ):
            checks.add(
                "primary_domain_subdomain_prefix_mismatch",
                row,
                {key: row[key] for key in ("domain_code", "subdomain_code")},
            )
        if primary_subdomain:
            subdomain_labels[primary_subdomain].add(row["subdomain_code"])
        memberships.append(
            {
                "aiid_id": row["aiid_id"],
                "scope": "primary",
                "position": 0,
                "domain_numeric_code": primary_domain,
                "domain_label": row["domain_code"],
                "subdomain_numeric_code": primary_subdomain,
                "subdomain_label": row["subdomain_code"],
                "justification": row["domain_justification"],
            }
        )
        additional = parsed[row["aiid_id"]]["additional_subdomains"]
        if not isinstance(additional, list):
            continue
        lengths[len(additional)] += 1
        seen: set[str] = set()
        for index, entry in enumerate(additional, start=1):
            if isinstance(entry, dict):
                additional_keys[json.dumps(sorted(entry))] += 1
            if (
                not isinstance(entry, dict)
                or not isinstance(entry.get("code"), str)
                or not isinstance(entry.get("justification"), str)
            ):
                checks.add(
                    "additional_classification_shape",
                    row,
                    {"position": index, "entry": entry},
                )
                continue
            code = risk_code(entry["code"])
            domain = code.split(".")[0] if code else None
            if code is None or "." not in code or domain not in domain_names:
                checks.add(
                    "additional_subdomain_bad_code",
                    row,
                    {"position": index, "entry": entry},
                )
            if code == primary_subdomain:
                checks.add(
                    "additional_repeats_primary_subdomain",
                    row,
                    {"position": index, "entry": entry},
                )
            if code in seen:
                checks.add(
                    "duplicate_additional_subdomain",
                    row,
                    {"position": index, "entry": entry},
                )
            if code:
                seen.add(code)
                subdomain_labels[code].add(entry["code"])
            memberships.append(
                {
                    "aiid_id": row["aiid_id"],
                    "scope": "additional",
                    "position": index,
                    "domain_numeric_code": domain,
                    "domain_label": domain_names.get(domain or ""),
                    "subdomain_numeric_code": code,
                    "subdomain_label": entry["code"],
                    "justification": entry["justification"],
                }
            )
        if row["ai_goal_secondary"] == row["ai_goal_primary"]:
            checks.add(
                "ai_goal_secondary_repeats_primary",
                row,
                {
                    "ai_goal_primary": row["ai_goal_primary"],
                    "ai_goal_secondary": row["ai_goal_secondary"],
                },
            )
    frequency_rows: list[dict[str, Any]] = []
    for scope in ("primary", "additional", "any"):
        items = [
            entry for entry in memberships if scope == "any" or entry["scope"] == scope
        ]
        for level in ("domain", "subdomain"):
            grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
            for item in items:
                grouped[item[f"{level}_numeric_code"] or "UNKNOWN"].append(item)
            for code, values in sorted(grouped.items()):
                identifiers = sort_ids(item["aiid_id"] for item in values)
                frequency_rows.append(
                    {
                        "scope": scope,
                        "level": level,
                        "numeric_code": code,
                        "labels": sorted(
                            {
                                item[f"{level}_label"]
                                for item in values
                                if item[f"{level}_label"] is not None
                            }
                        ),
                        "membership_count": len(values),
                        "distinct_incident_count": len(identifiers),
                        "all_incident_denominator": len(rows),
                        "aiid_ids": identifiers,
                    }
                )
    write_csv(
        output_dir / "classification_memberships.csv",
        memberships,
        [
            "aiid_id",
            "scope",
            "position",
            "domain_numeric_code",
            "domain_label",
            "subdomain_numeric_code",
            "subdomain_label",
            "justification",
        ],
    )
    write_csv(
        output_dir / "classification_frequencies.csv",
        frequency_rows,
        [
            "scope",
            "level",
            "numeric_code",
            "labels",
            "membership_count",
            "distinct_incident_count",
            "all_incident_denominator",
            "aiid_ids",
        ],
    )
    primary_codes = {
        item["subdomain_numeric_code"]
        for item in memberships
        if item["scope"] == "primary"
    }
    additional_codes = {
        item["subdomain_numeric_code"]
        for item in memberships
        if item["scope"] == "additional"
    }
    return {
        "primary_field_map": {
            "domain": "domain_code",
            "subdomain": "subdomain_code",
            "causal": ["causal_entity", "causal_intent", "causal_timing"],
        },
        "additional_field": "additional_subdomains",
        "additional_entry_keysets": dict(additional_keys),
        "additional_length_distribution": dict(sorted(lengths.items())),
        "additional_membership_count": sum(
            key * count for key, count in lengths.items()
        ),
        "incidents_with_additional_classifications": sum(
            count for length, count in lengths.items() if length > 0
        ),
        "domain_label_map": {
            code: sorted(labels) for code, labels in sorted(domain_labels.items())
        },
        "subdomain_label_map": {
            code: sorted(labels) for code, labels in sorted(subdomain_labels.items())
        },
        "domain_code_label_variants": {
            code: sorted(labels)
            for code, labels in domain_labels.items()
            if len(labels) > 1
        },
        "subdomain_code_label_variants": {
            code: sorted(labels)
            for code, labels in subdomain_labels.items()
            if len(labels) > 1
        },
        "subdomains_only_in_additional": sorted(
            code for code in additional_codes - primary_codes if code
        ),
        "frequencies": frequency_rows,
        "additional_causal_fields_present": False,
        "additional_domain_field_present": False,
        "interpretation": "Additional objects encode subdomain code+label and justification. Parent domain is derived from the numeric prefix. There is one record-level causal triple, no separately encoded causal triple for each additional label. Any-label categories must deduplicate aiid_id within each category, including several subdomains in the same domain.",
    }


def text_state(value: Any) -> str:
    """Conservative lexical annotation, not a general semantic classifier."""
    if value is None:
        return "json_null_or_absent"
    if not isinstance(value, str):
        return "non_string"
    text = value.strip()
    if not text:
        return "blank"
    normalized = text.casefold().rstrip(".")
    if normalized in {"n/a", "na", "none", "null", "not applicable"}:
        return "placeholder"
    if normalized in {
        "no",
        "false",
        "none reported",
        "not reported",
        "no harm",
        "no harm reported",
    }:
        return "explicit_negative_token"
    if normalized in {"yes", "true"}:
        return "explicit_affirmative_token"
    if re.match(
        r"^(?:the )?reports? (?:does|do) not (?:explicitly )?(?:describe|mention|report|detail|indicate|provide|specify)\b",
        normalized,
    ):
        return "negative_reporting_statement_lexical"
    if re.fullmatch(
        r"no [^.?!;]+ (?:was|were|is|are) (?:reported|described|mentioned)", normalized
    ):
        return "negative_reporting_statement_lexical"
    return "narrative_requires_review"


def harm_and_severity_audit(
    rows: list[dict[str, str]],
    parsed: dict[str, dict[str, Any]],
    checks: Checks,
    output_dir: Path,
) -> tuple[dict[str, Any], dict[str, dict[str, int]]]:
    checks.register(
        "harm_object_keyset",
        "structural_error",
        "A populated harm object does not have exactly Reported, Directly caused, Indirectly caused, Inferred additional harm.",
    )
    checks.register(
        "harm_object_nonstring_value",
        "structural_error",
        "A harm object contains a non-string value.",
    )
    checks.register(
        "severity_zero_encoding",
        "encoding_uncertainty",
        "A harm-component severity is zero while the dominant observed encoding is 1..5. Zero is preserved, never silently remapped.",
    )
    checks.register(
        "severity_outside_zero_to_five",
        "structural_diagnostic",
        "A component severity falls outside observed 0..5 encoding.",
    )
    checks.register(
        "severity_gt1_with_absent_narrative",
        "semantic_diagnostic_not_proven_error",
        "Component severity >1 but its paired narrative is absent, a placeholder, or an explicit negative token; threshold is provisional pending documented scale.",
    )
    checks.register(
        "severity_le1_with_substantive_narrative",
        "semantic_diagnostic_not_proven_error",
        "Component severity <=1 but its paired narrative requires review or is an affirmative token. Narrative could describe lack of harm, so manual review is necessary.",
    )
    checks.register(
        "people_reported_harmed_positive_scores_le1",
        "definition_dependent_diagnostic",
        "Positive total_people_reported_harmed while all 13 direct+indirect severity values are <=1.",
    )
    checks.register(
        "people_reported_harmed_zero_scores_gt1",
        "definition_dependent_diagnostic",
        "Zero total_people_reported_harmed while some direct+indirect severity >1; zero might mean unquantified and some dimensions concern non-person harms.",
    )
    checks.register(
        "natsec_overall_differs_from_max_dimension",
        "arithmetic_diagnostic",
        "natsec_overall_score differs from maximum of five natsec dimension scores; governing aggregation formula is not independently documented here.",
    )
    checks.register(
        "natsec_score_response_mapping_mismatch",
        "categorical_diagnostic",
        "Overall score does not agree with observed score/response encoding 1 Minor, 2 Moderate, 3 Substantial, 4 Severe, 5 Critical.",
    )
    harm_rows: list[dict[str, Any]] = []
    computed: dict[str, dict[str, int]] = {}
    reported_states: dict[str, Counter[str]] = defaultdict(Counter)
    channel_states: dict[str, Counter[str]] = defaultdict(Counter)
    score_state: Counter[tuple[str, str, int, str]] = Counter()
    per_harm: dict[str, dict[str, Any]] = {}
    expected_keys = {"Reported", *HARM_TEXT_KEYS.values()}
    absence = {"json_null_or_absent", "blank", "placeholder", "explicit_negative_token"}
    for row in rows:
        identifier = row["aiid_id"]
        calculated: dict[str, int] = {}
        for group_name, harms in (("10", HARM_10), ("13", HARM_13)):
            for channel in CHANNELS:
                values = [int(row[f"{harm}_severity_{channel}"]) for harm in harms]
                calculated[f"sum_{group_name}_{channel}"] = sum(values)
                calculated[f"max_{group_name}_{channel}"] = max(values)
                calculated[f"count_gt1_{group_name}_{channel}"] = sum(
                    value > 1 for value in values
                )
            calculated[f"max_{group_name}_direct_indirect"] = max(
                calculated[f"max_{group_name}_{channel}"]
                for channel in ("direct", "indirect")
            )
            calculated[f"max_{group_name}_all"] = max(
                calculated[f"max_{group_name}_{channel}"] for channel in CHANNELS
            )
        computed[identifier] = calculated
        for harm, text_field in HARM_TEXT_FIELDS.items():
            value = parsed[identifier][text_field]
            if isinstance(value, dict) and set(value) != expected_keys:
                checks.add(
                    "harm_object_keyset",
                    row,
                    {"field": text_field, "keys": sorted(value)},
                )
            if isinstance(value, dict) and any(
                not isinstance(child, str) for child in value.values()
            ):
                checks.add(
                    "harm_object_nonstring_value",
                    row,
                    {"field": text_field, "value": value},
                )
            item = value if isinstance(value, dict) else {}
            reported_state = text_state(item.get("Reported"))
            reported_states[harm][reported_state] += 1
            out: dict[str, Any] = {
                "aiid_id": identifier,
                "harm_dimension": harm,
                "source_text_field": text_field,
                "reported_text": item.get("Reported"),
                "reported_text_state": reported_state,
            }
            for channel, key in HARM_TEXT_KEYS.items():
                field = f"{harm}_severity_{channel}"
                score = int(row[field])
                state = text_state(item.get(key))
                channel_states[f"{harm}:{channel}"][state] += 1
                score_state[(harm, channel, score, state)] += 1
                out[f"{channel}_severity"] = score
                out[f"{channel}_text"] = item.get(key)
                out[f"{channel}_text_state"] = state
                if score == 0:
                    checks.add(
                        "severity_zero_encoding",
                        row,
                        {
                            "field": field,
                            "value": score,
                            "model_name": row["model_name"],
                            "prompt_version": row["prompt_version"],
                        },
                    )
                if score < 0 or score > 5:
                    checks.add(
                        "severity_outside_zero_to_five",
                        row,
                        {"field": field, "value": score},
                    )
                if score > 1 and state in absence:
                    checks.add(
                        "severity_gt1_with_absent_narrative",
                        row,
                        {
                            "score_field": field,
                            "score": score,
                            "text_key": key,
                            "text": item.get(key),
                            "text_state": state,
                        },
                    )
                if score <= 1 and state in {
                    "narrative_requires_review",
                    "explicit_affirmative_token",
                }:
                    checks.add(
                        "severity_le1_with_substantive_narrative",
                        row,
                        {
                            "score_field": field,
                            "score": score,
                            "text_key": key,
                            "text": item.get(key),
                            "text_state": state,
                        },
                    )
            harm_rows.append(out)
        if (
            int(row["total_people_reported_harmed"]) > 0
            and calculated["max_13_direct_indirect"] <= 1
        ):
            checks.add(
                "people_reported_harmed_positive_scores_le1",
                row,
                {
                    "total_people_reported_harmed": row["total_people_reported_harmed"],
                    "max_13_direct_indirect": calculated["max_13_direct_indirect"],
                },
            )
        if (
            int(row["total_people_reported_harmed"]) == 0
            and calculated["max_13_direct_indirect"] > 1
        ):
            checks.add(
                "people_reported_harmed_zero_scores_gt1",
                row,
                {
                    "total_people_reported_harmed": row["total_people_reported_harmed"],
                    "max_13_direct_indirect": calculated["max_13_direct_indirect"],
                },
            )
        natsec_fields = [
            f"natsec_{dimension}_score"
            for dimension in (
                "physical",
                "information",
                "sovereignty",
                "economic",
                "societal",
            )
        ]
        natsec_max = max(int(row[field]) for field in natsec_fields)
        if natsec_max != int(row["natsec_overall_score"]):
            checks.add(
                "natsec_overall_differs_from_max_dimension",
                row,
                {
                    "natsec_overall_score": row["natsec_overall_score"],
                    "computed_max": natsec_max,
                    "component_values": {field: row[field] for field in natsec_fields},
                },
            )
        response_map = {
            1: "Minor",
            2: "Moderate",
            3: "Substantial",
            4: "Severe",
            5: "Critical",
        }
        if (
            response_map.get(int(row["natsec_overall_score"]))
            != row["natsec_response_level"]
        ):
            checks.add(
                "natsec_score_response_mapping_mismatch",
                row,
                {
                    key: row[key]
                    for key in ("natsec_overall_score", "natsec_response_level")
                },
            )
    formula_tests: dict[str, Any] = {}
    formula_candidates = {
        "severity_sum_direct": ["sum_13_direct", "sum_10_direct"],
        "severity_sum_direct_10": ["sum_10_direct", "sum_13_direct"],
        "severity_sum_indirect_10": ["sum_10_indirect", "sum_13_indirect"],
        "severity_sum_inferred_10": ["sum_10_inferred", "sum_13_inferred"],
        "highest_severity": [
            f"max_{count}_{channel}"
            for count in ("10", "13")
            for channel in (*CHANNELS, "direct_indirect", "all")
        ],
        "highest_severity_10": [
            f"max_{count}_{channel}"
            for count in ("10", "13")
            for channel in (*CHANNELS, "direct_indirect", "all")
        ],
    }
    for field, formulas in formula_candidates.items():
        formula_tests[field] = {}
        for formula in formulas:
            mismatch_ids = sort_ids(
                row["aiid_id"]
                for row in rows
                if int(row[field]) != computed[row["aiid_id"]][formula]
            )
            formula_tests[field][formula] = {
                "matches": len(rows) - len(mismatch_ids),
                "mismatches": len(mismatch_ids),
                "mismatch_aiid_ids": mismatch_ids,
            }
    severity_rows = [
        {
            "aiid_id": row["aiid_id"],
            **{field: int(row[field]) for field in formula_candidates},
            **computed[row["aiid_id"]],
        }
        for row in rows
    ]
    write_csv(
        output_dir / "severity_recomputed.csv", severity_rows, list(severity_rows[0])
    )
    write_csv(output_dir / "harm_evidence_long.csv", harm_rows, list(harm_rows[0]))
    score_state_rows = [
        {
            "harm_dimension": harm,
            "channel": channel,
            "severity": score,
            "text_state": state,
            "count": count,
        }
        for (harm, channel, score, state), count in sorted(score_state.items())
    ]
    write_csv(
        output_dir / "harm_score_text_state_frequencies.csv",
        score_state_rows,
        ["harm_dimension", "channel", "severity", "text_state", "count"],
    )
    for harm in HARM_13:
        per_harm[harm] = {
            "reported_text_states": dict(reported_states[harm]),
            "severity_counts_by_channel": {
                channel: dict(
                    sorted(
                        Counter(
                            int(row[f"{harm}_severity_{channel}"]) for row in rows
                        ).items()
                    )
                )
                for channel in CHANNELS
            },
            "text_states_by_channel": {
                channel: dict(channel_states[f"{harm}:{channel}"])
                for channel in CHANNELS
            },
        }
    summary_measures: dict[str, Any] = {}
    for count in ("10", "13"):
        for channels in (
            ("direct",),
            ("indirect",),
            ("inferred",),
            ("direct", "indirect"),
            CHANNELS,
        ):
            name = f"any_component_gt1_{count}_" + "_".join(channels)
            ids = sort_ids(
                row["aiid_id"]
                for row in rows
                if any(
                    computed[row["aiid_id"]][f"max_{count}_{channel}"] > 1
                    for channel in channels
                )
            )
            summary_measures[name] = {
                "count": len(ids),
                "aiid_ids": ids,
                "status": "provisional_threshold_diagnostic_not_validated_harm_prevalence",
            }
    version_ids = sort_ids(
        row["aiid_id"]
        for row in rows
        if row["highest_severity"] != row["highest_severity_10"]
    )
    return {
        "ten_dimension_names": list(HARM_10),
        "thirteen_dimension_names": list(HARM_13),
        "three_added_dimensions": list(HARM_13[10:]),
        "harm_text_field_map": HARM_TEXT_FIELDS,
        "harm_object_channel_map": HARM_TEXT_KEYS,
        "reported_key_meaning": "Reported is free text (including No, negative reporting narratives, and descriptive narratives), not a boolean. Direct/indirect refer to causal relation; inferred denotes additional inferred harm, a separate epistemic status.",
        "lexical_state_method": "Exact null/blank/placeholders and yes/no tokens plus narrowly defined negative-reporting phrases. Other prose remains narrative_requires_review; this is not an entailment classifier.",
        "severity_scale_status": "No authoritative severity rubric is embedded. 1 co-occurs extensively with N/A/No harm narratives and must not be counted as harm. Threshold >1 is exposed only as a reproducible sensitivity/diagnostic pending external rubric verification. Preserve zero values separately.",
        "explicit_v2_severity_columns": [
            field for field in rows[0] if "severity" in field and "v2" in field
        ],
        "formula_tests": formula_tests,
        "exactly_matching_formulas": {
            field: [
                formula
                for formula, result in results.items()
                if result["mismatches"] == 0
            ]
            for field, results in formula_tests.items()
        },
        "highest_severity_vs_highest_severity_10_difference_count": len(version_ids),
        "highest_severity_vs_highest_severity_10_difference_aiid_ids": version_ids,
        "natsec_aggregate": {
            "candidate_formula": "max(natsec_physical_score, natsec_information_score, natsec_sovereignty_score, natsec_economic_score, natsec_societal_score)",
            "formula_mismatch_incident_count": len(
                {
                    event["aiid_id"]
                    for event in checks.events
                    if event["check_code"]
                    == "natsec_overall_differs_from_max_dimension"
                }
            ),
            "score_response_encoding": {
                1: "Minor",
                2: "Moderate",
                3: "Substantial",
                4: "Severe",
                5: "Critical",
            },
            "interpretation": "National-security impact is a separate five-dimension assessment; do not substitute its labels/scores for the harm severity rubric.",
        },
        "by_dimension": per_harm,
        "threshold_diagnostics": summary_measures,
        "sums_caution": "Raw component sums include a baseline of one per dimension for the dominant encoding; changing 10 to 13 dimensions changes the baseline. Ordinal scores are not calibrated cardinal harm units; arithmetic agreement does not justify averaging or adding them across incidents.",
    }, computed


def metadata_audit(
    rows: list[dict[str, str]],
    parsed: dict[str, dict[str, Any]],
    checks: Checks,
    output_dir: Path,
) -> dict[str, Any]:
    checks.register(
        "identity_nonstring_list_item",
        "structural_error",
        "An identity list contains a non-string item.",
    )
    checks.register(
        "identity_duplicate_list_item",
        "redundant_membership",
        "An identity list repeats an exact string within one incident.",
    )
    checks.register(
        "identity_blank_item",
        "structural_diagnostic",
        "An identity list contains a blank string item.",
    )
    checks.register(
        "missing_info_false_with_detail",
        "semantic_diagnostic_not_proven_error",
        "missing_information=false but missing_information_detail contains text beyond blank/null/None/N/A; the detail may explain why missing information is not material.",
    )
    checks.register(
        "missing_info_true_without_detail",
        "semantic_diagnostic_not_proven_error",
        "missing_information=true with blank/placeholder detail.",
    )
    checks.register(
        "eu_risk_code_reasoning_prefix_mismatch",
        "internal_annotation_disagreement",
        "A recognized leading EU risk label disagrees with numeric encoding inferred from the dominant label/code cross-tab.",
    )
    item_rows: list[dict[str, Any]] = []
    identity_summary: dict[str, Any] = {}
    for field in IDENTITY_LIST_FIELDS:
        incidence: dict[str, set[str]] = defaultdict(set)
        membership: Counter[str] = Counter()
        length_counts: Counter[str] = Counter()
        sentinel_only: list[str] = []
        for row in rows:
            items = parsed[row["aiid_id"]][field]
            if not isinstance(items, list):
                length_counts["blank_or_invalid"] += 1
                continue
            length_counts[str(len(items))] += 1
            if items and all(
                isinstance(value, str) and value.strip().casefold() in NULL_LIKE_TOKENS
                for value in items
            ):
                sentinel_only.append(row["aiid_id"])
            seen: set[str] = set()
            for index, item in enumerate(items, start=1):
                if not isinstance(item, str):
                    checks.add(
                        "identity_nonstring_list_item",
                        row,
                        {"field": field, "position": index, "value": item},
                    )
                    continue
                if item in seen:
                    checks.add(
                        "identity_duplicate_list_item",
                        row,
                        {"field": field, "value": item},
                    )
                if not item.strip():
                    checks.add(
                        "identity_blank_item", row, {"field": field, "position": index}
                    )
                seen.add(item)
                membership[item] += 1
                incidence[item].add(row["aiid_id"])
                item_rows.append(
                    {
                        "aiid_id": row["aiid_id"],
                        "field": field,
                        "position": index,
                        "value": item,
                        "is_null_like_token": item.strip().casefold()
                        in NULL_LIKE_TOKENS,
                    }
                )
        identity_summary[field] = {
            "length_counts": dict(sorted(length_counts.items())),
            "sentinel_only_count": len(sentinel_only),
            "sentinel_only_aiid_ids": sort_ids(sentinel_only),
            "frequencies": [
                {
                    "value": value,
                    "membership_count": membership[value],
                    "incident_count": len(incidence[value]),
                }
                for value in sorted(membership)
            ],
        }
    write_csv(
        output_dir / "identity_list_items.csv",
        item_rows,
        ["aiid_id", "field", "position", "value", "is_null_like_token"],
    )
    batches: dict[tuple[str, str, str, str], list[dict[str, str]]] = defaultdict(list)
    eu_prefixes: Counter[tuple[str, str]] = Counter()
    prefix_rows: list[tuple[dict[str, str], str]] = []
    for row in rows:
        batches[
            (
                row["model_name"],
                row["prompt_version"],
                row["ai_identity_source"],
                datetime.fromisoformat(row["classified_at"]).date().isoformat(),
            )
        ].append(row)
        detail_state = text_state(row["missing_information_detail"])
        if row["missing_information"] == "false" and detail_state not in {
            "blank",
            "placeholder",
            "json_null_or_absent",
            "explicit_negative_token",
        }:
            checks.add(
                "missing_info_false_with_detail",
                row,
                {
                    "missing_information": row["missing_information"],
                    "detail": row["missing_information_detail"],
                },
            )
        if row["missing_information"] == "true" and detail_state in {
            "blank",
            "placeholder",
            "json_null_or_absent",
        }:
            checks.add(
                "missing_info_true_without_detail",
                row,
                {
                    "missing_information": row["missing_information"],
                    "detail": row["missing_information_detail"],
                },
            )
        match = re.match(
            r"\s*(unacceptable|high|limited|minimal)(?:[- ]risk)?\b",
            row["eu_ai_act_risk_reasoning"],
            re.IGNORECASE,
        )
        if match:
            label = match.group(1).casefold()
            eu_prefixes[(row["eu_ai_act_risk_level"], label)] += 1
            prefix_rows.append((row, label))
    eu_map: dict[str, str] = {}
    for level in sorted({level for level, _ in eu_prefixes}):
        counts = Counter(
            {
                label: count
                for (code, label), count in eu_prefixes.items()
                if code == level
            }
        )
        eu_map[level] = counts.most_common(1)[0][0]
    for row, label in prefix_rows:
        if eu_map[row["eu_ai_act_risk_level"]] != label:
            checks.add(
                "eu_risk_code_reasoning_prefix_mismatch",
                row,
                {
                    "level": row["eu_ai_act_risk_level"],
                    "recognized_prefix": label,
                    "reasoning": row["eu_ai_act_risk_reasoning"],
                },
            )
    batch_rows = []
    for (model, prompt, identity_source, day), members in sorted(batches.items()):
        batch_rows.append(
            {
                "model_name": model,
                "prompt_version": prompt,
                "ai_identity_source": identity_source,
                "classification_day": day,
                "incident_count": len(members),
                "incident_date_min": min(row["date"] for row in members),
                "incident_date_max": max(row["date"] for row in members),
                "classified_at_min": min(row["classified_at"] for row in members),
                "classified_at_max": max(row["classified_at"] for row in members),
                "identity_all_five_fields_blank_count": sum(
                    all(not row[field].strip() for field in IDENTITY_LIST_FIELDS)
                    for row in members
                ),
                "any_zero_severity_count": sum(
                    any(
                        int(row[f"{harm}_severity_{channel}"]) == 0
                        for harm in HARM_13
                        for channel in CHANNELS
                    )
                    for row in members
                ),
                "aiid_ids": sort_ids(row["aiid_id"] for row in members),
            }
        )
    write_csv(
        output_dir / "classification_batches.csv", batch_rows, list(batch_rows[0])
    )
    pair_lengths_differ = sort_ids(
        row["aiid_id"]
        for row in rows
        if isinstance(parsed[row["aiid_id"]]["ai_developers"], list)
        and isinstance(parsed[row["aiid_id"]]["ai_models"], list)
        and len(parsed[row["aiid_id"]]["ai_developers"])
        != len(parsed[row["aiid_id"]]["ai_models"])
    )
    all_lengths_differ = sort_ids(
        row["aiid_id"]
        for row in rows
        if len(
            {
                len(parsed[row["aiid_id"]][field])
                for field in IDENTITY_LIST_FIELDS
                if isinstance(parsed[row["aiid_id"]][field], list)
            }
        )
        > 1
    )
    return {
        "classifier_model_counts": dict(
            sorted(Counter(row["model_name"] for row in rows).items())
        ),
        "prompt_version_counts": dict(
            sorted(Counter(row["prompt_version"] for row in rows).items())
        ),
        "identity_extraction_version_counts": dict(
            sorted(Counter(row["ai_identity_source"] for row in rows).items())
        ),
        "classification_batches": batch_rows,
        "identity_lists": identity_summary,
        "developer_vs_model_array_length_differ_count": len(pair_lengths_differ),
        "developer_vs_model_array_length_differ_aiid_ids": pair_lengths_differ,
        "any_identity_array_length_differ_count": len(all_lengths_differ),
        "any_identity_array_length_differ_aiid_ids": all_lengths_differ,
        "identity_join_caution": "These are independent arrays without object-level links between developer/model/name/version/variant. Do not zip by index or form a Cartesian product and treat it as verified model identity.",
        "classifier_vs_subject": "model_name is the classifying model; subject_model_name and ai_* identity lists describe the implicated system. prompt_version and ai_identity_source are different processing-stage versions.",
        "taxonomy_metadata_fields": [field for field in rows[0] if "taxonom" in field],
        "prompt_text_or_rubric_embedded": False,
        "confidence_caution": "High/Medium/Low are ordinal annotations, not measured probability, confidence intervals, or inter-model agreement. One stored classifier row per ID does not supply replicate classifications or agreement estimates.",
        "eu_risk_reasoning_derived_label_map": eu_map,
        "eu_risk_recognized_prefix_row_count": len(prefix_rows),
        "eu_risk_code_prefix_crosstab": [
            {"code": code, "label_prefix": label, "count": count}
            for (code, label), count in sorted(eu_prefixes.items())
        ],
        "eu_risk_label_map_status": "Mapping is derived from recognized leading labels in classifier reasoning, not an independently validated legal risk assessment.",
    }


def artifact_tables(
    headers: list[str],
    rows: list[dict[str, str]],
    profiles: list[dict[str, Any]],
    parsed: dict[str, dict[str, Any]],
    computed: dict[str, dict[str, int]],
    output_dir: Path,
) -> dict[str, Any]:
    frequency_rows = []
    frequencies: dict[str, Any] = {}
    normalized_variants: dict[str, Any] = {}
    for profile in profiles:
        field = profile["name"]
        if profile["all_value_counts"] is not None and field not in JSON_FIELDS:
            frequencies[field] = {
                "role": profile["role"],
                "denominator": len(rows),
                "value_counts": profile["all_value_counts"],
            }
            for value, count in profile["all_value_counts"].items():
                frequency_rows.append(
                    {
                        "field": field,
                        "value": value,
                        "count": count,
                        "is_blank": not value.strip(),
                        "is_null_like_token": value.strip().casefold()
                        in NULL_LIKE_TOKENS,
                    }
                )
            groups: dict[str, list[str]] = defaultdict(list)
            for value in profile["all_value_counts"]:
                groups[unicodedata.normalize("NFKC", value).strip().casefold()].append(
                    value
                )
            variants = {
                key: values for key, values in groups.items() if len(values) > 1
            }
            if variants:
                normalized_variants[field] = variants
    write_csv(
        output_dir / "field_value_frequencies.csv",
        frequency_rows,
        ["field", "value", "count", "is_blank", "is_null_like_token"],
    )
    missing_rows = [
        {
            key: profile[key]
            for key in (
                "name",
                "role",
                "rows",
                "blank_count",
                "empty_string_count",
                "whitespace_only_count",
                "leading_or_trailing_whitespace_count",
                "distinct_nonblank",
                "type_counts",
                "null_like_token_counts",
                "blank_aiid_ids",
            )
        }
        for profile in profiles
    ]
    write_csv(output_dir / "field_profiles.csv", missing_rows, list(missing_rows[0]))
    core_fields = [
        field
        for field in headers
        if field_role(field) not in {"free_text", "json_object", "json_array"}
        or field == "title"
    ]
    incident_rows = []
    for row_number, row in enumerate(rows, start=1):
        core: dict[str, Any] = {"csv_record_number": row_number, "title": row["title"]}
        core.update({field: row[field] for field in core_fields})
        core["date_year"] = datetime.fromisoformat(row["date"]).year
        core["additional_subdomains"] = parsed[row["aiid_id"]]["additional_subdomains"]
        core.update(
            {field: parsed[row["aiid_id"]][field] for field in IDENTITY_LIST_FIELDS}
        )
        core.update(computed[row["aiid_id"]])
        incident_rows.append(core)
    dump_json(output_dir / "incident_index.json", incident_rows)
    write_csv(output_dir / "incident_index.csv", incident_rows, list(incident_rows[0]))
    dump_json(output_dir / "categorical_and_numeric_frequencies.json", frequencies)
    return {"frequencies": frequencies, "normalization_variants": normalized_variants}


def observation_unit_audit(rows: list[dict[str, str]]) -> dict[str, Any]:
    occurrence_ids = sort_ids(
        row["aiid_id"] for row in rows if int(row["number_of_occurrences"]) > 1
    )
    report_ids = sort_ids(
        row["aiid_id"] for row in rows if int(row["report_count"]) > 1
    )
    different_ids = sort_ids(
        row["aiid_id"]
        for row in rows
        if row["report_count"] != row["number_of_occurrences"]
    )
    aggregation_examples = [
        {
            key: row[key]
            for key in (
                "aiid_id",
                "title",
                "date",
                "report_count",
                "number_of_occurrences",
                "description",
                "classification_summary",
            )
        }
        for row in rows
        if int(row["number_of_occurrences"]) >= 100
    ]
    return {
        "record_unit": "One row per distinct aiid_id incident record in this export; not one report and not necessarily one discrete event or affected person.",
        "total_incident_records": len(rows),
        "report_count_sum": sum(int(row["report_count"]) for row in rows),
        "report_count_gt1_records": len(report_ids),
        "report_count_gt1_aiid_ids": report_ids,
        "number_of_occurrences_sum": sum(
            int(row["number_of_occurrences"]) for row in rows
        ),
        "number_of_occurrences_gt1_records": len(occurrence_ids),
        "number_of_occurrences_gt1_aiid_ids": occurrence_ids,
        "report_count_differs_from_occurrence_count": len(different_ids),
        "report_count_differs_from_occurrence_count_aiid_ids": different_ids,
        "aggregation_examples_ge100_occurrences": aggregation_examples,
        "report_provenance": {
            "source_url_blank_count": sum(
                not row["source_url"].strip() for row in rows
            ),
            "report_ids_present": False,
            "report_dates_present": False,
            "report_urls_present": False,
        },
        "denominator_caution": "Sum(report_count) describes record-level report counts, not verified unique source reports; report identifiers are absent. Sum(number_of_occurrences) is neither distinct incident records nor necessarily nonoverlapping real-world occurrences. Both must remain separate from N incidents. A populated occurrence value of 1 is not independently verified as exactly one real-world event; no uncertainty or default-value flag is supplied.",
    }


def crossfield_diagnostics(
    rows: list[dict[str, str]],
    profiles: list[dict[str, Any]],
    parsed: dict[str, dict[str, Any]],
    computed: dict[str, dict[str, int]],
    numeric: dict[str, Any],
    checks: Checks,
    output_dir: Path,
) -> dict[str, Any]:
    checks.register(
        "reported_text_no_but_direct_or_indirect_gt1",
        "internal_annotation_diagnostic",
        "A harm object's Reported is exactly No/False/not reported while its direct or indirect component score is >1. Inferred scores are excluded from this check.",
    )
    negative_reported: dict[str, list[str]] = defaultdict(list)
    for row in rows:
        for harm, text_field in HARM_TEXT_FIELDS.items():
            value = parsed[row["aiid_id"]][text_field]
            if not isinstance(value, dict):
                continue
            if text_state(value.get("Reported")) == "explicit_negative_token":
                scores = {
                    channel: int(row[f"{harm}_severity_{channel}"])
                    for channel in ("direct", "indirect")
                }
                if max(scores.values()) > 1:
                    checks.add(
                        "reported_text_no_but_direct_or_indirect_gt1",
                        row,
                        {
                            "harm_dimension": harm,
                            "reported_text": value.get("Reported"),
                            "scores": scores,
                            "direct_text": value.get("Directly caused"),
                            "indirect_text": value.get("Indirectly caused"),
                        },
                    )
                    negative_reported[harm].append(row["aiid_id"])
    inferred_driven: dict[str, Any] = {}
    for count in ("10", "13"):
        identifiers = sort_ids(
            row["aiid_id"]
            for row in rows
            if computed[row["aiid_id"]][f"max_{count}_all"]
            > computed[row["aiid_id"]][f"max_{count}_direct_indirect"]
        )
        inferred_driven[count] = {
            "incident_count": len(identifiers),
            "aiid_ids": identifiers,
        }
    thresholds: list[dict[str, Any]] = []
    for count in ("10", "13"):
        for threshold in (2, 3, 4, 5):
            reported_ids = sort_ids(
                row["aiid_id"]
                for row in rows
                if computed[row["aiid_id"]][f"max_{count}_direct_indirect"] >= threshold
            )
            all_ids = sort_ids(
                row["aiid_id"]
                for row in rows
                if computed[row["aiid_id"]][f"max_{count}_all"] >= threshold
            )
            inferred_only_ids = sort_ids(set(all_ids) - set(reported_ids))
            thresholds.append(
                {
                    "dimension_count": int(count),
                    "threshold_greater_than_or_equal": threshold,
                    "direct_or_indirect_count": len(reported_ids),
                    "any_channel_count": len(all_ids),
                    "only_reaches_threshold_when_inferred_included_count": len(
                        inferred_only_ids
                    ),
                    "only_reaches_threshold_when_inferred_included_aiid_ids": inferred_only_ids,
                }
            )
    write_csv(
        output_dir / "severity_channel_thresholds.csv", thresholds, list(thresholds[0])
    )
    denominators = []
    for profile in profiles:
        if profile["name"] not in CATEGORICAL_FIELDS:
            continue
        sentinel_count = sum(profile["null_like_token_counts"].values())
        denominators.append(
            {
                "field": profile["name"],
                "all_incident_denominator": len(rows),
                "blank_count": profile["blank_count"],
                "literal_null_like_token_count": sentinel_count,
                "nonblank_non_sentinel_denominator": len(rows)
                - profile["blank_count"]
                - sentinel_count,
                "null_like_token_counts": profile["null_like_token_counts"],
                "other_retained_as_category_count": sum(
                    row[profile["name"]] == "Other" for row in rows
                ),
                "rule_caution": "Sensitivity denominator only. Exact sentinel tokens are listed; Other is retained. Field-specific codebook decides whether missing, not applicable, and no additional label can be pooled.",
            }
        )
    write_csv(
        output_dir / "categorical_denominators.csv", denominators, list(denominators[0])
    )
    grouped: dict[tuple[str, str, str], list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        grouped[
            (row["model_name"], row["prompt_version"], row["ai_identity_source"])
        ].append(row)
    cohorts = []
    for (model, prompt, source), members in sorted(grouped.items()):
        zero_ids = sort_ids(
            row["aiid_id"]
            for row in members
            if any(
                int(row[f"{harm}_severity_{channel}"]) == 0
                for harm in HARM_13
                for channel in CHANNELS
            )
        )
        cohorts.append(
            {
                "model_name": model,
                "prompt_version": prompt,
                "ai_identity_source": source,
                "incident_count": len(members),
                "all_identity_arrays_blank_count": sum(
                    all(not row[field].strip() for field in IDENTITY_LIST_FIELDS)
                    for row in members
                ),
                "zero_severity_incident_count": len(zero_ids),
                "zero_severity_aiid_ids": zero_ids,
            }
        )
    write_csv(output_dir / "processing_cohorts.csv", cohorts, list(cohorts[0]))
    crosstab_rows = []
    for left, right in (
        ("behaviour_type", "natsec_autonomy_level"),
        ("model_name", "prompt_version"),
        ("prompt_version", "ai_identity_source"),
        ("confidence", "missing_information"),
        ("causal_entity", "causal_intent"),
        ("highest_severity", "highest_severity_10"),
    ):
        pairs: dict[tuple[str, str], list[str]] = defaultdict(list)
        for row in rows:
            pairs[(row[left], row[right])].append(row["aiid_id"])
        for (left_value, right_value), identifiers in sorted(pairs.items()):
            crosstab_rows.append(
                {
                    "left_field": left,
                    "right_field": right,
                    "left_value": left_value,
                    "right_value": right_value,
                    "incident_count": len(identifiers),
                    "aiid_ids": sort_ids(identifiers),
                }
            )
    write_csv(
        output_dir / "categorical_crosstabs.csv", crosstab_rows, list(crosstab_rows[0])
    )
    narrative_checks = {}
    for check in (
        "severity_gt1_with_absent_narrative",
        "severity_le1_with_substantive_narrative",
    ):
        entries = [event for event in checks.events if event["check_code"] == check]
        by_channel = {}
        for channel in CHANNELS:
            selected = [
                event
                for event in entries
                if event["evidence"]["score_field"].endswith("_" + channel)
            ]
            by_channel[channel] = {
                "cell_count": len(selected),
                "incident_count": len({entry["aiid_id"] for entry in selected}),
                "aiid_ids": sort_ids(entry["aiid_id"] for entry in selected),
            }
        narrative_checks[check] = by_channel
    majority_model = Counter(row["model_name"] for row in rows).most_common(1)[0][0]
    selected_ids = {
        row["aiid_id"]
        for row in rows
        if row["model_name"] != majority_model
        or any(not row[field].strip() for field in HARM_TEXT_FIELDS.values())
    }
    selected_ids.update(
        event["aiid_id"]
        for event in checks.events
        if event["check_code"]
        in {"severity_zero_encoding", "reported_text_no_but_direct_or_indirect_gt1"}
    )
    selected_ids.update(
        identifier
        for field in PEOPLE_FIELDS
        for identifier in numeric[field]["max_aiid_ids"]
    )
    selected_ids.update(numeric["number_of_occurrences"]["max_aiid_ids"])
    exceptions = []
    fields = [
        "aiid_id",
        "title",
        "date",
        "model_name",
        "prompt_version",
        "classified_at",
        "ai_identity_source",
        "report_count",
        "number_of_occurrences",
        *PEOPLE_FIELDS,
        "highest_severity",
        "highest_severity_10",
        "severity_sum_direct",
        "severity_sum_direct_10",
        "severity_sum_indirect_10",
        "severity_sum_inferred_10",
        "classification_summary",
        "description",
    ]
    for row in rows:
        if row["aiid_id"] not in selected_ids:
            continue
        exceptions.append(
            {
                **{field: row[field] for field in fields},
                "zero_severity_fields": [
                    f"{harm}_severity_{channel}"
                    for harm in HARM_13
                    for channel in CHANNELS
                    if int(row[f"{harm}_severity_{channel}"]) == 0
                ],
                "blank_harm_text_fields": [
                    field
                    for field in HARM_TEXT_FIELDS.values()
                    if not row[field].strip()
                ],
                "all_severity_components": {
                    f"{harm}_severity_{channel}": int(row[f"{harm}_severity_{channel}"])
                    for harm in HARM_13
                    for channel in CHANNELS
                },
            }
        )
    dump_json(output_dir / "exception_incidents.json", exceptions)
    people_summary = {
        field: {
            key: numeric[field][key]
            for key in (
                "min",
                "max",
                "median",
                "p90_nearest_rank",
                "p99_nearest_rank",
                "arithmetic_sum_diagnostic_only",
                "zero_count",
                "max_aiid_ids",
            )
        }
        for field in PEOPLE_FIELDS
    }
    return {
        "highest_severity_strictly_raised_by_inferred_channel": inferred_driven,
        "severity_threshold_channel_comparison": thresholds,
        "categorical_denominator_sensitivities": denominators,
        "processing_cohorts": cohorts,
        "severity_narrative_discrepancy_channel_breakdown": narrative_checks,
        "reported_no_with_direct_or_indirect_gt1_by_dimension": {
            harm: {
                "incident_count": len(set(identifiers)),
                "aiid_ids": sort_ids(identifiers),
            }
            for harm, identifiers in sorted(negative_reported.items())
        },
        "people_numeric_diagnostics": people_summary,
        "exception_incident_ids": sort_ids(selected_ids),
    }


def write_report(audit: dict[str, Any], path: Path) -> None:
    n = audit["row_count"]
    dup = audit["identifiers_and_duplicates"]
    dates = audit["timestamps"]
    unit = audit["observation_unit"]
    classification = audit["classification"]
    harm = audit["harm_and_severity"]
    metadata = audit["metadata"]
    diagnostics = audit["crossfield_diagnostics"]
    rubric = audit["published_harm_rubric_v2"]
    checks = audit["checks"]
    missing = [profile for profile in audit["field_profiles"] if profile["blank_count"]]
    lines = [
        "# CSV schema and denominator audit",
        "",
        f"Baseline: **{audit['analysis_date']}**. Input: `{audit['source']['path']}`.",
        f"SHA-256: `{audit['source']['sha256']}`. Size: {audit['source']['size_bytes']:,} bytes.",
        f"Reproduce: `python3 scripts/audit_schema.py --input {audit['source']['path']}`.",
        "",
        "## Record identity and observation unit",
        "",
        f"- **{n:,} data rows × {audit['column_count']} columns**, excluding the CSV header; {dup['distinct_aiid_ids']:,} distinct `aiid_id` values. IDs are kept as strings in reusable tables.",
        f"- Duplicate groups: `{json.dumps(dup['duplicate_group_counts'], sort_keys=True)}`. No ID range continuity is assumed; missing numeric IDs do not imply missing CSV rows.",
        f"- {dup['near_title_candidate_pair_count']} similar-title pairs were retained by an explicit deterministic screen, involving {dup['near_title_candidate_incident_count']} IDs. They are **candidates, not confirmed semantic duplicates**. Exact/normalized description-duplicate groups are also exposed in `duplicate_audit.json`. See `research/schema/title_similarity_candidates.csv`; do not merge on title alone.",
        f"- `report_count` sums to **{unit['report_count_sum']:,}**, with {unit['report_count_gt1_records']:,} records containing >1 report. Report rows/IDs, report dates, and report URLs are not exported.",
        f"- `number_of_occurrences` sums to **{unit['number_of_occurrences_sum']:,}**, with {unit['number_of_occurrences_gt1_records']} records containing >1 occurrence. It differs from `report_count` in {unit['report_count_differs_from_occurrence_count']} rows. The safe count unit is the **incident record**, not a discrete real-world event, report, or person.",
        "- Large occurrence-count rows and their original narratives are preserved in `observation_unit.aggregation_examples_ge100_occurrences` in the JSON audit. These show that records can aggregate a series/collection of events. There is no per-count uncertainty/default flag establishing whether a value of 1 really means exactly one discrete event.",
        "",
        "## Time and provenance",
        "",
        f"- Raw `date`: **{dates['date']['min']} → {dates['date']['max']}**; {dates['date']['midnight_count']}/{n} values are midnight timestamps. Per `docs/coordination.md` this is provisionally the AIID incident date. The export supplies no authoritative date definition or estimated-date/precision flag.",
        f"- `classified_at`: **{dates['classified_at']['min']} → {dates['classified_at']['max']}**. This is classification time, not occurrence or reporting time. Annual counts are in `incident_year_counts.csv`; 2026 is incomplete.",
        f"- `source_url` is blank in **{unit['report_provenance']['source_url_blank_count']:,}/{n:,} rows**. A constructed AIID citation URL from an ID can help retrieve provenance later but is not an original exported source link. No reporting lag can be estimated from this CSV.",
        "",
        "## Missingness and encodings",
        "",
        "The full 130-field inventory includes exact blanks, whitespace, literal null-like strings, and all scalar categorical/numeric frequency distributions. Empty strings, JSON `[]`, `N/A`, `None`, `null`, `unknown`/`Unknown`, and `unspecified` are preserved as distinct encodings; a blanket CSV NA conversion would lose information.",
        "",
        "| Field | Blank cells |",
        "|---|---:|",
    ]
    lines.extend(
        f"| `{profile['name']}` | {profile['blank_count']} |" for profile in missing
    )
    lines += [
        "",
        "See `field_profiles.csv`, `categorical_and_numeric_frequencies.json`, and `field_value_frequencies.csv` for every field/value, including nonblank missingness sentinels. Free-text entity labels are not guaranteed delimited lists and must not be blindly split on commas.",
        f"The {audit['json_structure_profiles']['expected_json_field_count']} expected JSON fields contain {audit['json_structure_profiles']['nonblank_json_cell_count']:,} nonblank JSON cells and {audit['json_structure_profiles']['blank_json_cell_count']} blank cells. All nonblank expected JSON cells decode successfully; prose that merely starts with a bracket is not counted as a malformed JSON field.",
        '`ishikawa` has six fixed axes (`Management`, `Technology`, `Human Factors`, `Process and Methods`, `Data Inputs`, `Regulatory Environment`), each containing arrays of `{"Cause": string, "Explanation": string}` objects. Preserve `N/A` placeholder objects. These suggested-cause narratives are separate from the record-level causal taxonomy. All nested paths, types, array lengths and keysets are in `json_structure_profiles.json`.',
        "",
        "## Primary versus additional risk classifications",
        "",
        "- `domain_code` and `subdomain_code` are strings combining a numeric code and a human-readable label, not plain numbers. Parse the leading code, retain the original full label.",
        f"- {len(classification['domain_label_map'])} primary domains; {len({item['numeric_code'] for item in classification['frequencies'] if item['scope'] == 'primary' and item['level'] == 'subdomain'})} primary subdomains. All primary fields are populated.",
        f"- `additional_subdomains` is a JSON array in every row. Length distribution: `{json.dumps(classification['additional_length_distribution'], sort_keys=True)}`; **{classification['additional_membership_count']:,} additional memberships** across {classification['incidents_with_additional_classifications']:,} incidents.",
        f"- Additional entry keysets: `{json.dumps(classification['additional_entry_keysets'], sort_keys=True)}`. Additional-only numeric subdomains: `{classification['subdomains_only_in_additional']}`.",
        "- Additional entries carry subdomain+justification, not their own domain label or causal triple. The parent domain in the membership table is explicitly derived from the subdomain prefix. `causal_entity`, `causal_intent`, and `causal_timing` occur once per incident record.",
        "- `classification_memberships.csv` preserves primary/additional scope and list position. `classification_frequencies.csv` exposes both membership counts and **distinct incident counts**, plus all-incident denominators. Any-label counts deduplicate incident ID within a category; category totals need not sum to N.",
        "",
        "| Primary field | Exact frequency encoding |",
        "|---|---|",
    ]
    for field in (
        "domain_code",
        "causal_entity",
        "causal_intent",
        "causal_timing",
        "behaviour_type",
        "eu_ai_act_risk_level",
    ):
        counts = audit["categorical_and_numeric_frequencies"][field]["value_counts"]
        lines.append(
            f"| `{field}` | {'; '.join(f'{value}: {count}' for value, count in counts.items())} |"
        )
    lines += [
        "",
        f"EU risk codes map empirically to leading reasoning labels as `{metadata['eu_risk_reasoning_derived_label_map']}` over {metadata['eu_risk_recognized_prefix_row_count']} recognized prefixes. Numeric order is not increasing severity; this mapping is not an independent legal assessment.",
        "",
        "## Harm evidence and severity versions",
        "",
        "- **13 harm dimensions × 3 channels = 39 component score fields.** Original ten dimensions are listed in JSON. Psychological, epistemic, and CSEA dimensions are the three additions.",
        "- Each harm-text field is a JSON object with `Reported`, `Directly caused`, `Indirectly caused`, and `Inferred additional harm` text. `Reported` is **not a boolean**: it mixes `No`, negative reporting statements, and descriptive narratives. A negative reporting statement is not proof of no harm.",
        "- Direct/indirect distinguish causal pathways; inferred adds a different evidentiary status. Keep the channels separate. `harm_evidence_long.csv` preserves all text and scores; lexical states are explicitly diagnostic, not semantic truth labels.",
        "- **Level 1 is not a binary harm indicator.** It occurs extensively with `N/A`/negative text; the published v2 rubric also explicitly includes minor harms within level 1. A score of 1 cannot establish either harm or no harm. Zero-valued components remain a distinct encoding requiring review.",
        "",
        "| Exported aggregate | Formula matching every row |",
        "|---|---|",
    ]
    for field, formulas in harm["exactly_matching_formulas"].items():
        lines.append(
            f"| `{field}` | {', '.join(f'`{formula}`' for formula in formulas) or '**No tested formula matches every row**'} |"
        )
    lines += [
        "",
        "Formula notation: `sum_13_direct` adds 13 direct component scores; `max_13_direct_indirect` takes the maximum over 26 direct/indirect scores; `max_13_all` also includes inferred scores. The analogous `10` formulas use the original ten dimensions.",
        f"- `highest_severity` differs from `highest_severity_10` in **{harm['highest_severity_vs_highest_severity_10_difference_count']} records**; all IDs are in JSON and both source values plus all recomputed variants are in `severity_recomputed.csv`.",
        f"- Inferred scores strictly raise the 13-dimension maximum above the direct/indirect maximum in **{diagnostics['highest_severity_strictly_raised_by_inferred_channel']['13']['incident_count']} incidents**. `severity_channel_thresholds.csv` quantifies threshold sensitivity by 10/13 dimensions and channel inclusion.",
        "- There are **no exported severity columns explicitly named v2**. `prompt_version` contains `aiid.v2`/`aiid.v2.1`; do not equate prompt version, 10-versus-13 dimension aggregates, and an externally named severity-v2 scale without documentation.",
        "- Raw severity sums include baseline ones (typically 10 or 13 before increments); they are sums of ordinal categories, not harm quantities. Arithmetic consistency does not validate their comparability or make them calibrated cardinal scores.",
        "- `natsec_overall_score` matches the maximum of its five national-security dimension scores in all 1,698 rows. Its response encoding is **1 Minor, 2 Moderate, 3 Substantial, 4 Severe, 5 Critical**, distinct from the harm rubric's names. No score/response-label discrepancies were found.",
        "",
        "## Models, prompt versions, and taxonomy metadata",
        "",
        f"- Classifier `model_name`: `{metadata['classifier_model_counts']}`; prompt versions: `{metadata['prompt_version_counts']}`; identity extraction versions: `{metadata['identity_extraction_version_counts']}`.",
        "- `subject_model_name` and `ai_developers`/`ai_models`/`ai_model_names`/`ai_model_versions`/`ai_model_variants` concern the implicated AI system. Their source is a separate extraction stage. Do not group incidents by classifier model as though it were the implicated product.",
        f"- Developer and model arrays have different lengths in {metadata['developer_vs_model_array_length_differ_count']} incidents; at least two of the five identity arrays differ in length in {metadata['any_identity_array_length_differ_count']}. They lack linked identity objects, so positional joins are unsafe.",
        "- `classification_batches.csv` quantifies classifier × prompt × identity-extraction × classification-day cohorts and missing identities/zero severities. It exposes version-linked missingness rather than silently mixing cohorts.",
        "- The CSV contains no explicit taxonomy/rubric version, prompt text, source-report set, human verification flag, or replicate classifier/agreement output. Confidence labels are classifier annotations, not statistical certainty.",
        "",
        "## Executable discrepancies and diagnostic checks",
        "",
        "Definitions distinguish hard structure checks from definition-dependent diagnostics and benign version differences. Counts below are distinct incidents; events can be multiple cells per incident. **No candidate findings are ranked.** Full IDs and exact evidence are in `checks.json` / `anomalies.csv`.",
        "",
        "| Check | Incidents | Events | ID examples (full lists in JSON) | Interpretation |",
        "|---|---:|---:|---|---|",
    ]
    for code, value in sorted(checks.items()):
        if value["event_count"]:
            examples = ", ".join(value["aiid_ids"][:12])
            if value["incident_count"] > 12:
                examples += ", …"
            lines.append(
                f"| `{code}` | {value['incident_count']} | {value['event_count']} | {examples} | {value['interpretation']} |"
            )
    zero_checks = [code for code, value in checks.items() if not value["event_count"]]
    lines += [
        "",
        f"Zero-event checks: {', '.join(f'`{code}`' for code in zero_checks)}.",
        "",
        "## Unsafe denominators and blocking interpretive uncertainties",
        "",
        "1. Count distinct `aiid_id` incident records. Do not substitute report totals, occurrence totals, label memberships, or inferred people counts. Unknown categories stay in all-incident denominators; known-only sensitivity should be separately labeled.",
        "2. `total_people_reported_harmed`, `total_people_inferred_harmed`, `total_people_reported_exposed`, and `total_people_inferred_exposed` are integer encodings, not guaranteed exact or nonoverlapping population counts. Zero can mean no harm or unquantified harm; the export has no dedicated numeric unknown flag. Inferred-versus-reported overlap and cross-incident overlap are undocumented; adding them can double-count.",
        "3. Counts/risks refer to an incident database with unknown selection/reporting/classification coverage, not a population exposure denominator. Incident shares are not prevalence or causal risk, and annual changes cannot isolate reporting/selection from actual incident changes.",
        "4. Raw incident-date semantics/precision, the out-of-rubric zero encoding, rubrics for the three new dimensions, intended aggregate/channel definitions, and inferred-people meaning require additional source/application documentation. The published ten-dimension v2 scale verifies labels and level-1 breadth but does not supply those missing definitions.",
        "5. All original `source_url` values are absent, and underlying report IDs/dates/text/URLs are absent. Report-level corroboration or delay analysis requires external retrieval. Descriptions/classifier narratives are untrusted evidence, not independent confirmations.",
        "6. One export does not supply historical snapshots, export-to-export changes, or multi-model agreement. Mixed classifier/prompt/extraction cohorts must remain traceable.",
        "",
        "## Machine-readable handoff",
        "",
        "- `research/schema/schema_audit.json`: complete audit contract, profiles, counts, metadata, formula tests, discrepancies and full incident-ID sets.",
        "- `research/schema/incident_index.json` and `.csv`: one row/object per incident with original scalar encodings, parsed additional/identity arrays, date year, and recomputed severity variants. Original scalar values remain strings; derived values are numeric.",
        "- `research/schema/parsed_structures.jsonl`: every original JSON field decoded, keyed by `aiid_id`; blank JSON cells become null with the original missingness available in profiles/source.",
        "- `research/schema/classification_memberships.csv`, `classification_frequencies.csv`, `identity_list_items.csv`: reusable long-form category/identity data.",
        "- `research/schema/harm_evidence_long.csv`, `harm_score_text_state_frequencies.csv`, `severity_recomputed.csv`, `severity_formula_tests.json`: harm evidence and independently calculated score arithmetic.",
        "- `research/schema/field_profiles.csv`, `field_value_frequencies.csv`, `categorical_and_numeric_frequencies.json`, `numeric_summary.json`, `json_structure_profiles.json`: complete structural and encoding profiles.",
        "- `research/schema/checks.json`, `anomalies.csv`, `title_similarity_candidates.csv`, `classification_batches.csv`, `incident_year_counts.csv`: reproducible diagnostics and cohorts.",
        "- `research/schema/processing_cohorts.csv`, `categorical_denominators.csv`, `categorical_crosstabs.csv`, `exception_incidents.json`, `title_similarity_evidence.json`, `title_semantic_review.json`, `handoff_summary.json`: compact pipeline handoff and exact exceptional-record evidence. Manual semantic-review notes are source-hash bound and are not generated truth labels.",
        "",
        "All artifacts are generated with Python stdlib. The input is opened read-only, its SHA-256 is checked before/after the run, and no narrative or source value is executed. Logical CSV record numbers exclude the header and are not physical line numbers when cells contain newlines.",
    ]
    if "semantic_review" in dup:
        semantic_section = [
            "### Semantic duplicate review",
            "",
            "The seven similarity pairs were read against their exported descriptions, dates, harmed-party fields and summaries. **IDs 230 and 353 are a probable same-event duplicate**: both date 2019-03-01, describe a fatal Tesla Model 3/tractor-trailer collision in Florida, and name Jeremy Beren Banner / Jeremy Banner. They remain two distinct incident records; underlying reports are needed before an event-level merge.",
            "",
            "The identical descriptions in **74 and 439** do not justify merging: their harmed-party fields name Robert Julian-Borchak Williams versus Michael Oliver and dates differ. Their classifier summaries broaden to multiple arrests, so report-level scope overlap remains possible. Other similar pairs differ in company, location, person impersonated, or claim made. All seven decisions and source evidence are in `title_semantic_review.json` and `title_similarity_evidence.json`.",
            "",
        ]
        insert_at = lines.index("## Time and provenance")
        lines[insert_at:insert_at] = semantic_section
    if rubric["status"] == "verified_against_local_public_source_snapshot":
        section = [
            "",
            "## Published v2 rubric verified from the local source snapshot",
            "",
            f"The chart-research agent retrieved the [published harm rubric]({rubric['source']['requested_url']}) at `{rubric['source']['retrieved_at_utc']}`. The audit verifies its raw and extracted-text SHA-256 against `research/web/manifest.json` and parses all 50 score/category definitions into `published_harm_rubric_v2.json` and `.csv`.",
            f"Document title: **{rubric['scale_title']}**. Raw SHA-256: `{rubric['source']['raw_sha256']}`.",
            "",
            "| Score | Published label |",
            "|---:|---|",
            *[
                f"| {score} | {label} |"
                for score, label in rubric["score_labels"].items()
            ],
            "",
            "Level-1 examples, quoted verbatim: physical harm **“None to minor injuries”**; toxic/malicious content **“No harmful content to moderately offensive content (e.g., minor profanity, slurs)”**; financial loss **“None to small direct financial loss (<$10,000)”**. Thus `>1` measures above-negligible scoring, not the existence of any harm. The published tab defines the original ten dimensions; psychological, epistemic, and CSEA thresholds are not present in that tab. The CSV has no field establishing which rubric version each classifier run used.",
            "",
            "Rubric-v2 document version, prompt `aiid.v2`/`aiid.v2.1`, and `_10` versus 13-dimension aggregates are three distinct version concepts.",
        ]
        insert_at = lines.index("## Models, prompt versions, and taxonomy metadata")
        lines[insert_at:insert_at] = section + [""]
    else:
        lines = [
            line.replace(
                "the published v2 rubric also explicitly includes minor harms within level 1",
                "a separate published rubric snapshot was not available in this run",
            )
            for line in lines
        ]
    counts_table = [
        "",
        "### People-count numeric diagnostics",
        "",
        "These are export arithmetic diagnostics, **not totals of distinct people**. Full extreme records are preserved in `exception_incidents.json`.",
        "Incident **781** supplies **8,000,000,000 in all four people fields**. Its narrative describes Clearview scraping billions of images; the export does not provide a traceable conversion from images to distinct people. Preserve this value as exported, but do not present it or a sum as a verified population count. People fields exceed signed 32-bit range; Python integers or at least 64-bit storage are appropriate.",
        "",
        "| Field | Zeros | Median | Maximum | IDs at maximum | Arithmetic sum (unsafe as population total) |",
        "|---|---:|---:|---:|---|---:|",
    ]
    for field, value in diagnostics["people_numeric_diagnostics"].items():
        counts_table.append(
            f"| `{field}` | {value['zero_count']} | {value['median']:g} | {value['max']:,} | {', '.join(value['max_aiid_ids'])} | {value['arithmetic_sum_diagnostic_only']:,} |"
        )
    insert_at = lines.index("## Machine-readable handoff")
    lines[insert_at:insert_at] = counts_table + [""]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--analysis-date", default="2026-09-27")
    parser.add_argument("--preview", action="store_true")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    headers, rows, metadata = source_rows(args.input)
    if not rows:
        raise ValueError("No data records found")
    if metadata["row_width_defects"] or metadata["duplicate_header_names"]:
        raise ValueError(
            "Malformed CSV header/record widths; stop rather than collapse data"
        )
    profiles = profile_fields(headers, rows)
    output_dir = ROOT / "research" / "schema"
    output_dir.mkdir(parents=True, exist_ok=True)
    checks = Checks()
    rubric = documented_rubric_audit(output_dir)
    duplicates = duplicate_audit(headers, rows, output_dir)
    semantic_review_path = output_dir / "title_semantic_review.json"
    if semantic_review_path.exists():
        semantic_review = json.loads(semantic_review_path.read_text(encoding="utf-8"))
        if semantic_review.get("source_sha256") == metadata["sha256"]:
            duplicates["semantic_review"] = semantic_review
            duplicates["semantic_review_sha256"] = hashlib.sha256(
                semantic_review_path.read_bytes()
            ).hexdigest()
    timestamps = timestamp_audit(rows, args.analysis_date, checks, output_dir)
    numeric = numeric_audit(profiles, rows, checks)
    parsed, structures = parse_structures(rows, checks, output_dir)
    classification = classification_audit(rows, parsed, checks, output_dir)
    harm, computed = harm_and_severity_audit(rows, parsed, checks, output_dir)
    model_metadata = metadata_audit(rows, parsed, checks, output_dir)
    tables = artifact_tables(headers, rows, profiles, parsed, computed, output_dir)
    observation_unit = observation_unit_audit(rows)
    diagnostics = crossfield_diagnostics(
        rows, profiles, parsed, computed, numeric, checks, output_dir
    )
    if rubric["status"] == "verified_against_local_public_source_snapshot":
        harm["severity_scale_status"] = (
            "Published v2 ten-dimension rubric verified from its hashed local snapshot: 1 Negligible, 2 Minor, 3 Substantial, 4 Severe, 5 Catastrophic. Level 1 spans no harm through low-level harm, so neither >=1 nor >1 is a binary any-harm indicator. Zero is outside that rubric. Definitions for the added psychological, epistemic and CSEA dimensions are absent from the published tab, and no per-record rubric version is exported."
        )
        harm["published_rubric_source"] = rubric["source"]
        harm["published_score_labels_for_original_ten"] = rubric["score_labels"]
    check_summary = checks.summary()
    audit = {
        "audit_version": "1.1",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "python_version": sys.version,
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "analysis_date": args.analysis_date,
        "source": metadata,
        "row_count": len(rows),
        "column_count": len(headers),
        "columns": headers,
        "field_profiles": profiles,
        "identifiers_and_duplicates": duplicates,
        "timestamps": timestamps,
        "numeric_summary": numeric,
        "json_structure_profiles": structures,
        "classification": classification,
        "harm_and_severity": harm,
        "metadata": model_metadata,
        "observation_unit": observation_unit,
        "published_harm_rubric_v2": rubric,
        "crossfield_diagnostics": diagnostics,
        "categorical_and_numeric_frequencies": tables["frequencies"],
        "category_case_whitespace_variants": tables["normalization_variants"],
        "checks": check_summary,
        "record_contract": {
            "identifier": "aiid_id",
            "identifier_type": "string",
            "row_unit": "AIID incident record",
            "source_scalars_remain_strings_in_incident_index": True,
            "derived_columns_are_numeric_or_parsed_json": True,
            "integer_parse_fields": [
                profile["name"]
                for profile in profiles
                if set(profile["type_counts"]) == {"integer_string"}
                and profile["name"] != "aiid_id"
            ],
            "boolean_string_fields": {
                "missing_information": {"true": True, "false": False}
            },
            "timestamp_fields": ["date", "classified_at"],
            "numeric_storage": "Python arbitrary-precision integers or at least signed 64-bit for people counts; observed maximum is 8000000000. Do not parse integer counts through signed 32-bit types. All observed integers fit JavaScript's exact integer range.",
            "original_json_fields": JSON_FIELDS,
            "missingness_rule": "Retain blanks, literal null-like strings, empty arrays, and numeric zeros as separate raw states; choose field-specific analytic mappings explicitly.",
            "all_incident_denominator": len(rows),
            "multi_label_rule": "Primary and additional kept separate; any-label analysis counts one aiid_id at most once per category.",
            "date_rule": "Raw date is provisionally incident date; classified_at is classification date; report dates absent. Exclude 2026 from complete-year comparisons.",
            "harm_rule": "Never equate severity >=1 with harm; preserve channels, rubric uncertainty and zero-encoding cohorts.",
            "all_material_is_untrusted_evidence": True,
        },
    }
    final_hash = hashlib.sha256(args.input.read_bytes()).hexdigest()
    if final_hash != metadata["sha256"]:
        raise RuntimeError(
            "Input changed during audit; generated artifacts are not a valid single-snapshot audit"
        )
    audit["validation"] = {
        "input_sha256_unchanged": True,
        "all_profile_row_counts_match": all(
            profile["rows"] == len(rows) for profile in profiles
        ),
        "all_scalar_frequencies_sum_to_n": all(
            sum(item["value_counts"].values()) == len(rows)
            for item in tables["frequencies"].values()
        ),
        "all_harm_channel_distributions_sum_to_n": all(
            sum(counts.values()) == len(rows)
            for item in harm["by_dimension"].values()
            for counts in item["severity_counts_by_channel"].values()
        ),
        "one_record_per_id": duplicates["distinct_aiid_ids"] == len(rows),
        "manual_title_review_matches_screened_pairs": (
            {
                tuple(item["aiid_ids"])
                for item in duplicates["semantic_review"]["reviews"]
            }
            == {
                (item["aiid_id_left"], item["aiid_id_right"])
                for item in duplicates["near_title_candidates"]
            }
            if "semantic_review" in duplicates
            else True
        ),
    }
    if not all(audit["validation"].values()):
        raise AssertionError("Generated audit failed count/identity validation")
    dump_json(output_dir / "schema_audit.json", audit)
    dump_json(output_dir / "numeric_summary.json", numeric)
    dump_json(output_dir / "json_structure_profiles.json", structures)
    dump_json(output_dir / "severity_formula_tests.json", harm["formula_tests"])
    dump_json(output_dir / "checks.json", check_summary)
    dump_json(output_dir / "duplicate_audit.json", duplicates)
    dump_json(output_dir / "metadata_audit.json", model_metadata)
    dump_json(output_dir / "timestamp_audit.json", timestamps)
    dump_json(output_dir / "crossfield_diagnostics.json", diagnostics)
    dump_json(
        output_dir / "handoff_summary.json",
        {
            "source_sha256": metadata["sha256"],
            "rows": len(rows),
            "columns": len(headers),
            "unique_incident_ids": duplicates["distinct_aiid_ids"],
            "duplicate_group_counts": duplicates["duplicate_group_counts"],
            "duplicate_description_groups": duplicates["duplicate_groups"][
                "description_exact"
            ],
            "near_title_pair_count": duplicates["near_title_candidate_pair_count"],
            "probable_same_event_duplicate_pairs": [
                review["aiid_ids"]
                for review in duplicates.get("semantic_review", {}).get("reviews", [])
                if review["status"]
                == "probable_same_event_duplicate_pending_source_confirmation"
            ],
            "source_url_blank_count": observation_unit["report_provenance"][
                "source_url_blank_count"
            ],
            "report_count_sum": observation_unit["report_count_sum"],
            "occurrence_count_sum": observation_unit["number_of_occurrences_sum"],
            "records_with_multiple_reports": observation_unit[
                "report_count_gt1_records"
            ],
            "records_with_multiple_occurrences": observation_unit[
                "number_of_occurrences_gt1_records"
            ],
            "incident_date_range": [
                timestamps["date"]["min"],
                timestamps["date"]["max"],
            ],
            "classification_timestamp_range": [
                timestamps["classified_at"]["min"],
                timestamps["classified_at"]["max"],
            ],
            "primary_subdomain_count": len({row["subdomain_code"] for row in rows}),
            "additional_memberships": classification["additional_membership_count"],
            "additional_list_lengths": classification["additional_length_distribution"],
            "subdomains_only_in_additional": classification[
                "subdomains_only_in_additional"
            ],
            "exact_aggregate_formulas": harm["exactly_matching_formulas"],
            "highest_severity_vs_10_difference_count": harm[
                "highest_severity_vs_highest_severity_10_difference_count"
            ],
            "highest_severity_raised_by_inferred_count": {
                key: value["incident_count"]
                for key, value in diagnostics[
                    "highest_severity_strictly_raised_by_inferred_channel"
                ].items()
            },
            "people_numeric_diagnostics": diagnostics["people_numeric_diagnostics"],
            "processing_cohorts": diagnostics["processing_cohorts"],
            "published_rubric_status": rubric["status"],
            "published_rubric_score_labels": rubric.get("score_labels"),
            "checks_with_events": {
                key: {
                    name: value[name]
                    for name in ("interpretation", "incident_count", "event_count")
                }
                for key, value in check_summary.items()
                if value["event_count"]
            },
            "exception_incident_ids": diagnostics["exception_incident_ids"],
            "validation": audit["validation"],
        },
    )
    write_csv(
        output_dir / "anomalies.csv",
        checks.events,
        ["check_code", "aiid_id", "evidence"],
    )
    write_report(audit, ROOT / "research" / "schema_audit.md")
    if args.preview:
        print(
            json.dumps(
                {
                    "row_count": len(rows),
                    "column_count": len(headers),
                    "duplicate_group_counts": duplicates["duplicate_group_counts"],
                    "title_similarity_candidates": duplicates["near_title_candidates"],
                    "date_range": [
                        timestamps["date"]["min"],
                        timestamps["date"]["max"],
                    ],
                    "classified_at_range": [
                        timestamps["classified_at"]["min"],
                        timestamps["classified_at"]["max"],
                    ],
                    "aggregate_formula_matches": harm["exactly_matching_formulas"],
                    "rubric_status": rubric["status"],
                    "nonzero_checks": {
                        code: {
                            key: result[key]
                            for key in ("incident_count", "event_count")
                        }
                        for code, result in check_summary.items()
                        if result["event_count"]
                    },
                    "validation": audit["validation"],
                },
                ensure_ascii=False,
                indent=2,
            )
        )
    LOGGER.info(
        json.dumps(
            {
                "event": "schema_audit_completed",
                "rows": len(rows),
                "columns": len(headers),
                "output": str(output_dir),
            }
        )
    )


if __name__ == "__main__":
    main()
