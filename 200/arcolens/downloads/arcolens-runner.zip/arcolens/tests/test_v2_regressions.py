"""Regression counterexamples from the Fable 5.1 second review (reviewer 3 and its verifier).

Each test encodes a defect that was present in code 0.1.1 and is fixed in 0.2.0. All rows are
synthetic (tests/test_analysis.raw_row); nothing here is a real export.
"""

from __future__ import annotations

import csv
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from datetime import date
from pathlib import Path

from tests.test_analysis import DAY, ROOT, raw_row
from tracker.__main__ import code_files, documentation_files, next_due, verify_run
from tracker.audit import nonempirical_check
from tracker.calc import Engine, severity_state
from tracker.candidates import CHART_CAVEAT, candidate_shortlist, cohort_info
from tracker.data import code, json_bytes, load_incidents, parse_row
from tracker.explore import explore
from tracker.models import AnalysisConfig, Selection, SeveritySpec
from tracker.report import write_candidate_report

CONFIG = AnalysisConfig.model_validate_json(
    (ROOT / "config/analysis.json").read_text(encoding="utf-8")
)
REPRODUCTION_RUN = ROOT / json.loads((ROOT / "LATEST_RUN.json").read_text())["path"]


def engine(*rows: dict[str, str], day: date = DAY) -> Engine:
    return Engine([parse_row(row, day) for row in rows], CONFIG, day)


class IngestionErrorsAreAttributable(unittest.TestCase):
    def test_fractional_severity_cell_names_incident(self) -> None:
        with self.assertRaisesRegex(
            ValueError, r"Incident 1: physical_harm_severity_direct"
        ):
            parse_row(raw_row(1, physical_harm_severity_direct="3.0"), DAY)

    def test_additional_subdomain_missing_code_is_valueerror_naming_incident(
        self,
    ) -> None:
        with self.assertRaisesRegex(ValueError, r"Incident 1: additional_subdomains"):
            parse_row(raw_row(1, additional_subdomains='[{"kode": "4.3 F"}]'), DAY)

    def test_additional_subdomain_string_item_is_valueerror(self) -> None:
        with self.assertRaisesRegex(ValueError, r"Incident 1"):
            parse_row(raw_row(1, additional_subdomains='["4.3 F"]'), DAY)

    def test_bad_date_names_incident(self) -> None:
        with self.assertRaisesRegex(ValueError, r"Incident 1: date"):
            parse_row(raw_row(1, date="2024-13-01"), DAY)

    def test_bare_identity_string_is_valueerror_naming_incident(self) -> None:
        with self.assertRaisesRegex(ValueError, r"Incident 1: ai_developers"):
            parse_row(raw_row(1, ai_developers="OpenAI"), DAY)


class IngestionSemantics(unittest.TestCase):
    def test_classified_at_with_surrounding_whitespace_parses(self) -> None:
        parse_row(raw_row(1, classified_at=" 2026-07-18 00:00:00+00 "), DAY)

    def test_leading_zero_id_is_same_incident(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "x.csv"
            first, second = raw_row(1), raw_row("01")
            with path.open("w", newline="", encoding="utf-8") as handle:
                writer = csv.DictWriter(handle, fieldnames=list(first))
                writer.writeheader()
                writer.writerows([first, second])
            with self.assertRaisesRegex(ValueError, "Duplicate incident IDs"):
                load_incidents(path, DAY)

    def test_unicode_digits_are_rejected(self) -> None:
        for field, value in (
            ("aiid_id", "１"),
            ("natsec_overall_score", "٣"),
            ("physical_harm_severity_direct", "３"),
        ):
            with self.subTest(field=field), self.assertRaises(ValueError):
                parse_row(raw_row(1, **{field: value}), DAY)

    def test_three_level_code_is_rejected_not_truncated(self) -> None:
        with self.assertRaises(ValueError):
            code("7.3.1 deep")
        self.assertEqual(code("7.3 Lack"), "7.3")
        self.assertEqual(code("7.30 vs"), "7.30")

    def test_blank_domain_with_primary_subdomain_derives_domain(self) -> None:
        row = parse_row(raw_row(1, domain_code=""), DAY)
        self.assertEqual(row.domain, "1")

    def test_plus_sign_and_underscore_severity_rejected(self) -> None:
        for value in ("+3", "0_3"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                parse_row(raw_row(1, physical_harm_severity_direct=value), DAY)

    def test_explicit_zero_is_distinguishable_from_blank_but_both_unknown(self) -> None:
        zero = parse_row(raw_row(1, physical_harm_severity_direct="0"), DAY)
        blank = parse_row(raw_row(2, physical_harm_severity_direct=""), DAY)
        self.assertEqual(zero.severity["physical_harm"]["direct"], 0)
        self.assertIsNone(blank.severity["physical_harm"]["direct"])
        self.assertEqual(zero.zero_coded_severity_cells, 1)
        self.assertEqual(blank.blank_severity_cells, 1)
        for row in (zero, blank):
            self.assertEqual(
                severity_state(row, SeveritySpec(threshold=4)), (False, True)
            )


class EngineContracts(unittest.TestCase):
    def test_duplicate_categories_in_severity_spec_rejected(self) -> None:
        with self.assertRaises(ValueError):
            SeveritySpec(
                categories=["financial_loss", "financial_loss"], minimum_categories=2
            )

    def test_numeric_min_on_non_numeric_field_names_field(self) -> None:
        with self.assertRaisesRegex(ValueError, "title"):
            engine(raw_row(1, title="abc")).fraction(
                "nm", Selection(numeric_min={"title": 1})
            )

    def test_identity_contains_unknown_field_is_valueerror(self) -> None:
        with self.assertRaisesRegex(ValueError, "identity field"):
            engine(raw_row(1)).fraction(
                "ic", Selection(identity_contains={"title": ["x"]})
            )

    def test_series_population_window_conflict_is_explicit(self) -> None:
        with self.assertRaisesRegex(ValueError, "conflicts"):
            engine(raw_row(1, year=2019), raw_row(2, year=2022)).series(
                "conflict", Selection(), 2019, 2022, Selection(min_year=2021)
            )

    def test_cohort_tie_break_is_deterministic(self) -> None:
        rows_ab = [raw_row(1, model_name="A"), raw_row(2, model_name="B")]
        rows_ba = [raw_row(1, model_name="B"), raw_row(2, model_name="A")]
        self.assertEqual(
            cohort_info(engine(*rows_ab))["model"],
            cohort_info(engine(*rows_ba))["model"],
        )
        self.assertTrue(cohort_info(engine(*rows_ab))["tie_broken_by_name"])


class TemplatesAndReports(unittest.TestCase):
    def test_known_primary_sensitivity_flags_no_effect(self) -> None:
        rows = [
            raw_row(i, year=2021, primary="7.3" if i < 40 else "1.1")
            for i in range(1, 101)
        ]
        rows += [
            raw_row(i, year=2025, primary="7.3" if i < 130 else "1.1")
            for i in range(101, 201)
        ]
        candidates, _ = candidate_shortlist(
            engine(*rows), {"start_year": 2021, "end_year": 2025}
        )
        c2 = {c.candidate_id: c for c in candidates}["IT-C002"]
        variant = next(
            v for v in c2.robustness if v["alternative"].startswith("known primary")
        )
        self.assertTrue(variant["identical_to_base"])
        self.assertIn("no effect", variant["alternative"])

    def test_report_handles_candidate_without_chart(self) -> None:
        candidates, _ = candidate_shortlist(
            engine(raw_row(1, year=2021), raw_row(2, year=2025)),
            {"start_year": 2021, "end_year": 2025},
        )
        table_only = candidates[0].model_copy(update={"chart_ids": []})
        with tempfile.TemporaryDirectory() as directory:
            write_candidate_report(
                Path(directory), engine(raw_row(1, year=2021)), [table_only], [], []
            )
            text = (Path(directory) / "candidate_insights.md").read_text(
                encoding="utf-8"
            )
        self.assertIn("Supporting table only", text)

    def test_concentration_ledger_skips_none_winner(self) -> None:
        ledger = explore(
            engine(raw_row(1, year=2021, subdomain_code=""), raw_row(2, year=2025))
        )
        self.assertFalse(
            any(
                x["family"] == "within_domain_concentration"
                and x["name"].endswith(":None")
                for x in ledger
            )
        )

    def test_ledger_has_channel_contrast_and_emergence_flags(self) -> None:
        rows = [raw_row(i, year=2021, primary="7.3") for i in range(1, 61)]
        rows += [
            raw_row(i, year=2025, primary="2.1" if i < 170 else "7.3")
            for i in range(100, 200)
        ]
        ledger = explore(engine(*rows))
        self.assertTrue(any(x["family"] == "channel_contrast" for x in ledger))
        emergent = [
            x
            for x in ledger
            if x["family"] == "subdomain_endpoint" and x["name"] == "primary:2.1"
        ]
        self.assertTrue(emergent and emergent[0]["emergence_candidate"])

    def test_code_snapshot_excludes_review_and_documentation(self) -> None:
        names = {p.relative_to(ROOT).as_posix() for p in code_files()}
        self.assertFalse(any(n.startswith("review/") for n in names))
        self.assertNotIn("FABLE_HANDOFF.md", names)
        self.assertNotIn("README.md", names)
        docs = {p.relative_to(ROOT).as_posix() for p in documentation_files()}
        self.assertIn("README.md", docs)

    def test_next_due_monthly_keeps_month_end_anchor(self) -> None:
        self.assertEqual(
            next_due(next_due(date(2026, 1, 31), "monthly"), "monthly"),
            date(2026, 3, 31),
        )
        self.assertEqual(next_due(date(2026, 9, 27), "monthly"), date(2026, 10, 27))
        self.assertEqual(next_due(date(2026, 9, 27), "fortnightly"), date(2026, 10, 11))

    def test_no_stale_resolution_statements_in_constants(self) -> None:
        self.assertNotIn("differs from the supplied export", CHART_CAVEAT)
        self.assertNotIn("not browser rendering", CHART_CAVEAT)
        out = nonempirical_check(
            engine(raw_row(1)),
            {"claim_id": "APP-HIGHEST", "publication_status": "current_app_text"},
        )
        self.assertNotIn("unresolved", out["reason"])


@unittest.skipUnless(REPRODUCTION_RUN.exists(), "reproduction run not present")
class VerifyAndPortability(unittest.TestCase):
    def test_tampered_id_set_is_detected_even_with_regenerated_manifest(self) -> None:
        from tracker.__main__ import artifact_manifest

        with tempfile.TemporaryDirectory() as directory:
            copy = Path(directory) / REPRODUCTION_RUN.name
            shutil.copytree(REPRODUCTION_RUN, copy)
            measures = json.loads(
                (copy / "calculations.json").read_text(encoding="utf-8")
            )["measures"]
            measure = measures["candidate.IT-C002.primary.2025"]
            numerator_path = copy / measure["numerator_ids_ref"]
            ids = json.loads(numerator_path.read_text(encoding="utf-8"))
            denominator = json.loads(
                (copy / measure["denominator_ids_ref"]).read_text(encoding="utf-8")
            )
            replacement = next(i for i in denominator if i not in ids)
            ids[0] = replacement
            numerator_path.write_bytes(json_bytes(ids))
            artifact_manifest(copy)
            with self.assertRaisesRegex(ValueError, "content hash mismatch"):
                verify_run(copy, ROOT)

    def test_unmanifested_file_is_detected(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            copy = Path(directory) / REPRODUCTION_RUN.name
            shutil.copytree(REPRODUCTION_RUN, copy)
            (copy / "evidence/stray_note.txt").write_text("stray", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "not in the manifest"):
                verify_run(copy, ROOT)

    def test_evidence_cli_survives_ascii_locale(self) -> None:
        env = {
            **os.environ,
            "PYTHONCOERCECLOCALE": "0",
            "PYTHONUTF8": "0",
            "LC_ALL": "C",
            "LANG": "C",
        }
        completed = subprocess.run(
            [
                sys.executable,
                "-B",
                "-m",
                "tracker",
                "evidence",
                "--run",
                str(REPRODUCTION_RUN),
                "--candidate",
                "IT-C002",
            ],
            cwd=ROOT,
            env=env,
            capture_output=True,
            text=True,
            encoding="utf-8",
        )
        self.assertEqual(completed.returncode, 0, completed.stderr[-500:])
        self.assertIn("candidate.IT-C002.primary.2021", completed.stdout)

    def test_unknown_candidate_exits_cleanly(self) -> None:
        completed = subprocess.run(
            [
                sys.executable,
                "-B",
                "-m",
                "tracker",
                "evidence",
                "--run",
                str(REPRODUCTION_RUN),
                "--candidate",
                "NOPE",
            ],
            cwd=ROOT,
            capture_output=True,
            text=True,
        )
        self.assertNotEqual(completed.returncode, 0)
        self.assertIn("Unknown candidate_id", completed.stderr)
        self.assertNotIn("Traceback", completed.stderr)


if __name__ == "__main__":
    unittest.main()
