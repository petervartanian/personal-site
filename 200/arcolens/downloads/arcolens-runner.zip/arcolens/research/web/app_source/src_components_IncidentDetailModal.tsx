/** @jsxImportSource preact */
import { h, ComponentChildren } from 'preact';
import { Modal } from './Modal';
import { ImpactPill } from './NatSecIncidentDetailModal';
import { SeverityRadar } from './SeverityRadar';
import { IshikawaDiagram } from './IshikawaDiagram';
import { parseIshikawa } from '../lib/ishikawa';
import { formatTaxonomyLabel } from '../lib/taxonomyFormat';
import { aiIdentityLabels, hasAiIdentityCell, parseAiIdentity } from '../lib/aiIdentity';
import { DOMAIN_ORDER } from '../data/incidentDomainColors';

// Shared styles for the 3-column Primary/Additional subdomain table
const colHeaderStyle = {
  fontSize: 11,
  fontWeight: 600,
  color: 'var(--gc-text-muted, #6b7280)',
} as const;
const groupLabelStyle = {
  fontSize: 11,
  fontWeight: 700,
  color: 'var(--gc-foreground, inherit)',
  textTransform: 'uppercase',
  letterSpacing: '0.04em',
  marginTop: 8,
  marginBottom: 2,
} as const;

/** "7.3 Lack of capability…" → "7 AI system safety, failures, & limitations" */
function domainForSubdomainCode(code: string): string {
  const prefix = code.match(/^(\d+)\./)?.[1];
  if (!prefix) return '—';
  return DOMAIN_ORDER.find((d) => d.startsWith(`${prefix} `)) ?? `Domain ${prefix}`;
}

export interface IncidentDetail {
  [key: string]: unknown;
}

interface IncidentDetailContentProps {
  incidentId: string;
  incident: IncidentDetail | null;
  loading: boolean;
  /** Omit the "Incident N" label and title, for a host page that already
   * shows the title as its own heading (the per-incident pages). */
  hideTitle?: boolean;
}

interface IncidentDetailModalProps extends IncidentDetailContentProps {
  isOpen: boolean;
  onClose: () => void;
}

// Mirror gov detail-modal tag palette
const TAG_BG = '#41454D';
const TAG_TEXT = '#ffffff';
const TAG_ACCENT_BG = '#B10F41';

// 10 severity categories in display order. Each maps to three Airtable
// fields (Direct score / Indirect score / Harm Caused reasoning text) and
// optionally the Ishikawa / Severity Spider attachments.
// The 10 tracker categories plus the Arcola-pipeline additions. Rows and
// the radar only render categories actually present on the record, so the
// extended list is harmless for the original 10-category dataset.
const SEVERITY_CATEGORIES = [
  { key: 'physical', label: 'Physical' },
  { key: 'infrastructure', label: 'Infrastructure' },
  { key: 'property', label: 'Property' },
  { key: 'financial', label: 'Financial' },
  { key: 'environmental', label: 'Environmental' },
  { key: 'maliciousContent', label: 'Malicious Content' },
  { key: 'differentialTreatment', label: 'Differential Treatment' },
  { key: 'civilRights', label: 'Civil Rights' },
  { key: 'democracy', label: 'Democracy' },
  { key: 'privacy', label: 'Privacy' },
  { key: 'psychological', label: 'Psychological' },
  { key: 'epistemic', label: 'Epistemic' },
  { key: 'csea', label: 'CSEA' },
  { key: 'digitalSystems', label: 'Digital Systems & Data' },
  { key: 'reputational', label: 'Reputational' },
] as const;

function readString(doc: IncidentDetail | null, ...keys: string[]): string {
  if (!doc) return '';
  for (const k of keys) {
    const v = doc[k];
    if (v !== undefined && v !== null && String(v).trim() !== '') return String(v);
  }
  return '';
}

function readNumber(doc: IncidentDetail | null, ...keys: string[]): number | null {
  if (!doc) return null;
  for (const k of keys) {
    const v = doc[k];
    if (v === undefined || v === null || v === '') continue;
    const n = Number(v);
    if (Number.isFinite(n)) return n;
  }
  return null;
}

/**
 * Airtable attachment fields come through as an array of
 * `{ url, filename, ... }` objects. The Severity Spider chart image is one
 * such field — pull out the first URL, or '' if the field is empty.
 */
function readAttachmentUrl(doc: IncidentDetail | null, key: string): string {
  if (!doc) return '';
  const v = doc[key];
  if (!Array.isArray(v) || v.length === 0) return '';
  const first = v[0];
  if (first && typeof first === 'object' && 'url' in first && typeof (first as { url: unknown }).url === 'string') {
    return (first as { url: string }).url;
  }
  return '';
}

function Tag({ label, bg = TAG_BG, color = TAG_TEXT }: { label: string; bg?: string; color?: string }) {
  return (
    <span
      style={{
        display: 'inline-block',
        padding: '4px 10px',
        margin: '3px 4px 3px 0',
        borderRadius: 4,
        fontSize: 12,
        lineHeight: 1.4,
        background: bg,
        color,
      }}
    >
      {label}
    </span>
  );
}

function SectionHeading({ children }: { children: ComponentChildren }) {
  return (
    <h3 style={{ margin: '0 0 12px 0', fontSize: 15, fontWeight: 600, color: 'var(--gc-foreground, inherit)' }}>
      {children}
    </h3>
  );
}

function SectionDivider() {
  return <div style={{ borderTop: '2px solid var(--gc-border, #e5e7eb)', margin: '8px 0 0 0' }} />;
}

function TwoColRow({
  leftLabel, leftValue, rightLabel, rightValue,
}: {
  leftLabel: string; leftValue: string;
  rightLabel: string; rightValue: string;
}) {
  const cellLabel = {
    fontSize: 12,
    fontWeight: 600 as const,
    color: 'var(--gc-text-muted, #6b7280)',
    marginBottom: 2,
  };
  const cellValue = {
    fontSize: 13,
    color: 'var(--gc-foreground, inherit)',
    minHeight: 20,
  };

  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 24,
      padding: '8px 0',
      borderBottom: '1px solid var(--gc-border, #e5e7eb)',
    }}>
      <div>
        <div style={cellLabel}>{leftLabel}</div>
        <div style={cellValue}>{leftValue || '—'}</div>
      </div>
      <div>
        <div style={cellLabel}>{rightLabel}</div>
        <div style={cellValue}>{rightValue || '—'}</div>
      </div>
    </div>
  );
}

/**
 * One per-category harm row: 3-column grid with the reasoning text on
 * the left and the Direct / Indirect score cells on the right. Mirrors
 * the layout the user signed off on (see the "{Category} Harm Caused"
 * screenshots) — each column has its own subhead so the row reads as a
 * standalone block instead of a wide table.
 */
function HarmCategoryRow({
  category,
  reasoning,
  direct,
  indirect,
}: {
  category: string;
  reasoning: string;
  direct: number | null;
  indirect: number | null;
}) {
  const scoreCellStyle = {
    fontSize: 11,
    fontWeight: 600 as const,
    color: 'var(--gc-text-muted, #6b7280)',
    marginBottom: 6,
  };

  // Hide a category row entirely when neither score nor reasoning is set —
  // keeps older records that haven't been re-classified from showing 10
  // empty rows.
  if (direct == null && indirect == null && !reasoning) return null;

  return (
    <div
      style={{
        display: 'grid',
        gridTemplateColumns: '2fr 1fr 1fr',
        gap: 24,
        padding: '14px 0',
        borderBottom: '1px solid var(--gc-border, #e5e7eb)',
        alignItems: 'start',
      }}
    >
      <div>
        <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 6, color: 'var(--gc-foreground, inherit)' }}>
          {category} Harm Caused
        </div>
        {reasoning ? (
          <div style={{ fontSize: 12, lineHeight: 1.55, color: 'var(--gc-foreground, inherit)', whiteSpace: 'pre-wrap' }}>
            {reasoning}
          </div>
        ) : (
          <div style={{ fontSize: 12, color: 'var(--gc-text-muted, #9ca3af)' }}>—</div>
        )}
      </div>
      <div>
        <div style={scoreCellStyle}>{category} Severity Direct</div>
        <ImpactPill score={direct} variant="standard" />
      </div>
      <div>
        <div style={scoreCellStyle}>{category} Severity Indirect</div>
        <ImpactPill score={indirect} variant="standard" />
      </div>
    </div>
  );
}

function formatNumber(n: number | null): string {
  if (n == null) return '';
  return n.toLocaleString();
}

function LinkButton({ href, label, title }: { href: string; label: string; title?: string }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noreferrer"
      title={title}
      style={{
        color: 'var(--gc-link, inherit)',
        textDecoration: 'none',
        fontWeight: 600,
        fontSize: 13,
        padding: '6px 14px',
        border: '1px solid currentColor',
        borderRadius: 4,
        display: 'inline-block',
      }}
    >
      {label} ↗
    </a>
  );
}

export function IncidentDetailModal({ isOpen, onClose, ...content }: IncidentDetailModalProps) {
  return (
    <Modal isOpen={isOpen} onClose={onClose} width="min(1000px, 92vw)">
      <IncidentDetailContent {...content} />
    </Modal>
  );
}

/**
 * The incident detail body, shared by the modal (above) and the inline
 * per-incident page embed (IncidentDetailInline): one layout, two hosts.
 */
export function IncidentDetailContent({
  incidentId,
  incident,
  loading,
  hideTitle = false,
}: IncidentDetailContentProps) {
  const title = readString(incident, 'title');
  const summary = readString(incident, 'summary');
  const description = readString(incident, 'description');
  const date = readString(incident, 'date');
  // Canonical AIID citation URL is /cite/<incidentId>; the `url` field on
  // the record points at the report list, not the incident page itself.
  const aiidUrl = incidentId ? `https://incidentdatabase.ai/cite/${encodeURIComponent(incidentId)}` : '';

  const domain = readString(incident, 'domain');
  const subdomain = readString(incident, 'subdomain');
  const domainJustification = readString(incident, 'domainJustification');
  // Additional risk subdomains (Arcola datasets): JSON string of
  // [{ code, justification }]. Absent/empty on the original dataset.
  const additionalSubdomains: Array<{ code: string; justification: string }> = (() => {
    const raw = readString(incident, 'additionalSubdomains');
    if (!raw.startsWith('[')) return [];
    try {
      const arr = JSON.parse(raw);
      if (!Array.isArray(arr)) return [];
      return arr
        .filter((e): e is { code?: unknown; justification?: unknown } => typeof e === 'object' && e !== null)
        .map((e) => ({ code: String(e.code ?? ''), justification: String(e.justification ?? '') }))
        .filter((e) => e.code);
    } catch {
      return [];
    }
  })();
  const entity = readString(incident, 'entity');
  const intent = readString(incident, 'intent');
  const timing = readString(incident, 'timing');
  const euAct = readString(incident, 'euAiActRiskClassification');
  const behaviourType = readString(incident, 'behaviourType');
  // `model` is the CLASSIFIER — the LLM that produced this classification
  // (e.g. "anthropic/claude-sonnet-4") — NOT the system in the incident. It
  // used to be the fallback for the "Model" cell, so any incident with no
  // subject name showed the classifier as if it were the implicated system.
  const classifierModel = readString(incident, 'model');
  // Subject system as the classification names it (free text; the legacy
  // base writes "N/A" for none).
  const rawModelName = readString(incident, 'modelName');
  const modelName = rawModelName.trim().toUpperCase() === 'N/A' ? '' : rawModelName;
  // Structured subject-system identity (Arcola mirror): five JSON-array
  // cells, rendered as separate labelled lines rather than zipped by index
  // — the arrays are not guaranteed to align (two developers can share one
  // model name). Developer and family always show, including the three
  // state labels; name / version / variant only when something is named.
  // See src/lib/aiIdentity.ts.
  const hasIdentity = hasAiIdentityCell(readString(incident, 'aiModels'))
    || hasAiIdentityCell(readString(incident, 'aiDevelopers'));
  const identityLines: Array<{ label: string; value: string }> = [];
  if (hasIdentity) {
    identityLines.push({ label: 'Developer', value: aiIdentityLabels(readString(incident, 'aiDevelopers')).join(', ') });
    identityLines.push({ label: 'Model family', value: aiIdentityLabels(readString(incident, 'aiModels')).join(', ') });
    for (const [key, label] of [['aiModelNames', 'Model name'], ['aiModelVersions', 'Version'], ['aiModelVariants', 'Variant']] as const) {
      const parsed = parseAiIdentity(readString(incident, key));
      if (parsed.state === 'named') identityLines.push({ label, value: parsed.values.join(', ') });
    }
  }

  const highest = readNumber(incident, 'highestSeverityScore');

  const occurrences = readNumber(incident, 'numberOfOccurrences');
  const peopleHarmed = readNumber(incident, 'totalPeopleReportedlyHarmed');
  const peopleInferredHarmed = readNumber(incident, 'totalPeopleInferredHarmed');

  const allegedDeployer = readString(incident, 'allegedDeployer');
  const allegedDeveloper = readString(incident, 'allegedDeveloper');
  const allegedHarmedParties = readString(incident, 'allegedHarmedParties');
  const confidence = readString(incident, 'confidence');
  const severitySpiderUrl = readAttachmentUrl(incident, 'severitySpider');

  // Categories that actually carry data on this record — 10 for the
  // original dataset, up to 15 for the Arcola mirror. Drives both the
  // per-category rows and the client-rendered radar.
  const presentCategories = SEVERITY_CATEGORIES.filter((cat) =>
    readNumber(incident, `${cat.key}SeverityDirect`) != null
    || readNumber(incident, `${cat.key}SeverityIndirect`) != null
    || readString(incident, `${cat.key}HarmCaused`));
  // Client-rendered radar replaces the pre-generated spider image when the
  // record has scores but no attachment (Arcola datasets have no images).
  const showRadar = !severitySpiderUrl && presentCategories.some(
    (cat) => readNumber(incident, `${cat.key}SeverityDirect`) != null);
  const hasSpiderVisual = Boolean(severitySpiderUrl) || showRadar;

  // When the 3-column Primary/Additional subdomain table renders (Arcola
  // datasets), every Risk Classification sub-section aligns to the SAME
  // column grid so vertical gridlines run through the whole block instead
  // of jumping at each section. Datasets without additional subdomains
  // keep the original per-section layouts untouched.
  const useSharedGrid = additionalSubdomains.length > 0;
  const SHARED_GRID_COLS = '1fr 1.2fr 1.8fr';
  const sharedGridStyle = {
    display: 'grid',
    gridTemplateColumns: SHARED_GRID_COLS,
    gap: '4px 20px',
    alignItems: 'start',
  } as const;

  // ---- Risk Classification additions ---------------------------------
  const causalJustification = readString(incident, 'causalJustification');
  const euAiActRiskReasoning = readString(incident, 'euAiActRiskReasoning');

  // ---- Numbers of People Affected (full set) -------------------------
  const peopleReportedlyExposed = readNumber(incident, 'totalPeopleReportedlyExposed');
  const peopleInferredExposed = readNumber(incident, 'totalPeopleInferredExposed');

  // ---- Potential Causes (Ishikawa / fishbone) ------------------------
  // The field carries a different shape per dataset: the original tracker
  // base holds a pre-rendered PNG attachment (built by the Python pipeline
  // and rasterised only because Airtable renders SVG attachments badly),
  // while the Arcola mirror holds the RCA JSON and the diagram is drawn
  // here. Prefer the JSON — it reflows to the modal width, stays readable
  // on a phone, and costs no image request.
  const ishikawaBones = parseIshikawa(incident?.ishikawa);
  const ishikawaUrl = ishikawaBones.length > 0 ? '' : readAttachmentUrl(incident, 'ishikawa');

  // ---- Information Quality additions ---------------------------------
  const reasonForConfidence = readString(incident, 'reasonForConfidence');
  const missingInformation = readString(incident, 'missingInformation');
  const missingInformationDetail = readString(incident, 'missingInformationDetail');
  const ambiguitiesIdentified = readString(incident, 'ambiguitiesIdentified');
  const alternativeInterpretations = readString(incident, 'alternativeInterpretations');

  return (
    <>
      {loading ? (
        <div style={{ padding: 48, textAlign: 'center', color: 'var(--gc-text-muted, #6b7280)' }}>
          Loading incident details...
        </div>
      ) : !incident ? (
        <div style={{ padding: 48, textAlign: 'center', color: 'var(--gc-text-muted, #6b7280)' }}>
          Incident not found.
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
          {!hideTitle && (
            <div>
              <div style={{ fontSize: 12, color: 'var(--gc-text-muted, #6b7280)', marginBottom: 4 }}>
                Incident {incidentId}
              </div>
              <h2 style={{ margin: 0, fontSize: 22, fontWeight: 700, lineHeight: 1.3, color: 'var(--gc-foreground, inherit)' }}>
                {title || incidentId}
              </h2>
            </div>
          )}

          {summary && (
            <div style={{ fontSize: 14, lineHeight: 1.6, color: 'var(--gc-foreground, inherit)' }}>
              {summary}
            </div>
          )}

          {description && description !== summary && (
            <div>
              <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--gc-text-muted, #6b7280)', marginBottom: 4 }}>
                Description
              </div>
              <div style={{ fontSize: 13, lineHeight: 1.6, color: 'var(--gc-foreground, inherit)' }}>
                {description}
              </div>
            </div>
          )}

          {(aiidUrl || date) && (
            <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap', alignItems: 'center' }}>
              {aiidUrl && (
                <LinkButton
                  href={aiidUrl}
                  label="AI Incident Database"
                  title="View full incident details and source reports on the AI Incident Database site"
                />
              )}
              {date && (
                <span style={{ fontSize: 13, color: 'var(--gc-text-muted, #6b7280)' }}>
                  <strong style={{ color: 'var(--gc-foreground, inherit)' }}>Incident date:</strong> {date}
                </span>
              )}
            </div>
          )}

          <SectionDivider />
          <div>
            <SectionHeading>Risk Classification</SectionHeading>
            <p style={{ fontSize: 12, lineHeight: 1.55, color: 'var(--gc-text-muted, #6b7280)', margin: '0 0 16px' }}>
              Based on MIT AI Risk Repository{' '}
              <a href="https://airisk.mit.edu/#Causal-Taxonomy-of-AI-Risks" target="_blank" rel="noreferrer" style={{ color: 'var(--gc-link, #2563eb)' }}>Causal</a>
              {' '}and{' '}
              <a href="https://airisk.mit.edu/#Domain-Taxonomy-of-AI-Risks" target="_blank" rel="noreferrer" style={{ color: 'var(--gc-link, #2563eb)' }}>Domain</a>
              {' '}Taxonomies and the{' '}
              <a href="https://artificialintelligenceact.eu/high-level-summary/" target="_blank" rel="noreferrer" style={{ color: 'var(--gc-link, #2563eb)' }}>EU AI Act Risk Tiers</a>.
            </p>

            {/* Risk Domain / Subdomain. With additional subdomains present
                (Arcola datasets) this renders as a 3-column table — Domain |
                Subdomain | Reasoning — under Primary / Additional group
                labels; the parent domain of each additional subdomain is
                derived from its numeric code prefix. Without them (original
                dataset) the layout is unchanged from before. */}
            {(domainJustification || domain || subdomain) && (additionalSubdomains.length > 0 ? (
              <div style={{ marginBottom: 18 }}>
                <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--gc-foreground, inherit)', marginBottom: 8 }}>
                  Risk Domain / Subdomain
                </div>
                <div style={sharedGridStyle}>
                  <div style={colHeaderStyle}>Domain</div>
                  <div style={colHeaderStyle}>Subdomain</div>
                  <div style={colHeaderStyle}>Reasoning</div>

                  <div style={{ gridColumn: '1 / -1', ...groupLabelStyle }}>Primary</div>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{domain ? formatTaxonomyLabel(domain) : '—'}</div>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{subdomain ? formatTaxonomyLabel(subdomain) : '—'}</div>
                  <div style={{ fontSize: 12, lineHeight: 1.55, color: 'var(--gc-text-muted, #6b7280)' }}>
                    {domainJustification || '—'}
                  </div>

                  <div style={{ gridColumn: '1 / -1', ...groupLabelStyle }}>Additional</div>
                  {additionalSubdomains.map((s) => [
                    <div key={`${s.code}-d`} style={{ fontSize: 13, fontWeight: 600 }}>
                      {formatTaxonomyLabel(domainForSubdomainCode(s.code))}
                    </div>,
                    <div key={`${s.code}-s`} style={{ fontSize: 13, fontWeight: 600 }}>{formatTaxonomyLabel(s.code)}</div>,
                    <div key={`${s.code}-r`} style={{ fontSize: 12, lineHeight: 1.55, color: 'var(--gc-text-muted, #6b7280)' }}>
                      {s.justification || '—'}
                    </div>,
                  ])}
                </div>
              </div>
            ) : (
              <div style={{ marginBottom: 18 }}>
                <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--gc-foreground, inherit)', marginBottom: 6 }}>
                  Risk Domain / Subdomain
                </div>
                {domainJustification && (
                  <div style={{ fontSize: 13, lineHeight: 1.6, color: 'var(--gc-foreground, inherit)', marginBottom: 10 }}>
                    {domainJustification}
                  </div>
                )}
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
                  <div>
                    <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--gc-text-muted, #6b7280)', marginBottom: 4 }}>Domain</div>
                    <div style={{ fontSize: 14, fontWeight: 600 }}>{domain ? formatTaxonomyLabel(domain) : '—'}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--gc-text-muted, #6b7280)', marginBottom: 4 }}>Subdomain</div>
                    <div style={{ fontSize: 14, fontWeight: 600 }}>{subdomain ? formatTaxonomyLabel(subdomain) : '—'}</div>
                  </div>
                </div>
              </div>
            ))}

            {/* Causal Classification */}
            {(causalJustification || entity || intent || timing) && (
              <div style={{ marginBottom: 18 }}>
                <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--gc-foreground, inherit)', marginBottom: 6 }}>
                  Causal Classification
                </div>
                {causalJustification && (
                  <div style={{ fontSize: 13, lineHeight: 1.6, color: 'var(--gc-foreground, inherit)', marginBottom: 10 }}>
                    {causalJustification}
                  </div>
                )}
                <div style={useSharedGrid ? sharedGridStyle : { display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 24 }}>
                  <div>
                    <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--gc-text-muted, #6b7280)', marginBottom: 4 }}>Entity</div>
                    <div style={{ fontSize: 14, fontWeight: 600 }}>{entity || '—'}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--gc-text-muted, #6b7280)', marginBottom: 4 }}>Intent</div>
                    <div style={{ fontSize: 14, fontWeight: 600 }}>{intent || '—'}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--gc-text-muted, #6b7280)', marginBottom: 4 }}>Timing</div>
                    <div style={{ fontSize: 14, fontWeight: 600 }}>{timing || '—'}</div>
                  </div>
                </div>
              </div>
            )}

            {/* EU AI Act */}
            {(euAct || euAiActRiskReasoning) && (
              <div style={{ marginBottom: 8 }}>
                <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--gc-foreground, inherit)', marginBottom: 6 }}>
                  EU AI Act Risk Tier
                </div>
                <div style={useSharedGrid ? sharedGridStyle : { display: 'grid', gridTemplateColumns: '1fr 2fr', gap: 24 }}>
                  <div>
                    <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--gc-text-muted, #6b7280)', marginBottom: 4 }}>EU AI Act Risk Tier</div>
                    {/* Stored as "3 Limited Risk"; the same number-dash-name
                        form the domain/subdomain rows use reads better and
                        keeps the modal internally consistent. */}
                    <div style={{ fontSize: 14, fontWeight: 600 }}>{euAct ? formatTaxonomyLabel(euAct) : '—'}</div>
                  </div>
                  <div style={useSharedGrid ? { gridColumn: '2 / -1' } : undefined}>
                    <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--gc-text-muted, #6b7280)', marginBottom: 4 }}>EU AI Act Risk Classification Reasoning</div>
                    <div style={{ fontSize: 13, lineHeight: 1.6 }}>{euAiActRiskReasoning || '—'}</div>
                  </div>
                </div>
              </div>
            )}

            {/* Model & behaviour metadata kept as a footer row — less central
                than the three classifications above but still useful. */}
            {(modelName || behaviourType || hasIdentity) && (
              useSharedGrid ? (
                <div style={{
                  ...sharedGridStyle,
                  borderTop: '1px solid var(--gc-border, #e5e7eb)',
                  marginTop: 8,
                  padding: '8px 0',
                }}>
                  <div>
                    <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--gc-text-muted, #6b7280)', marginBottom: 2 }}>Model / System (as reported)</div>
                    <div style={{ fontSize: 13, minHeight: 20 }}>{modelName || '—'}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--gc-text-muted, #6b7280)', marginBottom: 2 }}>Behaviour type</div>
                    <div style={{ fontSize: 13, minHeight: 20 }}>{behaviourType || '—'}</div>
                  </div>
                </div>
              ) : (
                <div style={{ borderTop: '1px solid var(--gc-border, #e5e7eb)', marginTop: 8 }}>
                  <TwoColRow
                    leftLabel="Model / System (as reported)"
                    leftValue={modelName}
                    rightLabel="Behaviour type"
                    rightValue={behaviourType}
                  />
                </div>
              )
            )}

            {/* Structured subject-system identity (Arcola mirror only). Kept
                apart from the AIID "Alleged developer" above: different
                source (the report text, via Arcola's registry), different
                rule (recorded only when the report says who built it). */}
            {hasIdentity && (
              <div style={{ borderTop: '1px solid var(--gc-border, #e5e7eb)', padding: '8px 0' }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--gc-text-muted, #6b7280)', marginBottom: 4 }}>AI system (Arcola registry)</div>
                <div style={{ fontSize: 13, lineHeight: 1.6 }}>
                  {identityLines.map(({ label, value }) => (
                    <div key={label}>
                      <span style={{ color: 'var(--gc-text-muted, #6b7280)' }}>{label}: </span>
                      {value || '—'}
                    </div>
                  ))}
                </div>
                <div style={{ fontSize: 11, lineHeight: 1.5, color: 'var(--gc-text-muted, #6b7280)', marginTop: 4 }}>
                  Derived from the AIID report and normalised against Arcola’s registry; re-derived as the registry grows. Distinct from the AIID “Alleged developer” field.
                </div>
              </div>
            )}

            {/* Provenance, labelled honestly: this is the LLM that produced
                the classification, not the system in the incident. */}
            {classifierModel && (
              <div style={{ fontSize: 11, color: 'var(--gc-text-muted, #6b7280)', marginTop: 6 }}>
                Classified by {classifierModel}
              </div>
            )}
          </div>

          {(highest != null || severitySpiderUrl || SEVERITY_CATEGORIES.some((c) => readString(incident, `${c.key}HarmCaused`))) && (
            <>
              <SectionDivider />
              <div>
                <SectionHeading>Harm Severity</SectionHeading>
                <div style={{ fontSize: 12, lineHeight: 1.55, color: 'var(--gc-text-muted, #6b7280)', marginBottom: 12 }}>
                  Harm caused by the incident is broken out into:
                </div>
                <ul style={{ margin: '0 0 12px 18px', padding: 0, fontSize: 12, lineHeight: 1.55, color: 'var(--gc-text-muted, #6b7280)' }}>
                  <li>Explicitly reported <strong>directly caused</strong> harm (e.g. financial loss from an AI-enabled fraud)</li>
                  <li>Explicitly reported <strong>indirectly caused</strong> harm (e.g. financial value of reputational damage following an incident)</li>
                  <li><strong>Inferred</strong> harm, that was not explicitly described in the reports but was inferred by the model and may be worthy of further investigation.</li>
                </ul>
                <p style={{ fontSize: 12, lineHeight: 1.55, color: 'var(--gc-text-muted, #6b7280)', margin: '0 0 18px' }}>
                  <strong>Highest Direct Severity Score</strong> is the highest Direct Severity for this incident in any single category.
                </p>

                {/* Spider + headline numbers laid out side-by-side on wide
                    screens; spider stacks on top on narrow ones. */}
                <div style={{ display: 'grid', gridTemplateColumns: hasSpiderVisual ? '1fr 1fr' : '1fr', gap: 24, alignItems: 'center', marginBottom: 16 }}>
                  {severitySpiderUrl && (
                    <div style={{ textAlign: 'center' }}>
                      <img
                        src={severitySpiderUrl}
                        alt="Harm Severity Spider — per-category direct severity scores 0–5"
                        style={{ maxWidth: '100%', maxHeight: 280, borderRadius: 4 }}
                      />
                    </div>
                  )}
                  {showRadar && (
                    <SeverityRadar
                      categories={presentCategories.map((cat) => ({
                        label: cat.label,
                        direct: readNumber(incident, `${cat.key}SeverityDirect`),
                        indirect: readNumber(incident, `${cat.key}SeverityIndirect`),
                      }))}
                    />
                  )}
                  <div>
                    {highest != null && (
                      <div style={{ marginBottom: 16 }}>
                        <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--gc-text-muted, #6b7280)' }}>
                          Highest Direct Severity Score
                        </div>
                        <div style={{ fontSize: 11, color: 'var(--gc-text-muted, #9ca3af)', marginBottom: 8 }}>
                          (in any single category)
                        </div>
                        {/* Same size as the per-category pills in the table
                            below — a larger hero pill read as a different
                            kind of value. */}
                        <ImpactPill score={highest} variant="standard" />
                      </div>
                    )}
                  </div>
                </div>

                {/* Per-category 3-column rows: reasoning · direct · indirect */}
                <div style={{ borderTop: '1px solid var(--gc-border, #e5e7eb)' }}>
                  {presentCategories.map((cat) => (
                    <HarmCategoryRow
                      key={cat.key}
                      category={cat.label}
                      reasoning={readString(incident, `${cat.key}HarmCaused`)}
                      direct={readNumber(incident, `${cat.key}SeverityDirect`)}
                      indirect={readNumber(incident, `${cat.key}SeverityIndirect`)}
                    />
                  ))}
                </div>
              </div>
            </>
          )}

          {(occurrences != null
            || peopleReportedlyExposed != null || peopleInferredExposed != null
            || peopleHarmed != null || peopleInferredHarmed != null) && (
            <>
              <SectionDivider />
              <div>
                <SectionHeading>Numbers of People Affected</SectionHeading>
                <p style={{ fontSize: 12, lineHeight: 1.55, color: 'var(--gc-text-muted, #6b7280)', margin: '0 0 12px' }}>
                  These numbers are produced by the LLM tool from the incident reports. Treat as indicative
                  and verify against the underlying sources.
                </p>
                {occurrences != null && (
                  <div style={{ marginBottom: 12 }}>
                    <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--gc-text-muted, #6b7280)' }}>Number of occurrences reported</div>
                    <div style={{ fontSize: 18, fontWeight: 600 }}>{formatNumber(occurrences)}</div>
                  </div>
                )}
                <div style={{ borderTop: '1px solid var(--gc-border, #e5e7eb)' }}>
                  <TwoColRow
                    leftLabel="Total people reportedly exposed to risk"
                    leftValue={formatNumber(peopleReportedlyExposed)}
                    rightLabel="Total people reportedly harmed"
                    rightValue={formatNumber(peopleHarmed)}
                  />
                  <TwoColRow
                    leftLabel="Total people inferred exposed to risk"
                    leftValue={formatNumber(peopleInferredExposed)}
                    rightLabel="Total people inferred harmed"
                    rightValue={formatNumber(peopleInferredHarmed)}
                  />
                </div>
              </div>
            </>
          )}

          {(ishikawaBones.length > 0 || ishikawaUrl) && (
            <>
              <SectionDivider />
              <div>
                <SectionHeading>Potential Causes of Incident</SectionHeading>
                <p style={{ fontSize: 12, lineHeight: 1.55, color: 'var(--gc-text-muted, #6b7280)', margin: '0 0 12px' }}>
                  <strong>Fishbone / Ishikawa Diagram</strong> — potential causes for the incident identified
                  by the LLM analysis, organised by category. Treat as indicative / worthy of further
                  investigation.
                </p>
                {ishikawaBones.length > 0 ? (
                  <div style={{ background: 'var(--gc-surface-muted, #f8fafc)', borderRadius: 6, padding: '14px 10px' }}>
                    <IshikawaDiagram bones={ishikawaBones} title={title} />
                  </div>
                ) : (
                  <div style={{ textAlign: 'center', background: 'var(--gc-surface-muted, #f8fafc)', borderRadius: 6, padding: 12 }}>
                    <img
                      src={ishikawaUrl}
                      alt="Fishbone / Ishikawa diagram of potential incident causes"
                      style={{ maxWidth: '100%', maxHeight: 420 }}
                    />
                  </div>
                )}
              </div>
            </>
          )}

          {(allegedDeployer || allegedDeveloper || allegedHarmedParties) && (
            <>
              <SectionDivider />
              <div>
                <SectionHeading>Alleged Entities</SectionHeading>
                <p style={{ fontSize: 12, lineHeight: 1.55, color: 'var(--gc-text-muted, #6b7280)', margin: '0 0 12px' }}>
                  As identified by the AI Incident Database.
                </p>
                <div style={{ borderTop: '1px solid var(--gc-border, #e5e7eb)' }}>
                  <TwoColRow
                    leftLabel="Alleged deployer"
                    leftValue={allegedDeployer}
                    rightLabel="Alleged developer"
                    rightValue={allegedDeveloper}
                  />
                  {allegedHarmedParties && (
                    <TwoColRow
                      leftLabel="Alleged harmed parties"
                      leftValue={allegedHarmedParties}
                      rightLabel=""
                      rightValue=""
                    />
                  )}
                </div>
              </div>
            </>
          )}

          {(confidence || reasonForConfidence || missingInformation || missingInformationDetail
            || ambiguitiesIdentified || alternativeInterpretations) && (
            <>
              <SectionDivider />
              <div>
                <SectionHeading>Information Quality</SectionHeading>
                <div style={{ borderTop: '1px solid var(--gc-border, #e5e7eb)' }}>
                  <TwoColRow
                    leftLabel="Confidence"
                    leftValue={confidence}
                    rightLabel="Missing Information"
                    rightValue={missingInformation}
                  />
                  {(reasonForConfidence || missingInformationDetail) && (
                    <TwoColRow
                      leftLabel="Reason for Confidence"
                      leftValue={reasonForConfidence}
                      rightLabel="Missing Information Detail"
                      rightValue={missingInformationDetail}
                    />
                  )}
                  {ambiguitiesIdentified && (
                    <TwoColRow
                      leftLabel="Ambiguities identified"
                      leftValue={ambiguitiesIdentified}
                      rightLabel=""
                      rightValue=""
                    />
                  )}
                  {alternativeInterpretations && (
                    <TwoColRow
                      leftLabel="Alternative interpretations"
                      leftValue={alternativeInterpretations}
                      rightLabel=""
                      rightValue=""
                    />
                  )}
                </div>
              </div>
            </>
          )}
        </div>
      )}
    </>
  );
}
