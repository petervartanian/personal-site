/** @jsxImportSource preact */
import { h } from 'preact';
import { useState, useEffect, useRef, useCallback, useMemo } from 'preact/hooks';
import * as echarts from 'echarts';
import { getCategoryColor, getChartTheme, detectDarkMode, getResponsiveConfig, loadTheme } from '@/lib/theme';
import { getDomainColor, getSubdomainPaletteColor, DOMAIN_ORDER } from '@/data/incidentDomainColors';
import { getSubdomainDescription } from '@/data/riskTaxonomy';
import { bindChartTap } from '@/lib/chartTap';
import { isAiIdentityStateLabel, AI_IDENTITY_UNIDENTIFIED, AI_IDENTITY_NONE_NAMED } from '@/lib/aiIdentity';
import type { IncidentChartConfig } from '@/data/chartConfigs';
import { ViewMode, ViewModeToggle } from './ViewModeToggle';
import { IncidentListModal, IncidentListItem, ActiveFilter } from './IncidentListModal';
import { formatTaxonomyLabel } from '../lib/taxonomyFormat';
import { IncidentDetailModal, IncidentDetail } from './IncidentDetailModal';
import { IncidentFilterBar, FilterDim } from './IncidentFilterBar';

export interface IncidentChartProps {
  config: IncidentChartConfig;
  apiBase: string;
  containerId: string;
  /** Year floor (e.g. 2015 hides every incident before 1 Jan 2015) */
  minYear?: number;
  /** Incidents dataset to serve from (API `src` param, e.g.
   * 'incidents-arcola'). Omit for the default dataset. */
  dataset?: string;
}

export type StackByDim = 'domain' | 'subdomain' | 'allSubdomains' | 'entity' | 'intent' | 'timing' | 'aiGoal' | 'aiModel' | 'aiDeveloper' | 'euRisk' | 'highestSeverity' | 'natSecImpact' | 'harmCategory';

// External filter control for incident charts (parallels the governance
// CategoryBarChart controller). Setters accept array, comma-separated string,
// or single value; pass [] to clear.
export interface IncidentChartController {
  setStackBy: (value: StackByDim | null) => void;
  setYearFilter: (value: string | string[]) => void;
  /** Year-≥ floor filter. Layers on top of the init-time `minYear` prop;
   * effective floor = max(prop, this). Pass [] / '' to clear. */
  setMinYearFilter: (value: string | string[]) => void;
  setDomainFilter: (value: string | string[]) => void;
  setSubdomainFilter: (value: string | string[]) => void;
  /** Membership filter over primary + additional subdomains (datasets with
   * additional subdomains only; no-op elsewhere). */
  setAllSubdomainsFilter: (value: string | string[]) => void;
  /** Membership filter over harm categories with reported (direct or
   * indirect ≥ 2) harm. */
  setHarmCategoryFilter: (value: string | string[]) => void;
  setEntityFilter: (value: string | string[]) => void;
  setIntentFilter: (value: string | string[]) => void;
  setTimingFilter: (value: string | string[]) => void;
  setEuRiskFilter: (value: string | string[]) => void;
  setAiGoalFilter: (value: string | string[]) => void;
  /** Membership filters over the subject AI-system identity (Arcola mirror
   * only; no-op elsewhere). Values are registry labels or one of the three
   * state labels — NOT stable keys: an unregistered name is passed through
   * raw and later collapses to its canonical label, so never persist a
   * value in a preset or deep link. */
  setAiModelFilter: (value: string | string[]) => void;
  setAiDeveloperFilter: (value: string | string[]) => void;
  /** Replace the severity filter map. Keys are `minSeverity*` param names
   * (e.g. `minSeverityHighest`, `minSeverityPhysical`); values are 1–5
   * thresholds. Pass {} to clear. */
  setSeverityFilters: (filters: Record<string, number>) => void;
  /** Switch between `'counts'` (raw incident counts) and `'proportion'`
   * (100% normalised per category). Bar charts only — pie ignores it. */
  setViewMode: (mode: ViewMode) => void;
  resetFilters: () => void;
}

const incidentChartRegistry = new Map<string, IncidentChartController>();

export function getIncidentChartController(id: string): IncidentChartController | undefined {
  return incidentChartRegistry.get(id);
}

// Some filterable values contain commas (e.g. the subdomain "2.1 Compromise
// of privacy by obtaining, leaking or correctly inferring sensitive
// information", or aiGoal "Fraud, scams, and targeted manipulation"). Treat
// a string as a single value; callers wanting multi-value should pass an
// array — which matches the documented `string | string[]` API.
const normalizeFilterValue = (v: string | string[]): string[] => {
  if (Array.isArray(v)) return v;
  if (!v) return [];
  return [v];
};

// ---------------------------------------------------------------------
// Hover-text helpers — show full untruncated labels (and, for subdomain
// labels, the canonical risk-taxonomy definition) when the user hovers a
// legend entry or a chart tooltip. Mirrors the description-on-axis-hover
// behaviour already implemented on the Gov Map risk-subdomain bar chart
// in src/charts/RiskSubdomainBar.ts.
// ---------------------------------------------------------------------

/** Extract a subdomain id like "2.1" from a label that prefixes its name
 * with the canonical dotted number. Returns null for non-subdomain labels
 * (domains use a single number like "1", everything else has no prefix). */
function getSubdomainId(label: string): string | null {
  const m = label.match(/^(\d+\.\d+)\s/);
  return m ? m[1] : null;
}

function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, (c) => (
    c === '&' ? '&amp;' :
    c === '<' ? '&lt;' :
    c === '>' ? '&gt;' :
    c === '"' ? '&quot;' :
    '&#39;'
  ));
}

/** Plain-text tooltip used as the `title` attribute on HTML legend rows.
 * Returns the full label, plus the subdomain definition on a new line
 * when the label is a known subdomain. */
function getLegendHoverText(label: string): string {
  const id = getSubdomainId(label);
  const disp = formatTaxonomyLabel(label);
  if (!id) return disp;
  const desc = getSubdomainDescription(id);
  return desc ? `${disp}\n\n${desc}` : disp;
}

/** HTML markup for ECharts tooltips/legend.tooltip. Bolds the label and,
 * when the label is a subdomain, appends the wrapped definition. `suffix`
 * (e.g. ": 191") renders on the label line, BEFORE the definition block -
 * appending it to this function's return value instead would drop it below
 * the definition <div> as a bare, label-less line. */
function getEchartsHoverHtml(label: string, suffix = ''): string {
  const id = getSubdomainId(label);
  const safe = escapeHtml(formatTaxonomyLabel(label));
  const sfx = escapeHtml(suffix);
  if (!id) return safe + sfx;
  const desc = getSubdomainDescription(id);
  if (!desc) return safe + sfx;
  return `<strong>${safe}</strong>${sfx}<div style="margin-top:4px;max-width:340px;white-space:normal;font-weight:normal;line-height:1.45;">${escapeHtml(desc)}</div>`;
}

/** Effective year floor sent to the API: max of the host-side `minYear` prop
 * and the user's in-chart Year ≥ filter. Returns null when neither is set. */
function computeEffectiveMinYear(prop: number | undefined, userFilter: string[]): number | null {
  const userVal = userFilter.length > 0 ? parseInt(userFilter[0], 10) : NaN;
  const candidates: number[] = [];
  if (typeof prop === 'number' && Number.isFinite(prop)) candidates.push(prop);
  if (Number.isFinite(userVal)) candidates.push(userVal);
  if (candidates.length === 0) return null;
  return Math.max(...candidates);
}

interface IncidentApiResponse {
  chartType: string;
  totalIncidents: number;
  totalIncidentsAll: number;
  years?: string[];
  domains?: string[];
  /** Series-axis labels for the active stackBy dimension */
  categories?: string[];
  series?: Array<{ name: string; data: number[] }>;
  data?: Array<{ name: string; value: number }>;
  domainTotals?: number[];
  /** Echo of the active stackBy so the chart knows how to colour series */
  stackBy?: StackByDim;
  /** If set, maps a synthetic series name (e.g. "Other") to the underlying
   *  category values it bundles. Lets bar-segment clicks expand "Other"
   *  back to a multi-value filter for the list modal. */
  seriesMembers?: Record<string, string[]>;
  lastUpdated: string;
  // Filter options
  subdomains?: string[];
  /** Union of primary + additional subdomains (Arcola-pilot datasets) */
  allSubdomains?: string[];
  /** True when the dataset distinguishes primary vs additional subdomains */
  hasAdditionalSubdomains?: boolean;
  /** Harm categories with reported harm anywhere in the dataset */
  harmCategories?: string[];
  entities?: string[];
  intents?: string[];
  timings?: string[];
  euRisks?: string[];
  aiGoals?: string[];
  /** Subject AI-system identity (Arcola mirror): registry-normalised model
   * families / developers plus the three state labels, named-first. */
  aiModels?: string[];
  aiDevelopers?: string[];
  /** True when the dataset carries identity cells at all — gates the two
   * dimensions (on the legacy base they would be one "Not assessed" bar). */
  hasAiIdentity?: boolean;
  severityFields?: Array<{ key: string; label: string }>;
}

const MOBILE_BREAKPOINT = 640;

/**
 * Approximate how many rows ECharts will use to render a wrapped legend.
 * We can't know the exact wrap target without measuring — this errs on
 * the safe side so the grid always leaves enough room for the legend.
 */
function estimateLegendRows(items: string[], isMobile: boolean, fontSize: number): number {
  if (!items.length) return 1;
  const containerWidth = isMobile ? 360 : 1100; // conservative reference widths
  const charPx = fontSize * 0.6;
  const iconAndGap = 14 + 5 + 12; // itemWidth + label gap + itemGap
  let rows = 1;
  let used = 0;
  for (const label of items) {
    const w = label.length * charPx + iconAndGap;
    if (used + w > containerWidth && used > 0) {
      rows += 1;
      used = w;
    } else {
      used += w;
    }
  }
  return rows;
}

function niceMax(value: number): number {
  if (value <= 0) return 1;
  const rawInterval = value / 5;
  const magnitude = Math.pow(10, Math.floor(Math.log10(rawInterval)));
  const normalized = rawInterval / magnitude;
  let tickInterval: number;
  if (normalized <= 1.5) tickInterval = magnitude;
  else if (normalized <= 3.5) tickInterval = 2 * magnitude;
  else if (normalized <= 7.5) tickInterval = 5 * magnitude;
  else tickInterval = 10 * magnitude;
  return Math.ceil(value / tickInterval) * tickInterval;
}

/**
 * Default dimension per chart type, matching what the API renders when no
 * stackBy is sent. The pie included: the server slices it by domain, so the
 * "View by" pill must read "Domain" — it used to return null here, which
 * rendered the pill as "None" while the chart was in fact sliced by domain.
 */
function defaultStackBy(chartType: string): StackByDim | null {
  switch (chartType) {
    case 'incident-domain-year': return 'domain';
    case 'incident-subdomain-year': return 'subdomain';
    case 'incident-domain-subdomain': return 'subdomain';
    case 'incident-domain-pie': return 'domain';
    default: return null;
  }
}

/**
 * Whether a stackBy dimension is offered by a given chart. The horizontal
 * domain/subdomain chart always has domain on the y-axis, so stacking by
 * domain is meaningless there.
 */
function stackByOptionsFor(chartType: string): StackByDim[] {
  // 'allSubdomains' is offered everywhere 'subdomain' is, but is pruned at
  // render time for datasets without additional subdomains (where it would
  // be indistinguishable from Primary Subdomain). 'aiModel' / 'aiDeveloper'
  // are likewise pruned for datasets without identity cells.
  switch (chartType) {
    case 'incident-domain-year':
    case 'incident-subdomain-year':
      return ['domain', 'subdomain', 'allSubdomains', 'entity', 'intent', 'timing', 'aiGoal', 'aiModel', 'aiDeveloper', 'euRisk', 'highestSeverity', 'natSecImpact', 'harmCategory'];
    case 'incident-domain-subdomain':
      return ['subdomain', 'allSubdomains', 'entity', 'intent', 'timing', 'aiGoal', 'aiModel', 'aiDeveloper', 'euRisk', 'highestSeverity', 'natSecImpact', 'harmCategory'];
    case 'incident-domain-pie':
      // Pie uses the same dimension list but rebrands the control as "View by"
      // — there's no stacking; the selector picks how to slice the pie.
      return ['domain', 'subdomain', 'allSubdomains', 'entity', 'intent', 'timing', 'aiGoal', 'aiModel', 'aiDeveloper', 'euRisk', 'highestSeverity', 'natSecImpact', 'harmCategory'];
    default:
      return [];
  }
}

const STACK_BY_LABELS: Record<StackByDim, string> = {
  domain: 'Domain',
  subdomain: 'Subdomain',
  allSubdomains: 'All Subdomains',
  entity: 'Entity',
  intent: 'Intent',
  timing: 'Timing',
  aiGoal: 'AI Purpose',
  aiModel: 'AI Model Family',
  aiDeveloper: 'AI Developer',
  euRisk: 'EU AI Act Risk Tier',
  highestSeverity: 'Highest severity',
  natSecImpact: 'NatSec Overall Impact',
  harmCategory: 'Harm category',
};

/** Hover tooltips for stack-by/filter dimensions whose label isn't
 * self-explanatory. Threaded through IncidentFilterBar to the stack-by
 * menu, add-filter menu, and active chip. */
const STACK_BY_TOOLTIPS: Partial<Record<StackByDim, string>> = {
  aiModel: 'The model family of the AI system(s) the incident report names (e.g. GPT, Claude, Gemini), normalised against Arcola’s registry. The 10 most frequent named families are shown; the rest group into "Other". Kept separate: "Unidentified AI system" = the report evidences AI but does not identify it; "No AI system named" = none is mentioned; "Not assessed" = no identity was derived. An incident appears under each system it names, so totals can exceed the incident count.',
  aiDeveloper: 'Who built the AI system(s) the incident report names, normalised against Arcola’s registry. The 10 most frequent named developers are shown; the rest group into "Other". Recorded only when the report says so, so many rows are "Unidentified AI system" (kept separate from "Other"). Distinct from the AIID "Alleged developer" field. An incident appears under each developer it names, so totals can exceed the incident count.',
  euRisk: 'Risk tier as defined by the EU AI Act',
  highestSeverity: 'Highest Severity Score (in any single category)',
  natSecImpact: 'Highest NatSec Impact Score (in any single category)',
  allSubdomains: 'Primary and additional risk subdomains combined. An incident appears under each subdomain it touches, so totals can exceed the incident count.',
  harmCategory: 'Categories where the classification reports direct or indirect harm of at least Minor (2/5) severity. An incident appears under each category it harmed, so totals can exceed the incident count.',
};

/** Dataset-aware label/tooltip maps: when the dataset distinguishes primary
 * vs additional subdomains, "Subdomain" reads as "Primary Subdomain" and
 * gains an explanatory tooltip. */
function stackLabelsFor(hasAllSubdomains: boolean): Record<StackByDim, string> {
  return hasAllSubdomains
    ? { ...STACK_BY_LABELS, subdomain: 'Primary Subdomain' }
    : STACK_BY_LABELS;
}
function stackTooltipsFor(hasAllSubdomains: boolean): Partial<Record<StackByDim, string>> {
  return hasAllSubdomains
    ? { ...STACK_BY_TOOLTIPS, subdomain: 'The single best-fit subdomain from the incident’s classification. Each incident counts exactly once.' }
    : STACK_BY_TOOLTIPS;
}

// Plural labels used as the legend header (parallels the gov "Authority:" header
// shown above the swatch row in Gov Mapping charts).
const STACK_BY_LEGEND_TITLE: Record<StackByDim, string> = {
  domain: 'Domains',
  subdomain: 'Risk Subdomains',
  allSubdomains: 'Risk Subdomains (all identified)',
  entity: 'Entities',
  intent: 'Intents',
  timing: 'Timings',
  aiGoal: 'AI Purposes',
  aiModel: 'AI Model Families',
  aiDeveloper: 'AI Developers',
  euRisk: 'EU AI Act Risk Tiers',
  highestSeverity: 'Highest severity',
  natSecImpact: 'NatSec Overall Impact',
  harmCategory: 'Harm Categories',
};

/**
 * Legend notes for the MULTI-VALUED dimensions — the ones where an
 * incident is counted once per value it carries, so the series
 * deliberately total more than the incident count. Without saying so the
 * chart just looks wrong (the bars overshoot the number of incidents),
 * and the explanation was previously only reachable by hovering the
 * stack-by control. Single-valued dimensions get no note.
 */
const STACK_BY_LEGEND_NOTE: Partial<Record<StackByDim, string>> = {
  allSubdomains:
    'Each incident can be associated with more than one subdomain, so the counts total more than the number of incidents.',
  harmCategory:
    'Each incident can be associated with more than one harm category, so the counts total more than the number of incidents.',
  aiModel:
    'Top 10 named families; the rest are grouped as "Other". "Unidentified AI system" is kept separate: AI was involved but the report does not say which. Each incident can name more than one AI system, so the counts can total more than the number of incidents.',
  aiDeveloper:
    'Top 10 named developers; the rest are grouped as "Other". "Unidentified AI system" is kept separate: the report does not say who built it. Each incident can name more than one AI system, so the counts can total more than the number of incidents.',
};

export function IncidentChart({ config, apiBase, containerId, minYear, dataset }: IncidentChartProps) {
  const chartRef = useRef<HTMLDivElement>(null);
  const chartInstance = useRef<echarts.ECharts | null>(null);
  // Detaches the tap/click listeners bound by bindChartTap. Re-bound on
  // every option rebuild, so the previous binding must be torn down first.
  const tapCleanupRef = useRef<(() => void) | null>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);
  const theme = loadTheme();

  const initialStackBy = defaultStackBy(config.chartType);
  const availableStackByAll = stackByOptionsFor(config.chartType);
  const yearIsXAxis = config.chartType === 'incident-domain-year'
    || config.chartType === 'incident-subdomain-year';

  // Filter state
  const [stackBy, setStackBy] = useState<StackByDim | null>(initialStackBy);
  const [yearFilter, setYearFilter] = useState<string[]>([]);
  const [domainFilter, setDomainFilter] = useState<string[]>([]);
  const [subdomainFilter, setSubdomainFilter] = useState<string[]>([]);
  const [allSubdomainsFilter, setAllSubdomainsFilter] = useState<string[]>([]);
  const [harmCategoryFilter, setHarmCategoryFilter] = useState<string[]>([]);
  const [entityFilter, setEntityFilter] = useState<string[]>([]);
  const [intentFilter, setIntentFilter] = useState<string[]>([]);
  const [timingFilter, setTimingFilter] = useState<string[]>([]);
  const [euRiskFilter, setEuRiskFilter] = useState<string[]>([]);
  const [aiGoalFilter, setAiGoalFilter] = useState<string[]>([]);
  const [aiModelFilter, setAiModelFilter] = useState<string[]>([]);
  const [aiDeveloperFilter, setAiDeveloperFilter] = useState<string[]>([]);
  // User-controlled year floor. Layered on top of the optional `minYear`
  // prop — effective floor is max(prop, user value). Stored as a single
  // string year to fit the FilterDim 'min' contract.
  const [minYearFilter, setMinYearFilter] = useState<string[]>([]);
  const [severityFilters, setSeverityFilters] = useState<Record<string, number>>({});
  const [isMobile, setIsMobile] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(detectDarkMode());
  // Series toggled off via the custom subdomain legend.
  const [hiddenSeries, setHiddenSeries] = useState<Set<string>>(new Set());

  // View mode: 'counts' shows raw incident counts; 'proportion' normalises
  // each category (year / domain) to 100% — matches the gov ViewModeToggle.
  const [viewMode, setViewMode] = useState<ViewMode>('counts');

  // Click-to-list-modal + nested incident-detail modal
  const [listModalOpen, setListModalOpen] = useState(false);
  const [listModalTitle, setListModalTitle] = useState('');
  const [listModalFilters, setListModalFilters] = useState<ActiveFilter[]>([]);
  const [listModalItems, setListModalItems] = useState<IncidentListItem[]>([]);
  const [listModalLoading, setListModalLoading] = useState(false);
  const [detailOpen, setDetailOpen] = useState(false);
  const [detailId, setDetailId] = useState('');
  const [detailIncident, setDetailIncident] = useState<IncidentDetail | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);

  // Data state
  const [apiData, setApiData] = useState<IncidentApiResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Dropdown options
  const [yearOptions, setYearOptions] = useState<string[]>([]);
  const [domainOptions, setDomainOptions] = useState<string[]>([]);
  const [subdomainOptions, setSubdomainOptions] = useState<string[]>([]);
  const [allSubdomainsOptions, setAllSubdomainsOptions] = useState<string[]>([]);
  const [harmCategoryOptions, setHarmCategoryOptions] = useState<string[]>([]);
  // Whether the active dataset distinguishes primary vs additional
  // subdomains — gates the All Subdomains dimension and the
  // "Primary Subdomain" relabelling.
  const [hasAllSubdomains, setHasAllSubdomains] = useState(false);
  const [entityOptions, setEntityOptions] = useState<string[]>([]);
  const [intentOptions, setIntentOptions] = useState<string[]>([]);
  const [timingOptions, setTimingOptions] = useState<string[]>([]);
  const [euRiskOptions, setEuRiskOptions] = useState<string[]>([]);
  const [aiGoalOptions, setAiGoalOptions] = useState<string[]>([]);
  const [aiModelOptions, setAiModelOptions] = useState<string[]>([]);
  const [aiDeveloperOptions, setAiDeveloperOptions] = useState<string[]>([]);
  // Whether the active dataset carries AI-system identity cells — gates
  // the AI Model Family / AI Developer dimensions and filters.
  const [hasAiIdentity, setHasAiIdentity] = useState(false);
  const [severityFields, setSeverityFields] = useState<Array<{ key: string; label: string }>>([]);

  // Track wrapper width to drive mobile breakpoint for the filter bar
  useEffect(() => {
    if (!wrapperRef.current) return;
    const update = () => {
      if (wrapperRef.current) setIsMobile(wrapperRef.current.clientWidth < MOBILE_BREAKPOINT);
    };
    update();
    const ro = new ResizeObserver(update);
    ro.observe(wrapperRef.current);
    return () => ro.disconnect();
  }, []);

  // Track OS-level dark-mode preference so the chart re-renders if the user
  // toggles it. Class-based dark mode (e.g. host page adds a `.dark` class)
  // is handled separately via `inheritedColor` below.
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const media = window.matchMedia('(prefers-color-scheme: dark)');
    const update = () => setIsDarkMode(media.matches);
    if (typeof media.addEventListener === 'function') {
      media.addEventListener('change', update);
      return () => media.removeEventListener('change', update);
    }
  }, []);

  // Fetch data
  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);

    const params = new URLSearchParams();
    if (dataset) params.set('src', dataset);
    params.set('chartType', config.apiChartType);
    const effectiveMinYear = computeEffectiveMinYear(minYear, minYearFilter);
    if (effectiveMinYear !== null) params.set('minYear', String(effectiveMinYear));
    if (stackBy) params.set('stackBy', stackBy);
    // Use repeated params (subdomain=a&subdomain=b) rather than comma-joins
    // because some subdomain names contain commas.
    for (const v of yearFilter) params.append('year', v);
    for (const v of domainFilter) params.append('domain', v);
    for (const v of subdomainFilter) params.append('subdomain', v);
    for (const v of allSubdomainsFilter) params.append('allSubdomains', v);
    for (const v of harmCategoryFilter) params.append('harmCategory', v);
    for (const v of entityFilter) params.append('entity', v);
    for (const v of intentFilter) params.append('intent', v);
    for (const v of timingFilter) params.append('timing', v);
    for (const v of euRiskFilter) params.append('euRisk', v);
    for (const v of aiGoalFilter) params.append('aiGoal', v);
    for (const v of aiModelFilter) params.append('aiModel', v);
    for (const v of aiDeveloperFilter) params.append('aiDeveloper', v);

    for (const [key, val] of Object.entries(severityFilters)) {
      if (val > 0) params.set(key, String(val));
    }

    try {
      const resp = await fetch(`${apiBase}/data/incidents?${params}`);
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const data: IncidentApiResponse = await resp.json();
      setApiData(data);

      // Set dropdown options from first response
      if (data.years) setYearOptions(data.years);
      if (data.domains) setDomainOptions(data.domains);
      if (data.subdomains) setSubdomainOptions(data.subdomains);
      if (data.allSubdomains) setAllSubdomainsOptions(data.allSubdomains);
      if (data.harmCategories) setHarmCategoryOptions(data.harmCategories);
      setHasAllSubdomains(Boolean(data.hasAdditionalSubdomains));
      if (data.entities) setEntityOptions(data.entities);
      if (data.intents) setIntentOptions(data.intents);
      if (data.timings) setTimingOptions(data.timings);
      if (data.euRisks) setEuRiskOptions(data.euRisks);
      if (data.aiGoals) setAiGoalOptions(data.aiGoals);
      if (data.aiModels) setAiModelOptions(data.aiModels);
      if (data.aiDevelopers) setAiDeveloperOptions(data.aiDevelopers);
      setHasAiIdentity(Boolean(data.hasAiIdentity));
      if (data.severityFields) setSeverityFields(data.severityFields);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load data');
    } finally {
      setLoading(false);
    }
  }, [apiBase, dataset, config.apiChartType, minYear, minYearFilter, stackBy, yearFilter, domainFilter, subdomainFilter, allSubdomainsFilter, harmCategoryFilter, entityFilter, intentFilter, timingFilter, euRiskFilter, aiGoalFilter, aiModelFilter, aiDeveloperFilter, severityFilters]);

  useEffect(() => { fetchData(); }, [fetchData]);

  // Render chart
  useEffect(() => {
    if (!apiData || !chartRef.current) return;

    if (!chartInstance.current) {
      chartInstance.current = echarts.init(chartRef.current);
    }

    const chartTheme = getChartTheme(isDarkMode);
    // Read the host page's text colour so axis labels render in the right
    // colour even when the page uses class-based dark mode (where
    // `prefers-color-scheme` doesn't reflect the active theme). Mirrors
    // CategoryBarChart's approach.
    const inheritedColor =
      getComputedStyle(chartRef.current.parentElement ?? chartRef.current).color
      || chartTheme.text;
    const containerWidth = chartRef.current.clientWidth;
    const isMobile = containerWidth < MOBILE_BREAKPOINT;

    let option: echarts.EChartsOption;

    switch (config.visualType) {
      case 'vertical-bar':
        option = buildVerticalBarOption(apiData, chartTheme, inheritedColor, isMobile, containerWidth, config, hiddenSeries, viewMode);
        break;
      case 'horizontal-bar':
        option = buildHorizontalBarOption(apiData, chartTheme, inheritedColor, isMobile, containerWidth, hiddenSeries, viewMode);
        break;
      case 'pie':
        // The legend always renders as HTML below the canvas (see
        // SubdomainLegend / FlatCategoricalLegend below), so the pie
        // option suppresses ECharts' own legend and drops hidden slices.
        option = buildPieOption(apiData, chartTheme, inheritedColor, isMobile, hiddenSeries);
        break;
      default:
        return;
    }

    chartInstance.current.setOption(option, { notMerge: true });
    // The chart-height calc shrinks the wrapper div when filters reduce
    // the row count (e.g. horizontal bar going from 7 domains to 3 after
    // a severity filter). Without an explicit resize, the ECharts canvas
    // keeps its previous larger size and renders bars past the bottom of
    // the wrapper — they bled into the HTML legend area below. Forcing
    // resize() here makes ECharts pick up the new container size in the
    // same paint as the option update, instead of waiting for the
    // ResizeObserver tick.
    chartInstance.current.resize();

    // Register the bar-segment tap/click handler. setOption(notMerge: true)
    // keeps listeners attached, so bindChartTap detaches first to avoid
    // stacking handlers with stale closure state on each re-render.
    // Tooltips are configured with `show: !isMobile` (suppressing the popup
    // on mobile) but `triggerOn` is left at the default — overriding it to
    // 'none' stops ECharts binding touch handlers, which on mobile prevents
    // taps reaching this listener at all.
    tapCleanupRef.current?.();
    tapCleanupRef.current = bindChartTap(chartInstance.current, chartRef.current!, (raw) => {
      const p = raw as { componentType: string; seriesType?: string; seriesName?: string; dataIndex?: number; name?: string };
      if (p.componentType !== 'series') return;
      if (p.dataIndex === undefined) return;
      // Pie has no meaningful seriesName (ECharts synthesises a placeholder
      // when unnamed) — the slice's own name carries the filter dimension.
      const seriesName = p.seriesType === 'pie' ? '' : (p.seriesName ?? '');
      if (p.seriesType !== 'pie' && !seriesName) return;
      handleBarClickRef.current(seriesName, p.dataIndex, p.name ?? '');
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [apiData, config, hiddenSeries, viewMode, isDarkMode]);

  // Reset legend toggles when the stacking dimension changes (the series
  // names are different, so per-series visibility no longer applies).
  useEffect(() => {
    setHiddenSeries(new Set());
  }, [stackBy]);

  // Resize handler
  useEffect(() => {
    if (!chartRef.current) return;
    const ro = new ResizeObserver(() => {
      chartInstance.current?.resize();
    });
    ro.observe(chartRef.current);
    return () => ro.disconnect();
  }, []);

  // Cleanup
  useEffect(() => {
    return () => {
      tapCleanupRef.current?.();
      tapCleanupRef.current = null;
      chartInstance.current?.dispose();
      chartInstance.current = null;
    };
  }, []);

  // WHETHER a legend renders is keyed off the REQUESTED dimension, so bar
  // charts left on "Stack by: None" keep their current legend-less look.
  // The pie always gets one — it always slices by something, falling back
  // to 'domain' exactly as buildPieOption does.
  //
  // EVERY chart renders that legend as HTML in a sibling div below the
  // canvas — bars always did, and the pie now does too. ECharts' built-in
  // legend is painted *inside* the canvas, so any high-cardinality
  // dimension (allSubdomains 23, harmCategory 14, aiGoal ~90) overflowed
  // its column and covered the plot. Keeping the legend out of the canvas
  // makes that overlap structurally impossible for every stack-by value,
  // present and future — rather than special-casing the dimensions that
  // happen to be long today.
  const usesCustomLegend =
    Boolean(apiData) && (config.visualType === 'pie' || stackBy !== null);

  // WHICH dimension the legend describes comes from the DATA (the API
  // echoes it back), not the request. The two differ for the ~1s a refetch
  // is in flight, and describing the request made the legend re-group the
  // previous dimension's values — domain names briefly rendered under a
  // bogus "Domain 0" heading before the subdomain rows arrived. Keyed off
  // the data, legend and chart always flip together.
  const legendStackBy: StackByDim = apiData?.stackBy ?? stackBy ?? 'domain';
  // Base height + per-config scale (defaults to 1). Used by the "tall"
  // variants (e.g. incident-subdomain-year-tall) to extend vertical room
  // without changing width or layout behaviour.
  const chartHeight = Math.round(
    getChartHeight(config.visualType, apiData, isMobile, usesCustomLegend)
    * (config.heightScale ?? 1)
  );
  // Subdomain-valued dimensions get the domain-grouped multi-column
  // legend; everything else gets the flat wrapping one. Both render below
  // the canvas, for every visual type.
  const showCustomSubdomainLegend = usesCustomLegend && isSubdomainDim(legendStackBy);
  const showFlatCustomLegend = usesCustomLegend && !isSubdomainDim(legendStackBy);
  const supportsViewModeToggle =
    config.visualType !== 'pie' && config.chartType !== 'incident-domain-subdomain';

  // Caption stating the year floor actually in force — the `minYear` embed
  // option combined with any user-set floor. Derived rather than written
  // into the page copy, so it cannot drift if the embed's minYear changes.
  const captionMinYear = computeEffectiveMinYear(minYear, minYearFilter);
  const minYearCaption = captionMinYear !== null
    ? `Showing incidents since ${captionMinYear}`
    : '';

  // Build options for MultiSelectDropdown (value === label for free-text fields)
  const yearDropdown = useMemo(() => yearOptions.map((v) => ({ value: v, label: v })), [yearOptions]);
  const domainDropdown = useMemo(() => domainOptions.map((v) => ({ value: v, label: formatTaxonomyLabel(v) })), [domainOptions]);
  const subdomainDropdown = useMemo(() => subdomainOptions.map((v) => ({ value: v, label: formatTaxonomyLabel(v) })), [subdomainOptions]);
  const allSubdomainsDropdown = useMemo(() => allSubdomainsOptions.map((v) => ({ value: v, label: formatTaxonomyLabel(v) })), [allSubdomainsOptions]);
  const harmCategoryDropdown = useMemo(() => harmCategoryOptions.map((v) => ({ value: v, label: v })), [harmCategoryOptions]);
  const entityDropdown = useMemo(() => entityOptions.map((v) => ({ value: v, label: v })), [entityOptions]);
  const intentDropdown = useMemo(() => intentOptions.map((v) => ({ value: v, label: v })), [intentOptions]);
  const timingDropdown = useMemo(() => timingOptions.map((v) => ({ value: v, label: v })), [timingOptions]);
  const euRiskDropdown = useMemo(() => euRiskOptions.map((v) => ({ value: v, label: v })), [euRiskOptions]);
  const aiGoalDropdown = useMemo(() => aiGoalOptions.map((v) => ({ value: v, label: v })), [aiGoalOptions]);
  const aiModelDropdown = useMemo(() => aiModelOptions.map((v) => ({ value: v, label: v })), [aiModelOptions]);
  const aiDeveloperDropdown = useMemo(() => aiDeveloperOptions.map((v) => ({ value: v, label: v })), [aiDeveloperOptions]);

  // Prune the All Subdomains dimension for datasets that don't carry
  // additional subdomains, and relabel Subdomain → Primary Subdomain when
  // they do. Likewise prune the AI-system identity dimensions for
  // datasets without identity cells.
  const availableStackBy = availableStackByAll.filter((d) =>
    (hasAllSubdomains || d !== 'allSubdomains')
    && (hasAiIdentity || (d !== 'aiModel' && d !== 'aiDeveloper')));
  const stackLabels = stackLabelsFor(hasAllSubdomains);
  const stackTooltips = stackTooltipsFor(hasAllSubdomains);

  const hasActiveFilter = yearFilter.length || domainFilter.length || subdomainFilter.length
    || allSubdomainsFilter.length || harmCategoryFilter.length
    || entityFilter.length || intentFilter.length || timingFilter.length || euRiskFilter.length
    || aiGoalFilter.length || aiModelFilter.length || aiDeveloperFilter.length || minYearFilter.length
    || Object.values(severityFilters).some((v) => v > 0)
    || (initialStackBy !== null && stackBy !== initialStackBy);

  const resetFilters = () => {
    setYearFilter([]);
    setDomainFilter([]);
    setSubdomainFilter([]);
    setAllSubdomainsFilter([]);
    setHarmCategoryFilter([]);
    setEntityFilter([]);
    setIntentFilter([]);
    setTimingFilter([]);
    setEuRiskFilter([]);
    setAiGoalFilter([]);
    setAiModelFilter([]);
    setAiDeveloperFilter([]);
    setMinYearFilter([]);
    setSeverityFilters({});
    setStackBy(initialStackBy);
    setHiddenSeries(new Set());
    setViewMode('counts');
  };

  // Click on a bar segment → query the incident list filtered by:
  //   - the row label (year for vertical-bar, domain for horizontal-bar)
  //   - the series (whichever stackBy is active)
  //   - any active filters
  // Opens IncidentListModal with the filter chips up top.
  const handleBarClick = useCallback((seriesName: string, dataIndex: number, axisName: string) => {
    if (!apiData) return;

    const qs = new URLSearchParams();
    if (dataset) qs.set('src', dataset);
    qs.set('chartType', 'incident-list');
    const listEffectiveMinYear = computeEffectiveMinYear(minYear, minYearFilter);
    if (listEffectiveMinYear !== null) qs.set('minYear', String(listEffectiveMinYear));

    // Filter chips for the modal header
    const chips: ActiveFilter[] = [];

    // Row label → year or domain depending on chart orientation
    let rowLabel = axisName;
    if (config.visualType === 'pie') {
      // Pie: the slice name IS the filter value, dimension comes from
      // apiData.stackBy (domain or subdomain).
      const pieDim = apiData.stackBy ?? 'domain';
      if (rowLabel) {
        // A synthetic "Other" slice (top-N collapse) expands back into the
        // names it bundles, same as the bar-series path below.
        const members = apiData.seriesMembers?.[rowLabel];
        if (members && members.length) {
          for (const m of members) qs.append(pieDim, m);
        } else {
          qs.set(pieDim, rowLabel);
        }
        chips.push({ label: stackLabels[pieDim] ?? pieDim, values: [formatTaxonomyLabel(rowLabel)] });
      }
    } else if (config.visualType === 'horizontal-bar') {
      // axisName may be truncated; resolve original from apiData.domains
      const orig = apiData.domains?.[dataIndex];
      rowLabel = orig || axisName;
      if (rowLabel) {
        qs.set('domain', rowLabel);
        chips.push({ label: 'Domain', values: [formatTaxonomyLabel(rowLabel)] });
      }
    } else if (yearIsXAxis) {
      // vertical bar: axisName is the year
      if (rowLabel) {
        qs.set('year', rowLabel);
        chips.push({ label: 'Year', values: [rowLabel] });
      }
    }

    // Series → stack dimension value. If this series is a synthetic "Other"
    // bucket (from the top-N collapse), expand it back into the underlying
    // category values so the list modal queries the right records.
    if (stackBy && seriesName) {
      const members = apiData.seriesMembers?.[seriesName];
      if (members && members.length) {
        for (const m of members) qs.append(stackBy, m);
      } else {
        qs.append(stackBy, seriesName);
      }
      chips.push({ label: stackLabels[stackBy], values: [formatTaxonomyLabel(seriesName)] });
    }

    // Layered filters (only include the ones that aren't already pinned by
    // the click context, so we don't double-up chips). Repeated params so
    // values with commas (e.g. some subdomain names) survive transport.
    if (yearFilter.length && !qs.has('year')) {
      for (const v of yearFilter) qs.append('year', v);
      chips.push({ label: 'Year', values: [...yearFilter] });
    }
    if (domainFilter.length && !qs.has('domain')) {
      for (const v of domainFilter) qs.append('domain', v);
      chips.push({ label: 'Domain', values: domainFilter.map(formatTaxonomyLabel) });
    }
    if (subdomainFilter.length && !qs.has('subdomain')) {
      for (const v of subdomainFilter) qs.append('subdomain', v);
      chips.push({ label: stackLabels.subdomain, values: subdomainFilter.map(formatTaxonomyLabel) });
    }
    if (allSubdomainsFilter.length && !qs.has('allSubdomains')) {
      for (const v of allSubdomainsFilter) qs.append('allSubdomains', v);
      chips.push({ label: stackLabels.allSubdomains, values: allSubdomainsFilter.map(formatTaxonomyLabel) });
    }
    if (harmCategoryFilter.length && !qs.has('harmCategory')) {
      for (const v of harmCategoryFilter) qs.append('harmCategory', v);
      chips.push({ label: stackLabels.harmCategory, values: [...harmCategoryFilter] });
    }
    if (entityFilter.length && !qs.has('entity')) {
      for (const v of entityFilter) qs.append('entity', v);
      chips.push({ label: 'Entity', values: [...entityFilter] });
    }
    if (intentFilter.length && !qs.has('intent')) {
      for (const v of intentFilter) qs.append('intent', v);
      chips.push({ label: 'Intent', values: [...intentFilter] });
    }
    if (timingFilter.length && !qs.has('timing')) {
      for (const v of timingFilter) qs.append('timing', v);
      chips.push({ label: 'Timing', values: [...timingFilter] });
    }
    if (euRiskFilter.length) {
      for (const v of euRiskFilter) qs.append('euRisk', v);
      chips.push({ label: 'EU AI Act Risk Tier', values: [...euRiskFilter] });
    }
    if (aiGoalFilter.length && !qs.has('aiGoal')) {
      for (const v of aiGoalFilter) qs.append('aiGoal', v);
      chips.push({ label: 'AI Purpose', values: [...aiGoalFilter] });
    }
    if (aiModelFilter.length && !qs.has('aiModel')) {
      for (const v of aiModelFilter) qs.append('aiModel', v);
      chips.push({ label: stackLabels.aiModel, values: [...aiModelFilter] });
    }
    if (aiDeveloperFilter.length && !qs.has('aiDeveloper')) {
      for (const v of aiDeveloperFilter) qs.append('aiDeveloper', v);
      chips.push({ label: stackLabels.aiDeveloper, values: [...aiDeveloperFilter] });
    }
    for (const [key, val] of Object.entries(severityFilters)) {
      if (val > 0) qs.set(key, String(val));
    }

    const titleParts = [rowLabel, seriesName].filter(Boolean).map(formatTaxonomyLabel);
    setListModalTitle(titleParts.join(' — ') || 'Incidents');
    setListModalFilters(chips);
    setListModalOpen(true);
    setListModalLoading(true);
    setListModalItems([]);

    fetch(`${apiBase}/data/incidents?${qs}`)
      .then((r) => r.json())
      .then((json: { items?: IncidentListItem[] }) => {
        setListModalItems(json?.items ?? []);
      })
      .catch((err) => console.error('Failed to fetch incident list:', err))
      .finally(() => setListModalLoading(false));
  }, [apiData, apiBase, dataset, config.visualType, minYear, minYearFilter, stackBy, yearIsXAxis, yearFilter, domainFilter, subdomainFilter, allSubdomainsFilter, harmCategoryFilter, hasAllSubdomains, entityFilter, intentFilter, timingFilter, euRiskFilter, aiGoalFilter, aiModelFilter, aiDeveloperFilter, severityFilters]);

  // Keep a ref to the latest click handler so the ECharts listener (registered
  // in the render effect) sees up-to-date filter state without us having to
  // re-register on every filter change.
  const handleBarClickRef = useRef(handleBarClick);
  useEffect(() => { handleBarClickRef.current = handleBarClick; }, [handleBarClick]);

  const handleIncidentClick = useCallback((incidentId: string) => {
    setDetailId(incidentId);
    setDetailOpen(true);
    setDetailLoading(true);
    setDetailIncident(null);

    const qs = new URLSearchParams();
    if (dataset) qs.set('src', dataset);
    qs.set('chartType', 'incident-detail');
    qs.set('incidentId', incidentId);

    fetch(`${apiBase}/data/incidents?${qs}`)
      .then((r) => r.json())
      .then((json: { incident?: IncidentDetail }) => {
        setDetailIncident(json?.incident ?? null);
      })
      .catch((err) => console.error('Failed to fetch incident detail:', err))
      .finally(() => setDetailLoading(false));
  }, [apiBase, dataset]);

  // Register a controller for external filter control via GovCharts.applyFilters().
  useEffect(() => {
    const controller: IncidentChartController = {
      setStackBy: (v) => setStackBy(v),
      setYearFilter: (v) => setYearFilter(normalizeFilterValue(v)),
      setMinYearFilter: (v) => setMinYearFilter(normalizeFilterValue(v)),
      setDomainFilter: (v) => setDomainFilter(normalizeFilterValue(v)),
      setSubdomainFilter: (v) => setSubdomainFilter(normalizeFilterValue(v)),
      setAllSubdomainsFilter: (v) => setAllSubdomainsFilter(normalizeFilterValue(v)),
      setHarmCategoryFilter: (v) => setHarmCategoryFilter(normalizeFilterValue(v)),
      setEntityFilter: (v) => setEntityFilter(normalizeFilterValue(v)),
      setIntentFilter: (v) => setIntentFilter(normalizeFilterValue(v)),
      setTimingFilter: (v) => setTimingFilter(normalizeFilterValue(v)),
      setEuRiskFilter: (v) => setEuRiskFilter(normalizeFilterValue(v)),
      setAiGoalFilter: (v) => setAiGoalFilter(normalizeFilterValue(v)),
      setAiModelFilter: (v) => setAiModelFilter(normalizeFilterValue(v)),
      setAiDeveloperFilter: (v) => setAiDeveloperFilter(normalizeFilterValue(v)),
      setSeverityFilters: (next) => setSeverityFilters(next),
      setViewMode: (mode) => setViewMode(mode),
      resetFilters: () => {
        setYearFilter([]);
        setMinYearFilter([]);
        setDomainFilter([]);
        setSubdomainFilter([]);
        setAllSubdomainsFilter([]);
        setHarmCategoryFilter([]);
        setEntityFilter([]);
        setIntentFilter([]);
        setTimingFilter([]);
        setEuRiskFilter([]);
        setAiGoalFilter([]);
        setAiModelFilter([]);
        setAiDeveloperFilter([]);
        setSeverityFilters({});
        setStackBy(initialStackBy);
        setHiddenSeries(new Set());
        setViewMode('counts');
      },
    };
    incidentChartRegistry.set(containerId, controller);
    return () => { incidentChartRegistry.delete(containerId); };
  }, [containerId, initialStackBy]);

  // Build the dimension list for the filter bar. Year is included only when
  // year isn't the chart's x-axis (otherwise filtering by year is redundant
  // with the axis). AI Purpose and EU Risk only appear once the API has
  // surfaced values for them.
  const filterDims: FilterDim[] = [];
  if (!yearIsXAxis && yearDropdown.length > 0) {
    filterDims.push({ key: 'year', label: 'Year', options: yearDropdown, selected: yearFilter, onChange: setYearFilter });
  }
  // Year ≥ floor — applies to every chart (including those where year is on
  // the x-axis: it shifts the axis start).
  if (yearDropdown.length > 0) {
    filterDims.push({
      key: 'yearMin',
      label: 'Year',
      kind: 'min',
      options: yearDropdown,
      selected: minYearFilter,
      onChange: setMinYearFilter,
    });
  }
  filterDims.push({ key: 'domain', label: stackLabels.domain, options: domainDropdown, selected: domainFilter, onChange: setDomainFilter });
  filterDims.push({ key: 'subdomain', label: stackLabels.subdomain, options: subdomainDropdown, selected: subdomainFilter, onChange: setSubdomainFilter, tooltip: stackTooltips.subdomain });
  if (hasAllSubdomains) {
    filterDims.push({ key: 'allSubdomains', label: stackLabels.allSubdomains, options: allSubdomainsDropdown, selected: allSubdomainsFilter, onChange: setAllSubdomainsFilter, tooltip: stackTooltips.allSubdomains });
  }
  if (harmCategoryOptions.length > 0) {
    filterDims.push({ key: 'harmCategory', label: stackLabels.harmCategory, options: harmCategoryDropdown, selected: harmCategoryFilter, onChange: setHarmCategoryFilter, tooltip: stackTooltips.harmCategory });
  }
  filterDims.push({ key: 'entity', label: stackLabels.entity, options: entityDropdown, selected: entityFilter, onChange: setEntityFilter });
  filterDims.push({ key: 'intent', label: STACK_BY_LABELS.intent, options: intentDropdown, selected: intentFilter, onChange: setIntentFilter });
  filterDims.push({ key: 'timing', label: STACK_BY_LABELS.timing, options: timingDropdown, selected: timingFilter, onChange: setTimingFilter });
  if (aiGoalOptions.length > 0) {
    filterDims.push({ key: 'aiGoal', label: STACK_BY_LABELS.aiGoal, options: aiGoalDropdown, selected: aiGoalFilter, onChange: setAiGoalFilter });
  }
  if (hasAiIdentity && aiModelOptions.length > 0) {
    filterDims.push({ key: 'aiModel', label: STACK_BY_LABELS.aiModel, options: aiModelDropdown, selected: aiModelFilter, onChange: setAiModelFilter, tooltip: STACK_BY_TOOLTIPS.aiModel });
  }
  if (hasAiIdentity && aiDeveloperOptions.length > 0) {
    filterDims.push({ key: 'aiDeveloper', label: STACK_BY_LABELS.aiDeveloper, options: aiDeveloperDropdown, selected: aiDeveloperFilter, onChange: setAiDeveloperFilter, tooltip: STACK_BY_TOOLTIPS.aiDeveloper });
  }
  if (euRiskOptions.length > 0) {
    filterDims.push({ key: 'euRisk', label: STACK_BY_LABELS.euRisk, options: euRiskDropdown, selected: euRiskFilter, onChange: setEuRiskFilter, tooltip: STACK_BY_TOOLTIPS.euRisk });
  }

  return (
    <div ref={wrapperRef} style={{ fontFamily: 'system-ui, -apple-system, sans-serif', color: 'inherit' }}>
      {/* Filter bar: stack-by (or view-by for pie), add-filter menu, severity
          popover, and a chip row for active filters. */}
      <IncidentFilterBar
        availableStackBy={availableStackBy}
        stackBy={stackBy}
        onStackByChange={setStackBy}
        stackByLabels={stackLabels}
        stackByTooltips={stackTooltips}
        stackByControlLabel={config.visualType === 'pie' ? 'View by' : 'Stack by'}
        allowNoneStackBy={config.visualType !== 'pie'}
        dimensions={filterDims}
        severityFields={severityFields}
        severityFilters={severityFilters}
        onSeverityChange={setSeverityFilters}
        hasActiveFilter={Boolean(hasActiveFilter)}
        onResetAll={resetFilters}
        isMobile={isMobile}
      />

      {/* Chart — keep the canvas div permanently mounted once data has
          arrived, so the ECharts instance stays attached. Re-mounting the
          div on every filter change orphans the chart and the new render
          paints into a node that isn't in the DOM. */}
      {!apiData && loading && (
        <div style={{ padding: '40px', textAlign: 'center', color: 'var(--gc-text-muted, #6b7280)' }}>Loading...</div>
      )}
      {!apiData && error && (
        <div style={{ padding: '40px', textAlign: 'center', color: '#dc2626' }}>Error: {error}</div>
      )}
      {apiData && (
        // paddingBottom separates the legend from whatever the host page
        // stacks underneath (on the tracker pages that is the "Preset
        // filter configurations" heading, which otherwise sat right on
        // top of the legend's last row and read as part of it).
        <div style={{ position: 'relative', paddingBottom: 32 }}>
          {error && (
            <div style={{
              position: 'absolute',
              inset: 0,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              background: 'rgba(255,255,255,0.7)',
              color: '#dc2626',
              fontSize: 12,
              zIndex: 1,
            }}>
              Error: {error}
            </div>
          )}
          <div ref={chartRef} style={{ width: '100%', height: `${chartHeight}px`, overflow: 'hidden', opacity: loading ? 0.5 : 1, transition: 'opacity 0.15s' }} />
          {apiData && (supportsViewModeToggle || minYearCaption) && (
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'baseline',
              gap: 12,
              marginTop: 2,
              marginBottom: 4,
              paddingRight: 4,
            }}>
              {/* Left of the same row as the View-by control, in its muted
                  label style. States the year floor where the reader is
                  already looking at where the axis starts, instead of
                  leaving it implicit in the embed config. Empty span keeps
                  the toggle right-aligned when there is no floor. */}
              <span style={{ fontSize: 11, color: 'var(--gc-text-muted, #6b7280)', whiteSpace: 'nowrap' }}>
                {minYearCaption}
              </span>
              {supportsViewModeToggle && (
                <ViewModeToggle
                  viewMode={viewMode}
                  onViewModeChange={setViewMode}
                  isMobile={isMobile}
                  countsLabel="Incident counts"
                  // Under All Subdomains the denominator is incident-subdomain
                  // pairings (an incident weighs once per subdomain it touches),
                  // so the percentage reads as share of assignments, not share
                  // of incidents.
                  proportionLabel={stackBy === 'allSubdomains'
                    ? 'Share of subdomain assignments'
                    : stackBy === 'harmCategory'
                      ? 'Share of harm-category assignments'
                      : stackBy === 'aiModel' || stackBy === 'aiDeveloper'
                        ? 'Share of AI-system assignments'
                        : 'Proportion of reported incidents'}
                />
              )}
            </div>
          )}
          {showCustomSubdomainLegend && apiData && (
            <div>
              <LegendHeader
                title={STACK_BY_LEGEND_TITLE[legendStackBy]}
                note={STACK_BY_LEGEND_NOTE[legendStackBy]}
              />
              <SubdomainLegend
                seriesNames={
                  config.visualType === 'pie'
                    ? (apiData.data || []).map((d) => d.name)
                    : (apiData.series || []).map((s) => s.name)
                }
                hiddenSeries={hiddenSeries}
                onToggle={(names, makeVisible) => {
                  setHiddenSeries((prev) => {
                    const next = new Set(prev);
                    for (const n of names) {
                      if (makeVisible) next.delete(n);
                      else next.add(n);
                    }
                    return next;
                  });
                }}
                chartTheme={getChartTheme(detectDarkMode())}
                isMobile={isMobile}
              />
            </div>
          )}
          {showFlatCustomLegend && apiData && (
            <FlatCategoricalLegend
              title={STACK_BY_LEGEND_TITLE[legendStackBy]}
              note={STACK_BY_LEGEND_NOTE[legendStackBy]}
              seriesNames={
                config.visualType === 'pie'
                  ? (apiData.data || []).map((d) => d.name)
                  : (apiData.series || []).map((s) => s.name)
              }
              stackBy={legendStackBy}
              hiddenSeries={hiddenSeries}
              onToggle={(name) => {
                setHiddenSeries((prev) => {
                  const next = new Set(prev);
                  if (next.has(name)) next.delete(name);
                  else next.add(name);
                  return next;
                });
              }}
              chartTheme={getChartTheme(detectDarkMode())}
            />
          )}
        </div>
      )}

      <IncidentListModal
        isOpen={listModalOpen}
        onClose={() => setListModalOpen(false)}
        title={listModalTitle}
        items={listModalItems}
        loading={listModalLoading}
        onIncidentClick={handleIncidentClick}
        activeFilters={listModalFilters}
      />

      <IncidentDetailModal
        isOpen={detailOpen}
        onClose={() => setDetailOpen(false)}
        incidentId={detailId}
        incident={detailIncident}
        loading={detailLoading}
      />
    </div>
  );
}

// ============================================
// Legend header + flat legend (gov pattern)
// ============================================

/**
 * Legend heading block: title, an optional explanatory note for
 * multi-valued dimensions, then the toggle hint.
 *
 * The title is deliberately bolder and a step larger than the domain
 * group headings inside SubdomainLegend (11px/600) so the legend reads as
 * a titled block rather than one more domain group. The hint sits on its
 * own line rather than trailing the title, so the same three-part shape
 * holds whether or not a note is present.
 */
function LegendHeader({ title, note }: { title: string; note?: string }) {
  return (
    <div style={{ color: 'inherit', marginTop: 8, marginBottom: 6 }}>
      <div style={{ fontSize: 13, fontWeight: 700, lineHeight: 1.3 }}>
        {title}
      </div>
      {note && (
        <div style={{
          fontSize: 11,
          fontStyle: 'italic',
          opacity: 0.8,
          marginTop: 3,
          maxWidth: '85ch',
          lineHeight: 1.4,
        }}>
          {note}
        </div>
      )}
      <div style={{ fontSize: 10, fontStyle: 'italic', opacity: 0.75, marginTop: 3 }}>
        Click categories to toggle visibility
      </div>
    </div>
  );
}

interface FlatCategoricalLegendProps {
  title: string;
  note?: string;
  seriesNames: string[];
  stackBy: StackByDim;
  hiddenSeries: Set<string>;
  onToggle: (name: string) => void;
  chartTheme: ReturnType<typeof getChartTheme>;
}

function FlatCategoricalLegend({
  title,
  note,
  seriesNames,
  stackBy,
  hiddenSeries,
  onToggle,
  chartTheme,
}: FlatCategoricalLegendProps) {
  // Match the colour assignment used by the bars
  const subdomainsByDomain = isSubdomainDim(stackBy)
    ? buildSubdomainIndex(seriesNames)
    : new Map<string, string[]>();

  return (
    <div>
      <LegendHeader title={title} note={note} />
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12 }}>
        {seriesNames.map((name, i) => {
          const isHidden = hiddenSeries.has(name);
          const color = colorForSeries(name, stackBy, i, subdomainsByDomain);
          return (
            <div
              key={name}
              onClick={() => onToggle(name)}
              title={getLegendHoverText(name)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 5,
                cursor: 'pointer',
                opacity: isHidden ? 0.35 : 1,
                fontSize: 12,
                color: 'inherit',
                userSelect: 'none',
              }}
            >
              <span style={{
                display: 'inline-block',
                width: 14,
                height: 14,
                borderRadius: 2,
                background: color,
                flexShrink: 0,
              }} />
              {formatTaxonomyLabel(name)}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ============================================
// Chart height calculation
// ============================================

function getChartHeight(
  visualType: string,
  data: IncidentApiResponse | null,
  isMobile = false,
  usesCustomLegend = false,
): number {
  if (!data) return 400;

  // Custom HTML legends (subdomain + flat) render in sibling divs below
  // the canvas, so the chart itself only needs plot + axis space.
  if (usesCustomLegend) {
    switch (visualType) {
      // Tall enough for plot + 50px bottom (axis-name) + y-axis-name margin
      case 'vertical-bar': return 380;
      case 'horizontal-bar': {
        const rowCount = data.domains?.length || 7;
        return Math.max(300, rowCount * 60 + 80);
      }
      case 'pie': return 420;
      default: return 400;
    }
  }

  // NB: the pie never reaches here — it always uses the custom HTML
  // legend, so it returns from the branch above.
  const seriesNames = (data.series || []).map((s) => s.name);

  switch (visualType) {
    case 'vertical-bar': {
      const rows = estimateLegendRows(seriesNames, isMobile, 11);
      const plot = 320;
      const legendBlock = rows * 18 + 8;
      return Math.max(400, plot + legendBlock + 40);
    }
    case 'horizontal-bar': {
      const rowCount = data.domains?.length || 7;
      const plot = rowCount * 60;
      const rows = estimateLegendRows(seriesNames, isMobile, 10);
      const legendBlock = rows * 18 + 8;
      return Math.max(300, plot + legendBlock + 80);
    }
    case 'pie':
      return 420;
    default:
      return 400;
  }
}

// ============================================
// Vertical stacked bar (year on x; configurable stack dimension)
// ============================================

/**
 * Pick a colour for a series based on the active stackBy. Domain and
 * subdomain use the canonical palettes; everything else cycles through
 * the generic category palette so series stay distinguishable.
 */
// Sequential 1→5 ramp used for the ordinal stack-by dimensions
// (Highest severity, NatSec Overall Impact). Mirrors the severity palette
// already shipped in config/style.json so the gradient matches the
// in-app severity colouring elsewhere.
const SEVERITY_RAMP: Record<number, string> = {
  1: '#9ca3af',
  2: '#60a5fa',
  3: '#f59e0b',
  4: '#ef4444',
  5: '#b91c1c',
};

/** Dimensions whose series values are risk-subdomain labels — they share
 * the subdomain colour palette and custom-legend treatment. */
function isSubdomainDim(d: StackByDim | null | undefined): boolean {
  return d === 'subdomain' || d === 'allSubdomains';
}

function colorForSeries(
  name: string,
  stackBy: StackByDim | undefined,
  index: number,
  subdomainsByDomain: Map<string, string[]>,
): string {
  // Synthetic catch-all bucket from the top-N collapse — neutral grey
  if (name === 'Other') return '#9ca3af';
  // The three AI-system identity state labels are "no answer" buckets,
  // not categories — keep them neutral so the palette goes to named
  // systems, graded so the three stay tellable apart AND distinct from the
  // "Other" grey above (Other = small named tail; these = no answer).
  if ((stackBy === 'aiModel' || stackBy === 'aiDeveloper') && isAiIdentityStateLabel(name)) {
    if (name === AI_IDENTITY_UNIDENTIFIED) return '#6b7280';
    if (name === AI_IDENTITY_NONE_NAMED) return '#cbd5e1';
    return '#e5e7eb';
  }
  if (stackBy === 'domain') return getDomainColor(name);
  if (isSubdomainDim(stackBy)) {
    const domainNum = name.match(/^(\d+)\./)?.[1] || '0';
    const siblings = subdomainsByDomain.get(domainNum) || [];
    const idx = siblings.indexOf(name);
    return getSubdomainPaletteColor(name, idx >= 0 ? idx : 0);
  }
  if (stackBy === 'highestSeverity' || stackBy === 'natSecImpact') {
    if (name === 'Unknown') return '#cbd5e1';
    const n = parseInt(name.match(/^(\d)\s/)?.[1] || '0', 10);
    return SEVERITY_RAMP[n] ?? '#9ca3af';
  }
  return getCategoryColor(index);
}

function buildSubdomainIndex(seriesNames: string[]): Map<string, string[]> {
  const map = new Map<string, string[]>();
  for (const name of seriesNames) {
    const domainNum = name.match(/^(\d+)\./)?.[1] || '0';
    if (!map.has(domainNum)) map.set(domainNum, []);
    map.get(domainNum)!.push(name);
  }
  return map;
}

/**
 * Pick a column count for the subdomain legend based on container width.
 * Wider containers tolerate more columns; mobile collapses to a single
 * vertical list.
 */
function subdomainLegendColumnCount(containerWidth: number): number {
  if (containerWidth < 640) return 1;
  if (containerWidth < 960) return 2;
  return 3;
}

/**
 * Partition the ordered list of domain group sizes into `colCount`
 * contiguous groups, minimising the row count of the tallest column.
 * Domains stay whole — they are never split across columns.
 *
 * Brute-force search; with 7 domains and 3 columns the search space is
 * trivial (15 candidate splits), so this stays cheap to recompute on
 * every chart re-render.
 */
function partitionDomainsByMinMaxRows(domainCounts: number[], colCount: number): number[][] {
  const n = domainCounts.length;
  if (n === 0) return Array.from({ length: colCount }, () => []);
  if (colCount <= 1) return [domainCounts.map((_, i) => i)];
  if (colCount >= n) return domainCounts.map((_, i) => [i]);

  let bestPartition: number[][] = [];
  let bestMax = Infinity;

  const explore = (start: number, colsLeft: number, current: number[][]): void => {
    if (colsLeft === 1) {
      const lastGroup: number[] = [];
      for (let i = start; i < n; i++) lastGroup.push(i);
      if (!lastGroup.length) return;
      const trial = [...current, lastGroup];
      const maxRows = Math.max(
        ...trial.map((g) => g.reduce((a, i) => a + domainCounts[i], 0)),
      );
      if (maxRows < bestMax) {
        bestMax = maxRows;
        bestPartition = trial;
      }
      return;
    }
    for (let end = start + 1; end <= n - colsLeft + 1; end++) {
      const group: number[] = [];
      for (let i = start; i < end; i++) group.push(i);
      explore(end, colsLeft - 1, [...current, group]);
    }
  };

  explore(0, colCount, []);
  return bestPartition;
}

/**
 * Group series names by their domain numeric prefix, preserving the
 * canonical 1..n ordering returned by the API.
 */
function groupSeriesByDomain(seriesNames: string[]): {
  domainKeys: string[];
  byDomain: Map<string, string[]>;
} {
  const byDomain = new Map<string, string[]>();
  for (const name of seriesNames) {
    const dom = name.match(/^(\d+)\./)?.[1] || '0';
    if (!byDomain.has(dom)) byDomain.set(dom, []);
    byDomain.get(dom)!.push(name);
  }
  const domainKeys = [...byDomain.keys()].sort(
    (a, b) => parseInt(a, 10) - parseInt(b, 10),
  );
  return { domainKeys, byDomain };
}

function buildVerticalBarOption(
  data: IncidentApiResponse,
  chartTheme: ReturnType<typeof getChartTheme>,
  inheritedColor: string,
  isMobile: boolean,
  _containerWidth: number,
  _config: IncidentChartConfig,
  hiddenSeries: Set<string>,
  viewMode: ViewMode,
): echarts.EChartsOption {
  const years = data.years || [];
  const rawSeries = data.series || [];
  const stackBy = data.stackBy;
  const isProportion = viewMode === 'proportion';

  const subdomainsByDomain = isSubdomainDim(stackBy)
    ? buildSubdomainIndex(rawSeries.map((s) => s.name))
    : new Map<string, string[]>();

  // For proportion view, normalise each year's stack (visible series only)
  // to 100%. Hidden series contribute 0, so the bars stay at 100% of what
  // the user has switched on — mirrors gov ViewMode behaviour.
  const visibleTotalsPerYear = years.map((_, yi) =>
    rawSeries.reduce((sum, s) => hiddenSeries.has(s.name) ? sum : sum + (s.data[yi] || 0), 0),
  );

  const seriesData = isProportion
    ? rawSeries.map((s) => ({
        name: s.name,
        data: s.data.map((v, yi) => {
          const tot = visibleTotalsPerYear[yi];
          if (!tot || hiddenSeries.has(s.name)) return 0;
          return (v / tot) * 100;
        }),
      }))
    : rawSeries;

  const series: echarts.BarSeriesOption[] = seriesData.map((s, i) => ({
    name: s.name,
    type: 'bar',
    stack: 'total',
    data: s.data,
    itemStyle: { color: colorForSeries(s.name, stackBy, i, subdomainsByDomain) },
    // On mobile we don't show tooltips or any other hover affordance —
    // a tap should commit straight to the list modal, not flicker a
    // highlight first. `emphasis.disabled` stops ECharts firing the
    // hover state on touchstart / unfiring it on touchend, which was
    // reading as a tooltip "popping up then disappearing".
    emphasis: isMobile ? { disabled: true } : { focus: 'series' },
  }));

  // Compute max for y-axis. In proportion mode the axis is always 0-100%.
  const maxVal = isProportion
    ? 100
    : Math.max(
        ...years.map((_, yi) =>
          rawSeries.reduce((sum, s) => hiddenSeries.has(s.name) ? sum : sum + (s.data[yi] || 0), 0),
        ),
        1,
      );

  // With many stack segments the per-axis tooltip becomes a wall of text,
  // so switch to a per-segment tooltip once the chart has >10 series.
  const manySeries = rawSeries.length > 10;

  const formatValue = (n: number): string =>
    isProportion ? `${n.toFixed(1)}%` : String(Math.round(n));

  // Calendar year, for tagging the in-progress year's axis label.
  const currentYearLabel = String(new Date().getFullYear());

  // Enough bottom space for the axis ticks AND the "Year" axis name.
  // The current-year tick label is two lines ("2026" over "(to date)"),
  // so the name sits at nameGap 44 and the grid reserves room for both.
  const xAxisNameSpace = 64;
  const yAxisLabel = isProportion ? 'Proportion of Reported Incidents' : 'Incident Count';

  // Native ECharts legend is always hidden — the custom HTML legend below
  // the canvas (LegendHeader + FlatCategoricalLegend / SubdomainLegend)
  // owns visibility toggling for all stack dimensions.
  const legendOption: echarts.LegendComponentOption = {
    show: false,
    data: seriesData.map((s) => s.name),
    selected: Object.fromEntries(seriesData.map((s) => [s.name, !hiddenSeries.has(s.name)])),
  };

  const gridBottom = xAxisNameSpace;

  return {
    backgroundColor: 'transparent',
    // Widen ECharts' touch hit-radius on coarse pointers (phones/tablets).
    // Default precision misclassifies a wobbly finger tap on a thin bar
    // segment as a drag and silently drops the click — leaving the user
    // wondering why nothing happens.
    useCoarsePointer: true,
    tooltip: {
      show: !isMobile,
      trigger: manySeries ? 'item' : 'axis',
      axisPointer: isMobile ? { type: 'none' } : { type: 'shadow' },
      backgroundColor: chartTheme.tooltipBg,
      borderColor: chartTheme.tooltipBorder,
      textStyle: { color: chartTheme.tooltipText, fontSize: 12 },
      formatter: manySeries
        ? (params: any) => {
            // Per-segment tooltip (stackBy=subdomain hits this — 24
            // series exceeds the manySeries threshold). When the
            // series is a subdomain, append its canonical definition.
            const p = params as { name: string; seriesName: string; value: number; marker: string };
            return `${p.name}<br/>${p.marker}${getEchartsHoverHtml(p.seriesName, `: ${formatValue(p.value)}`)}`;
          }
        : (params: any) => {
            const arr = params as Array<{ name: string; seriesName: string; value: number; marker: string }>;
            if (!arr?.length) return '';
            const header = arr[0].name;
            const lines = arr
              .filter((p) => p.value > 0)
              .map((p) => `${p.marker}${escapeHtml(formatTaxonomyLabel(p.seriesName))}: ${formatValue(p.value)}`)
              .join('<br/>');
            return `${header}<br/>${lines}`;
          },
    },
    legend: legendOption,
    grid: {
      // Extra left padding leaves room for the rotated y-axis name
      left: isMobile ? 60 : 75,
      right: 20,
      top: 20,
      bottom: gridBottom,
      containLabel: false,
    },
    xAxis: {
      type: 'category',
      data: years,
      axisLabel: {
        color: inheritedColor,
        fontSize: isMobile ? 10 : 12,
        // The wide "(to date)" second line makes ECharts' auto-interval
        // skip alternate years; force every label while the floored axis
        // stays short, and fall back to auto for long unfloored spans.
        interval: years.length <= 15 ? 0 : 'auto',
        // The in-progress year is not a full year of data — label it
        // "(to date)" so its shorter bar isn't read as a decline.
        formatter: (value: string) =>
          value === currentYearLabel ? `${value}\n{toDate|(to date)}` : value,
        rich: {
          toDate: {
            color: inheritedColor,
            fontSize: isMobile ? 8 : 10,
            opacity: 0.7,
            align: 'center',
          },
        },
      },
      axisLine: { lineStyle: { color: chartTheme.grid } },
      axisTick: { lineStyle: { color: chartTheme.grid } },
      name: 'Year',
      nameLocation: 'middle',
      nameGap: 44,
      nameTextStyle: { color: inheritedColor, fontSize: 12, opacity: 0.7 },
    },
    yAxis: {
      type: 'value',
      max: isProportion ? 100 : niceMax(maxVal),
      axisLabel: {
        color: inheritedColor,
        fontSize: isMobile ? 10 : 12,
        formatter: (v: number) => isProportion ? `${Math.round(v)}%` : String(Math.round(v)),
      },
      splitLine: { lineStyle: { color: chartTheme.grid, type: 'dashed' } },
      name: yAxisLabel,
      nameLocation: 'middle',
      nameGap: isMobile ? 42 : 55,
      nameRotate: 90,
      nameTextStyle: { color: inheritedColor, fontSize: 12, opacity: 0.7 },
    },
    series,
    animationDuration: 400,
  };
}

// ============================================
// Horizontal stacked bar (domain/subdomain)
// ============================================

function buildHorizontalBarOption(
  data: IncidentApiResponse,
  chartTheme: ReturnType<typeof getChartTheme>,
  inheritedColor: string,
  isMobile: boolean,
  _containerWidth: number,
  hiddenSeries: Set<string>,
  viewMode: ViewMode,
): echarts.EChartsOption {
  const domains = data.domains || [];
  const rawSeries = data.series || [];
  const domainTotals = data.domainTotals || [];
  const stackBy = data.stackBy;
  const isProportion = viewMode === 'proportion';
  const showDomainTotalInTooltip = !isProportion && domainTotals.length > 0;

  const subdomainsByDomain = isSubdomainDim(stackBy)
    ? buildSubdomainIndex(rawSeries.map((s) => s.name))
    : new Map<string, string[]>();

  // Visible totals per domain row, used both for the x-axis max and for
  // normalising to 100% in proportion mode.
  const visibleDomainTotals = domains.map((_, di) =>
    rawSeries.reduce((sum, s) => hiddenSeries.has(s.name) ? sum : sum + (s.data[di] || 0), 0),
  );

  const seriesData = isProportion
    ? rawSeries.map((s) => ({
        name: s.name,
        data: s.data.map((v, di) => {
          const tot = visibleDomainTotals[di];
          if (!tot || hiddenSeries.has(s.name)) return 0;
          return (v / tot) * 100;
        }),
      }))
    : rawSeries;

  const series: echarts.BarSeriesOption[] = seriesData.map((s, i) => ({
    name: s.name,
    type: 'bar',
    stack: 'total',
    data: s.data,
    itemStyle: { color: colorForSeries(s.name, stackBy, i, subdomainsByDomain) },
    // Same mobile rule as the vertical bar — no hover affordance, taps
    // commit straight to the list modal.
    emphasis: isMobile ? { disabled: true } : { focus: 'series' },
    label: { show: false },
  }));

  const maxTotal = isProportion ? 100 : Math.max(...visibleDomainTotals, ...domainTotals.map(() => 0), 1);
  const labelWidth = isMobile ? 100 : 240;

  const manySeries = rawSeries.length > 10;
  const formatValue = (n: number): string =>
    isProportion ? `${n.toFixed(1)}%` : String(Math.round(n));

  // Wrap long domain labels onto extra lines instead of truncating —
  // "7 - AI system safety, failures, & limitations" must read in full.
  // Greedy word wrap; ECharts renders the embedded newlines natively.
  const labelMaxChars = isMobile ? 20 : 40;
  const displayLabels = domains.map((d) => {
    const words = formatTaxonomyLabel(d).split(' ');
    const lines: string[] = [];
    let line = '';
    for (const w of words) {
      if (line && line.length + w.length + 1 > labelMaxChars) {
        lines.push(line);
        line = w;
      } else {
        line = line ? line + ' ' + w : w;
      }
    }
    if (line) lines.push(line);
    return lines.join(String.fromCharCode(10));
  });

  // Enough bottom space for the axis ticks AND the "Incident Count" axis
  // name (nameGap 30 + ~14px text). Same value as the vertical bar uses.
  const xAxisNameSpace = 50;

  // Native ECharts legend always off — custom HTML legend below the canvas
  // handles category visibility for every stack dimension.
  const legendOption: echarts.LegendComponentOption = {
    show: false,
    data: seriesData.map((s) => s.name),
    selected: Object.fromEntries(seriesData.map((s) => [s.name, !hiddenSeries.has(s.name)])),
  };

  const gridBottom = xAxisNameSpace;

  return {
    backgroundColor: 'transparent',
    // Widen ECharts' touch hit-radius on coarse pointers (phones/tablets).
    // Default precision misclassifies a wobbly finger tap on a thin bar
    // segment as a drag and silently drops the click — leaving the user
    // wondering why nothing happens.
    useCoarsePointer: true,
    tooltip: {
      show: !isMobile,
      trigger: manySeries ? 'item' : 'axis',
      axisPointer: isMobile ? { type: 'none' } : { type: 'shadow' },
      backgroundColor: chartTheme.tooltipBg,
      borderColor: chartTheme.tooltipBorder,
      textStyle: { color: chartTheme.tooltipText, fontSize: 12 },
      formatter: manySeries
        ? (params: any) => {
            // Per-segment tooltip (stackBy=subdomain hits this path —
            // 24 series exceeds the manySeries threshold). When the
            // series is a subdomain, append its canonical definition.
            const p = params as { name: string; seriesName: string; value: number; marker: string; dataIndex: number };
            const fullDomain = domains[p.dataIndex] ?? p.name;
            const header = showDomainTotalInTooltip
              ? `${escapeHtml(formatTaxonomyLabel(fullDomain))} — Domain total: ${domainTotals[p.dataIndex]}`
              : escapeHtml(formatTaxonomyLabel(fullDomain));
            return `${header}<br/>${p.marker}${getEchartsHoverHtml(p.seriesName, `: ${formatValue(p.value)}`)}`;
          }
        : (params: any) => {
            const arr = params as Array<{ name: string; seriesName: string; value: number; marker: string; dataIndex: number }>;
            if (!arr?.length) return '';
            const di = arr[0].dataIndex;
            const fullDomain = domains[di] ?? arr[0].name;
            const header = showDomainTotalInTooltip
              ? `${escapeHtml(formatTaxonomyLabel(fullDomain))} — Domain total: ${domainTotals[di]}`
              : escapeHtml(formatTaxonomyLabel(fullDomain));
            const lines = arr
              .filter((p) => p.value > 0)
              .map((p) => `${p.marker}${escapeHtml(formatTaxonomyLabel(p.seriesName))}: ${formatValue(p.value)}`)
              .join('<br/>');
            return `${header}<br/>${lines}`;
          },
    },
    legend: legendOption,
    grid: {
      left: labelWidth + 20,
      right: 60,
      top: 10,
      bottom: gridBottom,
      containLabel: false,
    },
    xAxis: {
      type: 'value',
      max: isProportion ? 100 : niceMax(maxTotal),
      axisLabel: {
        color: inheritedColor,
        fontSize: isMobile ? 10 : 12,
        formatter: (v: number) => isProportion ? `${Math.round(v)}%` : String(Math.round(v)),
      },
      splitLine: { lineStyle: { color: chartTheme.grid, type: 'dashed' } },
      name: isProportion ? 'Proportion of Reported Incidents' : 'Incident Count',
      nameLocation: 'middle',
      nameGap: 30,
      nameTextStyle: { color: inheritedColor, fontSize: 12, opacity: 0.7 },
    },
    yAxis: {
      type: 'category',
      data: displayLabels,
      inverse: true,
      axisLabel: {
        color: inheritedColor,
        fontSize: isMobile ? 9 : 11,
        // Labels are pre-wrapped into <= labelMaxChars lines (displayLabels)
        // so no width/overflow truncation — the full domain name always shows.
        lineHeight: isMobile ? 11 : 14,
      },
      axisLine: { lineStyle: { color: chartTheme.grid } },
      axisTick: { show: false },
    },
    series,
    animationDuration: 400,
  };
}

// ============================================
// Pie chart (domain proportion)
// ============================================

function buildPieOption(
  data: IncidentApiResponse,
  chartTheme: ReturnType<typeof getChartTheme>,
  inheritedColor: string,
  isMobile: boolean,
  hiddenSeries: Set<string>,
): echarts.EChartsOption {
  const pieStackBy = data.stackBy ?? 'domain';
  const allNames = (data.data || []).map((d) => d.name);
  // Must use isSubdomainDim, not `=== 'subdomain'`: without the index the
  // sibling lookup in colorForSeries misses and every subdomain in a
  // domain collapses onto palette index 0 — i.e. one flat colour per
  // domain instead of the graded ramp the bar charts show.
  const subdomainsByDomain = isSubdomainDim(pieStackBy)
    ? buildSubdomainIndex(allNames)
    : new Map<string, string[]>();
  // Colour index is the slice's position in the UNFILTERED list. The
  // categorical palette is index-based, and the HTML legend indexes over
  // the full list, so using the post-filter index would repaint every
  // remaining slice the moment one was toggled off — pie and legend would
  // then disagree about which colour meant what.
  const colorIndex = new Map(allNames.map((n, i) => [n, i]));
  // The page always renders its own HTML legend, so hidden slices are
  // dropped from the pie entirely and the remaining percentages recompute.
  const pieData = (data.data || [])
    .filter((d) => !hiddenSeries.has(d.name))
    .map((d) => ({
      ...d,
      itemStyle: {
        color: colorForSeries(d.name, pieStackBy, colorIndex.get(d.name) ?? 0, subdomainsByDomain),
      },
    }));

  const total = pieData.reduce((sum, d) => sum + d.value, 0);

  // Mobile has no room for leader lines once a dimension goes past a
  // handful of categories — previously hard-coded to the subdomain pie,
  // now driven by the actual slice count so it holds for any dimension.
  const hideAllLabels = isMobile && pieData.length > 8;
  const LABEL_MIN_PCT = 1;
  const showSliceLabel = (value: number) =>
    total > 0 && (value / total) * 100 >= LABEL_MIN_PCT;

  // No built-in legend, ever. It used to sit inside the canvas next to the
  // pie, which only worked while the dimension was short: 'subdomain' got a
  // hand-tuned two-column layout, and every other dimension fell through to
  // a single column that overflowed the moment the labels were long or
  // numerous (allSubdomains was the reported case). The legend now lives in
  // HTML below the canvas for all of them, so the pie owns the full width
  // and can sit dead centre.
  const legendOption: echarts.LegendComponentOption = { show: false };
  const pieCenter: [string, string] = ['50%', '50%'];
  // Leave room outside the ring for the percentage labels and their leader
  // lines, which now radiate on all sides instead of only into the gap the
  // legend left behind.
  const pieRadius: [string, string] = isMobile ? ['30%', '58%'] : ['32%', '62%'];

  return {
    backgroundColor: 'transparent',
    // Widen ECharts' touch hit-radius on coarse pointers (phones/tablets).
    // Default precision misclassifies a wobbly finger tap on a thin bar
    // segment as a drag and silently drops the click — leaving the user
    // wondering why nothing happens.
    useCoarsePointer: true,
    tooltip: {
      show: !isMobile,
      trigger: 'item',
      backgroundColor: chartTheme.tooltipBg,
      borderColor: chartTheme.tooltipBorder,
      textStyle: { color: chartTheme.tooltipText, fontSize: 12 },
      formatter: (params: any) => {
        const p = params as { name: string; value: number; percent: number };
        return `${getEchartsHoverHtml(p.name)}<br/>Count: ${p.value}<br/>Proportion: ${p.percent.toFixed(1)}%`;
      },
    },
    legend: legendOption,
    series: [
      {
        type: 'pie',
        radius: pieRadius,
        center: pieCenter,
        // Slices thinner than the threshold carry no label — their leader
        // lines otherwise stack into an unreadable ladder down one side
        // once a dimension has many small categories. The 7-domain pie has
        // nothing under 1%, so it renders exactly as before. Hidden labels
        // lose nothing: the slice is still in the legend and its tooltip.
        data: pieData.map((d) =>
          showSliceLabel(d.value) ? d : { ...d, label: { show: false }, labelLine: { show: false } },
        ),
        label: {
          show: !hideAllLabels,
          formatter: (params: any) => {
            const pct = ((params.value / total) * 100).toFixed(1);
            return `${pct}%`;
          },
          fontSize: 11,
          color: inheritedColor,
        },
        labelLine: { show: !hideAllLabels },
        // Mobile: no hover state on slices — a tap commits straight to
        // the list modal without a flicker.
        emphasis: isMobile
          ? { disabled: true }
          : {
              itemStyle: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.3)',
              },
            },
      },
    ],
    animationDuration: 400,
  };
}

// ============================================
// Custom subdomain legend
// ============================================

interface SubdomainLegendProps {
  seriesNames: string[];
  hiddenSeries: Set<string>;
  /** Toggle visibility for a list of series. makeVisible=true reveals them. */
  onToggle: (names: string[], makeVisible: boolean) => void;
  chartTheme: ReturnType<typeof getChartTheme>;
  isMobile: boolean;
}

/**
 * Multi-column legend grouped by risk domain. Each column contains whole
 * domains (no domain is ever split across columns). Domain headers are
 * clickable and toggle visibility for every subdomain in that group.
 */
function SubdomainLegend({
  seriesNames,
  hiddenSeries,
  onToggle,
  chartTheme,
  isMobile: _isMobile,
}: SubdomainLegendProps) {
  const legendRef = useRef<HTMLDivElement>(null);
  const [width, setWidth] = useState(0);

  useEffect(() => {
    if (!legendRef.current) return;
    const update = () => {
      if (legendRef.current) setWidth(legendRef.current.clientWidth);
    };
    update();
    const ro = new ResizeObserver(update);
    ro.observe(legendRef.current);
    return () => ro.disconnect();
  }, []);

  const { domainKeys, byDomain } = useMemo(
    () => groupSeriesByDomain(seriesNames),
    [seriesNames],
  );

  const colCount = Math.min(
    subdomainLegendColumnCount(width || 1100),
    Math.max(domainKeys.length, 1),
  );

  // For the canonical 7-domain dataset, use the explicit layout:
  // D1-D4 in col 1, D5-D6 in col 2, D7 in col 3 (or D1-D4 / D5-D7
  // at 2 cols; everything in one column at 1 col). Item-count-based
  // auto-balancing picks subtly different splits when subdomain
  // counts shift after filtering, so we lock the standard view.
  const counts = domainKeys.map((k) => byDomain.get(k)!.length);
  const partition = useMemo(() => {
    if (domainKeys.length === 7) {
      if (colCount === 3) return [[0, 1, 2], [3, 4], [5, 6]];
      if (colCount === 2) return [[0, 1, 2, 3], [4, 5, 6]];
      if (colCount === 1) return [[0, 1, 2, 3, 4, 5, 6]];
    }
    return partitionDomainsByMinMaxRows(counts, colCount);
  }, [domainKeys.length, counts.join(','), colCount]);

  const swatchColor = (name: string, idxInDomain: number): string => {
    return getSubdomainPaletteColor(name, idxInDomain);
  };

  const fontSize = 11;
  const swatchSize = 12;
  const swatchGap = 6;
  const itemRowGap = 2;
  const domainGap = 10;

  return (
    <div
      ref={legendRef}
      style={{
        display: 'grid',
        gridTemplateColumns: `repeat(${colCount}, minmax(0, 1fr))`,
        gap: 16,
        marginTop: 12,
        alignItems: 'start',
        fontSize,
        color: 'inherit',
      }}
    >
      {partition.map((domainIdxList, colIdx) => (
        <div key={colIdx} style={{ display: 'flex', flexDirection: 'column', gap: domainGap }}>
          {domainIdxList.map((di) => {
            const domainNum = domainKeys[di];
            const subs = byDomain.get(domainNum) || [];
            const allHidden = subs.length > 0 && subs.every((s) => hiddenSeries.has(s));
            const fullDomainName =
              DOMAIN_ORDER.find((d) => d.startsWith(`${domainNum} `)) || `Domain ${domainNum}`;
            return (
              <div key={domainNum}>
                <button
                  type="button"
                  onClick={() => onToggle(subs, allHidden)}
                  style={{
                    display: 'block',
                    width: '100%',
                    textAlign: 'left',
                    background: 'none',
                    border: 'none',
                    padding: 0,
                    marginBottom: 4,
                    fontSize,
                    fontWeight: 600,
                    cursor: 'pointer',
                    color: 'inherit',
                    opacity: allHidden ? 0.45 : 1,
                    fontFamily: 'inherit',
                  }}
                  title={allHidden ? 'Show all subdomains in this group' : 'Hide all subdomains in this group'}
                >
                  {formatTaxonomyLabel(fullDomainName)}
                </button>
                <div style={{ display: 'flex', flexDirection: 'column', gap: itemRowGap }}>
                  {subs.map((name, i) => {
                    const isHidden = hiddenSeries.has(name);
                    const color = swatchColor(name, i);
                    return (
                      <button
                        key={name}
                        type="button"
                        onClick={() => onToggle([name], isHidden)}
                        title={getLegendHoverText(name)}
                        style={{
                          display: 'flex',
                          alignItems: 'flex-start',
                          gap: swatchGap,
                          width: '100%',
                          textAlign: 'left',
                          background: 'none',
                          border: 'none',
                          padding: '1px 0',
                          fontSize,
                          color: 'inherit',
                          opacity: isHidden ? 0.45 : 1,
                          cursor: 'pointer',
                          fontFamily: 'inherit',
                          lineHeight: 1.3,
                        }}
                      >
                        <span
                          style={{
                            display: 'inline-block',
                            width: swatchSize,
                            height: swatchSize - 2,
                            borderRadius: 2,
                            background: isHidden ? chartTheme.grid : color,
                            flexShrink: 0,
                            marginTop: 2,
                          }}
                        />
                        <span style={{ wordBreak: 'break-word', minWidth: 0, flex: 1 }}>
                          {formatTaxonomyLabel(name)}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
}
